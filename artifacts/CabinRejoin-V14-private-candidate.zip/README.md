# CabinRejoin V14

> 🛟 **Need help or found a bug?** Get support at [support.doodesch.de/cabinrejoin](https://support.doodesch.de/cabinrejoin).

Privater Teststand. Der normale Steam-Neustart nach einem Host-Absturz ist bei laufendem Hintergrundserver fehlgeschlagen. Dieser Stand behebt den Neustartpfad noch nicht. Gruppenprüfung und andere Spielphasen stehen noch aus.

1. Entpacke das ZIP vollständig.
2. Schließe das Spiel und öffne `Installieren.bat`.
3. Starte das Spiel über Steam für eine neue Runde.

Unveränderte Installationen von V12, V13 und r6 lassen sich aktualisieren. Ersetzte Moddateien werden gesichert. Geänderte oder verknüpfte Dateien blockieren die Installation.

Wenn das Hauptmenü verfügbar ist, nutze zum Wiederverbinden die Karte `Rejoin`.

`Quit Game` des Hosts beendet die Runde. Bei einem Host-Absturz bleibt der Hintergrundserver für Rejoin bestehen.
