local refs=require('bound_refs')
local gt_scheduler = require("gt_scheduler")
local M = {}
local map_phase = require("map_phase")
local standing = require("standing")
local remaining_input = require("remaining_input")
local interaction_phase = require("interaction_phase")
local holding_inspect = require("holding_inspect")
local extended_card_restore = require("extended_card_restore")
local extended_intro_restore = require("extended_intro_restore")
local extended_phase_codec = require("extended_phase_codec")
local extended_engine = require("extended_engine_adapters")
local active
local MARKER = "CabinRejoinClient_v11"
local intro_visual = require("intro_visual_restore")
local flashlight = require("flashlight_restore")
local room_visual = require("room_visual_restore")
local wall_visual = require("room_wall_restore")
local SHADES = {"SM_Lamp_chandelier_shade_C", "SM_Lamp_chandelier_shade_A", "SM_Lamp_chandelier_shade_D", "SM_Lamp_chandelier_shade_B", "SM_Lamp_chandelier_shade_E"}
local MODES = {radio_seated=true, world_choice=true, action_resume=true, radio_resume=true, car_intro=true, card_inspect=true, holding_inspect = true, room_map = true, seated = true, active_turn = true, standing = true, intro = true, table_inspect = true, common = true}

local function valid(object) return object ~= nil and object:IsValid() end
local function address(object) return valid(object) and object:GetAddress() or 0 end
local function near(a, b) return math.abs(a - b) < 0.01 end
local function vector_equal(a, b) return near(a.X, b.X) and near(a.Y, b.Y) and near(a.Z, b.Z) end
local function rotation_equal(a, b)
    local function same(x, y) return math.abs((x - y + 180) % 360 - 180) < 0.01 end
    return same(a.Pitch, b.Pitch) and same(a.Yaw, b.Yaw) and same(a.Roll, b.Roll)
end

function M.key(object)
    assert(valid(object), "object key requires a valid object")
    local key = object:GetFullName():match("%.([^%.]+)$")
    assert(key and key:match("^[%w_]+$"), "object instance name cannot be encoded")
    return key
end

local function emit(s, level, message)
    if s.options.log then
        local ok, cause = pcall(s.options.log, level, message)
        if ok then return end
        print("[CabinRejoin] error: client log callback cause=" .. tostring(cause) .. "\n")
    end
    print("[CabinRejoin] " .. level .. ": " .. message .. "\n")
end

local function wait_reason(s, job, message)
    local now = os.time()
    job.repeats = job.reason == message and job.repeats + 1 or 1
    if job.reason ~= message or now - (job.last_log or 0) >= 60 then
        emit(s, "info", "client id=" .. job.id .. " " .. message .. " observations=" .. job.repeats)
        job.last_log = now
    end
    job.reason = message
end

local function finite(value)
    assert(type(value) == "number" and value == value and math.abs(value) < math.huge, "snapshot number is not finite")
    return value
end

local function integer(value)
    finite(value)
    assert(value % 1 == 0 and value >= 0, "snapshot count/id is not a nonnegative integer")
    return value
end

local function hex(value)
    assert(type(value) == "string" and #value > 0 and not value:find("%z"), "snapshot string is empty or contains NUL")
    return (value:gsub(".", function(byte) return string.format("%02X", string.byte(byte)) end))
end

local function unhex(value)
    assert(#value > 0 and #value % 2 == 0 and value:match("^[0-9A-F]+$"), "snapshot string encoding differs")
    local decoded = value:gsub("..", function(byte) return string.char(tonumber(byte, 16)) end)
    assert(not decoded:find("%z"), "snapshot string contains NUL")
    return decoded
end

local function codec(snapshot, source)
    local tokens, cursor = {}, 1
    local reading = source ~= nil
    if reading then
        assert(not source:find("||", 1, true) and source:sub(-1) ~= "|", "snapshot has empty fields")
        for token in source:gmatch("[^|]+") do tokens[#tokens + 1] = token end
        snapshot = {}
    end
    local function field(value)
        if reading then local token = assert(tokens[cursor], "snapshot field missing at " .. cursor); cursor = cursor + 1; return token end
        tokens[#tokens + 1] = value
    end
    local function number(value)
        if reading then return finite(tonumber(field())) end
        field(string.format("%.17g", finite(value)))
        return value
    end
    local function count(value)
        local result = integer(number(value))
        if reading then assert(result <= #tokens, "snapshot count exceeds available fields") end
        return result
    end
    local function flag(value)
        if reading then local n = number(); assert(n == 0 or n == 1, "snapshot flag differs"); return n == 1 end
        assert(type(value) == "boolean", "snapshot flag is not boolean"); field(value and "1" or "0"); return value
    end
    local function text(value)
        if reading then return unhex(field()) end
        field(hex(value)); return value
    end
    local function vector(value)
        value = value or {}; return {X = number(value.X), Y = number(value.Y), Z = number(value.Z)}
    end
    local function rotation(value)
        value = value or {}; return {Pitch = number(value.Pitch), Yaw = number(value.Yaw), Roll = number(value.Roll)}
    end
    local version = count(10); assert(version == 10, "snapshot schema differs")
    snapshot.pawn, snapshot.mode, snapshot.chair = text(snapshot.pawn), text(snapshot.mode), text(snapshot.chair)
    assert(snapshot.pawn == "owner" and (snapshot.chair == "-" or snapshot.chair:match("^[%w_]+$")), "snapshot owner/chair key differs")
    assert(MODES[snapshot.mode], "snapshot mode differs")
    snapshot.turn = flag(snapshot.turn)
    local cards = count(reading and nil or #(snapshot.cards or {}))
    snapshot.cards = snapshot.cards or {}
    for index = 1, cards do snapshot.cards[index] = text(snapshot.cards[index]) end
    snapshot.rotation = rotation(snapshot.rotation)
    local has_map = flag(reading and nil or snapshot.room_map ~= nil)
    assert(has_map == (snapshot.mode == "room_map"), "snapshot room Map mode/data differs")
    if has_map then
        local map = snapshot.room_map or {}; snapshot.room_map = map
        map.board, map.map, map.card, map.card_class = text(map.board), text(map.map), text(map.card), text(map.card_class)
        for _, key in ipairs({map.board, map.map, map.card}) do assert(key:match("^[%w_]+$"), "snapshot Map actor key differs") end
        map.generation, map.turn_index = integer(number(map.generation)), integer(number(map.turn_index))
        assert(map.generation > 0 and snapshot.turn, "snapshot Map generation/current turn differs")
        map.location, map.rotation = vector(map.location), rotation(map.rotation)
        map.rotation_basis, map.rotation_active = number(map.rotation_basis), flag(map.rotation_active)
        map.card_type, map.card_status = count(map.card_type), count(map.card_status)
        assert(map.card_type == 0 and map.card_status == 4, "snapshot current Map card differs from Room/4")
        map.card_owner = text(map.card_owner)
        assert(map.card_owner == "owner" or map.card_owner == "-", "snapshot Map card owner differs")
        map.card_holding = flag(map.card_holding)
        map.detector = text(map.detector)
        assert(map.detector == "-" or map.detector:match("^[%w_]+$"), "snapshot Map detector key differs")
        map.activity=map.activity or {}
        for _,name in ipairs({"pawn_halted","board_halted","special_halted","graveyard_open","in_animation"}) do
            map.activity[name]=flag(map.activity[name])
        end
        local port_count = count(reading and nil or #(map.ports or {})); map.ports = map.ports or {}
        for index = 1, port_count do map.ports[index] = integer(number(map.ports[index])) end
    end
    local has_holding = flag(reading and nil or snapshot.holding_inspect ~= nil)
    assert(has_holding==(snapshot.mode=="holding_inspect"),"snapshot Holding mode/data differs")
    if has_holding then
        local h=snapshot.holding_inspect or {}; snapshot.holding_inspect=h
        h.board,h.card,h.card_class,h.epoch=text(h.board),text(h.card),text(h.card_class),text(h.epoch)
        h.generation,h.turn_index,h.hand_matches=integer(number(h.generation)),integer(number(h.turn_index)),integer(number(h.hand_matches))
        h.card_type,h.card_status=count(h.card_type),count(h.card_status)
        h.card_owner,h.holding,h.room_card_disable=text(h.card_owner),flag(h.holding),flag(h.room_card_disable)
        h.location,h.rotation=vector(h.location),rotation(h.rotation)
        h.activity=h.activity or {}
        for _,name in ipairs({"pawn_halted","board_halted","special_halted","graveyard_open","in_animation"}) do
            h.activity[name]=flag(h.activity[name])
        end
        assert(snapshot.turn,"Holding inspect snapshot has no current turn")
        local validation={id=1,fingerprint="codec"}
        holding_inspect.contract(h,validation,validation)
    end
    extended_phase_codec.visit(snapshot,reading,{flag=flag,text=text,count=count,number=number,vector=vector,rotation=rotation})
    interaction_phase.visit(snapshot,reading,{boolean=flag,text=text,count=count})
    remaining_input.visit(snapshot,reading,{flag=flag,text=text,count=count,number=number,vector=vector,rotation=rotation})
    local has_world = flag(reading and nil or snapshot.world ~= nil)
    if has_world then
        local world = snapshot.world or {}; snapshot.world = world
        world.level_name = text(world.level_name)
        assert(world.level_name:match("^[%w_]+$"), "snapshot current level name differs")
        intro_visual.visit(world, reading, {flag=flag, text=text})
        room_visual.visit(world, reading, {flag=flag, text=text, vector=vector, rotation=rotation})
        wall_visual.visit(world, reading, {flag=flag, text=text, count=count, vector=vector, rotation=rotation})
        local streams = count(reading and nil or #(world.streams or {})); world.streams = world.streams or {}
        for index = 1, streams do
            local row = world.streams[index] or {}; world.streams[index] = row
            row.name, row.loaded, row.visible = text(row.name), flag(row.loaded), flag(row.visible)
            assert(row.name:match("^[%w_]+$"), "snapshot stream name differs")
        end
        local has_lamp = flag(reading and nil or world.lamp ~= nil)
        if has_lamp then
            local lamp = world.lamp or {}; world.lamp = lamp
            lamp.intensity, lamp.visible, lamp.on = number(lamp.intensity), flag(lamp.visible), flag(lamp.on)
            assert(lamp.intensity >= 0, "snapshot light intensity is negative")
            lamp.emissives = lamp.emissives or {}
            for index = 1, #SHADES do lamp.emissives[index] = number(lamp.emissives[index]) end
        end
        local chairs = count(reading and nil or #(world.chairs or {})); world.chairs = world.chairs or {}
        for index = 1, chairs do
            local row = world.chairs[index] or {}; world.chairs[index] = row
            row.chair = text(row.chair)
            assert(row.chair:match("^[%w_]+$"), "snapshot visual chair key differs")
            row.mesh, row.attach, row.collision = vector(row.mesh), vector(row.attach), count(row.collision)
            assert(row.collision <= 3, "snapshot collision enum differs")
            row.holder_visible = flag(row.holder_visible)
            local physical = count(reading and nil or #(row.cards or {})); row.cards = row.cards or {}
            for slot = 1, physical do
                local card = row.cards[slot] or {}; row.cards[slot] = card
                card.class, card.visible = text(card.class), flag(card.visible)
            end
        end
    end
    if reading then assert(cursor == #tokens + 1, "snapshot has trailing fields"); return snapshot end
    return table.concat(tokens, "|")
end

function M.encode(snapshot, id)
    assert(integer(id) > 0 and math.type(id) == "integer", "snapshot id must be an exact positive Lua integer")
    local body = codec(snapshot)
    local chunks, packets = {}, {}
    for first = 1, #body, 800 do chunks[#chunks + 1] = body:sub(first, first + 799) end
    for index, chunk in ipairs(chunks) do
        local packet = table.concat({MARKER, tostring(id), index, #chunks, chunk}, "|")
        assert(#packet < 1024, "snapshot FName exceeds transport envelope")
        packets[index] = packet
    end
    return packets
end

function M.fingerprint(snapshot) return codec(snapshot) end
function M.decode(source) return codec(nil, source) end

local function capture(pawn)
    local position = pawn:K2_GetActorLocation()
    local result = {turn = pawn.IsCurrentTurn, chair = address(pawn.Chair), cards = {}, physical = {}, position = {X=position.X,Y=position.Y,Z=position.Z}}
    pawn.CurrentCards:ForEach(function(index, parameter)
        local card = parameter:get(); assert(valid(card), "current ordered card class is invalid index=" .. index)
        result.cards[index] = card:GetAddress()
    end)
    pawn.CurrentCardsObjects:ForEach(function(index, parameter)
        local card = parameter:get(); assert(valid(card), "current physical card is invalid index=" .. index)
        result.physical[index] = card:GetAddress()
    end)
    result.card_count, result.physical_count = pawn.CurrentCards:GetArrayNum(), pawn.CurrentCardsObjects:GetArrayNum()
    return result
end

local function unchanged(pawn, before)
    local after = capture(pawn)
    assert(after.turn == before.turn and after.chair == before.chair, "restore changed current turn/chair")
    assert(vector_equal(after.position, before.position), "restore changed current pawn position")
    assert(after.card_count == before.card_count and after.physical_count == before.physical_count, "restore changed current card counts")
    for index, value in pairs(before.cards) do assert(after.cards[index] == value, "restore changed ordered card class index=" .. index) end
    for index, value in pairs(before.physical) do assert(after.physical[index] == value, "restore changed ordered physical card index=" .. index) end
end

local function matching_cards(pawn, wanted)
    if pawn.CurrentCards:GetArrayNum() ~= #wanted then return false end
    local matches = true
    pawn.CurrentCards:ForEach(function(index, parameter)
        local card = parameter:get()
        if not valid(card) or card:GetFullName() ~= wanted[index] then matches = false end
    end)
    return matches
end

local function pawn_at_chair(key)
    local found
    for _, pawn in ipairs(FindAllOf("Cabin_Player_C") or {}) do
        if valid(pawn) and valid(pawn.RootComponent) and valid(pawn.Chair) and M.key(pawn.Chair) == key then
            assert(not found, "ambiguous snapshot occupied chair key=" .. key); found = pawn
        end
    end
    return found
end

local function prepare_streams(s, job, pawn, world)
    if not world then return true end
    local library = StaticFindObject("/Script/Engine.Default__GameplayStatics")
    assert(valid(library), "GameplayStatics missing for local stream restore")
    if not job.streams then
        local rows = {}
        for _, row in ipairs(world.streams) do
            assert(not row.visible or row.loaded, "visible authority stream must be loaded="..row.name)
            local level = library:GetStreamingLevel(pawn, FName(row.name))
            if not valid(level) then return false, "waiting for original stream object="..row.name end
            assert(level:GetWorldAssetPackageFName():ToString():match("([^/]+)$") == row.name, "resolved original stream package differs="..row.name)
            rows[#rows+1] = {level=level, wanted=row}
        end
        job.streams = rows
    end
    for _, item in ipairs(job.streams) do
        local level, row = item.level, item.wanted
        assert(valid(level), "original stream ended during local restore="..row.name)
        if level:IsLevelLoaded() ~= row.loaded or level:IsLevelVisible() ~= row.visible then
            if not item.attempted then
                item.attempted = true
                emit(s, "info", "client id="..job.id.." stream requested name="..row.name.." loaded="..tostring(row.loaded).." visible="..tostring(row.visible).."; actual completion pending")
                level:SetShouldBeVisible(row.visible)
                level:SetShouldBeLoaded(row.loaded)
            end
            return false, "waiting for actual stream completion="..row.name
        elseif item.attempted and not item.confirmed then
            item.confirmed = true
            emit(s, "info", "client id="..job.id.." stream completion confirmed name="..row.name)
        end
    end
    return true
end

local function prepare_world(pawn, world)
    local prepared = {rows = {}}
    if not world then return prepared end
    local intro, intro_cause = intro_visual.prepare(pawn, world, M.key)
    if not intro then return nil, intro_cause end
    prepared.intro = intro
    local room, room_cause = room_visual.prepare(pawn, world, M.key)
    if not room then return nil, room_cause end
    prepared.room = room
    local wall, wall_cause = wall_visual.prepare(pawn, world)
    if not wall then return nil, wall_cause end
    prepared.wall = wall
    prepared.lighting = FindFirstOf("UpdateLighting_BP_C")
    if not valid(prepared.lighting) then return nil, "waiting for original lighting coordinator" end
    local library = StaticFindObject("/Script/Engine.Default__GameplayStatics")
    assert(valid(library), "GameplayStatics missing")
    for _, row in ipairs(world.streams) do
        local level = library:GetStreamingLevel(pawn, FName(row.name))
        if not valid(level) or level:IsLevelLoaded() ~= row.loaded or level:IsLevelVisible() ~= row.visible then return nil, "waiting for original stream state=" .. row.name end
    end
    if world.lamp then
        prepared.lamp = FindFirstOf("DiningRoomLight_BP_C")
        if not valid(prepared.lamp) or not valid(prepared.lamp.PointLight) then return nil, "waiting for original dining light" end
        prepared.materials = {}
        for index, name in ipairs(SHADES) do
            local component = prepared.lamp[name]
            if not valid(component) then return nil, "waiting for original light component=" .. name end
            local material = component:GetMaterial(0)
            if not valid(material) then return nil, "waiting for original light material=" .. name end
            prepared.materials[index] = material
        end
    end
    local seen = {}
    for _, row in ipairs(world.chairs) do
        local actor = pawn_at_chair(row.chair)
        if not actor then return nil, "waiting for original occupied visual chair=" .. row.chair end
        assert(not seen[actor:GetAddress()], "duplicate snapshot visual pawn"); seen[actor:GetAddress()] = true
        local chair = actor.Chair
        if not valid(chair.Chair) or not valid(chair.AttachPlayer) or not valid(chair.PlayerCards) then return nil, "waiting for original chair components=" .. row.chair end
        if actor.CurrentCardsObjects:GetArrayNum() ~= #row.cards then return nil, "waiting for original physical hand count=" .. row.chair end
        local cards, matches = {}, true
        actor.CurrentCardsObjects:ForEach(function(index, parameter)
            local card = parameter:get()
            if not valid(card) or not valid(card.RootComponent) or card:GetClass():GetFullName() ~= row.cards[index].class then matches = false
            else cards[index] = card end
        end)
        if not matches then return nil, "waiting for original ordered physical hand=" .. row.chair end
        prepared.rows[#prepared.rows + 1] = {actor = actor, chair = chair, cards = cards, row = row}
    end
    return prepared
end

local function restore_common(pc, pawn)
    local previous = pc.PlayerCharacter
    local old_hud = valid(previous) and previous.CabinHud_WBP or nil
    local gi = FindFirstOf("CabinAdvanceFriendsGameInstance_C")
    assert(valid(gi), "local game instance missing")
    pc.PlayerCharacter = pawn; pawn.CabinPlayerController = pc; pawn.GameInstance = gi
    assert(address(pc.PlayerCharacter) == pawn:GetAddress() and address(pawn.CabinPlayerController) == pc:GetAddress() and address(pawn.GameInstance) == gi:GetAddress(), "local reference assignment not acknowledged")
    pawn:SetActors()
    pc:LoadGameplayVariables()
    local hud = pawn.CabinHud_WBP
    if not valid(hud) or address(hud.PlayerCharacter) ~= pawn:GetAddress() then
        local factory = StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary")
        local class = StaticFindObject("/Game/CabinGameContent/HUD/CabinHUD_W.CabinHUD_W_C")
        assert(valid(factory) and valid(class), "HUD factory/class missing")
        hud = factory:Create(pawn, class, pc); assert(valid(hud), "HUD creation returned invalid object")
        pawn.CabinHud_WBP = hud
    end
    if not hud:IsInViewport() then hud:AddToViewport(0) end
    assert(address(hud.PlayerCharacter) == pawn:GetAddress() and address(hud:GetOwningPlayer()) == pc:GetAddress() and hud:IsInViewport(), "HUD ownership/viewport not acknowledged")
    if valid(old_hud) and old_hud:GetAddress() ~= hud:GetAddress() then
        assert(address(old_hud:GetOwningPlayer()) == pc:GetAddress(), "previous HUD belongs to another player")
        old_hud:RemoveFromParent(); assert(not old_hud:IsInViewport(), "previous HUD removal not acknowledged")
    end
    return hud
end

local function restore_seated(pc, pawn, wanted, restoring_holding)
    local camera = pawn.Camera
    assert(valid(camera) and valid(pawn.Chair) and address(pawn.Chair.PlayerCharacter) == pawn:GetAddress(), "settled seat camera/chair mapping differs")
    assert(not pawn.IsInTableCamInspect and not pawn.JournalOpen and (not pawn.IsInTurn or (restoring_holding and (wanted.mode=="holding_inspect" or wanted.mode=="card_inspect" or wanted.mode=="action_resume" or wanted.mode=="radio_resume" or wanted.mode=="radio_seated" or wanted.mode=="world_choice"))), "settled seat camera cannot replace active inspection/journal/turn phase")
    local local_base = pawn.BasedMovement
    assert(valid(local_base.MovementBase), "settled seat local movement base missing")
    assert(local_base.bRelativeRotation, "settled seat local relative rotation mode missing")
    local math_library = StaticFindObject("/Script/Engine.Default__KismetMathLibrary")
    assert(valid(math_library), "settled seat rotation math library missing")
    -- The owning client does not receive ReplicatedBasedMovement (COND_SimulatedOnly).
    local base_transform = local_base.MovementBase:GetSocketTransform(local_base.BoneName, 0)
    local relative = math_library:InverseTransformRotation(base_transform, wanted.rotation)
    local base_target = {Pitch = finite(relative.Pitch), Yaw = finite(relative.Yaw), Roll = finite(relative.Roll)}
    assert(rotation_equal(math_library:TransformRotation(base_transform, base_target), wanted.rotation), "settled seat local base rotation roundtrip differs")
    pawn.bUseControllerRotationYaw = false; camera.bUsePawnControlRotation = false
    pawn.BasedMovement.Rotation = base_target
    assert(rotation_equal(pawn.BasedMovement.Rotation, base_target), "initial seat based rotation write not acknowledged")
    assert(pawn:K2_SetActorRotation(wanted.rotation, true) == true, "initial seat body rotation setter rejected")
    assert(rotation_equal(pawn:K2_GetActorRotation(), wanted.rotation), "initial seat body rotation not acknowledged")
    camera:K2_SetRelativeLocation({X = 7, Y = 0, Z = -35.5}, false, {}, true)
    camera:K2_SetRelativeRotation({Pitch = -25.211215019226074, Yaw = -180, Roll = 0}, false, {}, true)
    local arm = pawn.CamFwd_SpringArm
    assert(valid(arm), "settled seat spring arm missing")
    local rotation = arm.RelativeRotation
    arm:K2_SetRelativeRotation({Pitch = rotation.Pitch, Yaw = rotation.Yaw, Roll = 0}, false, {}, true)
    local view = camera:K2_GetComponentRotation()
    pc:SetControlRotation(view); assert(rotation_equal(pc:GetControlRotation(), view), "seat control rotation not acknowledged")
    camera.bUsePawnControlRotation = true
    if address(pc:GetViewTarget()) ~= pawn:GetAddress() then pc:SetViewTargetWithBlend(pawn, 0, 0, 0, false) end
    assert(address(pc:GetViewTarget()) == pawn:GetAddress(), "seat view target not acknowledged")
    local clamp_view = camera:K2_GetComponentRotation()
    pawn:ClampCameraFunction(80, -50, 140, -140)
    local manager = pc.PlayerCameraManager
    assert(valid(manager) and near(manager.ViewYawMin, clamp_view.Yaw - 140) and near(manager.ViewYawMax, clamp_view.Yaw + 140), "seat camera clamp not acknowledged")
    assert(vector_equal(camera.RelativeLocation, {X = 7, Y = 0, Z = -35.5}) and camera.bUsePawnControlRotation and not pawn.bUseControllerRotationYaw, "seat camera flags/location not acknowledged")
    local fields = {DisableMovement = true, DisableAxisYAW = false, DisableAxisPITCH = false, DisableInteract = false, DisableFlashlight = true}
    for name, value in pairs(fields) do pawn[name] = value; assert(pawn[name] == value, "seat input flag not acknowledged=" .. name) end
    pawn.Chair:EnableInput(pc)
    assert(valid(pawn.Chair.InputComponent), "seat input registration not acknowledged")
    pawn:HideSelfHead_C(false)
    for _, name in ipairs({"Head", "Cosmetic", "SkeletalMeshhair"}) do
        assert(valid(pawn[name]) and not pawn[name]:IsVisible(), "owner head visibility not acknowledged component=" .. name)
    end
    pawn.BasedMovement.Rotation = base_target
    assert(rotation_equal(pawn.BasedMovement.Rotation, base_target), "seat based rotation write not acknowledged")
    assert(pawn:K2_SetActorRotation(wanted.rotation, true) == true, "seat body rotation setter rejected")
    assert(rotation_equal(pawn:K2_GetActorRotation(), wanted.rotation), "seat body rotation not acknowledged")
end

local function restore_active_turn(pc, pawn, wanted, hud)
    local board = pawn.GameBoard
    assert(wanted.turn and pawn.IsCurrentTurn and valid(board) and address(board.CurrentPlayerTurn)==pawn:GetAddress(), "active turn no longer belongs to retained owner")
    assert(not pawn.GameHalted and not board.HaltGame and not board.SpecialEventHalt and not board.GraveyardOpen and not pawn.InAnimation and not pawn.TTurnTransition, "active turn local presentation is blocked by current original phase")
    restore_seated(pc, pawn, wanted)
    local capsule = pawn.CapsuleComponent:K2_GetComponentRotation()
    local target = {Pitch=-50,Yaw=capsule.Yaw,Roll=capsule.Roll}
    pc:SetControlRotation(target)
    assert(rotation_equal(pc:GetControlRotation(), target), "active turn control view not acknowledged")
    for _, name in ipairs({"DisableMovement","DisableAxisYAW","DisableAxisPITCH","DisableInteract","DisableFlashlight"}) do
        pawn[name] = true
        assert(pawn[name] == true, "active turn input flag not acknowledged="..name)
    end
    pawn.IsInTurn, pawn.TTurnTransition = true, false
    pc.bShowMouseCursor = true
    board:EnableInput(pc)
    assert(valid(board.InputComponent) and pc.bShowMouseCursor and pawn.IsInTurn and not pawn.TTurnTransition, "active turn local input registration/phase not acknowledged")
    hud:ToggleCrosshairVisibility_E(false)
    assert(valid(hud.CrosshairOverlay) and hud.CrosshairOverlay:GetVisibility()==2, "active turn crosshair visibility not acknowledged")
    local layout = StaticFindObject("/Script/UMG.Default__WidgetLayoutLibrary")
    assert(valid(layout), "original viewport layout library missing")
    local viewport = layout:GetViewportSize(pawn)
    assert(viewport.X>0 and viewport.Y>0, "original active turn viewport size unavailable")
    pc:SetMouseLocation(math.floor(viewport.X/2), math.floor(viewport.Y/2))
end

local function actor_by_key(class, key, pawn)
    local found
    for _, actor in ipairs(FindAllOf(class) or {}) do
        if valid(actor) and not actor:IsActorBeingDestroyed() and M.key(actor)==key
            and address(actor:GetWorld())==address(pawn:GetWorld()) then
            assert(not found,"ambiguous current Map actor key=" .. key)
            found=actor
        end
    end
    return found
end

local function card_module(wanted)
    return wanted.mode=="holding_inspect" and holding_inspect or extended_card_restore
end
local function prepare_holding(pc,pawn,wanted,token,current_token)
    local h=assert(wanted.holding_inspect or wanted.card_inspect,"current Inspect snapshot missing")
    local board=actor_by_key("GameBoard_BP_C",h.board,pawn)
    if not board then return nil,"waiting for current Holding Board key" end
    local card,blocker=refs.resolve_card(pawn,board,h.card,h.card_status)
    if not card then return nil,blocker end
    local c={pc=pc,pawn=pawn,board=board,card=card,snapshot=h,
        key=refs.card_context_key(pawn,board,M.key),token=token,current_token=current_token}
    c.make_transform,c.transform_matches=extended_engine.make_transform,extended_engine.transform_matches
    local ready,cause=card_module(wanted).ready(c,false)
    if not ready then return nil,cause end
    return c
end

local function prepare_intro(pc,pawn,wanted,token,current_token)
    local h=assert(wanted.car_intro,"current Intro snapshot missing")
    local car,seat,blocker=refs.resolve_intro(pawn,FindAllOf("EndGameCar_BP_C") or {},h.seat,h.car_class)
    if not car then return nil,blocker end
    local scoped_key=function(v)
        if address(v)==address(car) then return 'intro_car' end
        if address(v)==address(seat) then return h.seat end
        return M.key(v)
    end
    local c={pc=pc,pawn=pawn,car=car,seat=seat,snapshot=h,key=scoped_key,token=token,current_token=current_token,
        server_time=function() return extended_engine.server_time(pawn) end,animation_position=extended_engine.animation_position,
        invariants=function() return capture(pawn) end,assert_invariants=function(a) unchanged(pawn,a) end}
    local ready,cause=extended_intro_restore.ready(c,false)
    if not ready then return nil,cause end
    return c
end

local function prepare_original_input(pc,pawn,wanted,job,s)
    local intent=assert(wanted.original_input,"original input snapshot missing")
    local board=actor_by_key(intent.phase_class,intent.phase_key,pawn)
    if not board then return nil,"waiting for current original input Board key" end
    local context={pc=pc,pawn=pawn,intent=intent,key=M.key,token=job.control_token,
        current_token=function() return s.options.token_for_job(pc,job.id) end,
        current_intent=function() return wanted.original_input end,
        log=function(level,message) emit(s,level,message) end,
        invariants=function() return capture(pawn) end,assert_invariants=function(a) unchanged(pawn,a) end}
    context.phase_matches=function()
        if not valid(board) or board:IsActorBeingDestroyed() or address(board:GetWorld())~=address(pawn:GetWorld())
            or board:GetClass():GetFullName():match("([^%.]+)$")~=intent.phase_class then
            return nil,"waiting for exact current original input Board/world" end
        local matches=0
        board.PlayerOrder:ForEach(function(_,p) if address(p:get())==pawn:GetAddress() then matches=matches+1 end end)
        if matches~=1 then return nil,"waiting for current input Board roster count="..matches end
        if address(pawn.GameBoard)~=address(board) then return nil,"waiting for original SetActors input Board binding" end
        if not valid(pawn.Mesh) or not valid(pawn.CapsuleComponent)
            or address(pawn.Mesh:GetAttachParent())~=address(pawn.CapsuleComponent) then
            return nil,"waiting for original normal-view mesh attachment; current special view is unresolved"
        end
        return true
    end
    context.reset_normal_view=function()
        pawn.JournalOpen,pawn.IsInTableCamInspect=false,false
        if valid(pawn.Chair) then
            restore_seated(pc,pawn,wanted,true)
        else
            local ordinary={id=job.id,snapshot={mode="standing",chair="-",turn=wanted.turn,cards=wanted.cards,rotation=wanted.rotation},
                control_token=job.control_token}
            standing.restore(ordinary,pc,pawn,context.current_token())
        end
        return true
    end
    return context
end

local function prepare_interaction(pc,pawn,wanted,job,s)
    local row=interaction_phase.contract(wanted.interaction_phase)
    local board=actor_by_key("GameBoard_BP_C",row.board,pawn)
    local family=row.kind=="radio" and "IntroRadio_BP_C" or row.kind=="neighbor" and "TheNeighbor_BP_C" or "ThiefTable_BP_C"
    if not board then return nil,"waiting for exact original interaction Board" end
    local member_maps={}
    local actor,blocker=refs.unique(FindAllOf(family) or {},function(candidate)
        if address(candidate:GetWorld())~=address(pawn:GetWorld()) then return false end
        if row.kind=="radio" then return row.actor=="radio" end
        if row.kind=="neighbor" and address(candidate.SpecificPlayer)~=address(pawn) then return false end
        local resolved={};local addresses={}
        for _,item in ipairs(row.items) do
            local object
            if row.kind=="neighbor" then object=candidate[item.key]
            else
                object=refs.unique(FindAllOf(item.class) or {},function(v)
                    return address(v:GetWorld())==address(pawn:GetWorld()) and address(v.ThiefTable)==address(candidate)
                        and (item.class~="ThiefChoiceCard_BP_C" or v.CardType==item.card_type) and refs.pose_matches(v,item.pose)
                end,"Thief member "..item.key)
            end
            if not valid(object) or object:IsActorBeingDestroyed() or addresses[address(object)] then return false end
            addresses[address(object)]=true;resolved[item.key]=object
        end
        member_maps[address(candidate)]=resolved
        return true
    end,"current "..row.kind.." actor/members")
    if not actor then return nil,blocker end
    local members=member_maps[address(actor)] or {}
    local scoped_key=function(v)
        if address(v)==address(actor) then return row.actor end
        for name,object in pairs(members) do if address(v)==address(object) then return name end end
        return M.key(v)
    end
    local c={pc=pc,pawn=pawn,board=board,actor=actor,items=members,snapshot=row,key=scoped_key,text=map_text,token=job.control_token,
        current_token=function() return s.options.token_for_job(pc,job.id) end,
        invariants=function() return capture(pawn) end,assert_invariants=function(a) unchanged(pawn,a) end}
    c.reset_normal_view=function()
        pawn.JournalOpen,pawn.IsInTableCamInspect=false,false
        if row.stance=="seated" then restore_seated(pc,pawn,wanted,true)
        else
            local ordinary={id=job.id,snapshot={mode="standing",chair=wanted.chair,turn=wanted.turn,cards=wanted.cards,rotation=wanted.rotation},control_token=job.control_token}
            standing.restore(ordinary,pc,pawn,c.current_token())
        end
        return true
    end
    local ready,cause=interaction_phase.ready(c,false)
    if not ready then return nil,cause end
    return c
end

local function prepare_room_map(pc,pawn,wanted,token)
    local row=assert(wanted.room_map,"current Map snapshot missing")
    assert(type(token)=="table" and token.generation==row.generation,"Map snapshot/current control generation differs")
    local board=actor_by_key("GameBoard_BP_C",row.board,pawn)
    local map=actor_by_key("CardMapLayout_BP_C",row.map,pawn)
    if not board or not map then return nil,"waiting for current keyed Board/Map replication" end
    local card=map.CurrentCard
    if not map.HasCard or address(map.CurrentPlayer)~=pawn:GetAddress() or not valid(card)
        or address(board.Card)~=address(card) or card:GetClass():GetFullName()~=row.card_class then
        return nil,"waiting for current replicated Map/Card/owner binding"
    end

    local detector=map["As Map Detector BP"]
    if (row.detector=="-" and valid(detector)) or (row.detector~="-" and (not valid(detector) or M.key(detector)~=row.detector)) then
        return nil,"waiting for current replicated Map detector binding"
    end
    if valid(detector) and (detector:IsActorBeingDestroyed() or address(detector:GetWorld())~=address(pawn:GetWorld())) then
        return nil,"waiting for current live same-world Map detector"
    end
    if address(board.CurrentPlayerTurn)~=pawn:GetAddress()
        or board.PlayerTurn~=row.turn_index or not valid(board.Card) or address(board.Card.CardLayout)~=map:GetAddress() then
        return nil,"waiting for current Board/CardLayout/Turn binding"
    end
    if board.GameEndTime or card.CardType~=row.card_type or card.Status~=row.card_status
        or address(map["Card Class"])~=address(card.CardClass) or card.IsHolding~=row.card_holding then
        return nil,"waiting for current original Map card state/class"
    end
    local expected_owner=row.card_owner=="owner" and pawn:GetAddress() or 0
    if address(card.CurrentOwnedPlayer)~=expected_owner then return nil,"waiting for current Map card owner replication" end
    local ports_match=card.OpenPorts:GetArrayNum()==#row.ports
    card.OpenPorts:ForEach(function(index,value) if value:get()~=row.ports[index] then ports_match=false end end)
    if not ports_match then return nil,"waiting for current Map card OpenPorts replication" end
    if not vector_equal(card:K2_GetActorLocation(),row.location) or not rotation_equal(card:K2_GetActorRotation(),row.rotation)
        or not near(map.CurrentCardROT,row.rotation_basis) then
        return nil,"waiting for current authoritative Map card pose/rotation basis"
    end
    if row.rotation_active then return nil,"waiting for fresh Authority Map rotation timeline completion" end
    if row.activity.special_halted then return nil,"waiting for current Authority special-event phase completion" end
    if row.activity.graveyard_open then return nil,"waiting for current Authority graveyard phase completion" end
    if row.activity.in_animation then return nil,"waiting for current Authority owner animation completion" end
    if not valid(map.Rotate_Card) or map.Rotate_Card:IsPlaying() then return nil,"waiting for current local Map rotation timeline" end
    if not map:IsActorTickEnabled() then return nil,"waiting for original Map tick availability" end
    local context={pc=pc,pawn=pawn,board=board,map=map,
        gameplay_statics=StaticFindObject("/Script/Engine.Default__GameplayStatics"),
        same_world=function(a,b) return address(a:GetWorld())~=0 and address(a:GetWorld())==address(b:GetWorld()) end,
        world_id=function(actor) return address(actor:GetWorld()) end}
    context.confirm_current=function(_,observed)
        return {phase="room_map",current=true,source="current token-bound Authority Map schema3 readback",
            round_key=tostring(row.generation),world=observed.world,pawn=observed.pawn,board=observed.board,
            map=observed.map,card=observed.card,turn_index=observed.turn_index,rotation_active=row.rotation_active,
            card_pose_matches=vector_equal(context.map.CurrentCard:K2_GetActorLocation(),row.location)
                and rotation_equal(context.map.CurrentCard:K2_GetActorRotation(),row.rotation)}
    end
    return context
end

local function restore_active_map_local_flags(context)
    local pawn,hud=context.pawn,context.pawn.CabinHud_WBP
    for _,name in ipairs({"DisableMovement","DisableAxisYAW","DisableAxisPITCH","DisableInteract","DisableFlashlight"}) do
        pawn[name]=true
        assert(pawn[name]==true,"original Map active input flag not acknowledged=" .. name)
    end
    pawn.IsInTurn,pawn.TTurnTransition=true,false
    assert(pawn.IsInTurn and not pawn.TTurnTransition,"original Map active local turn flags not acknowledged")
    hud:ToggleCrosshairVisibility_E(false)
    assert(valid(hud.CrosshairOverlay) and hud.CrosshairOverlay:GetVisibility()==2,"original Map crosshair visibility not acknowledged")
end

local function ack(s,job,receipt)
    job.status,job.receipt="confirmed",receipt
    emit(s,receipt.complete and "info" or "warn","client local receipt id=" .. job.id .. " mode=" .. receipt.mode
        .. "; complete=" .. tostring(receipt.complete) .. "; server acknowledgement pending")
    for _,gap in ipairs(receipt.gaps) do emit(s,"warn","client id=" .. job.id .. " gap=" .. gap) end
    if s.options.on_ack then
        local delivered,cause=pcall(s.options.on_ack,receipt)
        if not delivered then emit(s,"error","client acknowledgement callback id=" .. job.id .. " cause=" .. tostring(cause))
        else emit(s,"info","client acknowledgement callback returned id=" .. job.id .. "; server delivery unconfirmed") end
    end
end

local function map_text(source)
    local library=StaticFindObject("/Script/Engine.Default__KismetTextLibrary")
    assert(valid(library),"original Map text library unavailable")
    local text=library:Conv_StringToText(source)
    assert(type(text)=="userdata" and text:type()=="FText" and text:ToString()==source,
        "original Map label FText conversion/readback differs")
    return text
end

local function finish_holding(s,job)
    local pc=job.pc
    if not valid(pc) or pc:IsActorBeingDestroyed() then job.status="ended"; emit(s,"info","Holding controller ended id="..job.id); return end
    local pawn=pc.Pawn
    if not valid(pawn) or pawn:IsActorBeingDestroyed() then job.status="ended"; emit(s,"info","Holding pawn ended id="..job.id); return end
    local c,cause=prepare_holding(pc,pawn,job.snapshot,job.control_token,function() return s.options.token_for_job(pc,job.id) end)
    if not c then wait_reason(s,job,cause); return end
    local observed,blocker=card_module(job.snapshot).finish(c,job.holding_presentation)
    if not observed then wait_reason(s,job,blocker); return end
    job.holding_receipt.local_confirmed,job.holding_receipt.complete=true,#job.holding_receipt.gaps==0
    job.holding_receipt.camera_receipt="destination_observed"
    job.holding_receipt.input_receipt=observed.input_receipt
    job.holding_receipt[job.snapshot.mode]=observed
    ack(s,job,job.holding_receipt)
end

local function finish_intro(s,job)
    local pc=job.pc
    if not valid(pc) or pc:IsActorBeingDestroyed() then job.status="ended"; emit(s,"info","Intro controller ended id="..job.id); return end
    local pawn=pc.Pawn
    if not valid(pawn) or pawn:IsActorBeingDestroyed() then job.status="ended"; emit(s,"info","Intro pawn ended id="..job.id); return end
    local c,cause=prepare_intro(pc,pawn,job.snapshot,job.control_token,function() return s.options.token_for_job(pc,job.id) end)
    if not c then wait_reason(s,job,cause); return end
    local observed,blocker=extended_intro_restore.finish(c,job.intro_presentation)
    if not observed then wait_reason(s,job,blocker); return end
    job.intro_receipt.local_confirmed,job.intro_receipt.complete=true,#job.intro_receipt.gaps==0
    job.intro_receipt.camera_receipt="current_intro_observed"
    job.intro_receipt.input_receipt=observed.input_receipt
    job.intro_receipt.car_intro=observed
    ack(s,job,job.intro_receipt)
end

local function finish_room_map(s,job)
    local pc=job.pc
    if not valid(pc) or pc:IsActorBeingDestroyed() then
        job.status="ended"; emit(s,"info","client Map blend controller ended id=" .. job.id); return
    end
    local pawn=pc.Pawn
    if not valid(pawn) or pawn:IsActorBeingDestroyed() then
        job.status="ended"; emit(s,"info","client Map blend owner ended id=" .. job.id); return
    end
    if address(pawn)~=job.map_pawn or address(pawn.Controller)~=pc:GetAddress()
        or address(pc.AcknowledgedPawn)~=pawn:GetAddress() or not pawn:IsLocallyControlled()
        or pawn.IsCurrentTurn~=job.snapshot.turn or not matching_cards(pawn,job.snapshot.cards) then
        wait_reason(s,job,"waiting for current retained Map owner/hand/turn after blend"); return
    end
    local context,cause=prepare_room_map(pc,pawn,job.snapshot,job.control_token)
    if not context then wait_reason(s,job,cause); return end
    local checked,blocker=map_phase.ready(context)
    if not checked then wait_reason(s,job,blocker); return end
    if address(pc:GetViewTarget())~=context.map:GetAddress() then wait_reason(s,job,"waiting for original Map camera blend acknowledgement"); return end
    local presented,presentation_cause=map_phase.presentation_ready(context)
    if not presented then wait_reason(s,job,presentation_cause); return end
    local receipt=job.map_receipt
    receipt.camera_receipt="destination_observed"
    receipt.local_confirmed=true
    receipt.complete=#receipt.gaps==0
    ack(s,job,receipt)
end

local function apply_world(prepared, world, log)
    if not world then return end
    intro_visual.apply(prepared.intro, log)
    room_visual.apply(prepared.room, log)
    wall_visual.apply(prepared.wall, log)
    prepared.lighting.LevelName = FName(world.level_name)
    assert(prepared.lighting.LevelName:ToString() == world.level_name, "local lighting level name not acknowledged")
    for _, item in ipairs(prepared.rows) do
        local chair, row = item.chair, item.row
        local before = capture(item.actor)
        chair.Chair:SetCollisionEnabled(row.collision)
        chair.Chair:K2_SetRelativeLocation(row.mesh, false, {}, true)
        chair.AttachPlayer:K2_SetRelativeLocation(row.attach, false, {}, true)
        chair.PlayerCards:SetVisibility(row.holder_visible, true)
        for slot, card in ipairs(item.cards) do card.RootComponent:SetVisibility(row.cards[slot].visible, true) end
        assert(chair.Chair:GetCollisionEnabled() == row.collision and vector_equal(chair.Chair.RelativeLocation, row.mesh) and vector_equal(chair.AttachPlayer.RelativeLocation, row.attach), "visual chair component restore not acknowledged")
        assert(chair.PlayerCards:IsVisible() == row.holder_visible, "holder visibility not acknowledged")
        for slot, card in ipairs(item.cards) do assert(card.RootComponent:IsVisible() == row.cards[slot].visible, "physical card visibility not acknowledged slot=" .. slot) end
        unchanged(item.actor, before)
    end
    if world.lamp then
        local lamp, wanted = prepared.lamp, world.lamp
        lamp.PointLight:SetIntensity(wanted.intensity); lamp.PointLight:SetVisibility(wanted.visible, false); lamp.LightOn = wanted.on
        assert(near(lamp.PointLight.Intensity, wanted.intensity) and lamp.PointLight:IsVisible() == wanted.visible and lamp.LightOn == wanted.on, "dining light restore not acknowledged")
        for index, material in ipairs(prepared.materials) do
            material:SetScalarParameterValue(FName("LightsEmissive"), wanted.emissives[index])
            assert(near(material:K2_GetScalarParameterValue(FName("LightsEmissive")), wanted.emissives[index]), "shade emissive not acknowledged index=" .. index)
        end
    end
end

local function attempt(s, job)
    if job.status == "intro_pending" then finish_intro(s,job); return end
    if job.status == "holding_pending" then finish_holding(s,job); return end
    if job.status == "map_blend_pending" then finish_room_map(s,job); return end
    if job.status ~= "pending" then return end
    local pc, wanted = job.pc, job.snapshot
    if not valid(pc) or pc:IsActorBeingDestroyed() then job.status = "ended"; emit(s, "info", "client id=" .. job.id .. " controller ended before restore"); return end
    if not pc:IsLocalController() or pc:GetLocalRole() ~= 2 then wait_reason(s, job, "waiting for original remote-owned local controller"); return end
    local pawn = pc.Pawn
    if not valid(pawn) or not valid(pawn.RootComponent) or pawn:IsActorBeingDestroyed() then wait_reason(s, job, "waiting for assigned retained pawn replication"); return end
    if not pawn:IsLocallyControlled() or address(pawn.Controller) ~= pc:GetAddress() or address(pc.AcknowledgedPawn) ~= pawn:GetAddress() then wait_reason(s, job, "waiting for original retained ownership acknowledgement"); return end
    if (wanted.chair == "-" and valid(pawn.Chair)) or (wanted.chair ~= "-" and (not valid(pawn.Chair) or M.key(pawn.Chair) ~= wanted.chair)) then wait_reason(s, job, "waiting for assigned chair replication"); return end
    if pawn.IsCurrentTurn ~= wanted.turn or not matching_cards(pawn, wanted.cards) then wait_reason(s, job, "waiting for current authoritative ordered hand/turn snapshot"); return end
    local physical_ready = true
    pawn.CurrentCardsObjects:ForEach(function(_, parameter)
        if not valid(parameter:get()) then physical_ready = false end
    end)
    if not physical_ready then wait_reason(s, job, "waiting for current physical card actor replication"); return end
    local cause
    local interaction_context
    if wanted.mode=="radio_seated" or wanted.mode=="world_choice" then
        interaction_context,cause=prepare_interaction(pc,pawn,wanted,job,s)
        if not interaction_context then wait_reason(s,job,cause);return end
    end
    local flashlight_context, flashlight_ready_cause = flashlight.prepare(pc, pawn, wanted.mode, interaction_context)
    if not flashlight_context then wait_reason(s, job, flashlight_ready_cause); return end
    local streams_ready, stream_cause = prepare_streams(s, job, pawn, wanted.world)
    if not streams_ready then wait_reason(s, job, stream_cause); return end
    local world
    world, cause = prepare_world(pawn, wanted.world)
    if not world then wait_reason(s, job, cause); return end
    local input_context
    if wanted.mode=="action_resume" or wanted.mode=="radio_resume" then
        input_context,cause=prepare_original_input(pc,pawn,wanted,job,s)
        if not input_context then wait_reason(s,job,cause); return end
    end
    local intro_context
    if wanted.mode=="car_intro" then
        intro_context,cause=prepare_intro(pc,pawn,wanted,job.control_token,function() return s.options.token_for_job(pc,job.id) end)
        if not intro_context then wait_reason(s,job,cause); return end
    end
    local holding_context
    if (wanted.mode=="holding_inspect" or wanted.mode=="card_inspect") then
        holding_context,cause=prepare_holding(pc,pawn,wanted,job.control_token,function() return s.options.token_for_job(pc,job.id) end)
        if not holding_context then wait_reason(s,job,cause); return end
    end
    local map_context
    if wanted.mode=="room_map" then
        map_context,cause=prepare_room_map(pc,pawn,wanted,job.control_token)
        if not map_context then wait_reason(s,job,cause); return end
    end
    if wanted.mode == "standing" then
        local current_token = s.options.token_for_job and s.options.token_for_job(pc, job.id)
        local ready, blocker = standing.ready(pc, pawn, job, current_token)
        if not ready then wait_reason(s, job, blocker); return end
    end
    local before = capture(pawn)
    job.status = "attempted"
    emit(s, "info", "client restore attempted id=" .. job.id .. " mode=" .. wanted.mode .. " same retained pawn")
    local hud = restore_common(pc, pawn)
    unchanged(pawn, before)
    local gaps = {}
    if not wanted.world then gaps[#gaps + 1] = "authority world snapshot was not supplied" end
    if wanted.mode == "seated" then
        restore_seated(pc, pawn, wanted)
        pawn:DisableOwnCards_OC(true)
        pawn.CurrentCardsObjects:ForEach(function(index, parameter)
            local card = parameter:get()
            assert(valid(card) and card.DisableInteraction == true, "seated original card interaction lock not acknowledged slot=" .. index)
        end)
    elseif wanted.mode == "active_turn" then restore_active_turn(pc, pawn, wanted, hud)
    elseif (wanted.mode == "holding_inspect" or wanted.mode=="card_inspect") then
        restore_seated(pc,pawn,wanted,true)
        local capsule=pawn.CapsuleComponent:K2_GetComponentRotation()
        pc:SetControlRotation({Pitch=-50,Yaw=capsule.Yaw,Roll=capsule.Roll})
        for _,name in ipairs({"DisableMovement","DisableAxisYAW","DisableAxisPITCH","DisableInteract","DisableFlashlight"}) do
            pawn[name]=true; assert(pawn[name],"Holding active local input flag not acknowledged="..name)
        end
        hud:ToggleCrosshairVisibility_E(false)
        holding_context.log=function(level,message) emit(s,level,message) end
        holding_context.name,holding_context.text=function(v) return FName(v) end,map_text
        local presented,blocker=card_module(wanted).restore(holding_context)
        assert(presented,"Holding local restore failed: "..tostring(type(blocker)=="table" and blocker.error or blocker))
        job.holding_presentation=presented
    elseif wanted.mode=="car_intro" then
        intro_context.log=function(level,message) emit(s,level,message) end
        intro_context.name=function(v) return FName(v) end
        local shown,blocker=extended_intro_restore.restore(intro_context)
        assert(shown,"original Intro local restore failed: "..tostring(blocker))
        job.intro_presentation=shown
    elseif wanted.mode=="radio_seated" or wanted.mode=="world_choice" then
        local shown,blocker=interaction_phase.restore(interaction_context)
        assert(shown,"current original interaction restore failed: "..tostring(blocker))
        job.interaction_context,job.interaction_receipt=interaction_context,shown
    elseif wanted.mode=="action_resume" or wanted.mode=="radio_resume" then
        local presented,blocker=remaining_input.restore(input_context)
        assert(presented,"original input local restore failed: "..tostring(type(blocker)=="table" and blocker.cause or blocker))
        job.original_input_context,job.original_input_receipt=input_context,presented
    elseif wanted.mode == "standing" then
        job.standing_receipt = standing.restore(job, pc, pawn, s.options.token_for_job(pc, job.id))
    elseif wanted.mode == "room_map" then
        map_context.log=function(level,message) emit(s,level,message) end
        map_context.name=function(v) return FName(v) end
        map_context.text=map_text
        local prepared,prepare_cause=map_phase.ready(map_context)
        assert(prepared,"original Map local setup blocked: " .. tostring(prepare_cause))
        restore_active_map_local_flags(map_context)
        local map_receipt,blocker=map_phase.restore(map_context)
        assert(map_receipt,"original Map presentation failed: " .. tostring(type(blocker)=="table" and blocker.error or blocker))
        job.map_presentation=map_receipt
    else gaps[#gaps + 1] = "current " .. wanted.mode .. " camera/input/transition phase has no retained owner snapshot" end
    apply_world(world, wanted.world, function(level, message) emit(s, level, "client id=" .. job.id .. " " .. message) end)
    local flashlight_receipt, flashlight_cause = flashlight.restore(pc, pawn, wanted.mode,
        function(level, message) emit(s, level, "client id=" .. job.id .. " " .. message) end, flashlight_context,
        job.interaction_context, job.interaction_receipt)
    if not flashlight_receipt then gaps[#gaps + 1] = "flashlight presentation skipped: " .. flashlight_cause end
    job.flashlight_presentation = flashlight_receipt
    unchanged(pawn, before)
    assert(address(pc.Pawn) == pawn:GetAddress() and address(pawn.Controller) == pc:GetAddress() and address(pc.AcknowledgedPawn) == pawn:GetAddress(), "retained ownership changed during local restore")
    local receipt = {id = job.id, pc = pc, pawn = pawn, hud = hud, mode = wanted.mode, snapshot = wanted,
        control_token = job.control_token, standing = job.standing_receipt, local_confirmed = true, complete = #gaps == 0, gaps = gaps, server_acknowledged = false}
    if (wanted.mode=="holding_inspect" or wanted.mode=="card_inspect") then
        receipt.local_confirmed,receipt.complete=false,false
        receipt.input_receipt="incomplete"; receipt.camera_receipt="inspect_pp_pending"
        job.status,job.holding_receipt="holding_pending",receipt
        return
    end
    if wanted.mode=="car_intro" then
        receipt.local_confirmed,receipt.complete=false,false
        receipt.input_receipt="incomplete"; receipt.camera_receipt="current_intro_pending"
        job.status,job.intro_receipt="intro_pending",receipt
        return
    end
    if wanted.mode=="room_map" then
        receipt.local_confirmed,receipt.complete=false,false
        receipt.input_receipt="incomplete"
        receipt.camera_receipt="blend_pending"
        job.status,job.map_receipt,job.map_pawn="map_blend_pending",receipt,pawn:GetAddress()
        emit(s,"info","client Map presentation registered id=" .. job.id .. "; original blend/current readback pending")
        return
    end
    if job.interaction_receipt then
        local ready,blocker=interaction_phase.finish(job.interaction_context,job.interaction_receipt)
        assert(ready,"current original interaction completion failed: "..tostring(blocker))
        receipt.interaction_phase=ready
    end
    if job.original_input_receipt then
        local ready,blocker=remaining_input.finish(job.original_input_context,job.original_input_receipt)
        assert(ready,"original input local finish failed: "..tostring(blocker))
        receipt.original_input=ready
        receipt.input_receipt=ready.input_receipt
    end
    ack(s,job,receipt)
end

function M.restore(pc, snapshot, id)
    assert(active and active.running, "client receiver is not started")
    assert(integer(id) > 0 and math.type(id) == "integer" and valid(pc), "restore id/controller differs")
    local source = codec(snapshot)
    local checked = codec(nil, source)
    local key = pc:GetAddress()
    local previous = active.jobs[key]
    if previous and id <= previous.id then return false, "snapshot id already observed; no replay" end
    if previous and previous.source == source and previous.status ~= "pending" then return false, "same snapshot already attempted; changed causal evidence required" end
    local token
    if active.options.token_for_job then
        token = assert(active.options.token_for_job(pc, id), "snapshot job has no current control token")
    end
    if checked.mode=="room_map" then assert(type(token)=="table" and token.generation==checked.room_map.generation,"Map snapshot is not bound to current metadata generation") end
    if checked.mode=="holding_inspect" or checked.mode=="card_inspect" or checked.mode=="car_intro"
        or checked.mode=="action_resume" or checked.mode=="radio_resume" or checked.mode=="radio_seated" or checked.mode=="world_choice" then
        assert(type(token)=="table" and token.id==id and token.fingerprint==source,"phase snapshot is not bound to current metadata fingerprint")
    end
    active.jobs[key] = {pc = pc, snapshot = checked, source = source, id = id, status = "pending", repeats = 0, control_token = token}
    emit(active, "info", "client snapshot queued id=" .. id .. "; ownership/readback pending")
    return true, "queued"
end

local function receive(s, pc, text, payload)
    assert(text == "" and #payload < 1024, "client snapshot envelope differs")
    assert(valid(pc) and pc:IsLocalController() and pc:GetLocalRole() == 2, "snapshot target is not an owning remote client")
    local id, index, count, chunk = payload:match("^" .. MARKER .. "|(%d+)|(%d+)|(%d+)|(.+)$")
    assert(id and index and count and chunk, "snapshot packet envelope is malformed")
    id, index, count = tonumber(id), tonumber(index), tonumber(count)
    assert(integer(id) > 0 and math.type(id) == "integer" and integer(index) >= 1 and integer(count) >= index and #chunk <= 800, "snapshot packet indices differ")
    local key = pc:GetAddress()
    local previous = s.jobs[key]
    if previous and id <= previous.id then wait_reason(s, previous, "duplicate/stale snapshot skipped; no replay"); return end
    local assembly = s.assemblies[key]
    if not assembly or id > assembly.id then assembly = {id = id, count = count, parts = {}, received = 0}; s.assemblies[key] = assembly end
    if id < assembly.id then return end
    assert(assembly.count == count, "snapshot packet count changed for same id")
    if assembly.parts[index] then assert(assembly.parts[index] == chunk, "snapshot duplicate packet content differs"); return end
    assembly.parts[index], assembly.received = chunk, assembly.received + 1
    if assembly.received ~= count then return end
    local source = table.concat(assembly.parts)
    local snapshot = codec(nil, source)
    if s.options.bind_snapshot then
        local bound, cause = s.options.bind_snapshot(pc, id, source)
        assert(bound, "snapshot body binding failed cause=" .. tostring(cause))
    end
    local queued, cause = M.restore(pc, snapshot, id)
    assert(queued, "assembled snapshot queue failed cause=" .. tostring(cause))
    s.assemblies[key] = nil
    emit(s, "info", "client snapshot received id=" .. id .. " packets=" .. count .. "; client restore pending")
end

function M.start(options)
    assert(not active, "client module already started; use a fresh module instance after stop")
    local s = {options = options or {}, running = false, jobs = {}, assemblies = {}, queue_status = {id = "queue", repeats = 0}}
    for _, name in ipairs({"RegisterHook", "LoopInGameThreadWithDelay", "IsInGameThread", "FindFirstOf", "FindAllOf", "StaticFindObject"}) do assert(type(_G[name]) == "function", "client API missing=" .. name) end
    assert(_G.FName ~= nil, "client API missing=FName")
    assert(s.options.log == nil or type(s.options.log) == "function", "options.log must be callable")
    for _, name in ipairs({"on_ack", "on_wait", "token_for_job", "bind_snapshot"}) do
        assert(s.options[name] == nil or type(s.options[name]) == "function", "options." .. name .. " must be callable")
    end
    active = s
    local ok, cause = pcall(function()
        RegisterHook("/Script/Engine.PlayerController:ClientMessage", function(context, message, kind)
            if not s.running then return end
            local payload = kind:get():ToString()
            local old_schema=payload:match("^CabinRejoinClient_v(%d+)|")
            if old_schema and old_schema~="11" then
                s.old_schema_packets = (s.old_schema_packets or 0) + 1
                if s.old_schema_packets == 1 then emit(s, "error", "client snapshot schema differs received=" .. old_schema .. " required=11; packet rejected; repeated mismatches counted") end
                return
            end
            if payload:sub(1, #MARKER + 1) ~= MARKER .. "|" then return end
            local accepted, failure = pcall(receive, s, context:get(), message:get():ToString(), payload)
            if not accepted then emit(s, "error", "client snapshot receive cause=" .. tostring(failure)) end
        end)
        s.running = true
        gt_scheduler.loop(500, function()
            if not s.running then return true end
            if s.queued then
                if os.time() - s.queued_at >= 5 then wait_reason(s, s.queue_status, "game-thread callback acknowledgement pending; no replay") end
                return
            end
            s.queued, s.queued_at = true, os.time()
            local queued, failure = pcall(function()
                gt_scheduler.execute(function()
                    s.queued = false
                    if not s.running then return end
                    if s.queue_status.reason then emit(s, "info", "client game-thread queue recovered"); s.queue_status.reason = nil end
                    for key, job in pairs(s.jobs) do
                        local restored, error = pcall(attempt, s, job)
                        if not restored then job.status = "failed"; emit(s, "error", "client restore id=" .. job.id .. " cause=" .. tostring(error) .. "; no automatic replay") end
                        if restored and (job.status == "pending" or job.status == "map_blend_pending" or job.status == "holding_pending" or job.status=="intro_pending") and s.options.on_wait then
                            local notified, cause = pcall(s.options.on_wait, job.pc, job.reason or "restore pending")
                            if not notified then
                                local now=os.time()
                                cause=tostring(cause)
                                if job.refresh_failure~=cause or now-(job.refresh_log or 0)>=60 then
                                    emit(s, "error", "client refresh callback id=" .. job.id .. " cause=" .. cause)
                                    job.refresh_failure,job.refresh_log=cause,now
                                end
                            elseif job.refresh_failure then
                                emit(s,"info","client refresh callback recovered id="..job.id)
                                job.refresh_failure=nil
                            end
                        end
                        if job.status == "ended" then s.jobs[key], s.assemblies[key] = nil, nil end
                    end
                end)
            end)
            if not queued then s.running = false; emit(s, "error", "client game-thread queue cause=" .. tostring(failure)) end
        end)
        emit(s, "info", "client receiver started; no presentation mutation before marked same-pawn ownership snapshot")
    end)
    if not ok then s.running = false; emit(s, "error", "client start cause=" .. tostring(cause)); return false, cause end
    return true
end

function M.confirm_receipt(receipt)
    assert(active and active.running and type(receipt)=="table", "current client receiver required")
    local pc, pawn, wanted = receipt.pc, receipt.pawn, receipt.snapshot
    assert(valid(pc) and valid(pawn) and type(wanted)=="table", "local receipt binding missing")
    local job = active.jobs[pc:GetAddress()]
    assert(job and job.receipt==receipt and job.status=="confirmed", "receipt is not current confirmed restore job")
    local common=pc:IsLocalController() and pc:GetLocalRole()==2 and not pc:IsActorBeingDestroyed()
        and not pawn:IsActorBeingDestroyed() and pawn:IsLocallyControlled()
        and address(pc.Pawn)==pawn:GetAddress() and address(pawn.Controller)==pc:GetAddress()
        and address(pc.AcknowledgedPawn)==pawn:GetAddress() and pawn.IsCurrentTurn==wanted.turn
        and matching_cards(pawn,wanted.cards)
        and ((wanted.chair=="-" and not valid(pawn.Chair))
            or (wanted.chair~="-" and valid(pawn.Chair) and M.key(pawn.Chair)==wanted.chair))
    if not common then return false end
    if wanted.mode == "standing" then
        local current_token = active.options.token_for_job and active.options.token_for_job(pc, job.id)
        standing.verify_view(assert(receipt.standing, "Standing receipt missing"), current_token)
        return true
    end
    if (wanted.mode=="holding_inspect" or wanted.mode=="card_inspect") then
        local c,cause=prepare_holding(pc,pawn,wanted,job.control_token,function() return active.options.token_for_job(pc,job.id) end)
        if not c then emit(active,"info","Holding ACK readback pending id="..job.id.." cause="..cause); return false end
        local ready,blocker=card_module(wanted).finish(c,job.holding_presentation)
        if not ready then emit(active,"info","Holding ACK presentation pending id="..job.id.." cause="..blocker); return false end
        return receipt.local_confirmed==true and receipt.complete==true
    end
    if wanted.mode=="car_intro" then
        local c,cause=prepare_intro(pc,pawn,wanted,job.control_token,function() return active.options.token_for_job(pc,job.id) end)
        if not c then emit(active,"info","Intro ACK readback pending id="..job.id.." cause="..cause); return false end
        local ready,blocker=extended_intro_restore.finish(c,job.intro_presentation)
        if not ready then emit(active,"info","Intro ACK presentation pending id="..job.id.." cause="..blocker); return false end
        return receipt.local_confirmed==true and receipt.complete==true
    end
    if wanted.mode=="action_resume" or wanted.mode=="radio_resume" then
        local ready,blocker=remaining_input.finish(job.original_input_context,job.original_input_receipt)
        if not ready then emit(active,"info","original input ACK pending id="..job.id.." cause="..tostring(blocker));return false end
        return receipt.local_confirmed==true and receipt.complete==true
    end
    if wanted.mode=="radio_seated" or wanted.mode=="world_choice" then
        local ready,blocker=interaction_phase.finish(job.interaction_context,job.interaction_receipt)
        if not ready then emit(active,"info","current original interaction ACK pending id="..job.id.." cause="..tostring(blocker));return false end
        return receipt.local_confirmed==true and receipt.complete==true
    end
    if wanted.mode~="room_map" then return true end
    local context,cause=prepare_room_map(pc,pawn,wanted,job.control_token)
    if not context then emit(active,"info","client Map ACK readback pending id=" .. job.id .. " cause=" .. cause); return false end
    local presented,blocker=map_phase.presentation_ready(context)
    if not presented then emit(active,"info","client Map ACK presentation pending id=" .. job.id .. " cause=" .. blocker); return false end
    return receipt.camera_receipt=="destination_observed" and receipt.local_confirmed==true and receipt.complete==true
end

function M.stop()
    if not active then return true end
    active.running = false
    emit(active, "info", "client receiver stopped; callbacks dormant and pending work cancelled")
    return true
end

return M
