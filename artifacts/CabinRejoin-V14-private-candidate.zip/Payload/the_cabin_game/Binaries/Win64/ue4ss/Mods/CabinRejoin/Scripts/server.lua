local gt_scheduler = require("gt_scheduler")
local M = {}
local phase_ledger = require("phase_ledger")
local holding_evidence = require("holding_evidence")
local client = require("client")
local extended_context = require("extended_authority_context")
local extended_evidence = require("extended_card_evidence")
local extended_observer = require("extended_card_observer")
local extended_intro_observer = require("extended_intro_observer")
local extended_intro_evidence = require("extended_intro_evidence")
local extended_engine = require("extended_engine_adapters")
local native_input = require("native_input")
local remaining_input = require("remaining_input")
local interaction_phase = require("interaction_phase")
local lantern_cleanup = require("lantern_cleanup")
local state
local GM_PATH = "/Game/CabinGameContent/Cabin_GameMode.Cabin_GameMode_C:"

local function valid(object)
    return object ~= nil and object:IsValid()
end

local function address(object)
    return valid(object) and object:GetAddress() or 0
end

local function emit(s, level, message)
    if s.options.log then
        local ok, cause = pcall(s.options.log, level, message)
        if ok then return end
        print("[CabinRejoin] error: log callback cause=" .. tostring(cause) .. "\n")
    end
    print("[CabinRejoin] " .. level .. ": " .. message .. "\n")
end

local function reason(s, target, message, level)
    local now = os.time()
    local previous = target.reason
    target.repeats = (previous == message) and (target.repeats + 1) or 1
    if previous ~= message or now - (target.last_log or 0) >= 60 then
        emit(s, level or "info", target.label .. " " .. message .. " observations=" .. target.repeats)
        target.last_log = now
    end
    target.reason = message
end

local function protected(s, operation, callable)
    local ok, cause = pcall(callable)
    if not ok then emit(s, "error", operation .. " cause=" .. tostring(cause)) end
    return ok, cause
end

local function current_phase_round(s)
    local gm, count = nil, 0
    for _, object in ipairs(FindAllOf("Cabin_GameMode_C") or {}) do
        if valid(object) and not object:IsActorBeingDestroyed() and object:GetLocalRole() == 3
            and not s.ended_game_modes[object:GetAddress()] and valid(object:GetWorld()) then
            gm, count = object, count + 1
        end
    end
    assert(count <= 1, "live authority GameMode count measured=" .. count .. " required<=1")
    if not gm then return nil end
    assert(type(gm.GameStarted) == "boolean", "original GameMode GameStarted boolean unavailable")
    local changed = s.phase_gm_address ~= gm:GetAddress()
    if changed then
        s.entered_gameplay=false
        s.input_epoch=s.input_epoch+1
        if s.input then s.input.set_epoch(gm:GetWorld():GetAddress(),s.input_epoch) end
    end
    if gm.GameStarted then s.entered_gameplay=true end
    if changed or (s.phase_was_started == false and gm.GameStarted) then
        s.phase_generation = s.phase_generation + 1
        emit(s, "info", "phase round epoch observed generation=" .. s.phase_generation .. " started=" .. tostring(gm.GameStarted))
    end
    s.phase_gm, s.phase_gm_address, s.phase_was_started = gm, gm:GetAddress(), gm.GameStarted
    return gm, tostring(s.phase_generation)
end

local function phase_board(s, pawn)
    local world = pawn:GetWorld()
    assert(valid(world), "retained pawn world unavailable for phase Board lookup")
    local selected, count = nil, 0
    for _, board in ipairs(FindAllOf("GameBoard_BP_C") or {}) do
        if valid(board) and not board:IsActorBeingDestroyed() and board:GetLocalRole() == 3
            and not s.ended_boards[board:GetAddress()] and address(board:GetWorld()) == world:GetAddress() then
            s.observed_boards[board:GetAddress()] = true
            local matches = 0
            board.PlayerOrder:ForEach(function(_, parameter)
                if address(parameter:get()) == pawn:GetAddress() then matches = matches + 1 end
            end)
            if matches > 0 then selected, count = board, count + 1 end
        end
    end
    return selected, count
end

local function presentation_phase(s,pawn)
    if not valid(pawn.Chair) and s.intro_observer and s.intro_observer.released(pawn,s.phase_gm)
        and pawn.GameplayVars['IsSitting_13_5E5832C3491A59936F87C7A815E64A59']==false
        and not pawn.IsInTurn and not pawn.IsCurrentTurn and not pawn.GameHalted and not pawn.InAnimation then
        local board,count=nil,0
        for _,v in ipairs(FindAllOf('GameBoard_BP_C') or {}) do
            if valid(v) and not v:IsActorBeingDestroyed() and v:HasAuthority()
                and address(v:GetWorld())==address(pawn:GetWorld()) then board,count=v,count+1 end
        end
        assert(count<=1,'ambiguous original post-Intro Board')
        if board and board.GameStarted==false and board.PlayerTurn==-1 and board.PlayerOrder:GetArrayNum()==0
            and not valid(board.CurrentPlayerTurn) and not board.GameEndTime and not board.HaltGame and not board.SpecialEventHalt then
            return {phase='standing',post_intro=true,started=false}
        end
    end
    return s.ledger.inspect(pawn)
end

local function input_capture(s,pawn)
    local row,cause=s.input.inspect(pawn:GetAddress())
    if not row then return nil,cause end
    return nil,"original native flags exist but no current subclass interaction binding is proved; Board is not an action anchor"
end

local function snapshot(pawn)
    assert(valid(pawn) and valid(pawn.RootComponent) and not pawn:IsActorBeingDestroyed(), "retained pawn is not live")
    local hand, count = {}, 0
    pawn.CurrentCards:ForEach(function(index, parameter)
        local card = parameter:get()
        assert(valid(card), "ordered hand contains invalid card class at index=" .. index)
        hand[index] = card:GetAddress()
        count = count + 1
    end)
    assert(count == pawn.CurrentCards:GetArrayNum(), "ordered hand count receipt differs")
    return {hand = hand, count = count, turn = pawn.IsCurrentTurn, chair = address(pawn.Chair)}
end

local function unchanged(pawn, captured)
    local observed = snapshot(pawn)
    assert(observed.count == captured.count, "retained card count changed measured=" .. observed.count .. " required=" .. captured.count)
    for index, card in pairs(captured.hand) do
        assert(observed.hand[index] == card, "retained ordered card changed index=" .. index)
    end
    assert(observed.turn == captured.turn, "retained turn changed")
    assert(observed.chair == captured.chair, "retained chair changed")
end

local function temporary_defaults(pawn)
    assert(not valid(pawn.Chair) and not pawn.IsCurrentTurn, "temporary pawn is seated or has a current turn")
    assert(pawn.CurrentCardsObjects:GetArrayNum() == 0, "temporary pawn owns physical cards")
    local defaults = StaticFindObject("/Game/CabinGameContent/PlayerContent/Cabin_Player.Default__Cabin_Player_C")
    assert(valid(defaults), "original player defaults unavailable")
    local observed, original = snapshot(pawn), {}
    defaults.CurrentCards:ForEach(function(index, parameter)
        local card = parameter:get()
        assert(valid(card), "original default hand contains invalid class index=" .. index)
        original[index] = card:GetAddress()
    end)
    assert(observed.count == defaults.CurrentCards:GetArrayNum(), "temporary hand count differs from original defaults")
    for index, card in pairs(original) do
        assert(observed.hand[index] == card, "temporary hand differs from original defaults index=" .. index)
    end
end

local function roster(gm)
    local entries = {}
    gm.AllPlayerControllers:ForEach(function(index, parameter)
        entries[index] = address(parameter:get())
    end)
    return entries, gm.AllPlayerControllers:GetArrayNum()
end

local function slot_for(gm, pc)
    local found
    gm.AllPlayerControllers:ForEach(function(index, parameter)
        if address(parameter:get()) == pc:GetAddress() then
            assert(found == nil, "controller has duplicate roster entries")
            found = index
        end
    end)
    return found
end

local function touch(s, pc_address)
    local previous = s.native[pc_address]
    if not previous or previous.released then s.native[pc_address] = {released = false} end
end

local function release(s, pc_address)
    local entry = s.native[pc_address]
    if not entry or entry.released then return end
    assert(not entry.release_attempted, "native release previously failed pc=" .. pc_address .. "; no automatic replay")
    entry.release_attempted = true
    emit(s, "info", "release attempted pc=" .. pc_address)
    assert(CabinReleaseController(pc_address) == 1, "native release not acknowledged pc=" .. pc_address)
    local mode = CabinControllerStatus(pc_address)
    assert(mode == -1, "native release status differs measured=" .. tostring(mode) .. " required=-1")
    entry.released = true
    emit(s, "info", "release confirmed pc=" .. pc_address)
end

local function clear_round(s, cause)
    local failed = false
    if s.input and not protected(s,"round input stop",function() s.input.stop_all(cause) end) then failed=true end
    for pc_address in pairs(s.native) do
        if not protected(s, "round release pc=" .. pc_address, function() release(s, pc_address) end) then failed = true end
    end
    if failed then
        s.active = false
        if s.ledger then s.ledger.stop() end
        if s.interactions then s.interactions.stop() end
        if s.card_observer then s.card_observer.stop() end
        if s.extended_card_observer then s.extended_card_observer.stop() end
        if s.intro_observer then s.intro_observer.stop() end
        emit(s, "error", "round cleanup blocked cause=" .. cause .. "; unresolved native reservation, automatic work stopped")
        return false
    end
    if s.interactions then s.interactions.clear() end
    if s.card_observer then s.card_observer.clear(cause) end
    if s.extended_card_observer then s.extended_card_observer.clear(cause) end
    if s.intro_observer then s.intro_observer.clear(cause) end
    s.by_pc, s.by_id, s.candidates, s.cleanup, s.native = {}, {}, {}, {}, {}
    s.gm, s.gm_address = nil, nil
    emit(s, "info", "round observations cleared cause=" .. cause)
    return true
end

local function authenticate(s, candidate, force)
    local pc = candidate.pc
    local connection = address(pc.NetConnection)
    if connection == 0 then return nil, "waiting for remote NetConnection" end
    local now = os.time()
    if not force and candidate.auth_connection == connection and candidate.auth_checked and now - candidate.auth_checked < 30 then
        if candidate.steam_id then return candidate.steam_id, candidate.connection_handle end
        return nil, "waiting for authenticated native Steam identity; native log contains guard cause"
    end
    candidate.auth_connection, candidate.auth_checked = connection, now
    local steam_id, handle = CabinAuthenticatedSteamID(pc:GetAddress())
    if steam_id == nil then
        candidate.steam_id, candidate.connection_handle = nil, nil
        return nil, "waiting for authenticated native Steam identity; native log contains guard cause"
    end
    assert(math.type(steam_id) == "integer" and steam_id > 0, "native identity is not an exact positive Lua integer")
    assert(math.type(handle) == "integer" and handle > 0, "native connection handle is not a positive Lua integer")
    candidate.steam_id, candidate.connection_handle = steam_id, handle
    return steam_id, handle
end

local function reserve(s, candidate, gm, pawn, slot)
    local pc = candidate.pc
    local before = snapshot(pawn)
    local expected_id = candidate.steam_id
    local identity = authenticate(s, candidate, true)
    assert(identity == expected_id, "native identity changed before reservation")
    candidate.phase = "reserve_attempted"
    touch(s, pc:GetAddress())
    emit(s, "info", "reserve attempted " .. candidate.label .. " pawn=" .. pawn:GetAddress() .. " slot=" .. slot)
    assert(CabinReserveController(pc:GetAddress(), pawn:GetAddress(), s.unpossess:GetAddress(), 1) == 1, "native reserve not acknowledged")
    local mode, hits, outcome = CabinControllerStatus(pc:GetAddress())
    assert(mode == 1 and hits == 0 and outcome == 0, "native reserve status differs mode=" .. tostring(mode) .. " hits=" .. tostring(hits) .. " outcome=" .. tostring(outcome))
    assert(address(pc.Pawn) == pawn:GetAddress() and address(pawn.Controller) == pc:GetAddress(), "ownership changed during reservation")
    assert(slot_for(gm, pc) == slot, "roster slot changed during reservation")
    unchanged(pawn, before)
    local r = {pc = pc, pc_address = pc:GetAddress(), pawn = pawn, rosterIndex = slot,
        steam_id = candidate.steam_id, connection_handle = candidate.connection_handle,
        gm_address = gm:GetAddress(), disconnected = false}
    s.input_generation=s.input_generation+1
    r.input_generation=s.input_generation
    s.by_pc[r.pc_address], s.by_id[r.steam_id] = r, r
    s.input.arm(r,s.input_function)
    candidate.phase = "reserved"
    emit(s, "info", "reserve confirmed " .. candidate.label .. " same pawn/cards/turn/chair slot=" .. slot)
end

local function rejoin(s, candidate, gm, r)
    local pc, pawn = candidate.pc, r.pawn
    assert(not r.failed, "retained pawn EndPlay already observed")
    assert(r.gm_address == gm:GetAddress(), "reservation belongs to another GameMode")
    assert(r.logout_capture and r.disconnected, "logout snapshot missing")
    local before = snapshot(pawn)
    assert(not valid(pawn.Controller), "retained pawn already controlled")
    local mode, hits, outcome = CabinControllerStatus(r.pc_address)
    assert(mode == 1 and hits >= 1 and outcome == 2, "native detach receipt differs mode=" .. tostring(mode) .. " hits=" .. tostring(hits) .. " outcome=" .. tostring(outcome))
    local temporary = pc.Pawn
    assert(valid(temporary) and valid(temporary.RootComponent) and not temporary:IsActorBeingDestroyed(), "temporary default pawn unavailable")
    assert(temporary:GetAddress() ~= pawn:GetAddress(), "new controller already owns retained pawn without receipt")
    assert(address(temporary.Controller) == pc:GetAddress(), "temporary pawn ownership differs")
    temporary_defaults(temporary)
    local entries, count = roster(gm)
    assert(r.rosterIndex >= 1 and r.rosterIndex <= count, "captured roster slot outside array")
    local occupant = gm.AllPlayerControllers[r.rosterIndex]
    local new_slot = slot_for(gm, pc)
    assert(not valid(occupant) or occupant:GetAddress() == pc:GetAddress() or (occupant:GetAddress() == r.pc_address and not valid(occupant.Pawn)), "captured slot occupied by another or possessed controller")
    assert(new_slot == nil or new_slot == r.rosterIndex, "new controller already occupies a different roster slot")
    local identity, handle = authenticate(s, candidate, true)
    assert(identity == r.steam_id, "native identity changed before transfer")
    local old_address = r.pc_address
    candidate.phase = "transfer_attempted"
    emit(s, "info", "transfer attempted " .. candidate.label .. " retained=" .. pawn:GetAddress() .. " temporary=" .. temporary:GetAddress())
    local lantern_item, lantern_cause = lantern_cleanup.capture(pawn)
    if not lantern_item then emit(s, "info", "retained lantern capture pending cause=" .. lantern_cause) end
    pc:Possess(pawn)
    assert(address(pc.Pawn) == pawn:GetAddress() and address(pawn.Controller) == pc:GetAddress(), "Possess ownership not acknowledged")
    pc.PlayerCharacter = pawn
    assert(address(pc.PlayerCharacter) == pawn:GetAddress(), "PlayerCharacter assignment not acknowledged")
    pawn.CabinPlayerController = pc
    assert(address(pawn.CabinPlayerController) == pc:GetAddress(), "CabinPlayerController assignment not acknowledged")
    gm.AllPlayerControllers[r.rosterIndex] = pc
    local after, after_count = roster(gm)
    assert(after_count == count, "roster count changed during replacement")
    for index, controller in pairs(entries) do
        assert(after[index] == (index == r.rosterIndex and pc:GetAddress() or controller), "roster replacement changed slot=" .. index)
    end
    unchanged(pawn, before)
    release(s, old_address)
    touch(s, pc:GetAddress())
    emit(s, "info", "rearm attempted " .. candidate.label)
    assert(CabinReserveController(pc:GetAddress(), pawn:GetAddress(), s.unpossess:GetAddress(), 1) == 1, "new native reservation not acknowledged")
    local new_mode, new_hits, new_outcome = CabinControllerStatus(pc:GetAddress())
    assert(new_mode == 1 and new_hits == 0 and new_outcome == 0, "new native reservation status differs")
    unchanged(pawn, before)
    s.by_pc[old_address] = nil
    if s.options.on_disconnected then s.options.on_disconnected(old_address, "retained controller replaced") end
    r.pc, r.pc_address, r.connection_handle, r.disconnected = pc, pc:GetAddress(), handle, false
    r.capture = before
    r.lantern_cleanup = lantern_item
    if lantern_item then
        lantern_item.label, lantern_item.repeats = "retained lantern pawn=" .. pawn:GetAddress(), 0
        lantern_cleanup.connect(lantern_item, pc)
    end
    s.by_pc[r.pc_address] = r
    candidate.phase = "reserved"
    local phase=presentation_phase(s,pawn)
    local receipt = {pc = pc, pawn = pawn, temporary = temporary, reservation = r,
        steam_id = r.steam_id, connection_handle = handle, roster_index = r.rosterIndex,
        capture = r.capture, server_confirmed = true, phase = phase,
        card_phase=s.card_observer.inspect(pawn),input_capture=function() return input_capture(s,pawn) end,
        holding_capture=function() return s.holding.capture(pawn,s.card_observer) end,
        interaction_capture=function() return s.interactions.capture(pawn) end,
        extended_capture=function() return s.extended_card.capture(pawn,s.extended_card_observer) end,
        initial_gameplay_phase=not s.entered_gameplay and not phase.post_intro,
        intro_capture=function()
            if s.entered_gameplay then return nil,"original Intro lifecycle completed" end
            return s.intro_evidence.capture(pawn,s.intro_observer)
        end}
    s.cleanup[temporary:GetAddress()] = {receipt = receipt, due = os.time() + 1, due_tick = s.ticks + 2, label = "temporary=" .. temporary:GetAddress()}
    emit(s, "info", "transfer confirmed " .. candidate.label .. " same pawn/cards/turn/chair slot=" .. r.rosterIndex .. "; client restore pending")
    if s.options.on_rejoined then
        emit(s, "info", "on_rejoined attempted " .. candidate.label)
        local ok = protected(s, "on_rejoined " .. candidate.label, function() s.options.on_rejoined(receipt) end)
        emit(s, ok and "info" or "error", "on_rejoined " .. candidate.label .. (ok and " returned; client acknowledgement required" or " failed; server transfer remains confirmed"))
    end
end

local function cleanup(s, item)
    if item.failed or os.time() < item.due or s.ticks < item.due_tick then return end
    local receipt, now = item.receipt, os.time()
    if item.attempted then
        if item.endplay_reason ~= nil then
            assert(item.endplay_reason == 0, "temporary EndPlay reason differs measured=" .. item.endplay_reason .. " required=0")
            assert(address(receipt.pc.Pawn) == receipt.pawn:GetAddress() and address(receipt.pawn.Controller) == receipt.pc:GetAddress(), "retained ownership changed after temporary destruction")
            assert(item.retained_checked, "retained-state receipt missing after temporary destruction")
            assert(valid(receipt.pawn) and valid(receipt.pawn.RootComponent) and not receipt.pawn:IsActorBeingDestroyed(), "retained pawn no longer live after temporary destruction")
            emit(s, "info", item.label .. " destruction confirmed Destroyed EndPlay; retained pawn/cards/turn/chair unchanged")
            s.cleanup[item.address] = nil
        elseif now - item.attempted >= 5 then
            error("temporary destruction attempted but Destroyed EndPlay not acknowledged after5s; no replay")
        end
        return
    end
    local temporary = receipt.temporary
    assert(valid(temporary) and valid(temporary.RootComponent) and not temporary:IsActorBeingDestroyed(), "captured temporary actor no longer live")
    assert(not valid(temporary.Controller), "captured temporary actor is controlled")
    temporary_defaults(temporary)
    assert(address(receipt.pc.Pawn) == receipt.pawn:GetAddress() and address(receipt.pawn.Controller) == receipt.pc:GetAddress(), "retained ownership changed before temporary destruction")
    item.before = snapshot(receipt.pawn)
    item.address, item.attempted = temporary:GetAddress(), now
    emit(s, "info", item.label .. " destruction attempted")
    temporary:K2_DestroyActor()
    unchanged(receipt.pawn, item.before)
    item.retained_checked = true
end

local function observe_candidate(s, candidate, gm)
    if candidate.phase ~= "waiting" then return end
    local pc = candidate.pc
    if not valid(pc) or pc:IsActorBeingDestroyed() then candidate.phase = "ended"; return end
    if pc:GetLocalRole() ~= 3 then reason(s, candidate, "skip non-authority controller"); return end
    if not valid(pc.NetConnection) then reason(s, candidate, "waiting for remote NetConnection"); return end
    local pawn = pc.Pawn
    if not valid(pawn) or not valid(pawn.RootComponent) or pawn:IsActorBeingDestroyed() then reason(s, candidate, "waiting for original live pawn"); return end
    if address(pawn.Controller) ~= pc:GetAddress() then reason(s, candidate, "waiting for original pawn ownership"); return end
    local identity, detail = authenticate(s, candidate)
    if not identity then reason(s, candidate, detail, "warn"); return end
    local r = s.by_id[identity]
    if r then
        if r.pc_address == pc:GetAddress() and not r.disconnected then candidate.phase = "reserved"; return end
        if not r.disconnected then reason(s, candidate, "identity already has a connected reservation; observation only", "warn"); return end
        rejoin(s, candidate, gm, r)
        return
    end
    local slot = slot_for(gm, pc)
    if not slot then reason(s, candidate, "waiting for original roster slot"); return end
    reserve(s, candidate, gm, pawn, slot)
end

local function tick(s)
    s.ticks = s.ticks + 1
    local gm = current_phase_round(s)
    local phase_ok, phase_cause = s.ledger.tick()
    if not phase_ok then reason(s, s.phase_status, "phase observation failed cause=" .. tostring(phase_cause), "error")
    elseif s.phase_status.reason then
        emit(s, "info", "phase observer call recovered; invalidated history remains blocked")
        s.phase_status.reason = nil
    end
    if not valid(gm) or (s.entered_gameplay and not gm.GameStarted) or gm.GameEnd then
        if s.gm_address then clear_round(s, "original GameMode/started round ended") end
        reason(s, s, "waiting for original started server round")
        return
    end
    if gm:GetLocalRole() ~= 3 then reason(s, s, "skip non-authority GameMode"); return end
    if s.gm_address and s.gm_address ~= gm:GetAddress() and not clear_round(s, "GameMode replaced") then return end
    s.gm, s.gm_address = gm, gm:GetAddress()
    reason(s, s, "observing original gameplay lifecycle including initial Intro")
    for _, pc in ipairs(FindAllOf("Cabin_PC_C") or {}) do
        if valid(pc) and not pc:IsActorBeingDestroyed() and pc:GetLocalRole() == 3 and valid(pc.NetConnection) then
            local key = pc:GetAddress()
            s.candidates[key] = s.candidates[key] or {pc = pc, phase = "waiting", label = "pc=" .. key, repeats = 0}
        end
    end
    for key, candidate in pairs(s.candidates) do
        if not valid(candidate.pc) or candidate.pc:IsActorBeingDestroyed() then s.candidates[key] = nil
        else
            local ok = protected(s, "candidate " .. candidate.label .. " phase=" .. candidate.phase, function() observe_candidate(s, candidate, gm) end)
            if not ok then candidate.phase = "failed"; emit(s, "error", candidate.label .. " automatic mutation path stopped; no replay") end
        end
    end
    for _, item in pairs(s.cleanup) do
        local ok = protected(s, "cleanup " .. item.label, function() cleanup(s, item) end)
        if not ok then item.failed = true end
    end
    for _, r in pairs(s.by_id) do
        local item = r.lantern_cleanup
        if item and not item.failed and not r.disconnected and not r.failed then
            local ok = protected(s, "retained lantern cleanup pawn=" .. r.pawn:GetAddress(), function()
                local ready, cause = lantern_cleanup.observe(item, function(level, message) emit(s, level, message) end)
                if not ready then reason(s, item, cause)
                elseif item.reason then emit(s, "info", item.label .. " observation recovered"); item.reason = nil end
            end)
            if not ok then item.failed = true end
        end
    end
    if s.options.on_pending then
        for _, reservation in pairs(s.by_id) do
            if not reservation.disconnected and not reservation.failed and reservation.control_issued then
                protected(s, "pending client acknowledgement pc=" .. reservation.pc_address,
                    function() s.options.on_pending(reservation.pc) end)
            end
        end
    end
end

function M.start(options)
    assert(state == nil, "server core already started; reuse requires a fresh module instance")
    options = options or {}
    assert(options.log == nil or type(options.log) == "function", "options.log must be a function")
    assert(type(options.on_rejoined) == "function", "options.on_rejoined is required for confirmed client restoration")
    local s = {options = options, active = false, by_pc = {}, by_id = {}, candidates = {}, cleanup = {}, native = {}, label = "server", repeats = 0, ticks = 0,
        tick_status = {label = "server tick", repeats = 0}, queue_status = {label = "game-thread queue", repeats = 0},
        input_epoch = 0, input_generation = 0, phase_generation = 0, ended_game_modes = {}, ended_boards = {}, observed_boards = {},
        phase_status = {label = "phase observer", repeats = 0}}
    local ok, cause = protected(s, "start", function()
        for _, name in ipairs({"CabinInputIntentArm", "CabinInputIntentStatus", "CabinInputIntentStop", "CabinInputIntentStopAll", "CabinInputIntentEpoch", "CabinAuthenticatedSteamID", "CabinReserveController", "CabinControllerStatus", "CabinReleaseController", "RegisterHook", "RegisterEndPlayPreHook", "LoopInGameThreadWithDelay", "IsInGameThread", "StaticFindObject", "FindFirstOf", "FindAllOf"}) do
            assert(type(_G[name]) == "function", "required API unavailable=" .. name)
        end
        assert(type(math.type) == "function", "Lua exact integer support unavailable")
        s.unpossess = StaticFindObject("/Script/Engine.Controller:UnPossess")
        assert(valid(s.unpossess), "reflected UnPossess function unavailable")
        assert(valid(StaticFindObject(GM_PATH .. "K2_OnLogout")), "reflected logout hook unavailable")
        assert(valid(StaticFindObject(GM_PATH .. "Post_Login_E")), "reflected post-login hook unavailable")
        local initial_gm = current_phase_round(s)
        assert(valid(initial_gm) and initial_gm.GameStarted == false,
            "phase bootstrap requires live authority GameMode before original GameStarted=true")
        s.input_function=StaticFindObject("/Game/CabinGameContent/PlayerContent/Cabin_Player.Cabin_Player_C:DisablePlayerInputs_E")
        assert(valid(s.input_function),"original reflected DisablePlayerInputs_E unavailable")
        s.input=native_input.new({arm=CabinInputIntentArm,status=CabinInputIntentStatus,stop=CabinInputIntentStop,
            stop_all=CabinInputIntentStopAll,epoch=CabinInputIntentEpoch,key=client.key,
            log=function(level,message) emit(s,level,message) end,current_epoch=function() return s.input_epoch end,
            resolve=function(target)
                local found
                for _,r in pairs(s.by_id) do if address(r.pawn)==target then assert(not found,"duplicate input reservation");found=r end end
                return found
            end})
        s.input.set_epoch(initial_gm:GetWorld():GetAddress(),s.input_epoch)
        s.clock = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
        assert(valid(s.clock) and valid(StaticFindObject("/Script/Engine.KismetSystemLibrary:GetGameTimeInSeconds")),
            "reflected original world clock unavailable")
        s.ledger = phase_ledger.new({
            log = function(level, message) emit(s, level, message) end,
            current_round = function() return current_phase_round(s) end,
            now = function()
                assert(valid(s.phase_gm), "phase world clock GameMode unavailable")
                return s.clock:GetGameTimeInSeconds(s.phase_gm)
            end,
            resolve_reserved = function(object)
                local key = object:GetAddress()
                if s.interactions then s.interactions.ended(key) end
                local found
                for _, reservation in pairs(s.by_id) do
                    if reservation.pawn:GetAddress() == key then
                        assert(not found, "duplicate authenticated phase reservation")
                        found = reservation
                    end
                end
                return found
            end,
            resolve_board = function(pawn) return phase_board(s, pawn) end,
        })
        local phase_registered, phase_cause = s.ledger.register()
        assert(phase_registered, "phase ledger registration failed cause=" .. tostring(phase_cause))
        s.holding = holding_evidence.new({
            resolve_reserved = function(pawn)
                local found
                for _,r in pairs(s.by_id) do
                    if address(r.pawn)==pawn:GetAddress() then assert(not found,"duplicate Holding reservation"); found=r end
                end
                return found
            end,
            resolve_board = function(pawn) return phase_board(s,pawn) end,
            current_round = function() return current_phase_round(s) end,
            current_generation = function() return s.phase_generation end,
            native_identity = CabinAuthenticatedSteamID,
            key = client.key,
        })
        local function reserved(pawn)
            local found
            for _,r in pairs(s.by_id) do
                if address(r.pawn)==address(pawn) then assert(not found,"duplicate phase reservation"); found=r end
            end
            return found
        end
        s.extended_context=extended_context.new({resolve_reserved=reserved,
            resolve_board=function(pawn) return phase_board(s,pawn) end,
            current_round=function() return current_phase_round(s) end,
            current_generation=function() return s.phase_generation end,native_identity=CabinAuthenticatedSteamID,
            entered_gameplay=function() return s.entered_gameplay end})
        s.extended_card=extended_evidence.new({context=s.extended_context.card,key=client.key,
            resolve_actor=function(target,pawn,board)
                local found
                local function check(v) if address(v)==target then
                    if found then assert(address(found)==address(v),"phase card resolver address differs") end
                    found=v
                end end
                check(board.Card)
                pawn.CurrentCardsObjects:ForEach(function(_,p) check(p:get()) end)
                board.Graveyard:ForEach(function(_,p) check(p:get()) end)
                return found
            end})
        s.extended_card_observer=extended_observer.new({evidence=s.extended_card.evidence,current_card=s.extended_card.current_card,
            log=function(level,message) emit(s,level,message) end})
        local registered,cause=s.extended_card_observer.register()
        assert(registered,"extended original card observer registration failed cause="..tostring(cause))
        s.card_observer=s.extended_card_observer
        s.interactions=interaction_phase.new({context=s.extended_context.card,key=client.key,
            log=function(level,message) emit(s,level,message) end,
            find=function(name,pawn)
                local found={}
                for _,actor in ipairs(FindAllOf(name) or {}) do
                    if valid(actor) and not actor:IsActorBeingDestroyed() and address(actor:GetWorld())==address(pawn:GetWorld()) then found[#found+1]=actor end
                end
                return found
            end})
        local observed,observer_cause=s.interactions.register()
        assert(observed,"original Radio observer registration failed cause="..tostring(observer_cause))
        local function spline_context(actor)
            local gm,epoch=current_phase_round(s)
            if not valid(gm) or address(gm:GetWorld())~=address(actor:GetWorld()) then return nil,"original Intro spline has no current gameplay GM" end
            if gm.GameStarted or s.entered_gameplay or gm.GameEnd then return nil,"original Intro spline is outside initial gameplay lifecycle" end
            return {authority=actor:HasAuthority(),same_world=true,epoch=tostring(gm:GetAddress())..":"..epoch}
        end
        s.intro_observer=extended_intro_observer.new({context=spline_context,
            now=extended_engine.server_time,log=function(level,message) emit(s,level,message) end})
        local intro_registered,intro_cause=s.intro_observer.register()
        assert(intro_registered,"original Intro observer registration failed cause="..tostring(intro_cause))
        s.intro_evidence=extended_intro_evidence.new({context=s.extended_context.base,key=client.key,
            resolve_spline=function(car)
                local found,count=nil,0
                for _,v in ipairs(FindAllOf("CarSpline_BP_C") or {}) do
                    if valid(v) and not v:IsActorBeingDestroyed() and v:HasAuthority()
                        and address(v:GetWorld())==address(car:GetWorld()) and address(v.Car)==address(car) then found,count=v,count+1 end
                end
                return found,count
            end})
        state = s
        RegisterHook(GM_PATH .. "K2_OnLogout", function(_, exiting)
            if not s.active then return end
            protected(s, "logout", function()
                local pc = exiting:get()
                local r = s.by_pc[pc:GetAddress()]
                if not r then return end
                assert(valid(s.gm) and not s.gm.GameEnd and (s.gm.GameStarted or not s.entered_gameplay) and s.gm:GetAddress() == r.gm_address, "logout round differs from reservation")
                assert(not valid(r.pawn.Controller), "native detach not acknowledged at logout")
                local mode, hits = CabinControllerStatus(r.pc_address)
                assert(mode == 1 and hits >= 1, "native Destroyed reservation not observed at logout")
                r.logout_capture = snapshot(r.pawn)
                r.disconnected = true
                if s.options.on_disconnected then s.options.on_disconnected(r.pc_address, "original logout observed") end
                emit(s, "info", "logout confirmed detached live pawn pc=" .. r.pc_address .. " ordered_cards=" .. r.logout_capture.count .. " turn=" .. tostring(r.logout_capture.turn) .. " chair=" .. r.logout_capture.chair .. " slot=" .. r.rosterIndex)
            end)
        end)
        RegisterHook(GM_PATH .. "Post_Login_E", function(_, controller)
            if not s.active then return end
            protected(s, "post-login", function()
                local pc = controller:get()
                if valid(pc) and pc:GetLocalRole() == 3 then
                    local key = pc:GetAddress()
                    s.candidates[key] = s.candidates[key] or {pc = pc, phase = "waiting", label = "pc=" .. key, repeats = 0}
                    emit(s, "info", "post-login observed pc=" .. key .. "; original pawn/connection readiness pending")
                    local gm=current_phase_round(s)
                    if valid(gm) and not gm.GameEnd then
                        s.gm,s.gm_address=gm,gm:GetAddress()
                        observe_candidate(s,s.candidates[key],gm)
                    end
                end
            end)
        end)
        RegisterEndPlayPreHook(function(context, reason_parameter)
            if not s.active then return end
            protected(s, "EndPlay observation", function()
                local object = context:get()
                local key = object:GetAddress()
                if s.interactions then s.interactions.ended(key) end
                if key == s.phase_gm_address then s.ended_game_modes[key] = true end
                if s.observed_boards[key] then s.ended_boards[key] = true end
                local item = s.cleanup[key]
                if item then
                    item.endplay_reason = reason_parameter:get()
                    emit(s, item.attempted and "info" or "error", item.label .. " EndPlay observed reason=" .. item.endplay_reason .. " destroy_attempted=" .. tostring(item.attempted ~= nil))
                end
                for _, r in pairs(s.by_id) do
                    if r.lantern_cleanup then
                        lantern_cleanup.ended(r.lantern_cleanup, key, reason_parameter:get(), function(level, message) emit(s, level, message) end)
                    end
                    if key == r.pawn:GetAddress() then
                        r.failed = true
                        s.input.end_pawn(r,"original Pawn EndPlay reason="..reason_parameter:get())
                        emit(s, "error", "retained pawn EndPlay address=" .. key .. " reason=" .. reason_parameter:get() .. "; reservation no longer usable")
                    end
                end
            end)
        end)
        s.active = true
        gt_scheduler.loop(500, function()
            if not s.active then return true end
            if s.queued then
                if os.time() - s.queued_at >= 5 then reason(s, s.queue_status, "callback acknowledgement pending at least5s; no replay", "warn") end
                return
            end
            s.queued, s.queued_at = true, os.time()
            local queued = protected(s, "game-thread queue", function()
                gt_scheduler.execute(function()
                    s.queued = false
                    if not s.active then return end
                    if s.queue_status.reason then
                        emit(s, "info", "game-thread queue callback recovered")
                        s.queue_status.reason = nil
                    end
                    local observed, failure = pcall(tick, s)
                    if not observed then reason(s, s.tick_status, "observation failed cause=" .. tostring(failure), "error")
                    elseif s.tick_status.reason then
                        emit(s, "info", "server observation tick recovered")
                        s.tick_status.reason = nil
                    end
                end)
            end)
            if not queued then s.queued = false; s.active = false end
        end)
        emit(s, "info", "server core started; native hooks reserved only for authenticated original roster players")
    end)
    if not ok then
        s.active = false
        if s.ledger then s.ledger.stop() end
        if s.interactions then s.interactions.stop() end
        if s.card_observer then s.card_observer.stop() end
        if s.extended_card_observer then s.extended_card_observer.stop() end
        if s.intro_observer then s.intro_observer.stop() end
        if s.input then protected(s,"failed start input cleanup",function() s.input.stop_all("failed start") end) end
        return false, cause
    end
    return true
end

function M.stop()
    if not state then return true end
    state.active = false
    if state.ledger then state.ledger.stop() end
    if state.interactions then state.interactions.stop() end
    if state.card_observer then state.card_observer.stop() end
    if state.extended_card_observer then state.extended_card_observer.stop() end
    if state.intro_observer then state.intro_observer.stop() end
    return clear_round(state, "explicit stop")
end

function M.control_peer(pc)
    local s = assert(state, "server core unavailable")
    assert(s.active and valid(pc) and pc:GetLocalRole()==3 and not pc:IsActorBeingDestroyed(), "live authority control sender required")
    local gm = current_phase_round(s)
    local r = assert(s.by_pc[pc:GetAddress()], "authenticated current reservation unavailable")
    assert(valid(gm) and not gm.GameEnd and (gm.GameStarted or not state.entered_gameplay) and r.gm_address==gm:GetAddress(), "current control round differs")
    assert(not r.disconnected and not r.failed and address(r.pc)==pc:GetAddress()
        and address(pc.Pawn)==r.pawn:GetAddress() and address(r.pawn.Controller)==pc:GetAddress(), "current retained control ownership differs")
    r.generation = s.phase_generation
    return r
end

function M.presentation_receipt(pc)
    local r = M.control_peer(pc)
    local phase=presentation_phase(state,r.pawn)
    return {pc=pc, pawn=r.pawn, reservation=r, server_confirmed=true, phase=phase,
        card_phase=state.card_observer.inspect(r.pawn),input_capture=function() return input_capture(state,r.pawn) end,
        holding_capture=function() return state.holding.capture(r.pawn,state.card_observer) end,
        interaction_capture=function() return state.interactions.capture(r.pawn) end,
        extended_capture=function() return state.extended_card.capture(r.pawn,state.extended_card_observer) end,
        initial_gameplay_phase=not state.entered_gameplay and not phase.post_intro,
        intro_capture=function()
            if state.entered_gameplay then return nil,"original Intro lifecycle completed" end
            return state.intro_evidence.capture(r.pawn,state.intro_observer)
        end}
end

return M
