local M = {}
local HEADER = "__CABIN_CTRL_META1__"
local nonce_counter = 0

local function positive(v) return math.type(v) == "integer" and v > 0 end
local function live(pc, role)
    return pc and pc:IsValid() and pc:GetLocalRole() == role and not pc:IsActorBeingDestroyed()
end
local function emit(s, level, text)
    local ok, cause = pcall(s.options.log, level, "control_runtime: " .. text)
    if not ok then print("error control_runtime logger: " .. tostring(cause) .. "; " .. text) end
end
local function reason(s, item, level, text)
    local now = s.options.now()
    if item.reason ~= text then
        if item.reason then emit(s, "info", "previous condition ended; repeats=" .. item.repeats) end
        item.reason, item.repeats, item.logged = text, 0, now
        emit(s, level, text)
    else
        item.repeats = item.repeats + 1
        if now - item.logged >= s.options.log_interval then
            item.logged = now
            emit(s, level, text .. "; repeats=" .. item.repeats)
        end
    end
end
local function protect(s, operation, fn)
    local ok, result = pcall(fn)
    if not ok then
        local item = s.failures[operation] or {}
        s.failures[operation] = item
        reason(s, item, "error", operation .. ": " .. tostring(result))
        return nil, tostring(result)
    end
    local item = s.failures[operation]
    if item then
        emit(s, "info", operation .. " call returned after prior failures=" .. (item.repeats + 1) .. "; prior failed effects remain unconfirmed")
        s.failures[operation] = nil
    end
    return result
end
local function common(options)
    assert(type(options) == "table", "runtime options required")
    for _, name in ipairs({"log", "now"}) do assert(type(options[name]) == "function", name .. " adapter required") end
    for _, name in ipairs({"refresh_interval", "log_interval"}) do
        assert(type(options[name]) == "number" and options[name] > 0 and options[name] < math.huge, name .. " must be finite positive seconds")
    end
    assert(type(options.codec) == "table" and type(options.codec.encode) == "function"
        and type(options.codec.valid_nonce) == "function", "existing control codec required")
    return {options = options, running = true, bindings = {}, failures = {}}
end
function M.encode_header(codec, metadata)
    assert(positive(metadata.generation) and metadata.generation <= 2147483647, "invalid header generation")
    assert(positive(metadata.id) and codec.valid_nonce(metadata.nonce), "invalid header snapshot token")
    return table.concat({HEADER, tostring(metadata.generation), tostring(metadata.id), metadata.nonce}, "|")
end
function M.decode_header(codec, wire)
    if type(wire) ~= "string" or wire:sub(1, #HEADER) ~= HEADER then return nil, "unmarked" end
    if #wire > 160 then return nil, "header exceeds byte limit" end
    local generation, id, nonce = wire:match("^" .. HEADER .. "|([1-9][0-9]*)|([1-9][0-9]*)|([0-9a-f]+)$")
    if not generation then return nil, "invalid header fields" end
    generation, id = tonumber(generation, 10), tonumber(id, 10)
    if not positive(generation) or generation > 2147483647 or not positive(id) or not codec.valid_nonce(nonce) then
        return nil, "invalid header token"
    end
    local metadata = {generation = generation, id = id, nonce = nonce}
    if M.encode_header(codec, metadata) ~= wire then return nil, "noncanonical header" end
    return metadata
end

function M.start_server(options)
    local s = common(options)
    for _, name in ipairs({"authenticate", "current_peer", "capture", "next_id", "send_header", "send_snapshot"}) do
        assert(type(options[name]) == "function", name .. " adapter required")
    end
    assert(type(options.dispatcher) == "table" and type(options.dispatcher.new) == "function", "existing dispatcher required")
    assert(options.on_options4 == nil or type(options.on_options4) == "function", "on_options4 must be callable")
    assert(options.on_ack == nil or type(options.on_ack) == "function", "on_ack must be callable")
    local object = {}
    local function invalidate(key, cause)
        local old = s.bindings[key]
        if old then
            old.peer.pending_snapshot = nil
            s.bindings[key] = nil
            emit(s, "info", "pending invalidated pc=" .. key .. " cause=" .. cause)
        end
    end
    local function bind(pc)
        assert(s.running, "server runtime stopped")
        assert(live(pc, 3), "sender is not a live authority PC")
        local key = pc:GetAddress()
        assert(positive(key), "invalid PC address")
        local id, handle = options.authenticate(pc)
        if not positive(id) or not positive(handle) then invalidate(key, "native authentication unavailable"); error("native authentication unavailable pc=" .. key) end
        local peer = options.current_peer(pc)
        if type(peer) ~= "table" or peer.pc_address ~= key or peer.steam_id ~= id or peer.connection_handle ~= handle
            or not positive(peer.generation) or peer.generation > 2147483647 then
            invalidate(key, "current peer differs from native binding")
            error("current peer/native binding or generation invalid pc=" .. key)
        end
        local b = s.bindings[key]
        if b and (b.steam_id ~= id or b.handle ~= handle or b.generation ~= peer.generation or b.peer ~= peer) then
            invalidate(key, "native connection, generation or reservation changed"); b = nil
        end
        if not b then
            peer.pending_snapshot = nil
            b = {pc = pc, peer = peer, steam_id = id, handle = handle, generation = peer.generation}
            s.bindings[key] = b
        end
        return b
    end
    local function receipt(p)
        assert(p.calls_returned == true, "snapshot send failed or still attempted; unchanged state cannot replay")
        return {confirmed = true, generation = p.generation, id = p.id, nonce = p.nonce,
            calls_returned = true, acknowledged = p.acknowledged == true, fingerprint = p.fingerprint}
    end
    local function issue(b, current)
        current = current or options.capture(b.peer)
        assert(type(current) == "table" and type(current.fingerprint) == "string" and #current.fingerprint > 0
            and current.snapshot ~= nil, "fresh original capture/fingerprint unavailable")
        assert(bind(b.pc) == b, "native peer changed during fresh capture")
        local old = b.peer.pending_snapshot
        if old and old.fingerprint == current.fingerprint then
            reason(s, b, "info", "fresh read unchanged pc=" .. b.peer.pc_address .. "; gameplay send skipped; ACK=" .. tostring(old.acknowledged == true))
            return receipt(old)
        end
        local id = options.next_id(b.pc)
        assert(positive(id) and (not b.last_id or id > b.last_id), "snapshot allocator did not advance exact ID")
        assert(nonce_counter < math.maxinteger, "nonce counter exhausted")
        nonce_counter = nonce_counter + 1
        local p = {generation = b.generation, id = id, nonce = string.format("%016x%016x", b.peer.pc_address, nonce_counter),
            fingerprint = current.fingerprint, acknowledged = false, calls_returned = false,
            pc_address = b.peer.pc_address, steam_id = b.steam_id, connection_handle = b.handle}
        assert(options.codec.valid_nonce(p.nonce), "generated nonce invalid")
        b.last_id, b.peer.pending_snapshot = id, p
        emit(s, "info", "snapshot send attempted pc=" .. p.pc_address .. " generation=" .. p.generation .. " id=" .. id)
        assert(options.send_header(b.pc, M.encode_header(options.codec, p), p) == true, "original ClientMessage header call has no returned receipt")
        local sent = options.send_snapshot(b.pc, current.snapshot, p)
        assert(type(sent) == "table" and sent.calls_returned == true and sent.id == id
            and sent.fingerprint == p.fingerprint, "snapshot calls have no exact returned receipt")
        assert(bind(b.pc) == b and b.peer.pending_snapshot == p, "native peer or pending changed during snapshot send")
        p.calls_returned = true
        emit(s, "info", "snapshot calls returned id=" .. id .. "; actual client ACK pending")
        return receipt(p)
    end
    local function handler(peer)
        local b = assert(s.bindings[peer.pc_address], "request has no current runtime binding")
        return issue(bind(b.pc))
    end
    local dispatch = options.dispatcher.new({log = options.log, authenticate = options.authenticate,
        current_peer = function(pc) return bind(pc).peer end,
        lobby_owner = options.lobby_owner or function() return nil end,
        on_request = handler, on_refresh = handler,
        on_ack = function(peer, packet)
            local b = bind(assert(s.bindings[peer.pc_address], "ACK binding unavailable").pc)
            local p = assert(b.peer.pending_snapshot, "ACK pending unavailable")
            assert(p.calls_returned and p.generation == packet.generation and p.id == packet.snapshot_id
                and p.nonce == packet.nonce, "ACK differs from current returned snapshot")
            local current=options.capture(b.peer)
            assert(type(current)=="table" and type(current.fingerprint)=="string" and #current.fingerprint>0
                and current.snapshot~=nil,"ACK fresh original capture/fingerprint unavailable")
            assert(bind(b.pc)==b and b.peer.pending_snapshot==p,"native peer or pending changed during ACK capture")
            if current.fingerprint~=p.fingerprint then
                emit(s,"warn","ACK rejected for superseded Authority state pc=" .. p.pc_address .. " id=" .. p.id)
                local fresh=issue(b,current)
                return {confirmed=false,status="superseded",cause="Authority state changed before ACK",current=fresh}
            end
            p.acknowledged = true
            emit(s, "info", "actual client ACK received pc=" .. p.pc_address .. " id=" .. p.id)
            if options.on_ack then options.on_ack(b.pc, receipt(p)) end
            return receipt(p)
        end,
        on_options4 = options.on_options4,
    })
    function object.dispatch(pc, wire)
        if not s.running then return {status = "failed", cause = "server runtime stopped"} end
        if options.codec.marked(wire) then
            local b, cause = protect(s, "dispatch binding", function() return bind(pc) end)
            if not b then return {status = "failed", cause = cause} end
        end
        return dispatch.dispatch(pc, wire)
    end
    function object.issue(pc) return protect(s, "issue", function() return issue(bind(pc)) end) end
    function object.invalidate(pc_address, cause)
        assert(positive(pc_address) and type(cause) == "string" and #cause > 0, "exact invalidation address/cause required")
        invalidate(pc_address, cause)
    end
    function object.poll(pc)
        return protect(s, "refresh observation", function()
            local b = bind(pc)
            local p = b.peer.pending_snapshot
            if not p or p.acknowledged then return {status = "skipped", cause = "no pending client ACK"} end
            local now = options.now()
            if b.last_poll and now - b.last_poll < options.refresh_interval then return {status = "waiting", cause = "refresh interval"} end
            b.last_poll = now
            return issue(b)
        end)
    end
    function object.stop()
        s.running = false
        for key in pairs(s.bindings) do invalidate(key, "runtime stopped") end
        emit(s, "info", "server runtime stopped")
    end
    return object
end

function M.start_client(options)
    local s = common(options)
    for _, name in ipairs({"current_client", "send_control"}) do assert(type(options[name]) == "function", name .. " adapter required") end
    local object = {}
    local function bind(pc)
        assert(s.running, "client runtime stopped")
        assert(live(pc, 2), "receiver is not a live owning remote PC")
        local key, peer = pc:GetAddress(), options.current_client(pc)
        assert(positive(key), "invalid local PC address")
        assert(type(peer) == "table" and peer.pc_address == key and positive(peer.generation)
            and peer.generation <= 2147483647, "current client PC/generation unavailable")
        local b = s.bindings[key]
        if b and b.generation ~= peer.generation then
            emit(s, "info", "client pending invalidated pc=" .. key .. "; generation changed")
            s.bindings[key] = nil; b = nil
        end
        if not b then b = {pc = pc, generation = peer.generation, sequence = 0}; s.bindings[key] = b end
        return b
    end
    local function send(b, kind, extra, token)
        token = token or b.metadata
        assert(token, "current server metadata unavailable")
        assert(b.sequence < 2147483647, "control sequence exhausted")
        b.sequence = b.sequence + 1
        local packet = {kind = kind, generation = b.generation, sequence = b.sequence, nonce = token.nonce}
        for k, v in pairs(extra or {}) do packet[k] = v end
        local wire = assert(options.codec.encode(packet))
        emit(s, "info", kind .. " call attempted pc=" .. b.pc:GetAddress() .. " id=" .. tostring(token.id) .. " sequence=" .. b.sequence)
        assert(options.send_control(b.pc, wire) == true, "original ServerExecRPC call has no returned receipt")
        emit(s, "info", kind .. " call returned; server receipt unconfirmed")
        return {calls_returned = true, server_acknowledged = false, generation = b.generation,
            id = token.id, nonce = token.nonce, sequence = b.sequence}
    end
    function object.request(pc)
        return protect(s, "client snapshot request", function()
            local b = bind(pc)
            if b.request_attempted then return {status = "duplicate", cause = "request already attempted; no replay"} end
            assert(nonce_counter < math.maxinteger, "nonce counter exhausted")
            nonce_counter = nonce_counter + 1
            b.request_attempted = true
            return send(b, "request", nil, {nonce = string.format("%016x%016x", pc:GetAddress(), nonce_counter)})
        end)
    end
    function object.receive_header(pc, text, wire)
        return protect(s, "receive metadata", function()
            assert(text == "", "metadata requires empty original ClientMessage string")
            local metadata, cause = M.decode_header(options.codec, wire)
            assert(metadata, cause)
            local b = bind(pc)
            assert(metadata.generation == b.generation, "metadata generation differs from current client")
            if b.metadata then
                if metadata.id == b.metadata.id and metadata.nonce == b.metadata.nonce then return {status = "duplicate"} end
                assert(metadata.id > b.metadata.id, "stale metadata or reused ID")
            end
            b.metadata, b.ack_attempted, b.wait_attempted = metadata, nil, nil
            b.body_source, b.fingerprint = nil, nil
            emit(s, "info", "metadata accepted pc=" .. pc:GetAddress() .. " id=" .. metadata.id .. "; local restore receipt pending")
            return {status = "accepted", generation = metadata.generation, id = metadata.id, nonce = metadata.nonce}
        end)
    end
    function object.on_ack(local_receipt)
        return protect(s, "client ACK", function()
            assert(type(local_receipt) == "table", "local receipt required")
            local b = bind(local_receipt.pc)
            assert(b.metadata and local_receipt.id == b.metadata.id, "local receipt differs from current metadata")
            local token = local_receipt.control_token
            assert(type(token) == "table" and token.generation == b.generation and token.id == b.metadata.id
                and token.nonce == b.metadata.nonce, "local job token differs from current metadata")
            assert(local_receipt.local_confirmed == true and local_receipt.complete == true, "complete actual local restore receipt required")
            assert(options.confirm_local(local_receipt, b.metadata) == true, "current retained ownership/cards/turn readback differs")
            if b.ack_attempted then return {status = "duplicate", cause = "same local ACK already attempted; no replay"} end
            b.ack_attempted = true
            return send(b, "ack", {snapshot_id = b.metadata.id})
        end)
    end
    function object.bind_snapshot(pc, id, source)
        return protect(s, "bind snapshot body", function()
            local b = bind(pc)
            assert(pc:IsLocalController(), "snapshot body target is not a local controller")
            assert(b.metadata and b.metadata.id == id, "snapshot body ID has no current server metadata")
            assert(type(source) == "string" and #source > 0, "validated snapshot body source required")
            assert(type(options.fingerprint_source) == "function", "original snapshot codec adapter required")
            local fingerprint = options.fingerprint_source(source)
            assert(type(fingerprint) == "string" and #fingerprint > 0, "decoded snapshot fingerprint unavailable")
            if b.body_source then
                assert(b.body_source == source and b.fingerprint == fingerprint, "snapshot body changed for current server metadata")
                return {status = "duplicate"}
            end
            b.body_source, b.fingerprint = source, fingerprint
            return {status = "bound", generation = b.generation, id = id, nonce = b.metadata.nonce}
        end)
    end
    function object.token_for_job(pc, id)
        return protect(s, "bind local job token", function()
            local b = bind(pc)
            assert(b.metadata and b.metadata.id == id, "job ID has no current server metadata")
            return {generation = b.generation, id = id, nonce = b.metadata.nonce, fingerprint = b.fingerprint}
        end)
    end
    function object.on_wait(pc, cause)
        return protect(s, "client refresh request", function()
            local b = bind(pc)
            assert(b.metadata, "refresh waits for current server metadata")
            reason(s, b, "info", "local restore waiting id=" .. b.metadata.id .. " cause=" .. tostring(cause))
            local now = options.now()
            if b.last_wait and now - b.last_wait < options.refresh_interval then return {status = "waiting", cause = "refresh interval"} end
            if b.wait_attempted == false then return {status = "failed", cause = "previous refresh call failed; no replay"} end
            b.last_wait, b.wait_attempted = now, false
            local result = send(b, "refresh")
            b.wait_attempted = true
            return result
        end)
    end
    function object.stop() s.running = false; s.bindings = {}; emit(s, "info", "client runtime stopped") end
    assert(type(options.confirm_local) == "function", "confirm_local adapter required")
    return object
end

return M
