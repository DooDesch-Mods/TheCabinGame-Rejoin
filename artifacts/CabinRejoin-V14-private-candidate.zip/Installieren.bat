@echo off
setlocal DisableDelayedExpansion
set "CABIN_REJOIN_INSTALL_CHECK="
if "%~1"=="--check" set "CABIN_REJOIN_INSTALL_CHECK=-Check"
if not "%~1"=="" if not "%~1"=="--check" (
  echo error: Unbekanntes Argument.
  exit /b 1
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" %CABIN_REJOIN_INSTALL_CHECK%
set "CABIN_REJOIN_INSTALL_RESULT=%ERRORLEVEL%"
if not defined CABIN_REJOIN_INSTALL_CHECK if not defined CABIN_REJOIN_INSTALL_NO_PAUSE pause
exit /b %CABIN_REJOIN_INSTALL_RESULT%
