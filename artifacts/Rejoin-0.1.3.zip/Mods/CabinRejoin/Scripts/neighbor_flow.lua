local M={}
local CLASS="/Game/CabinGameContent/Event_BPs/Passive_Chance_Stuff/TheNeighbor/TheNeighbor_BP.TheNeighbor_BP_C"
-- Construct follows delays 2, 5, 5, 6, 6.5 and 3 before Choices_E.
local DIALOG_SECONDS=27.5
local function valid(v) return v and v:IsValid() end
local function count(actor)
 local n=0
 for _,name in ipairs({"ChoiceA_BP","ChoiceB_BP","ChoiceC_BP"}) do if valid(actor[name]) then n=n+1 end end
 return n
end
function M.start(options)
 if not os.getenv("CABIN_REJOIN_PROCESS_ID") then return true end
 local log=assert(options.log)
 local gameplay=StaticFindObject("/Script/Engine.Default__GameplayStatics")
 local loader=StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
 assert(valid(gameplay) and valid(loader),"Neighbor authority libraries unavailable")
 local class=loader:LoadClassAsset_Blocking(loader:Conv_SoftClassPathToSoftClassRef(loader:MakeSoftClassPath(CLASS)))
 assert(valid(class),"original Neighbor class unavailable")
 local pending={}
 local function clock(actor)
  local value=gameplay:GetTimeSeconds(actor)
  assert(type(value)=="number" and value==value and value>=0 and value<math.huge,"Neighbor world time invalid")
  return value
 end
 local function guarded(label,callback)
  return function(...)
   local ok,cause=xpcall(callback,debug.traceback,...)
   if not ok then log("error","Neighbor "..label.." failed: "..tostring(cause).."; no replay") end
  end
 end
 local function hook(name,callback)
  assert(valid(StaticFindObject(CLASS..":"..name)),"original Neighbor function unavailable="..name)
  local pre,post=RegisterHook(CLASS..":"..name,guarded(name,callback))
  assert(type(pre)=="number" and type(post)=="number","Neighbor hook registration failed="..name)
 end
 hook("AddNeighborWBP_E",function(context)
  local actor=context:get()
  assert(valid(actor) and actor:HasAuthority(),"Neighbor authority actor required")
  local key=actor:GetAddress()
  if pending[key] then return end
  local world=actor:GetWorld()
  assert(valid(world),"Neighbor authority world absent")
  pending[key]={name=actor:GetFullName(),world=world:GetAddress(),started=clock(actor),phase="waiting"}
  log("info","Neighbor dialogue observed; original choices pending after "..DIALOG_SECONDS.." world seconds")
 end)
 hook("Choices_E",function(context)
  local actor=context:get()
  if not valid(actor) then return end
  local row=pending[actor:GetAddress()]
  if row then row.phase="observing";row.called=clock(actor) end
 end)
 require("gt_scheduler").loop(100,function()
  if next(pending)==nil then return end
  local live={}
  for _,actor in ipairs(FindAllOf("TheNeighbor_BP_C") or {}) do
   if valid(actor) and not actor:IsActorBeingDestroyed() then live[actor:GetAddress()]=actor end
  end
  for key,row in pairs(pending) do
   local ok,cause=xpcall(function()
    local actor=live[key]
    if not actor or actor:GetFullName()~=row.name or not valid(actor:GetWorld()) or actor:GetWorld():GetAddress()~=row.world then
     log("info","Neighbor dialogue ended with actor/world departure; no choices replay")
     pending[key]=nil;return
    end
    if row.phase=="done" or row.phase=="failed" then return end
    assert(actor:HasAuthority(),"Neighbor actor lost authority")
    local now=clock(actor)
    assert(now>=row.started,"Neighbor world time moved backwards")
    local choices=count(actor)
    if row.phase=="waiting" then
     if choices>0 then
      row.phase="observing";row.called=now
      log("info","Neighbor original choices already present="..choices.."; no duplicate generation")
     elseif now-row.started>=DIALOG_SECONDS then
      assert(valid(actor.SpecificPlayer),"Neighbor original selecting player absent")
      row.phase="attempted";row.called=now
      log("info","Neighbor original Choices_E attempted after dialogue; elapsed="..(now-row.started))
      actor:Choices_E()
      assert(row.phase=="observing","Neighbor original Choices_E entry acknowledgement absent")
     end
    elseif row.phase=="observing" then
     if choices==3 then
      row.phase="done";log("info","Neighbor original choice actors confirmed=3; selection and rewards remain original")
     else
      assert(now-row.called<3,"Neighbor choices incomplete; measured="..choices.." required=3 elapsed="..(now-row.called))
     end
    end
   end,debug.traceback)
   if not ok then row.phase="failed";log("error","Neighbor authority transition: "..tostring(cause).."; no replay") end
  end
 end)
 return true
end
return M
