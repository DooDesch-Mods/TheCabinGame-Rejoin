local M = {}
local ROOT = "/Game/Cabin_Lobby_Content/Cards/"
local SPECS = {
    {card="LobbyDifficultyCard_BP",widget="LobbyDifficulty_WBP",value="DifficultyINT",widget_value="ChosenDifficulty",text="Difficulty",display="SelectedDifficulty_T",labels={[0]="Weenie","First-Timer","Daring","WTF!"}},
    {card="PlayerCollisionCard_BP",widget="PlayerCollision_WBP",value="Enabled",widget_value="Enabled",text="Selection",display="SelectedCollision_T",labels={[0]="Off","On"}},
    {card="IntroTutorialCard_BP",widget="IntroTutorial_WBP",value="Enabled",widget_value="Enabled",text="Selection",display="SelectedCollision_T",labels={[0]="disabled","enabled"}},
    {card="GoodieCard_BP",widget="Goodie_WBP",value="Enabled",widget_value="Enabled",text="Selection",display="SelectedCollision_T",labels={[0]="disabled","enabled"}},
}
local PRESSED = {
    [1]={[0]="Weenie_B_K2Node_ComponentBoundEvent_13", "Regular_B_K2Node_ComponentBoundEvent_15", "Hard_B_K2Node_ComponentBoundEvent_16", "WTF_B_K2Node_ComponentBoundEvent_14"},
    [2]={[0]="Regular_B_K2Node_ComponentBoundEvent_15", "Weenie_B_K2Node_ComponentBoundEvent_13"},
    [3]={[0]="Regular_B_K2Node_ComponentBoundEvent_15", "Weenie_B_K2Node_ComponentBoundEvent_13"},
    [4]={[0]="Regular_B_K2Node_ComponentBoundEvent_15", "Weenie_B_K2Node_ComponentBoundEvent_13"},
}
local function valid(o) return o and o:IsValid() end
local function address(o) assert(valid(o), "required original object unavailable"); return o:GetAddress() end
local function exact(o, path, kind) return valid(o) and o:GetClass():GetFullName() == (kind or "BlueprintGeneratedClass") .. " " .. path end
local function positive(v) return math.type(v) == "integer" and v > 0 end
local function decimal(v) return type(v) == "string" and v:match("^[1-9][0-9]*$") ~= nil end
local function label(v)
    assert(type(v) == "userdata" and v:type() == "FText", "original native FText property required")
    return v:ToString()
end
local function selection(option, index)
    assert(math.type(option) == "integer" and option >= 1 and option <= 4, "original option outside1..4")
    assert(math.type(index) == "integer" and SPECS[option].labels[index] ~= nil, "original index outside selection mapping")
    local method = "BndEvt__LobbyDifficulty_WBP_" .. PRESSED[option][index] .. "_OnButtonPressedEvent__DelegateSignature"
    return SPECS[option], method, option == 1 and index or index == 1
end

function M.new(options)
    assert(type(options) == "table", "original click adapters required")
    for _, name in ipairs({"log","context","authenticate","lobby_owner","resolve_cards","read_gi","read_save","validate_request"}) do
        assert(type(options[name]) == "function", name .. " adapter required")
    end
    local object, attempted = {}, {}
    local function log(level, text)
        local ok, cause = pcall(options.log, level, "original_click: " .. text)
        if not ok then error("original click logger cause=" .. tostring(cause) .. "; original=" .. text, 0) end
    end
    local function context(pc, request)
        assert(valid(pc) and pc:GetLocalRole() == 3 and not pc:IsActorBeingDestroyed() and valid(pc.NetConnection), "live remote authority PC required")
        local c = options.context(pc)
        assert(type(c) == "table" and address(c.pc) == address(pc) and valid(c.world)
            and address(pc:GetWorld()) == address(c.world), "actual PC/world context differs")
        assert(exact(c.gm, "/Game/Cabin_Lobby_Content/Lobby_Gamemode.Lobby_Gamemode_C") and c.gm:GetLocalRole() == 3
            and not c.gm:IsActorBeingDestroyed() and address(c.gm:GetWorld()) == address(c.world), "current original authority Lobby required")
        assert(valid(c.pawn) and not c.pawn:IsActorBeingDestroyed() and address(pc.Pawn) == address(c.pawn) and address(c.pawn.Controller) == address(pc)
            and address(c.pawn:GetWorld()) == address(c.world), "actual PC/Pawn/world ownership differs")
        assert(exact(c.gi, "/Game/CabinGameContent/CabinAdvanceFriendsGameInstance.CabinAdvanceFriendsGameInstance_C")
            and address(c.gm.AdvancedCabinGameInstance) == address(c.gi), "current original GI binding differs")
        local id, handle = options.authenticate(pc)
        assert(positive(id) and positive(handle), "actual native authentication unavailable")
        local owner = options.lobby_owner(c)
        assert(decimal(c.session_id) and type(owner) == "table" and owner.status == 1 and owner.lobby_id == c.session_id
            and decimal(owner.owner_id) and owner.owner_id == tostring(id), "native original Lobby owner/session differs")
        assert(options.validate_request(pc, c, request, id, handle) == true, "current owner grant/request provenance unavailable")
        c.steam_id, c.handle = id, handle
        return c
    end
    local function read(c, cards, save)
        local gi = options.read_gi(c.gi)
        assert(type(gi) == "table", "actual GI values unavailable")
        local result = {gi={},cards={},save=save}
        for i, spec in ipairs(SPECS) do
            local card = cards[i]
            assert(exact(card, ROOT .. spec.card .. "." .. spec.card .. "_C") and card:GetLocalRole() == 3
                and not card:IsActorBeingDestroyed() and address(card:GetWorld()) == address(c.world), "exact original authority card/world differs option=" .. i)
            local widget = card.Widget:GetWidget()
            assert(exact(widget, ROOT .. spec.widget .. "." .. spec.widget .. "_C", "WidgetBlueprintGeneratedClass")
                and address(widget.LobbyCard) == address(card), "original front widget binding differs option=" .. i)
            assert(valid(widget[spec.display]), "original selected display missing option=" .. i)
            assert(type(card.InTransition) == "boolean" and type(card.IsFlipped) == "boolean" and type(card.CanFlip) == "boolean", "original flip flags unavailable option=" .. i)
            local scalar, widget_scalar = card[spec.value], widget[spec.widget_value]
            if i == 1 then
                assert(math.type(gi[i]) == "integer" and math.type(scalar) == "integer" and math.type(widget_scalar) == "integer", "original difficulty scalar type differs")
            else assert(type(gi[i]) == "boolean" and type(scalar) == "boolean" and type(widget_scalar) == "boolean", "original option scalar type differs option=" .. i) end
            result.gi[i] = gi[i]
            result.cards[i] = {address=address(card),widget=address(widget),value=scalar,widget_value=widget_scalar,
                text=label(card[spec.text]),display=label(widget[spec.display]:GetText()),
                in_transition=card.InTransition,is_flipped=card.IsFlipped,can_flip=card.CanFlip}
        end
        assert(type(save) == "table", "actual read-only GameData values unavailable")
        for i = 1, 4 do
            assert((i == 1 and math.type(save[i]) == "integer") or (i ~= 1 and type(save[i]) == "boolean"), "GameData option type differs option=" .. i)
        end
        return result
    end
    function object.apply(pc, option, index, request)
        local ok, result = xpcall(function()
            local spec, method, expected = selection(option, index)
            assert(type(request) == "table" and positive(request.sequence) and request.option == option and request.index == index,
                "current positive request sequence and exact selection required")
            local c = context(pc, request)
            local key = tostring(address(pc)) .. ":" .. c.session_id .. ":" .. tostring(c.handle)
            assert(request.sequence > (attempted[key] or 0), "same or stale request cannot replay original callback")
            local cards = options.resolve_cards(c.world)
            assert(type(cards) == "table" and #cards == 4, "four exact original cards required")
            local before = read(c, cards, options.read_save(c))
            local card, widget = cards[option], cards[option].Widget:GetWidget()
            if card.CanFlip and not card.InTransition then
                assert(valid(card.CardMesh) and valid(card.Flip_Timeline) and valid(card.Flip_Cue), "original possible flip dependencies unavailable")
            end
            assert(type(StaticFindObject) == "function", "reflected function lookup unavailable")
            local reflected = StaticFindObject(ROOT .. spec.widget .. "." .. spec.widget .. "_C:" .. method)
            assert(valid(reflected), "exact original no-argument pressed callback unavailable")
            local current = context(pc, request)
            assert(address(current.world) == address(c.world) and current.session_id == c.session_id and current.handle == c.handle, "current binding changed before callback")
            attempted[key] = request.sequence
            log("info", "original pressed callback attempted option=" .. option .. " index=" .. index .. " sequence=" .. request.sequence .. "; original flip and GameData save included")
            widget[method](widget)
            local after_context = context(pc, request)
            assert(address(after_context.world) == address(c.world) and after_context.session_id == c.session_id
                and after_context.handle == c.handle, "current binding changed during original callback")
            local after = read(after_context, cards, options.read_save(after_context))
            for i = 1, 4 do
                local a, b = after.cards[i], before.cards[i]
                assert(a.address == b.address and a.widget == b.widget, "original card/widget replaced during callback option=" .. i)
                if i == option then
                    assert(after.gi[i] == expected and a.value == expected and a.widget_value == expected and after.save[i] == expected,
                        "original GI/card/widget/GameData scalar mismatch option=" .. i)
                    assert(a.text == a.display and a.text:lower() == spec.labels[index]:lower(), "original card/display text differs from selection")
                else
                    assert(after.gi[i] == before.gi[i] and a.value == b.value and a.widget_value == b.widget_value
                        and a.text == b.text and a.display == b.display and after.save[i] == before.save[i], "another original option changed option=" .. i)
                end
            end
            log("info", "original option GI/card/widget/GameData readback option=" .. option .. "; flip_pending=" .. tostring(after.cards[option].in_transition) .. "; actual remote replication unconfirmed")
            return {server_applied=true,option=option,index=index,sequence=request.sequence,session_id=c.session_id,
                owner_id=tostring(c.steam_id),connection_handle=c.handle,pc_address=address(pc),label=after.cards[option].text,
                persistence_readback_confirmed=true,flip_pending=after.cards[option].in_transition,
                client_display_confirmed=false,replication_delivery_confirmed=false,before=before,after=after}
        end, debug.traceback)
        if not ok then log("error", "original pressed callback cause=" .. tostring(result) .. "; attempted sequence is not replayed"); return nil, tostring(result) end
        return result
    end
    return object
end
return M
