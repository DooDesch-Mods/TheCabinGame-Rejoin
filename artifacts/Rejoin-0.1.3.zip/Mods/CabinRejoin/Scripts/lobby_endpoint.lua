local gt_scheduler = require("gt_scheduler")
local M = {}
local active
local function valid(o) return o and o:IsValid() end
local function address(o) return valid(o) and o:GetAddress() or 0 end

function M.start(options)
    assert(not active, "endpoint observer already started")
    local r = assert(options.receipt, "acknowledged authority receipt required")
    assert(r.bootstrap_confirmed and r.lobby_publication_confirmed and type(options.log) == "function", "authority publication/logger required")
    local lobby = assert(tonumber(r.session_id), "original session ID missing")
    assert(math.type(lobby) == "integer" and tostring(lobby) == r.session_id, "session ID lost precision")
    local identity = require("authority_identity")
    local lease = identity.capture(r)
    local s = {running=true, receipt=r, queued=false}
    active = s
    local function log(level,message) options.log(level,"endpoint " .. message) end
    local function failed(cause)
        s.running=false
        log("error","observation/publication cause=" .. tostring(cause) .. "; no replay")
        if options.on_error then
            local ok,why=pcall(options.on_error,cause)
            if not ok then log("error","authority failure status cause=" .. tostring(why) .. "; original=" .. tostring(cause)) end
        end
    end
    local function inspect()
        local current = identity.resolve(lease,r)
        if current.status == "session_changed" then
            s.running=false; log("info",current.cause .. "; observer stopped"); return
        end
        if current.status ~= "ready" then
            local previous=s.waiting
            s.waiting=current.cause; s.wait_count=(s.wait_count or 0)+1
            if previous~=s.waiting or s.wait_count%30==0 then
                log("info","current authority readiness pending=" .. current.cause ..
                    " cachedGI=" .. tostring(current.cached_before_resolution.cached_gi_valid) ..
                    " cachedWorld=" .. tostring(current.cached_before_resolution.cached_world_valid) ..
                    "; no publication attempted; observations=" .. s.wait_count)
            end
            return
        end
        if s.waiting then log("info","current authority readiness recovered=" .. s.waiting .. " sameGI=" .. current.gi_address .. " world=" .. current.world_address); s.waiting=nil end
        local prior=current.cached_before_resolution
        local diagnostic="cachedGI="..tostring(prior.cached_gi_valid).." cachedWorld="..tostring(prior.cached_world_valid)
        if prior.cached_gi_valid~=true or prior.cached_world_valid~=true then
            s.invalid_count=(s.invalid_count or 0)+1
            if s.invalid_reason~=diagnostic or s.invalid_count%30==0 then
                s.invalid_reason=diagnostic
            log("warn","same authority identity re-resolved cachedGI=" .. tostring(prior.cached_gi_valid) ..
                " cachedWorld=" .. tostring(prior.cached_world_valid) .. " actualGI=" .. current.gi_address ..
                " actualWorld=" .. current.world_address .. "; old wrapper cause remains unproved; observations=" .. s.invalid_count)
            end
        elseif s.invalid_reason then
            log("info","cached authority observation recovered=" .. s.invalid_reason .. "; observations=" .. s.invalid_count)
            s.invalid_reason=nil; s.invalid_count=0
        end
        local status,owner,_,_,owning,name,endpoint,cause = CabinSteamLobbySnapshot(lobby)
        assert(status == 1, "current lobby cache unavailable: " .. tostring(cause))
        if endpoint == r.endpoint then return end
        local driver = current.driver
        local measured,port,handle,sdk,detail = CabinSteamListenerPort(driver:GetAddress())
        assert((measured==1 or measured==2) and sdk==measured and port==r.port and handle>0,
            "current authority listener differs: measured=" .. tostring(measured) .. " port=" .. tostring(port) .. "/" .. r.port .. " cause=" .. tostring(detail))
        assert(endpoint ~= s.failed_endpoint, "same failed endpoint cannot replay publication")
        s.failed_endpoint=endpoint
        log("warn","original session metadata changed actual=" .. endpoint .. " required=" .. r.endpoint .. "; publication attempted")
        local published,addr_ack,port_ack,owner_ack,actual,why = CabinSteamPublishLobbyEndpoint(lobby,port)
        assert((published==1 or published==2) and addr_ack>0 and port_ack>0 and owner_ack==1 and actual==r.endpoint,
            "authority endpoint publication unconfirmed: " .. tostring(why))
        local read,after_owner,_,_,after_owning,after_name,after_endpoint,error_cause = CabinSteamLobbySnapshot(lobby)
        assert(read==1 and after_endpoint==r.endpoint and after_owner==owner and after_owning==owning and after_name==name,
            "endpoint/owner readback differs: " .. tostring(error_cause))
        s.failed_endpoint=nil
        log("info","authority endpoint restored actual=" .. after_endpoint .. "; owner/name preserved; remote propagation pending")
    end
    gt_scheduler.loop(2000,function()
        if not s.running then return true end
        if s.queued then return end
        s.queued=true
        local queued,cause=pcall(gt_scheduler.execute,function()
            local ok,why=xpcall(inspect,debug.traceback)
            if not ok then failed(why) end
            s.queued=false
        end)
        if not queued then failed("GameThread queue: " .. tostring(cause)) end
    end)
    log("info","observer registered; current metadata/listener acknowledgement pending")
    return s
end

return M
