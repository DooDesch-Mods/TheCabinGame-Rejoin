local M={}
local gt=require("gt_scheduler")
local current,observed_session,attempted_session
local MENU="World /Game/CabinGameContent/Menu.Menu"
local GI="BlueprintGeneratedClass /Game/CabinGameContent/CabinAdvanceFriendsGameInstance.CabinAdvanceFriendsGameInstance_C"
local CARD="/Game/CabinRejoin/Menu/MenuCardRejoin_WBP.MenuCardRejoin_WBP_C"
local PRESSED=CARD..":BndEvt__MenuCardRejoin_WBP_Host_B_K2Node_ComponentBoundEvent_2_OnButtonPressedEvent__DelegateSignature"
local function valid(o) return o and o:IsValid() end
local function text(v) return type(v)=="string" and v or v:ToString() end
local function integer(v,name)
    local parsed=type(v)=="string" and tonumber(v,10) or v
    assert(math.type(parsed)=="integer" and parsed>0 and (type(v)~="string" or tostring(parsed)==v),name.." exact positive integer required")
    return parsed
end
local function identity()
    local handle,online,id,app,owns,owns_app=CabinSteamClientState()
    assert(handle>0 and online==1 and math.type(id)=="integer" and id>0 and app==4406280 and owns==1 and owns_app==1,"menu original Steam identity/ownership unavailable")
    return id
end
local function instance()
    local found
    for _,v in ipairs(FindAllOf("CabinAdvanceFriendsGameInstance_C") or {}) do
        if valid(v) and not v:GetFullName():find("Default__",1,true) and valid(v:GetWorld()) then
            assert(v:GetClass():GetFullName()==GI and not found,"menu current original GI class/count differs"); found=v
        end
    end
    return found
end
local function session(gi)
    local library=StaticFindObject("/Script/AdvancedSessions.Default__AdvancedSessionsLibrary")
    assert(valid(library),"menu original session library unavailable")
    local state,id={},{}
    library:GetSessionState(gi,state); library:GetCurrentSessionID_AsString(gi,id)
    assert(math.type(state.SessionState)=="integer" and id.SessionId~=nil,"menu original session state/ID OUT missing")
    return state.SessionState,text(id.SessionId)
end
function M.decode(bytes)
    assert(type(bytes)=="string" and bytes:sub(-1)=="\n" and #bytes<=4096,"menu receipt complete bounded record required")
    local r,count={},0
    for line in bytes:gmatch("([^\n]+)\n") do
        local key,value=line:match("^([a-z_]+)=(.*)$")
        assert(key and not r[key],"menu receipt malformed/duplicate row"); r[key]=value; count=count+1
    end
    assert(count==7 and r.schema=="CabinRejoinMenuReceipt_v1" and r.complete_record=="1","menu receipt schema/field count differs")
    integer(r.owner_id,"receipt owner"); integer(r.lobby_id,"receipt lobby"); integer(r.server_owner,"receipt server owner"); integer(r.build,"receipt build")
    local server,port=r.endpoint:match("^steam%.([1-9][0-9]*):([1-9][0-9]*)$")
    assert(server and integer(server,"receipt endpoint server") and integer(port,"receipt endpoint port")<=65535,"menu receipt endpoint differs")
    return r
end
function M.observe_connection(pc,log)
    assert(valid(pc) and pc:IsLocalController() and pc:GetLocalRole()==2 and not pc:IsActorBeingDestroyed(),"menu connection receipt requires current owning remote PC")
    local gi=assert(instance(),"menu connected GI unavailable")
    assert(gi:GetWorld():GetAddress()==pc:GetWorld():GetAddress() and gi:GetWorld():GetFullName()~=MENU,"menu receipt connected world differs")
    local state,lobby=session(gi)
    if state==0 or lobby=="" then return false,"actual named session admission pending" end
    local owner=identity()
    local key=tostring(owner)..":"..lobby
    if observed_session==key then return true end
    local pawn=pc.Pawn
    if not (valid(pawn) and valid(pc.PlayerState) and pawn:IsLocallyControlled() and valid(pawn.Controller) and pawn.Controller:GetAddress()==pc:GetAddress() and valid(pc.AcknowledgedPawn) and pc.AcknowledgedPawn:GetAddress()==pawn:GetAddress()) then return false,"actual pawn/controller ownership acknowledgement pending" end
    local driver,count=nil,0
    for _,v in ipairs(FindAllOf("SteamSocketsNetDriver") or {}) do
        if valid(v) and not v:GetFullName():find("Default__",1,true) and valid(v:GetWorld()) and v:GetWorld():GetAddress()==pc:GetWorld():GetAddress() then driver,count=v,count+1 end
    end
    assert(count<=1,"menu receipt current Steam client driver ambiguous")
    if count~=1 or not valid(driver.ServerConnection) then return false,"actual Steam client ServerConnection pending" end
    local ack,_,_,_,server_owner,_,endpoint,cause=CabinSteamLobbySnapshot(integer(lobby,"connected lobby"))
    if ack~=1 then return false,"connected original lobby cache pending cause="..tostring(cause) end
    integer(server_owner,"connected server owner"); integer(gi.BuildVersionID,"connected original build")
    local bytes="schema=CabinRejoinMenuReceipt_v1\nowner_id="..owner.."\nlobby_id="..lobby.."\nendpoint="..endpoint.."\nserver_owner="..server_owner.."\nbuild="..gi.BuildVersionID.."\ncomplete_record=1\n"
    M.decode(bytes)
    if attempted_session==key then
        local read,actual=CabinMenuRejoinReceiptLoad()
        assert(read==1 and actual==bytes,"menu prior persistence failed and current readback does not prove expected receipt; no save replay cause="..tostring(actual))
        log("info","menu previous failed persistence recovered through exact receipt readback")
    else
        attempted_session=key
        local saved,why=CabinMenuRejoinReceiptSave(bytes)
        assert(saved==1,"menu previous connection save cause="..tostring(why))
    end
    observed_session=key
    if current then current.receipt=nil; current.loaded=false end
    log("info","menu own previously connected lobby receipt persisted and read back")
    return true
end
local function reason(s,level,cause)
    s.repeats=(s.reason==cause and (s.repeats or 0)+1 or 1)
    if s.reason~=cause then s.reason=cause; s.log(level,cause) end
end
local function host_busy()
    local host=require("steam_host_autostart").status()
    return host and host.phase~="waiting" and host.phase~="host_idle" and host.phase~="failed" and host.phase~="skipped"
end
local function context(gi)
    local gameplay=StaticFindObject("/Script/Engine.Default__GameplayStatics")
    assert(valid(gameplay),"menu original gameplay library unavailable")
    local pc=gameplay:GetPlayerController(gi,0)
    if not valid(pc) or pc:IsActorBeingDestroyed() then return nil,"menu original local PC pending" end
    assert(pc:IsLocalController() and valid(pc:GetWorld()) and pc:GetWorld():GetAddress()==gi:GetWorld():GetAddress(),"menu same-world local PC differs")
    local mode=gameplay:GetGameMode(gi)
    if not valid(mode) then return nil,"menu original GameMode pending" end
    local root=mode.MenuWidget
    if not valid(root) then return nil,"menu original GameMode MenuWidget pending" end
    assert(root:GetClass():GetFullName()=="WidgetBlueprintGeneratedClass /Game/MenuContent/Widgets/Menu_WBP.Menu_WBP_C" and valid(root:GetWorld()) and root:GetWorld():GetAddress()==gi:GetWorld():GetAddress(),"menu original root class/world differs")
    if not root:IsInViewport() then return nil,"menu original root viewport attachment pending" end
    local owner=root:GetOwningPlayer()
    if not valid(owner) then return nil,"menu original root owner pending" end
    assert(owner:GetAddress()==pc:GetAddress(),"menu original root owner differs")
    local row=root["3CardsHorizBox"]
    if not valid(row) then return nil,"menu original three-card row pending" end
    return root,row,pc,gameplay
end
local function child_named(class,name,widget)
    local found
    for _,v in ipairs(FindAllOf(class) or {}) do
        if valid(v) and v:GetFName():ToString():lower()==name:lower() and valid(v:GetOuter()) and valid(v:GetOuter():GetOuter()) and v:GetOuter():GetOuter():GetAddress()==widget:GetAddress() then
            assert(not found,"menu own widget child ambiguous="..name); found=v
        end
    end
    return assert(found,"menu own widget child unavailable="..name)
end
local ASSETS={
    widget={kind="class",path=CARD,prefix="WidgetBlueprintGeneratedClass",class="Class /Script/UMG.WidgetBlueprintGeneratedClass"},
    actor={kind="class",path="/Game/CabinRejoin/Menu/MenuCard_Rejoin.MenuCard_Rejoin_C",prefix="BlueprintGeneratedClass",class="Class /Script/Engine.BlueprintGeneratedClass"},
    material={kind="object",path="/Game/CabinRejoin/Menu/M_RT_MenuCardRejoin.M_RT_MenuCardRejoin",prefix="Material",class="Class /Script/Engine.Material"},
    target={kind="object",path="/Game/CabinRejoin/Menu/RT_MenuCardRejoin.RT_MenuCardRejoin",prefix="TextureRenderTarget2D",class="Class /Script/Engine.TextureRenderTarget2D"},
}
local function asset(name,log,world)
    local expected=assert(ASSETS[name],"menu fixed asset selector differs")
    assert(IsInGameThread()==true,"menu fixed soft load requires original GameThread")
    local value=StaticFindObject(expected.path)
    local cached=valid(value)
    if not cached then
        local system=StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
        assert(valid(system),"menu original soft loader library unavailable")
        log("info","menu original fixed soft load attempted path="..expected.path.." world="..world:GetFullName())
        if expected.kind=="class" then
            local reference=system:Conv_SoftClassPathToSoftClassRef(system:MakeSoftClassPath(expected.path))
            value=system:LoadClassAsset_Blocking(reference)
        else
            local reference=system:Conv_SoftObjPathToSoftObjRef(system:MakeSoftObjectPath(expected.path))
            value=system:LoadAsset_Blocking(reference)
        end
        assert(valid(value),"menu original fixed soft load returned no live object path="..expected.path)
    end
    local found=StaticFindObject(expected.path)
    assert(valid(found) and math.type(value:GetAddress())=="integer" and value:GetAddress()>0 and value:GetAddress()==found:GetAddress(),"menu fixed soft load exact path/address readback differs="..expected.path)
    assert(value:GetFullName()==expected.prefix.." "..expected.path and valid(value:GetClass()) and value:GetClass():GetFullName()==expected.class,"menu fixed soft load exact object/class differs="..expected.path)
    log("info","menu original fixed soft load confirmed path="..expected.path.." class="..expected.class.." address="..value:GetAddress().." cached="..tostring(cached).." world="..world:GetFullName())
    return value
end
local function enable(s,value,hide)
    if not valid(s.card) then return end
    local ack,cause=CabinMenuRejoinEnable(value and 1 or 0)
    assert(ack==1,"menu input guard acknowledgement cause="..tostring(cause))
    s.card.Play_B:SetIsEnabled(value); s.card.Host_B:SetIsEnabled(value)
    local join=s.phase=="join_attempted" and require("normal_join").status()
    local pending=s.phase=="click_validation" or s.phase=="join_attempted" and not (join and join.phase=="admitted")
    local visible=value or not hide and pending
    s.card:SetVisibility(visible and 0 or 1)
    assert(s.card.Play_B:GetIsEnabled()==value and s.card.Host_B:GetIsEnabled()==value and s.card:GetVisibility()==(visible and 0 or 1),"menu own card input/visibility readback differs")
end
local function create_card(s,gi,root,row,pc,gameplay)
    if valid(s.card) and s.root==root:GetAddress() then return true end
    if not (valid(root.MenuCardPlay_WBP) and valid(root.MenuCardProfile_WBP) and valid(root.MenuCardSocial_WBP)) then return false,"menu original three card widgets pending" end
    local count=row:GetChildrenCount()
    if count<3 then return false,"menu original three card row population pending" end
    require("cabin_menu_layout").originals(root,row)
    local original=root.MenuCardPlay_WBP.Play_Card
    if not valid(original) then return false,"menu original Play actor pending" end
    local profile=root.MenuCardProfile_WBP.Profile_Card
    if not valid(profile) then return false,"menu original Profile actor pending" end
    assert(original:GetAddress()~=profile:GetAddress() and valid(profile:GetWorld()) and profile:GetWorld():GetAddress()==gi:GetWorld():GetAddress(),"menu original adjacent Profile actor/world differs")
    local transform=original:GetTransform()
    local adjacent=profile:GetTransform().Translation
    local gap=adjacent.Y-transform.Translation.Y
    assert(adjacent.X==transform.Translation.X and adjacent.Z==transform.Translation.Z and gap>0,"menu original Play/Profile row spacing differs")
    transform.Translation.Y=transform.Translation.Y-gap
    local canvas=row.Slot
    assert(valid(canvas) and canvas:GetClass():GetFullName()=="Class /Script/UMG.CanvasPanelSlot" and canvas:GetAutoSize()==false,"menu original fixed Canvas row slot differs")
    local layout=canvas:GetLayout()
    assert(layout.Anchors.Minimum.X==0.5 and layout.Anchors.Maximum.X==0.5 and layout.Anchors.Minimum.Y==0.5 and layout.Anchors.Maximum.Y==0.5 and layout.Alignment.X==0 and layout.Alignment.Y==0 and layout.Offsets.Right>0 and layout.Offsets.Bottom>0,"menu original centered fixed Canvas layout differs")
    local library=StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary")
    assert(valid(library),"menu original widget Create dependency unavailable")
    local class=asset("widget",s.log,gi:GetWorld())
    local actor_class=asset("actor",s.log,gi:GetWorld())
    local material=asset("material",s.log,gi:GetWorld())
    local rt=asset("target",s.log,gi:GetWorld())
    assert(valid(class) and valid(actor_class) and valid(material) and valid(rt),"menu private original-style card package dependency unavailable")
    s.card=library:Create(gi,class,pc)
    assert(valid(s.card) and valid(s.card.Play_B) and valid(s.card.Host_B),"menu private card Create/front button failed")
    s.card:SetVisibility(1); s.card.Play_B:SetIsEnabled(false); s.card.Host_B:SetIsEnabled(false)
    local fn=StaticFindObject(PRESSED)
    assert(valid(fn),"menu own Pressed function unavailable")
    local parameters=0; fn:ForEachProperty(function() parameters=parameters+1 end)
    assert(parameters==0,"menu own Pressed signature differs")
    local ack,cause=CabinMenuRejoinArm(s.card:GetAddress(),fn:GetAddress())
    assert(ack==1,"menu own click interception cause="..tostring(cause))
    s.actor=gameplay:BeginDeferredActorSpawnFromClass(gi,actor_class,transform,1,nil,0)
    assert(valid(s.actor),"menu private actor deferred spawn failed")
    s.actor=gameplay:FinishSpawningActor(s.actor,transform,0)
    assert(valid(s.actor) and valid(s.actor.SceneCaptureComponent2D) and valid(s.actor.CardMesh),"menu private original-style actor finish failed")
    local placed=s.actor:GetTransform().Translation
    assert(math.abs(placed.X-transform.Translation.X)<0.001 and math.abs(placed.Y-transform.Translation.Y)<0.001 and math.abs(placed.Z-transform.Translation.Z)<0.001,"menu own original-spacing placement readback differs")
    s.log("info","menu own original lit-row placement confirmed Y="..placed.Y.." originalGap="..gap)
    s.card.Play_Card=s.actor
    assert(valid(s.card.Play_Card) and s.card.Play_Card:GetAddress()==s.actor:GetAddress(),"menu own card renderer binding readback differs; original Play actor preserved")
    local capture=s.actor.SceneCaptureComponent2D
    assert(valid(capture.TextureTarget) and capture.TextureTarget:GetAddress()==rt:GetAddress(),"menu clone SceneCapture owns incorrect RT; original RT preserved")
    capture.PrimitiveRenderMode=2; capture:ClearShowOnlyComponents(); capture:ShowOnlyActorComponents(s.actor,true)
    assert(capture.PrimitiveRenderMode==2,"menu clone capture isolation readback differs")
    local front=s.actor.Widget:GetWidget()
    local back=valid(s.actor.WidgetBackside) and s.actor.WidgetBackside:GetWidget()
    local menu_renderer="WidgetBlueprintGeneratedClass /Game/MenuContent/3DMenuCards/MenuCardPlay_W.MenuCardPlay_W_C"
    assert(valid(front) and front:GetClass():GetFullName()==menu_renderer and valid(back) and back:GetClass():GetFullName()==menu_renderer,"menu own duplicated original Play front/back renderer roles differ")
    assert(front:GetAddress()~=back:GetAddress(),"menu own duplicated front/back renderer instances differ")
    assert(valid(front:GetWorld()) and front:GetWorld():GetAddress()==gi:GetWorld():GetAddress() and valid(back:GetWorld()) and back:GetWorld():GetAddress()==gi:GetWorld():GetAddress(),"menu own duplicated front/back renderer worlds differ")
    for index,renderer in ipairs({front,back}) do
        assert(valid(renderer.VerticalBoxFront) and valid(renderer.VerticalBoxBack),"menu original specialized renderer visibility fields unavailable")
        renderer.Backside=index==2
        renderer.VerticalBoxFront:SetVisibility(index==1 and 0 or 2)
        renderer.VerticalBoxBack:SetVisibility(index==1 and 2 or 0)
        assert(renderer.Backside==(index==2) and renderer.VerticalBoxFront:GetVisibility()==(index==1 and 0 or 2) and renderer.VerticalBoxBack:GetVisibility()==(index==1 and 2 or 0),"menu own specialized renderer side/visibility readback differs")
    end
    s.log("info","menu own duplicated original Play renderers confirmed front="..front:GetAddress().." back="..back:GetAddress().." world="..back:GetWorld():GetFullName())
    local texts=StaticFindObject("/Script/Engine.Default__KismetTextLibrary")
    assert(valid(texts),"menu original text library unavailable")
    for _,renderer in ipairs({front,back}) do
        local title=child_named("TextBlock","Title_1",renderer)
        title:SetText(texts:Conv_StringToText("Rejoin"))
        assert(text(title:GetText())=="Rejoin","menu private front title readback differs")
        local reconnect=child_named("TextBlock","Host_T",renderer)
        reconnect:SetText(texts:Conv_StringToText("Reconnect"))
        assert(text(reconnect:GetText())=="Reconnect","menu private back entry readback differs")
        local box=renderer.VerticalBoxBack
        local slot=reconnect.Slot
        assert(valid(box) and reconnect:GetParent():GetAddress()==box:GetAddress() and box:GetChildrenCount()==6,"menu own original back entry layout differs")
        assert(valid(slot) and slot:GetClass():GetFullName()=="Class /Script/UMG.VerticalBoxSlot" and slot.Size.Value==1 and slot.Size.SizeRule==0 and slot.HorizontalAlignment==0 and slot.VerticalAlignment==0,"menu own original Reconnect text slot differs")
        local names={"Spacer_70","Single_T","Image","Host_T","Image_1","Joint"}
        local children={}
        for index,name in ipairs(names) do
            local child=box:GetChildAt(index-1)
            assert(valid(child) and child:GetFName():ToString():lower()==name:lower(),"menu own original back child order differs="..name)
            children[index]=child
        end
        assert(children[4]:GetAddress()==reconnect:GetAddress(),"menu own original Reconnect child identity differs")
        s.log("info","menu own single Reconnect text centering attempted")
        for _,child in ipairs(children) do
            if child:GetAddress()~=reconnect:GetAddress() then
                child:SetVisibility(1)
                assert(child:GetVisibility()==1,"menu own unused back child visibility differs="..child:GetFName():ToString())
            end
        end
        slot:SetSize({Value=1,SizeRule=1}); slot:SetVerticalAlignment(2)
        assert(slot.Size.Value==1 and slot.Size.SizeRule==1 and slot.VerticalAlignment==2 and slot.HorizontalAlignment==0,"menu own centered Reconnect text readback differs")
        s.log("info","menu own single Reconnect text centering confirmed")
    end
    for _,name in ipairs({"Single_B","Join_B","Single_Progressbar","Join_Progressbar"}) do
        local child=s.card[name]
        assert(valid(child),"menu own unused back control unavailable="..name)
        child:SetVisibility(1)
        assert(child:GetVisibility()==1,"menu own unused back control visibility differs="..name)
    end
    local button=s.card.Host_B.Slot
    assert(valid(button) and button:GetClass():GetFullName()=="Class /Script/UMG.CanvasPanelSlot","menu own original Reconnect button slot differs")
    local button_layout=button:GetLayout()
    assert(button_layout.Anchors.Minimum.X==0.5 and button_layout.Anchors.Minimum.Y==0.5 and button_layout.Anchors.Maximum.X==0.5 and button_layout.Anchors.Maximum.Y==0.5 and button_layout.Alignment.X==0 and button_layout.Alignment.Y==0 and button_layout.Offsets.Right>0 and button_layout.Offsets.Bottom>0,"menu own original Reconnect button layout differs")
    s.log("info","menu own Reconnect button/hover centering attempted; original dimensions and hover style retained")
    button:SetAlignment({X=0.5,Y=0.5}); button:SetPosition({X=0,Y=0})
    local centered=button:GetLayout()
    assert(centered.Alignment.X==0.5 and centered.Alignment.Y==0.5 and centered.Offsets.Left==0 and centered.Offsets.Top==0 and centered.Offsets.Right==button_layout.Offsets.Right and centered.Offsets.Bottom==button_layout.Offsets.Bottom and centered.Anchors.Minimum.X==button_layout.Anchors.Minimum.X and centered.Anchors.Minimum.Y==button_layout.Anchors.Minimum.Y and centered.Anchors.Maximum.X==button_layout.Anchors.Maximum.X and centered.Anchors.Maximum.Y==button_layout.Anchors.Maximum.Y,"menu own centered Reconnect button readback differs")
    s.log("info","menu own Reconnect button/hover centering confirmed")
    local border=child_named("Border","Border_42",s.card)
    border:SetBrushFromMaterial(material)
    assert(valid(border.Background.ResourceObject) and border.Background.ResourceObject:GetAddress()==material:GetAddress(),"menu own card material readback differs")
    s.actor:FlipStart_E(); capture:CaptureScene()
    require("cabin_menu_layout").attach(root,row,"rejoin",s.card,"left")
    s.menu_root=root; s.menu_row=row
    s.root=root:GetAddress(); s.requests=CabinMenuRejoinRequests()
    s.log("info","menu own fourth card attached left; original three widget identities/order retained; actual render/input preview pending")
    return true
end
local function fresh(s,gi)
    local ack,lobby,cause=CabinMenuRejoinLobbyStatus()
    assert(lobby==s.receipt.lobby_id,"menu refresh callback lobby differs")
    if ack==0 then reason(s,"info",cause); return false end
    if ack==-1 then s.available=false; reason(s,"warn",cause); return false end
    assert(ack==1 and tostring(identity())==s.receipt.owner_id,"menu fresh callback/current Steam identity differs")
    local cached,_,address,port,owner,_,endpoint,why=CabinSteamLobbySnapshot(integer(lobby,"fresh lobby"))
    assert(cached==1 and endpoint==s.receipt.endpoint and (not s.receipt.server_owner or owner==s.receipt.server_owner),"menu fresh previous lobby endpoint/owner differs cause="..tostring(why))
    local read,bytes=CabinSteamLobbyRequiredMetadata(integer(lobby,"fresh metadata lobby"))
    assert(read==1,"menu fresh original lobby metadata cause="..tostring(bytes))
    local rows={}
    for line in bytes:gmatch("[^\n]+") do
        local key,value=line:match("^([%w_]+)=(.*)$")
        assert(key and rows[key]==nil,"menu original required metadata row invalid/duplicate"); rows[key]=value
    end
    for _,key in ipairs({"NUMPUBCONN","NUMPRIVCONN","SESSIONFLAGS","BUILDID","OWNINGID","OWNINGNAME","NUMOPENPRIVCONN","NUMOPENPUBCONN","CONMETHOD","P2PADDR","P2PPORT","BuildVersionID_i"}) do
        if rows[key]==nil or rows[key]=="" then reason(s,"info","previous original lobby metadata missing="..key); return false end
    end
    if rows.original_build_cache_flag=="0" then reason(s,"info","original native BuildID cache not initialized"); return false end
    assert(rows.original_build_cache_flag=="1" and rows.BUILDID==rows.original_build_cache_value,"menu original native BUILDID differs")
    assert(rows.P2PADDR==address and rows.P2PPORT==port,"menu original cached endpoint changed between getters")
    local build=rows.BuildVersionID_i
    assert(build==tostring(gi.BuildVersionID) and (not s.receipt.build or build==s.receipt.build),"menu previous session/current original build differs")
    return true
end
local function request_refresh(s)
    local ack,cause=CabinMenuRejoinLobbyRefresh(integer(s.receipt.lobby_id,"previous lobby"))
    assert(ack==1,"menu lobby refresh start cause="..tostring(cause))
    s.available=false
end
local function original_hover_return(s,root,row,world)
    if row:GetVisibility()~=4 then return end
    local hovered=s.card:IsHovered()
    assert(type(hovered)=="boolean","menu own original exclusivity hover state differs")
    if not hovered then return end
    require("cabin_menu_layout").unhover_peer(root,row,"rejoin")
    local originals={
        {widget=root.MenuCardPlay_WBP,actor="Play_Card",class="Play",event="Unhovered_E"},
        {widget=root.MenuCardProfile_WBP,actor="Profile_Card",class="Profile",event="Unhover_E"},
        {widget=root.MenuCardSocial_WBP,actor="Social_Card",class="Social",event="Unhovered_E"},
    }
    local addresses={}
    for index,value in ipairs(originals) do
        local widget=value.widget
        assert(valid(widget) and widget:GetAddress()~=s.card:GetAddress() and row:GetChildAt(index):GetAddress()==widget:GetAddress(),"menu original hover exclusivity identity/order differs="..value.class)
        assert(widget:GetClass():GetFullName()=="WidgetBlueprintGeneratedClass /Game/MenuContent/3DMenuCards/MenuCard"..value.class.."_WBP.MenuCard"..value.class.."_WBP_C" and valid(widget:GetWorld()) and widget:GetWorld():GetAddress()==world:GetAddress(),"menu original hover exclusivity widget class/world differs="..value.class)
        local actor=widget[value.actor]
        if not valid(actor) or actor:IsActorBeingDestroyed() then return end
        assert(actor:GetAddress()~=s.actor:GetAddress() and not addresses[actor:GetAddress()] and actor:GetClass():GetFullName()=="BlueprintGeneratedClass /Game/MenuContent/3DMenuCards/MenuCard_"..value.class..".MenuCard_"..value.class.."_C" and valid(actor:GetWorld()) and actor:GetWorld():GetAddress()==world:GetAddress(),"menu original hover exclusivity actor class/world/binding differs="..value.class)
        addresses[actor:GetAddress()]=true
        value.bound=actor
        value.hovered=widget:IsHovered()
        assert(type(value.hovered)=="boolean" and type(actor.PlayFlip)=="boolean" and type(actor.Disabled)=="boolean","menu original hover exclusivity state differs="..value.class)
    end
    s.original_return=s.original_return or {}
    for index,value in ipairs(originals) do
        local actor=value.bound
        local state=s.original_return[index] or {log=s.log}; s.original_return[index]=state
        if not value.hovered and actor.PlayFlip then
            if actor.Disabled then reason(state,"info","menu original "..value.class.." hover return waits for enabled actor")
            else
                assert(valid(actor.Flip_TL),"menu original hover return timeline unavailable="..value.class)
                s.log("info","menu original "..value.class.." hover return attempted; own Rejoin hovered; original not hovered; no Join")
                value.widget[value.event](value.widget)
                assert(actor.PlayFlip==false and actor.Flip_TL:IsReversing()==true,"menu original hover return timeline direction readback differs="..value.class)
                s.log("info","menu original "..value.class.." hover return confirmed PlayFlip=false timeline reverse")
                state.reason=nil
            end
        end
    end
end
local function hover_return(s)
    local hovered=s.card:IsHovered()
    assert(type(hovered)=="boolean","menu own card hover state differs")
    if hovered then s.return_front=nil
    elseif s.was_hovered or s.actor.PlayFlip and require("cabin_menu_layout").peer_hovered(s.menu_root,s.menu_row,"rejoin") then s.return_front=true end
    s.was_hovered=hovered
    if not s.return_front then return true end
    assert(type(s.actor.Disabled)=="boolean","menu own actor Disabled state differs")
    if s.actor.Disabled then reason(s,"info","menu own original hover return waits for enabled actor"); return false end
    assert(valid(s.card.Play_Card) and s.card.Play_Card:GetAddress()==s.actor:GetAddress() and valid(s.actor.Flip_TL),"menu own hover return actor/timeline binding differs")
    s.log("info","menu own original Unhovered_E return attempted; no Join")
    s.card:Unhovered_E()
    assert(s.actor.PlayFlip==false and s.actor.Flip_TL:IsReversing()==true,"menu own original hover return timeline direction readback differs")
    s.return_front=nil
    s.log("info","menu own original hover return confirmed PlayFlip=false timeline reverse; visual completion pending")
    return true
end
local function advance(s)
    local gi=instance()
    if not gi or gi:GetWorld():GetFullName()~=MENU then
        if not gi then reason(s,"info","menu current original GI/world pending") end
        if gi then
            local gameplay=StaticFindObject("/Script/Engine.Default__GameplayStatics")
            assert(valid(gameplay),"menu connected original gameplay library unavailable")
            local pc=gameplay:GetPlayerController(gi,0)
            if valid(pc) and pc:IsLocalController() and pc:GetLocalRole()==2 then
                local ran,saved,cause=xpcall(function() return M.observe_connection(pc,s.log) end,debug.traceback)
                if not ran then reason(s,"error","menu previous connection receipt failed cause="..tostring(saved))
                elseif not saved then reason(s,"info","menu previous connection receipt waits cause="..tostring(cause)) end
            end
        end
        s.menu_world=nil; s.loaded=false; s.phase="waiting"; enable(s,false); return
    end
    local ready,cause=require("normal_join").retry_measure()
    if not ready or host_busy() then enable(s,false); reason(s,"info",not ready and cause or "original Host Create/Join in flight; rejoin card waits"); return end
    if s.menu_world~=gi:GetWorld():GetAddress() then
        s.menu_world=gi:GetWorld():GetAddress(); s.loaded=false; s.phase="waiting"
    end
    if not s.loaded then
        s.loaded=true; s.available=false; s.receipt=nil
        local ack,bytes=CabinMenuRejoinReceiptLoad()
        assert(ack~=-1,"menu own prior receipt load cause="..tostring(bytes))
        if ack==1 then s.receipt=M.decode(bytes); request_refresh(s)
        elseif not s.resume_attempted then
            s.resume_attempted=true
            local resumed,why=CabinHostAuthorityResume(identity())
            assert(resumed~=-1,"menu own authority validation cause="..tostring(why))
            s.authority_pending=resumed==1
            reason(s,"info",resumed==1 and "own authority receipt validated; availability pending; explicit card click required" or why)
        end
    end
    if s.authority_pending and not s.receipt then
        local ack,lobby,endpoint,why=CabinHostAuthorityStatus()
        assert(ack~=-1,"menu own authority status cause="..tostring(why))
        if ack==0 then reason(s,"info",why); return end
        s.receipt={owner_id=tostring(identity()),lobby_id=lobby,endpoint=endpoint}; s.authority_pending=false; request_refresh(s)
    end
    if not s.receipt then return end
    if not fresh(s,gi) then enable(s,false); return end
    local root,row,pc,gameplay=context(gi)
    if not root then enable(s,false,true); reason(s,"info",row); return end
    local created,why=create_card(s,gi,root,row,pc,gameplay)
    if not created then enable(s,false,true); reason(s,"info",why); return end
    if not valid(s.actor) or s.actor:IsActorBeingDestroyed() then
        enable(s,false,true); s.return_front=nil; s.was_hovered=nil
        reason(s,"info","menu own actor unavailable/destroying; no hover action or Join")
        return
    end
    assert(valid(s.actor:GetWorld()) and s.actor:GetWorld():GetAddress()==gi:GetWorld():GetAddress(),"menu own actor current world differs; no hover action or Join")
    local count=CabinMenuRejoinRequests()
    if count~=s.requests then
        assert(count==s.requests+1 and s.phase=="available","menu unexpected/repeated rejoin request; no duplicate Join")
        s.requests=count; s.phase="click_validation"; enable(s,false); request_refresh(s)
        s.log("info","menu explicit card click accepted; fresh original lobby acknowledgement pending")
        return
    end
    if s.phase=="click_validation" then
        local reset,why=require("normal_join").retry_after_create("rejoin card")
        assert(reset,"menu explicit rejoin original idle guard cause="..tostring(why))
        s.phase="join_attempted"; enable(s,false)
        local started,error=require("normal_join").start({log=s.log,lobby_id=s.receipt.lobby_id,expected_endpoint=s.receipt.endpoint,source="explicit rejoin card"})
        assert(started==true,"menu explicit guarded original Join start cause="..tostring(error))
        s.log("info","menu explicit guarded original Join observer started once; actual admission pending")
        return
    end
    if s.phase=="join_attempted" then enable(s,false); return end
    original_hover_return(s,root,row,gi:GetWorld())
    if not hover_return(s) then enable(s,false); return end
    s.phase="available"; s.available=true
    enable(s,row:GetVisibility()==4)
    reason(s,"info","previous disconnected session available through explicit fourth card")
end
function M.start(options)
    assert(not current,"menu rejoin module already started")
    local s={log=assert(options.log),phase="waiting",requests=0}; current=s
    if os.getenv("CABIN_REJOIN_PROCESS_ID") then s.phase="skipped"; s.log("info","menu rejoin UI skipped for background authority"); return true end
    for _,name in ipairs({"CabinMenuRejoinReceiptSave","CabinMenuRejoinReceiptLoad","CabinMenuRejoinLobbyRefresh","CabinMenuRejoinLobbyStatus","CabinMenuRejoinArm","CabinMenuRejoinEnable","CabinMenuRejoinRequests"}) do assert(type(_G[name])=="function","menu native dependency unavailable="..name) end
    gt.loop(100,function()
        if s.phase=="failed" then return true end
        if s.queued then return end; s.queued=true
        local queued,cause=pcall(gt.execute,function()
            local ok,why=xpcall(function() advance(s) end,debug.traceback); s.queued=false
            if not ok then
                s.phase="failed"; s.cause=tostring(why); s.log("error","menu rejoin cause="..s.cause.."; no Join replay")
                local disabled,error=pcall(enable,s,false)
                if not disabled then s.log("error","menu own failure input cleanup cause="..tostring(error)) end
            end
        end)
        if not queued then s.queued=false; s.phase="failed"; s.cause=tostring(cause); s.log("error","menu rejoin game-thread queue cause="..s.cause.."; no Join") end
    end)
    s.log("info","manual menu rejoin observer registered; no startup Join or authority spawn")
    return true
end
function M.status() return current end
return M
