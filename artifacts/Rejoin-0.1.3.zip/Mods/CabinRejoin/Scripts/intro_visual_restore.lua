local M = {}
local CLASS = "BlueprintGeneratedClass /Game/CabinGameContent/Event_BPs/Other_Event_Stuff/Intro/3SkeletonsIntro_BP.3SkeletonsIntro_BP_C"
local COMPONENTS = {"DefaultSceneRoot", "Right_Skeleton_Skull_Jaw2", "Right_Skeleton_Skull_Top2", "Right_Skeleton_Body",
    "Right_Skeleton_Skull_Jaw1", "Right_Skeleton_Skull_Top1", "Left_Skeleton_Body", "Right_Skeleton_Skull_Jaw",
    "Right_Skeleton_Skull_Top", "Middle_Skeleton_Body", "StaticMesh3", "Intro_Skele_Clothes_Left",
    "Intro_Skele_Clothes_Right", "Intro_Skele_Clothes_Middle", "StaticMesh2", "StaticMesh1", "StaticMesh", "PointLight",
    "INTRO_TUTORIAL_SKELETONS", "INTRO_TUTORIAL_SKELETONS_THREEfbx", "INTRO_TUTORIAL_SKELETONS_TWO"}
local TIMELINES = {"Timeline", "Timeline_0", "Timeline_1", "MoveSkulls_TL", "FadeSkeletons_TL", "LightningEffect_TL"}
local function valid(object) return object and object:IsValid() end
local function address(object) return valid(object) and object:GetAddress() or 0 end
local function same_world(actor, pawn) return address(actor:GetWorld()) ~= 0 and address(actor:GetWorld()) == address(pawn:GetWorld()) end
local observed
local function timelines(actor)
    local playing = {}
    for _, name in ipairs(TIMELINES) do
        assert(valid(actor[name]), "Intro visual timeline unavailable=" .. name)
        if actor[name]:IsPlaying() then playing[#playing+1] = name end
    end
    return #playing == 0 and "none" or table.concat(playing, ",")
end
local function diagnose(pawn, message)
    local world = address(pawn:GetWorld())
    local previous, now = observed, os.time()
    if not previous or previous.world ~= world or previous.message ~= message or now - previous.time >= 60 then
        print("[CabinRejoin] info: authority Intro visual capture world=" .. world .. " " .. message .. "\n")
        observed = {world=world, message=message, time=now}
    end
end
local function resolve(pawn, authority)
    local found
    for _, actor in ipairs(FindAllOf("3SkeletonsIntro_BP_C") or {}) do
        if valid(actor) and not actor:IsActorBeingDestroyed() and same_world(actor, pawn)
            and actor:GetClass():GetFullName() == CLASS then
            assert(not found, "ambiguous current-world original Intro visual actor")
            assert(actor:HasAuthority() == authority, "Intro visual actor authority differs")
            found = actor
        end
    end
    return found
end
function M.capture(pawn, key_of)
    local actor = resolve(pawn, true)
    if not actor then diagnose(pawn, "actor absent; current live exact-class search confirmed"); return nil end
    local row = {actor = key_of(actor), components = {}}
    local states = {}
    for index, name in ipairs(COMPONENTS) do
        local component = actor[name]
        assert(valid(component), "authority Intro visual component unavailable=" .. name)
        assert(address(component:GetOwner()) == actor:GetAddress(), "authority Intro visual component owner differs=" .. name)
        row.components[index] = {visible = component:IsVisible(), hidden = component.bHiddenInGame}
        assert(type(row.components[index].visible) == "boolean" and type(row.components[index].hidden) == "boolean", "authority Intro visual flags unavailable=" .. name)
        states[index] = name .. ":" .. tostring(row.components[index].visible) .. "/" .. tostring(row.components[index].hidden)
    end
    diagnose(pawn, "actor=" .. row.actor .. " visible/hidden=" .. table.concat(states, ",") .. " playing=" .. timelines(actor))
    return row
end
function M.visit(world, reading, api)
    local present = api.flag(reading and nil or world.intro_visual ~= nil)
    if not present then return end
    local row = world.intro_visual or {}; world.intro_visual = row
    row.actor = api.text(row.actor)
    assert(row.actor:match("^[%w_]+$"), "snapshot Intro visual key differs")
    row.components = row.components or {}
    for index = 1, #COMPONENTS do
        local item = row.components[index] or {}; row.components[index] = item
        item.visible, item.hidden = api.flag(item.visible), api.flag(item.hidden)
    end
    assert(#row.components == #COMPONENTS, "snapshot Intro visual component count differs")
end
function M.prepare(pawn, world, key_of)
    if not world.intro_visual then
        local actor = resolve(pawn, false)
        if actor then return nil, "waiting for absent authority Intro actor to leave client world=" .. key_of(actor) end
        return {}
    end
    local row = world.intro_visual
    assert(type(row.actor) == "string" and row.actor:match("^3SkeletonsIntro_BP_C_%d+$"), "snapshot Intro visual actor class differs")
    -- Replicated actor instance names can differ between authority and a recreated client.
    local actor = resolve(pawn, false)
    if not actor then return nil, "waiting for original Intro visual actor=" .. row.actor end
    local prepared = {actor = actor, actor_address = actor:GetAddress(), actor_key = key_of(actor),
        world_address = address(pawn:GetWorld()), pawn = pawn, key_of = key_of, row = row, components = {}}
    for index, name in ipairs(COMPONENTS) do
        local component = actor[name]
        if not valid(component) then return nil, "waiting for original Intro visual component=" .. name end
        assert(address(component:GetOwner()) == actor:GetAddress(), "local Intro visual component owner differs=" .. name)
        prepared.components[index] = component
    end
    return prepared
end
function M.apply(prepared, log)
    if not prepared.actor then return end
    assert(valid(prepared.actor) and not prepared.actor:IsActorBeingDestroyed() and same_world(prepared.actor, prepared.pawn)
        and prepared.actor:GetClass():GetFullName() == CLASS and not prepared.actor:HasAuthority()
        and prepared.actor:GetAddress() == prepared.actor_address and address(prepared.pawn:GetWorld()) == prepared.world_address
        and prepared.key_of(prepared.actor) == prepared.actor_key
        and address(resolve(prepared.pawn, false)) == prepared.actor_address, "Intro visual actor binding changed before local restore")
    log("info", "Intro visual restore attempted authority_actor=" .. prepared.row.actor .. " local_actor=" .. prepared.actor_key .. " components=" .. #COMPONENTS .. " playing=" .. timelines(prepared.actor))
    for index, component in ipairs(prepared.components) do
        assert(valid(component), "Intro visual component ended=" .. COMPONENTS[index])
        assert(address(component:GetOwner()) == prepared.actor:GetAddress(), "Intro visual component owner changed=" .. COMPONENTS[index])
        local wanted = prepared.row.components[index]
        component:SetVisibility(wanted.visible, false)
        component:SetHiddenInGame(wanted.hidden, false)
        assert(component:IsVisible() == wanted.visible and component.bHiddenInGame == wanted.hidden,
            "Intro visual restore not acknowledged component=" .. COMPONENTS[index])
    end
    log("info", "Intro visual restore component readback confirmed authority_actor=" .. prepared.row.actor .. " local_actor=" .. prepared.actor_key)
end
return M
