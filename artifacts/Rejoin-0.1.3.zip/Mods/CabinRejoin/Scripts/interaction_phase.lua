local refs=require('bound_refs')
local M={}
local labels=require('choice_labels')
local SITTING='IsSitting_13_5E5832C3491A59936F87C7A815E64A59'
local CARRY='UniversalBool_A_16_23558E974CE1E96862AEFFB2410CC6A8'
local RADIO='/Game/CabinGameContent/Event_BPs/Other_Event_Stuff/Intro/IntroRadio_BP.IntroRadio_BP_C:'
local function valid(v) return v and v:IsValid() end
local function address(v) return valid(v) and v:GetAddress() or 0 end
local function live(v) return valid(v) and not v:IsActorBeingDestroyed() end
local function boolean(v,label) assert(type(v)=='boolean','original phase Bool unavailable='..label);return v end
local function key(v,label) assert(type(v)=='string' and v:match('^[%w_]+$'),'original phase key invalid='..label);return v end
local function integer(v,label) assert(math.type(v)=='integer','original phase integer unavailable='..label);return v end
local function class(v) return v:GetClass():GetFullName():match('([^%.]+)$') end
local function world(a,b) return address(a:GetWorld())~=0 and address(a:GetWorld())==address(b:GetWorld()) end
local function copy(v) if type(v)~='table' then return v end;local r={};for k,x in pairs(v) do r[k]=copy(x) end;return r end
local function pose(v)
    local p,r=v:K2_GetActorLocation(),v:K2_GetActorRotation()
    return {p.X,p.Y,p.Z,r.Pitch,r.Yaw,r.Roll}
end
local function same_pose(v,before)
    local after=pose(v);for i=1,6 do assert(after[i]==before[i],'local widget restore changed interaction actor pose') end
end

function M.contract(row)
    assert(type(row)=='table' and (row.kind=='radio' or row.kind=='neighbor' or row.kind=='thief'),'current interaction kind unavailable')
    assert(row.source=='original_authority_phase','original Authority phase provenance required')
    for _,name in ipairs({'actor','board','world','epoch'}) do key(row[name],name) end
    assert(integer(row.generation,'generation')>0 and integer(row.revision,'revision')>0,'current phase generation/revision required')
    integer(row.turn,'turn');assert(row.stance=='seated' or row.stance=='standing','current Authority stance unavailable')
    for _,name in ipairs({'pawn_halted','board_halted','special_halted','carry'}) do boolean(row[name],name) end
    assert(type(row.items)=='table' and #row.items<=32,'bounded current original interaction actors required')
    local names={}
    for _,item in ipairs(row.items) do
        assert(type(item.pose)=='table' and #item.pose==6,'original interaction pose required');for i=1,6 do assert(type(item.pose[i])=='number' and math.abs(item.pose[i])<10000000,'bounded finite interaction pose required') end
        key(item.key,'item');assert(not names[item.key],'duplicate interaction actor');names[item.key]=true
        assert(item.class=='NeighborChoice_BP_C' or item.class=='ThiefChoiceCard_BP_C' or item.class=='Lever_BP_C','unsupported original interaction actor')
        for _,name in ipairs({'disabled','held','dropped','enable','picked'}) do boolean(item[name],name) end
        integer(item.card_type,'CardType');integer(item.card_num,'CardNum')
        if item.class=='NeighborChoice_BP_C' or item.class=='ThiefChoiceCard_BP_C' then labels.values(item.class,item.card_type) end
        assert(item.owner=='owner' or item.owner=='none','current interaction owner must be explicit')
        if row.kind=='neighbor' then assert(item.class=='NeighborChoice_BP_C' and item.owner=='owner','original Neighbor member/owner differs') end
        if row.kind=='thief' then assert((item.class=='ThiefChoiceCard_BP_C' or item.class=='Lever_BP_C') and (item.owner=='none' or (item.class=='ThiefChoiceCard_BP_C' and item.owner=='owner' and item.held and row.carry)),'original Thief member/owner differs') end
    end
    if row.kind=='radio' then assert(row.stance=='seated' and row.turn==-1 and #row.items==0,'current seated preturn Radio required') end
    if row.kind=='neighbor' then assert(#row.items==3,'exact original three Neighbor choices required') end
    if row.kind=='thief' then
        assert(#row.items>0,'current original Thief interaction members required')
        local held=0;for _,item in ipairs(row.items) do if item.owner=='owner' then held=held+1 end end
        assert(held==(row.carry and 1 or 0),'current original Thief carry/holder count differs')
    end
    return row
end

function M.new(o)
    for _,name in ipairs({'context','find','key','log'}) do assert(type(o[name])=='function','interaction phase adapter missing='..name) end
    local active,attempted,radio,failed,revision=true,false,nil,nil,0
    local api={}
    local function safe(operation,fn)
        local ok,cause=pcall(fn)
        if not ok then failed=tostring(cause);o.log('error','interaction observer '..operation..' cause='..failed..'; current Radio history unavailable') end
        return ok,cause
    end
    function api.observe(event,actor)
        assert(event=='start' or event=='clear','original Radio observer event required')
        if not live(actor) or not actor:HasAuthority() then return false end
        if event=='clear' then
            if radio and radio.address==actor:GetAddress() then radio=nil end
            return true
        end
        revision=revision+1
        radio={address=actor:GetAddress(),world=actor:GetWorld():GetAddress(),revision=revision};failed=nil
        return true
    end
    function api.capture(pawn)
        local c,cause=o.context(pawn);if not c then return nil,cause end
        assert(c.authenticated and c.authority and c.roster_matches==1 and live(c.board),'current authenticated original Board required')
        local board=c.board
        if board.GameEndTime then return nil,'original interaction round ending' end
        local stance=boolean(pawn.GameplayVars[SITTING],'GameplayVars.IsSitting') and 'seated' or 'standing'
        local base={source='original_authority_phase',board=o.key(board),world=o.key(pawn:GetWorld()),epoch=tostring(c.epoch):gsub(':','_'),
            generation=c.generation,revision=c.generation,turn=board.PlayerTurn,stance=stance,
            pawn_halted=boolean(pawn.GameHalted,'Pawn.GameHalted'),board_halted=boolean(board.HaltGame,'Board.HaltGame'),
            special_halted=boolean(board.SpecialEventHalt,'Board.SpecialEventHalt'),carry=boolean(pawn.PlayerEventVariables[CARRY],'PlayerEventVariables.UniversalBool_A'),items={}}
        local radios=o.find('IntroRadio_BP_C',pawn)
        if radio and not failed and radio.world==address(pawn:GetWorld()) and board.PlayerTurn==-1 then
            for _,actor in ipairs(radios) do
                if live(actor) and actor:HasAuthority() and actor:GetAddress()==radio.address then
                    base.kind,base.actor,base.revision='radio','radio',radio.revision
                    return M.contract(base)
                end
            end
            return nil,'observed original Radio actor ended or unresolved'
        end
        local neighbor
        for _,actor in ipairs(o.find('TheNeighbor_BP_C',pawn)) do
            if live(actor) and actor:HasAuthority() and world(actor,pawn) and address(actor.SpecificPlayer)==address(pawn) then
                local items={};local complete=true
                for _,name in ipairs({'ChoiceA_BP','ChoiceB_BP','ChoiceC_BP'}) do
                    local item=actor[name]
                    if not live(item) or class(item)~='NeighborChoice_BP_C' or not world(item,pawn) then complete=false;break end
                    assert(address(item.SpecificPlayer)==address(pawn),'original Neighbor choice owner differs')
                    items[#items+1]={key=name,class=class(item),pose=refs.pose(item),owner='owner',disabled=boolean(item.Disable,'NeighborChoice.Disable'),
                        card_type=integer(item.CardType,'NeighborChoice.CardType'),card_num=integer(item.CardNum,'NeighborChoice.CardNum'),
                        picked=boolean(item.WasPicked,'NeighborChoice.WasPicked'),held=false,dropped=false,enable=false}
                end
                if complete then assert(not neighbor,'ambiguous current original Neighbor choices');neighbor={actor=actor,items=items} end
            end
        end
        if neighbor then base.kind,base.actor,base.items='neighbor','neighbor',neighbor.items;return M.contract(base) end
        local tables=o.find('ThiefTable_BP_C',pawn)
        local selected
        for _,actor in ipairs(tables) do
            if live(actor) and actor:HasAuthority() and world(actor,pawn) then
                local items={};local usable=false
                for _,item in ipairs(o.find('ThiefChoiceCard_BP_C',pawn)) do
                    if live(item) and item:HasAuthority() and world(item,pawn) and address(item.ThiefTable)==address(actor) then
                        local disabled=boolean(item.DisableInteractions,'ThiefChoice.DisableInteractions')
                        usable=usable or not disabled
                        items[#items+1]={key=o.key(item),class=class(item),pose=refs.pose(item),owner=item.IsBeingHeld and address(item['Player Character'])==address(pawn) and 'owner' or 'none',disabled=disabled,
                            card_type=integer(item.CardType,'ThiefChoice.CardType'),card_num=0,
                            held=boolean(item.IsBeingHeld,'ThiefChoice.IsBeingHeld'),dropped=boolean(item.IsDroppedOff,'ThiefChoice.IsDroppedOff'),enable=false,picked=false}
                    end
                end
                for _,item in ipairs(o.find('Lever_BP_C',pawn)) do
                    if live(item) and item:HasAuthority() and world(item,pawn) and address(item.ThiefTable)==address(actor) then
                        local enabled=boolean(item.Enable,'Lever.Enable');usable=usable or enabled
                        items[#items+1]={key=o.key(item),class=class(item),pose=refs.pose(item),owner='none',disabled=false,card_type=0,card_num=0,held=false,dropped=false,enable=enabled,picked=false}
                    end
                end
                if usable then assert(not selected,'ambiguous current original Thief interaction');selected={actor=actor,items=items} end
            end
        end
        if selected then
            assert(stance=='standing','original Thief world interaction requires current standing stance')
            base.kind,base.actor,base.items='thief','thief',selected.items
            table.sort(base.items,function(a,b)
                if a.class~=b.class then return a.class<b.class end
                if a.card_type~=b.card_type then return a.card_type<b.card_type end
                for i=1,6 do if a.pose[i]~=b.pose[i] then return a.pose[i]<b.pose[i] end end
                error('ambiguous original Thief member class/type/pose')
            end)
            for i,item in ipairs(base.items) do item.key='thief_'..i end
            return M.contract(base)
        end
        return nil,failed and ('original Radio history failed: '..failed) or 'no current original Radio/choice actor binding'
    end
    function api.register()
        assert(not attempted,'interaction observer registration already attempted');attempted=true
        local ok,cause=safe('register',function()
            for _,event in ipairs({'StartRadio_E','ClearEverything_E'}) do
                assert(StaticFindObject(RADIO..event):IsValid(),'original Radio UFunction unavailable='..event)
                local pre,post=RegisterHook(RADIO..event,function(context)
                    if active then safe(event,function() api.observe(event=='StartRadio_E' and 'start' or 'clear',context:get()) end) end
                end)
                assert(type(pre)=='number' and pre~=0 and type(post)=='number' and post~=0,'original Radio script post-hook registration failed='..event)
            end
        end)
        if not ok then active=false end
        return ok,cause
    end
    function api.ended(actor) if radio and (radio.address==actor or radio.world==actor) then radio=nil end end
    function api.clear() radio,failed=nil,nil end
    function api.stop() active=false;radio=nil end
    return api
end

function M.visit(snapshot,reading,f)
    local enabled=snapshot.mode=='radio_seated' or snapshot.mode=='world_choice'
    if not enabled then assert(snapshot.interaction_phase==nil,'interaction data outside its mode');return snapshot end
    local row=reading and {} or copy(M.contract(snapshot.interaction_phase))
    for _,name in ipairs({'kind','source','actor','board','world','epoch','stance'}) do row[name]=f.text(row[name]) end
    row.generation=tonumber(f.text(reading and nil or tostring(row.generation)))
    row.revision=tonumber(f.text(reading and nil or tostring(row.revision)))
    row.turn=tonumber(f.text(reading and nil or tostring(row.turn)))
    for _,name in ipairs({'pawn_halted','board_halted','special_halted','carry'}) do row[name]=f.boolean(row[name]) end
    local item_count;if not reading then item_count=#row.items end
    local count=f.count(item_count);assert(count<=32,'too many original interaction actors')
    row.items=reading and {} or row.items
    for i=1,count do
        local item=reading and {} or row.items[i]
        for _,name in ipairs({'key','class','owner'}) do item[name]=f.text(item[name]) end
        for _,name in ipairs({'disabled','held','dropped','enable','picked'}) do item[name]=f.boolean(item[name]) end
        item.card_type=tonumber(f.text(reading and nil or tostring(item.card_type)))
        item.card_num=tonumber(f.text(reading and nil or tostring(item.card_num)))
        item.pose=reading and {} or item.pose
        for n=1,6 do
            local value;if not reading then value=string.format('%.17g',item.pose[n]) end
            item.pose[n]=tonumber(f.text(value))
        end
        row.items[i]=item
    end
    snapshot.interaction_phase=M.contract(row)
    assert((snapshot.mode=='radio_seated')==(row.kind=='radio'),'interaction mode/kind differs')
    return snapshot
end

function M.ready(c,after_common,after_restore)
    local row=M.contract(c.snapshot);local token=c.current_token()
    assert(token and c.token and token.id==c.token.id and token.generation==c.token.generation
        and token.nonce==c.token.nonce and token.fingerprint==c.token.fingerprint,'interaction token superseded')
    local pawn,pc=c.pawn,c.pc
    if not live(pawn) or not live(pc) or pc:GetLocalRole()~=2 or not pc:IsLocalController() or not pawn:IsLocallyControlled()
        or address(pc.Pawn)~=address(pawn) or address(pc.AcknowledgedPawn)~=address(pawn) or address(pawn.Controller)~=address(pc) then return nil,'waiting for exact retained interaction owner' end
    if not live(c.board) or c.key(c.board)~=row.board or not world(c.board,pawn) or c.key(pawn:GetWorld())~=row.world then return nil,'waiting for current interaction Board/world' end
    local count=0;c.board.PlayerOrder:ForEach(function(_,p) if address(p:get())==address(pawn) then count=count+1 end end)
    if count~=1 then return nil,'waiting for exact interaction Board roster' end
    if after_common and address(pawn.GameBoard)~=address(c.board) then return nil,'waiting for original SetActors interaction Board binding' end
    if c.board.SpecialEventHalt~=row.special_halted then return nil,'waiting for actual current replicated SpecialEventHalt' end
    if after_restore and (pawn.GameHalted~=row.pawn_halted or c.board.HaltGame~=row.board_halted) then return nil,'current original local interaction halt readback differs' end
    if (pawn.GameplayVars[SITTING] and 'seated' or 'standing')~=row.stance then return nil,'waiting for current replicated interaction stance' end
    local expected_actor=row.kind=='radio' and 'IntroRadio_BP_C' or row.kind=='neighbor' and 'TheNeighbor_BP_C' or 'ThiefTable_BP_C'
    if not live(c.actor) or class(c.actor)~=expected_actor or c.key(c.actor)~=row.actor or not world(c.actor,pawn) then return nil,'waiting for exact current original interaction actor' end
    if row.kind=='radio' and row.turn~=-1 then return nil,'current Radio turn differs' end
    for _,item in ipairs(row.items) do
        local object=c.items[item.key]
        if not live(object) or c.key(object)~=item.key or class(object)~=item.class or not world(object,pawn) or not refs.pose_matches(object,item.pose) then return nil,'waiting for original interaction actor='..item.key end
        if item.class=='NeighborChoice_BP_C' and item.owner=='owner' and address(object.SpecificPlayer)~=address(pawn) then return nil,'waiting for original specific-player binding='..item.key end
        if item.class=='ThiefChoiceCard_BP_C' or item.class=='Lever_BP_C' then
            if address(object.ThiefTable)~=address(c.actor) then return nil,'waiting for original Thief table binding='..item.key end
            if item.class=='ThiefChoiceCard_BP_C' and item.owner=='owner' and address(object['Player Character'])~=address(pawn) then return nil,'waiting for original replicated Thief Player Character holder' end
            if item.class=='ThiefChoiceCard_BP_C' and (object.IsBeingHeld~=item.held or object.IsDroppedOff~=item.dropped) then return nil,'waiting for current original Thief carry/drop replication' end
            if item.class=='Lever_BP_C' and object.Enable~=item.enable then return nil,'waiting for original lever Enable replication' end
        end
        if item.class=='NeighborChoice_BP_C' or item.class=='ThiefChoiceCard_BP_C' then
            if object.CardType~=item.card_type then return nil,'waiting for exact original choice CardType='..item.key end
            if item.class=='NeighborChoice_BP_C' and (object.CardNum~=item.card_num or object.WasPicked~=item.picked) then return nil,'waiting for original choice CardNum/WasPicked='..item.key end
            local widget=valid(object.Widget) and object.Widget:GetWidget()
            local expected=item.class=='NeighborChoice_BP_C' and 'NeighborChoice_WBP_C' or 'ThiefCard_W_C'
            if not valid(widget) or class(widget)~=expected or not valid(widget.Title) or not valid(widget.Description_Line1) then return nil,'waiting for original choice widget='..item.key end
        end
    end
    return true
end
function M.restore(c)
    local ready,cause=M.ready(c,true);if not ready then return nil,cause end
    local receipt={before=c.invariants(),poses={},complete=false,input_receipt='original_input_not_exercised'}
    for _,item in ipairs(c.snapshot.items) do receipt.poses[item.key]=pose(c.items[item.key]) end
    -- These local gates use the current Authority values, not a missing input-history default.
    c.pawn.GameHalted,c.board.HaltGame=c.snapshot.pawn_halted,c.snapshot.board_halted
    assert(c.reset_normal_view()==true,'original normal interaction view reset unconfirmed')
    for _,item in ipairs(c.snapshot.items) do
        local object=c.items[item.key]
        if item.class=='NeighborChoice_BP_C' then object.Disable=item.disabled
        elseif item.class=='ThiefChoiceCard_BP_C' then
            object.DisableInteractions=item.disabled
            assert(object.IsBeingHeld==item.held and object.IsDroppedOff==item.dropped,'waiting for current original Thief carry/drop replication')
        elseif item.class=='Lever_BP_C' then assert(object.Enable==item.enable,'waiting for original lever Enable replication') end
        if item.class=='NeighborChoice_BP_C' or item.class=='ThiefChoiceCard_BP_C' then
            local title,description=labels.values(item.class,item.card_type)
            local widget=object.Widget:GetWidget()
            widget:SetInfo_E(c.text(title),c.text(description),nil)
            assert(widget.Title:GetText():ToString()==title and widget.Description_Line1:GetText():ToString()==description,'original choice text readback differs='..item.key)
        end
    end
    if c.snapshot.kind=='thief' then
        c.pawn.PlayerEventVariables[CARRY]=c.snapshot.carry
        if c.snapshot.carry then
            c.pawn:AddInputInstruction_E(c.text('place card'),'thief_card',false,false,FName('Cabin_Interact'))
            local keys={};c.pawn.CabinHud_WBP.UniqueStringsArray:ForEach(function(_,p) keys[p:get():ToString()]=true end)
            assert(keys.thief_card,'original local Thief place-card hint not acknowledged')
        end
    end
    c.assert_invariants(receipt.before)
    for _,item in ipairs(c.snapshot.items) do same_pose(c.items[item.key],receipt.poses[item.key]) end
    local current,blocker=M.ready(c,true,true);assert(current,blocker)
    receipt.complete=true;return receipt
end
function M.finish(c,receipt)
    assert(receipt and receipt.complete,'current interaction local receipt required')
    local ready,cause=M.ready(c,true,true);if not ready then return nil,cause end
    c.assert_invariants(receipt.before)
    for _,item in ipairs(c.snapshot.items) do
        local v=c.items[item.key]
        if item.class=='NeighborChoice_BP_C' and v.Disable~=item.disabled then return nil,'original Neighbor gate changed' end
        if item.class=='ThiefChoiceCard_BP_C' and (v.DisableInteractions~=item.disabled or v.IsBeingHeld~=item.held or v.IsDroppedOff~=item.dropped) then return nil,'original Thief gate changed' end
        if item.class=='Lever_BP_C' and v.Enable~=item.enable then return nil,'original lever gate changed' end
        if item.class=='NeighborChoice_BP_C' or item.class=='ThiefChoiceCard_BP_C' then
            local title,description=labels.values(item.class,item.card_type);local widget=v.Widget:GetWidget()
            if widget.Title:GetText():ToString()~=title or widget.Description_Line1:GetText():ToString()~=description then return nil,'original choice labels changed' end
        end
    end
    if c.snapshot.kind=='thief' and c.pawn.PlayerEventVariables[CARRY]~=c.snapshot.carry then return nil,'current original carry flag changed' end
    return receipt
end
return M
