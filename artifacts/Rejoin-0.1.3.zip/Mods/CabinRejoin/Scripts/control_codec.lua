local M = {}
M.prefix = "__CABIN_CTRL1__"
M.max_bytes = 160
M.hand_max_bytes = 65536

local codes = { request = "Q", refresh = "R", ack = "A", options4 = "O", handlock = "H" }
local kinds = { Q = "request", R = "refresh", A = "ack", O = "options4", H = "handlock" }
local fields = { kind = true, generation = true, sequence = true, nonce = true }

local function integer(value, maximum)
    return math.type(value) == "integer" and value > 0 and value <= maximum
end

function M.valid_nonce(value)
    return type(value) == "string" and #value == 32 and value:match("^[0-9a-f]+$") ~= nil
end

function M.valid_options(value)
    return type(value) == "table" and math.type(value.difficulty) == "integer"
        and value.difficulty >= 0 and value.difficulty <= 3
        and type(value.player_collision) == "boolean"
        and type(value.radio_tutorial) == "boolean"
        and type(value.goodie_bag) == "boolean"
end

function M.same_options(a, b)
    return M.valid_options(a) and M.valid_options(b)
        and a.difficulty == b.difficulty and a.player_collision == b.player_collision
        and a.radio_tutorial == b.radio_tutorial and a.goodie_bag == b.goodie_bag
end

function M.encode(packet)
    if type(packet) ~= "table" or not codes[packet.kind] then return nil, "unknown kind" end
    if not integer(packet.generation, 2147483647) then return nil, "invalid generation" end
    if not integer(packet.sequence, 2147483647) then return nil, "invalid sequence" end
    if not M.valid_nonce(packet.nonce) then return nil, "invalid nonce" end
    for key in pairs(packet) do
        if not fields[key] and not ((packet.kind == "ack" or packet.kind == "handlock") and key == "snapshot_id")
            and not (packet.kind == "options4" and key == "options")
            and not (packet.kind == "handlock" and (key == "disabled" or key == "hand_signature")) then
            return nil, "unexpected packet field"
        end
    end
    local parts = { M.prefix, codes[packet.kind], tostring(packet.generation),
        tostring(packet.sequence), packet.nonce }
    if packet.kind == "ack" then
        if not integer(packet.snapshot_id, math.maxinteger) then return nil, "invalid snapshot id" end
        parts[#parts + 1] = tostring(packet.snapshot_id)
    elseif packet.kind == "handlock" then
        if not integer(packet.snapshot_id, math.maxinteger) then return nil, "invalid hand grant id" end
        if type(packet.disabled) ~= "boolean" then return nil, "invalid effective hand Bool" end
        if type(packet.hand_signature) ~= "string" or #packet.hand_signature == 0
            or packet.hand_signature:find("%z") then return nil, "invalid effective hand signature" end
        parts[#parts + 1] = tostring(packet.snapshot_id)
        parts[#parts + 1] = packet.disabled and "1" or "0"
        parts[#parts + 1] = packet.hand_signature:gsub(".", function(c) return string.format("%02X", string.byte(c)) end)
    elseif packet.kind == "options4" then
        local value = packet.options
        if not M.valid_options(value) then return nil, "invalid original options" end
        for key in pairs(value) do
            if key ~= "difficulty" and key ~= "player_collision" and key ~= "radio_tutorial"
                and key ~= "goodie_bag" then return nil, "unexpected option field" end
        end
        parts[#parts + 1] = tostring(value.difficulty)
        parts[#parts + 1] = value.player_collision and "1" or "0"
        parts[#parts + 1] = value.radio_tutorial and "1" or "0"
        parts[#parts + 1] = value.goodie_bag and "1" or "0"
    end
    local wire = table.concat(parts, "|")
    if #wire > (packet.kind == "handlock" and M.hand_max_bytes or M.max_bytes) then return nil, "packet exceeds byte limit" end
    return wire
end

local function decimal(text)
    if type(text) ~= "string" or not text:match("^[1-9][0-9]*$") then return nil end
    local value = tonumber(text, 10)
    if math.type(value) ~= "integer" or value <= 0 or tostring(value) ~= text then return nil end
    return value
end

function M.marked(wire)
    return type(wire) == "string" and wire:sub(1, #M.prefix) == M.prefix
end

function M.decode(wire)
    if not M.marked(wire) then return nil, "unmarked" end
    local is_hand = wire:sub(#M.prefix+1,#M.prefix+3) == "|H|"
    if #wire > (is_hand and M.hand_max_bytes or M.max_bytes) then return nil, "packet exceeds byte limit" end
    local parts = {}
    for part in wire:gmatch("[^|]+") do parts[#parts + 1] = part end
    local kind = kinds[parts[2]]
    if parts[1] ~= M.prefix or not kind then return nil, "invalid prefix or kind" end
    local expected = kind == "ack" and 6 or (kind == "options4" and 9 or (kind == "handlock" and 8 or 5))
    if #parts ~= expected then return nil, "invalid field count" end
    local packet = { kind = kind, generation = decimal(parts[3]),
        sequence = decimal(parts[4]), nonce = parts[5] }
    if kind == "ack" then
        packet.snapshot_id = decimal(parts[6])
    elseif kind == "handlock" then
        packet.snapshot_id = decimal(parts[6])
        if parts[7] ~= "0" and parts[7] ~= "1" then return nil, "invalid effective hand bit" end
        if #parts[8]%2 ~= 0 or not parts[8]:match("^[0-9A-F]+$") then return nil, "invalid effective hand encoding" end
        packet.disabled = parts[7] == "1"
        packet.hand_signature = parts[8]:gsub("..", function(c) return string.char(tonumber(c,16)) end)
    elseif kind == "options4" then
        if not parts[6]:match("^[0-3]$") then return nil, "invalid difficulty" end
        for i = 7, 9 do
            if parts[i] ~= "0" and parts[i] ~= "1" then return nil, "invalid option bit" end
        end
        packet.options = { difficulty = tonumber(parts[6], 10),
            player_collision = parts[7] == "1", radio_tutorial = parts[8] == "1",
            goodie_bag = parts[9] == "1" }
    end
    local canonical, cause = M.encode(packet)
    if not canonical then return nil, cause end
    if canonical ~= wire then return nil, "noncanonical packet" end
    return packet
end

return M
