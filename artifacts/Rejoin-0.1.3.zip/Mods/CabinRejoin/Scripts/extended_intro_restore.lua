local M={}
local recipe=require('extended_recipe')
local function valid(v) return v and v:IsValid() end
local function address(v) return valid(v) and v:GetAddress() or 0 end
local function near(a,b) return math.abs(a-b)<0.01 end
local function flags(p) return p.DisableMovement and p.DisableAxisYAW and p.DisableAxisPITCH and p.DisableInteract and p.DisableFlashlight end
function M.ready(c,after)
    recipe.intro(c.snapshot)
    local t=c.current_token()
    assert(t.id==c.token.id and t.fingerprint==c.token.fingerprint,'current authenticated Intro token differs')
    local pc,pawn,car,seat=c.pc,c.pawn,c.car,c.seat
    for _,v in ipairs({pc,pawn,car,seat}) do if not valid(v) then return nil,'waiting for current original Intro actors/seat' end end
    if pc:GetLocalRole()~=2 or not pc:IsLocalController() or not pawn:IsLocallyControlled() or address(pc.Pawn)~=address(pawn)
        or address(pc.AcknowledgedPawn)~=address(pawn) or address(pawn.Controller)~=address(pc) then return nil,'waiting for retained Intro owner acknowledgement' end
    local world=address(pawn:GetWorld())
    if world==0 or address(pc:GetWorld())~=world or address(car:GetWorld())~=world or address(seat:GetWorld())~=world
        or address(seat:GetOwner())~=address(car) then
        return nil,'waiting for original replicated Intro mesh/seat/world binding'
    end
    if not valid(pawn.Mesh) then return nil,'waiting for current original Intro visual mesh' end
    if after and address(pawn.Mesh:GetAttachParent())~=address(seat) then return nil,'waiting for current original Intro mesh seat readback' end
    if c.key(car)~=c.snapshot.car or c.key(seat)~=c.snapshot.seat or car:GetClass():GetFullName()~=c.snapshot.car_class then
        return nil,'waiting for exact original Intro car/seat keys/class'
    end
    if not valid(pawn.CamFwd_SpringArm) then return nil,'waiting for original Intro spring arm' end
    if pawn.IsFlashlightOn or pawn.IsCrouching then return nil,'waiting for original Intro lantern/crouch completion' end
    return true
end
function M.restore(c)
    for _,name in ipairs({'current_token','key','name','log','invariants','assert_invariants','server_time','animation_position'}) do
        assert(type(c[name])=='function','Intro local adapter missing='..name)
    end
    local ready,cause=M.ready(c,false); if not ready then return nil,cause end
    local r={attempted=true,complete=false,before=c.invariants(),input_receipt='original_input_not_exercised'}
    local ok,failure=pcall(function()
        local p=c.pawn
        assert(valid(p.Mesh) and address(p.Mesh)~=address(p.RootComponent),'original Intro visual mesh must not be actor root')
        if address(p.Mesh:GetAttachParent())~=address(c.seat) then
            local attached=p.Mesh:K2_AttachToComponent(c.seat,c.name('None'),0,0,1,true)
            assert(attached and address(p.Mesh:GetAttachParent())==address(c.seat),'original local Intro mesh attachment not acknowledged')
        end
        p.Mesh:K2_SetRelativeLocationAndRotation(c.snapshot.mesh_location,c.snapshot.mesh_rotation,false,{},false)
        p.DisableMovement,p.DisableAxisYAW,p.DisableAxisPITCH,p.DisableInteract,p.DisableFlashlight=true,true,true,true,true
        p.CamFwd_SpringArm:K2_SetRelativeLocation({X=0,Y=-20,Z=145},false,{},false)
        if c.snapshot.ui_stage~='removed' then
            if not valid(c.pc.IntroCarWidget) then c.pc:CarIntroWidget_E(false,false) end
            assert(valid(c.pc.IntroCarWidget) and c.pc.IntroCarWidget:IsInViewport(),'original Intro widget creation not acknowledged')
            r.widget=c.pc.IntroCarWidget
            if c.snapshot.ui_stage=='open' then
                local elapsed=c.server_time()-c.snapshot.opened_at
                assert(type(elapsed)=='number' and elapsed>=0,'synchronized original server Intro time required')
                assert(valid(r.widget.OpenEyesAnim),'original OpenEyes animation unavailable')
                r.animation_start=elapsed*0.5
                r.widget:PlayAnimation(r.widget.OpenEyesAnim,r.animation_start,1,0,0.5,false)
            end
        elseif valid(c.pc.IntroCarWidget) then c.pc.IntroCarWidget:RemoveFromParent() end
        c.assert_invariants(r.before,c.invariants())
    end)
    if not ok then c.log('error','Intro local restore cause='..tostring(failure)..'; receipt incomplete'); return nil,tostring(failure) end
    c.log('info','Intro local presentation attempted; current widget/animation readback pending')
    return r
end
function M.finish(c,r)
    local ready,cause=M.ready(c,true); if not ready then return nil,cause end
    c.assert_invariants(r.before,c.invariants())
    local v=c.pawn.CamFwd_SpringArm.RelativeLocation
    if not flags(c.pawn) or not near(v.X,0) or not near(v.Y,-20) or not near(v.Z,145) then return nil,'waiting for original Intro local camera/input readback' end
    local loc,rot,s=c.pawn.Mesh.RelativeLocation,c.pawn.Mesh.RelativeRotation,c.snapshot
    for _,name in ipairs({'X','Y','Z'}) do if not near(loc[name],s.mesh_location[name]) then return nil,'waiting for original Intro mesh location='..name end end
    for _,name in ipairs({'Pitch','Yaw','Roll'}) do if not near(rot[name],s.mesh_rotation[name]) then return nil,'waiting for original Intro mesh rotation='..name end end
    if c.snapshot.ui_stage=='removed' then
        if valid(c.pc.IntroCarWidget) and c.pc.IntroCarWidget:IsInViewport() then return nil,'waiting for original Intro overlay removal' end
    else
        if not valid(r.widget) or not r.widget:IsInViewport() then return nil,'waiting for original Intro overlay viewport acknowledgement' end
        if c.snapshot.ui_stage=='open' then
            local position=c.animation_position(r.widget,r.widget.OpenEyesAnim)
            if type(position)~='number' or position<r.animation_start-0.05 then return nil,'waiting for original OpenEyes position readback' end
        end
    end
    r.complete=true; r.local_confirmed=true
    return r
end
function M.detach_cleanup(c)
    assert(c.pc:IsLocalController(),'Intro cleanup needs current local controller')
    if valid(c.pc.IntroCarWidget) then
        c.pc.IntroCarWidget:RemoveFromParent()
        assert(not c.pc.IntroCarWidget:IsInViewport(),'Intro overlay removal not acknowledged')
    end
    return true
end
return M
