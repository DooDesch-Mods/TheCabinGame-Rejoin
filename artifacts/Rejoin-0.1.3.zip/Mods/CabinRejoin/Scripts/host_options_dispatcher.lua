local codec = require("control_codec")
local M = {}

local function positive(value)
    return math.type(value) == "integer" and value > 0
end

local function log(options, level, cause)
    local ok, failure = pcall(options.log, level, "control_transport: " .. cause)
    if not ok then print("error control_transport logger: " .. tostring(failure) .. "; " .. cause) end
end

local function failure(options, status, cause)
    log(options, "error", cause)
    return { status = status, cause = cause }
end

local function matches_snapshot(value, packet)
    return type(value) == "table" and value.generation == packet.generation
        and value.id == packet.snapshot_id and value.nonce == packet.nonce
end

local function result_copy(value)
    return { status = value.status, kind = value.kind, sequence = value.sequence,
        generation = value.generation, snapshot_id = value.snapshot_id,
        snapshot_nonce = value.snapshot_nonce, cause = value.cause }
end

function M.new(options)
    assert(type(options) == "table", "dispatcher options required")
    for _, name in ipairs({ "authenticate", "current_peer", "lobby_owner", "log" }) do
        assert(type(options[name]) == "function", name .. " adapter required")
    end
    local object = {}
    local handlers = { request = options.on_request, refresh = options.on_refresh,
        ack = options.on_ack, options4 = options.on_options4 }

    local function dispatch(pc, wire)
        local packet, cause = codec.decode(wire)
        if cause == "unmarked" then return { status = "ignored" } end
        if not packet then return failure(options, "rejected", "decode: " .. cause) end
        if not pc or not pc:IsValid() or pc:GetLocalRole() ~= 3 then
            return failure(options, "rejected", "sender is not a live authority controller")
        end
        local steam_id, handle = options.authenticate(pc)
        if not positive(steam_id) or not positive(handle) then
            return failure(options, "rejected", "native Steam authentication unavailable")
        end
        local peer = options.current_peer(pc)
        if type(peer) ~= "table" or peer.pc_address ~= pc:GetAddress()
            or peer.steam_id ~= steam_id or peer.connection_handle ~= handle then
            return failure(options, "rejected", "current server peer binding differs from native connection")
        end
        if not positive(peer.generation) or peer.generation > 2147483647
            or packet.generation ~= peer.generation then
            return failure(options, "rejected", "packet generation differs from current server generation")
        end
        if packet.kind == "options4" then
            local owner = options.lobby_owner(peer)
            if type(peer.lobby_id) ~= "string" or not peer.lobby_id:match("^[1-9][0-9]*$")
                or type(owner) ~= "table" or owner.status ~= 1 or owner.lobby_id ~= peer.lobby_id
                or owner.owner_id ~= tostring(steam_id) then
                return failure(options, "rejected", "current original Steam lobby owner does not match sender")
            end
        end
        local state = peer.control_transport
        if state == nil or (type(state) == "table" and (state.generation ~= peer.generation
            or state.pc_address ~= peer.pc_address or state.connection_handle ~= handle
            or state.steam_id ~= steam_id)) then
            state = { generation = peer.generation, pc_address = peer.pc_address,
                connection_handle = handle, steam_id = steam_id, last_sequence = 0 }
            peer.control_transport = state
        elseif type(state) ~= "table" then
            return failure(options, "rejected", "server transport state is not a table")
        end
        if math.type(state.last_sequence) ~= "integer" or state.last_sequence < 0 then
            return failure(options, "rejected", "server sequence state is invalid")
        end
        if state.busy then return failure(options, "rejected", "server handler is already executing") end
        if packet.sequence == state.last_sequence and wire == state.last_wire then
            local duplicate = result_copy(assert(state.result, "previous attempt has no result"))
            duplicate.original_status = duplicate.status
            duplicate.status = "duplicate"
            log(options, "info", "duplicate sequence skipped; original status " .. duplicate.original_status)
            return duplicate
        end
        if packet.sequence <= state.last_sequence then
            return failure(options, "rejected", "stale sequence or reused sequence with another packet")
        end
        if packet.kind == "ack" and not matches_snapshot(peer.pending_snapshot, packet) then
            return failure(options, "rejected", "ACK differs from current pending server snapshot")
        end
        local handler = handlers[packet.kind]
        if type(handler) ~= "function" then
            return failure(options, "rejected", "typed handler unavailable: " .. packet.kind)
        end
        state.last_sequence, state.last_wire, state.busy = packet.sequence, wire, true
        state.result = { status = "attempted", kind = packet.kind, sequence = packet.sequence,
            generation = packet.generation, snapshot_id = packet.snapshot_id }
        local ok, readback = pcall(handler, peer, packet)
        state.busy = false
        if not ok then
            state.result.status, state.result.cause = "failed", "handler " .. packet.kind .. ": " .. tostring(readback)
        elseif packet.kind == "options4" and type(readback) == "table" and readback.pending == true then
            state.pending_options = state.pending_options or {}
            state.pending_options[packet.sequence] = packet
            state.result.status, state.result.cause = "pending", readback.cause
        elseif type(readback) ~= "table" or readback.confirmed ~= true then
            state.result.status, state.result.cause = "failed", "handler " .. packet.kind .. " has no confirmed readback"
            if type(readback) == "table" and readback.cause then
                state.result.cause = state.result.cause .. ": " .. tostring(readback.cause)
            end
        elseif packet.kind == "ack" and not matches_snapshot(readback, packet) then
            state.result.status, state.result.cause = "failed", "ACK handler readback differs from issued snapshot"
        elseif packet.kind == "options4" and not codec.same_options(readback.options, packet.options) then
            state.result.status, state.result.cause = "failed", "original option readback differs from request"
        elseif (packet.kind == "request" or packet.kind == "refresh") and
            (readback.generation ~= peer.generation or not positive(readback.id)
                or not codec.valid_nonce(readback.nonce)
                or not matches_snapshot(peer.pending_snapshot, { generation = readback.generation,
                    snapshot_id = readback.id, nonce = readback.nonce })) then
            state.result.status, state.result.cause = "failed", "snapshot handler has no current issued snapshot receipt"
        else
            state.result.status = "confirmed"
            state.result.snapshot_id = readback.id or packet.snapshot_id
            state.result.snapshot_nonce = readback.nonce
        end
        if state.result.status == "failed" then log(options, "error", state.result.cause)
        elseif state.result.status == "pending" then log(options, "info", "pending original readback sequence " .. packet.sequence)
        else log(options, "info", "confirmed " .. packet.kind .. " sequence " .. packet.sequence) end
        return result_copy(state.result)
    end

    function object.complete_options(pc, sequence, nonce, readback)
        local ok, result = pcall(function()
            assert(pc and pc:IsValid() and pc:GetLocalRole() == 3, "O completion PC unavailable")
            local id, handle = options.authenticate(pc)
            local peer = options.current_peer(pc)
            assert(type(peer) == "table" and peer.pc_address == pc:GetAddress() and peer.steam_id == id
                and peer.connection_handle == handle, "O completion current native binding differs")
            local owner = options.lobby_owner(peer)
            assert(type(owner) == "table" and owner.status == 1 and owner.lobby_id == peer.lobby_id
                and owner.owner_id == tostring(id), "O completion original Owner differs")
            local state = assert(peer.control_transport, "O completion transport state unavailable")
            assert(state.generation == peer.generation and state.steam_id == id and state.connection_handle == handle,
                "O completion epoch/connection changed")
            local packet = assert(state.pending_options and state.pending_options[sequence], "O completion pending sequence unavailable")
            assert(packet.generation == peer.generation and packet.nonce == nonce, "O completion pending epoch/nonce differs")
            assert(type(readback) == "table" and readback.confirmed == true and codec.same_options(packet.options, readback.options),
                "O completion has no exact original options readback")
            state.pending_options[sequence] = nil
            if state.result.sequence == sequence then state.result.status, state.result.cause = "confirmed", nil end
            log(options, "info", "confirmed delayed original O readback sequence " .. sequence)
            return {status="confirmed", sequence=sequence, generation=peer.generation}
        end)
        if not ok then return failure(options, "failed", "O completion: " .. tostring(result)) end
        return result
    end

    function object.dispatch(pc, wire)
        local ok, result = pcall(dispatch, pc, wire)
        if not ok then return failure(options, "failed", "dispatch: " .. tostring(result)) end
        return result
    end
    return object
end

return M
