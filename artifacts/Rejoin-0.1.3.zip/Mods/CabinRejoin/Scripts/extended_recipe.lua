local M = {}
local function finite(v)
    return type(v)=='number' and v==v and v~=math.huge and v~=-math.huge
end
local function vec(v)
    assert(type(v)=='table' and finite(v.X) and finite(v.Y) and finite(v.Z),'finite original vector required')
    return {X=v.X,Y=v.Y,Z=v.Z}
end
local function rot(v)
    assert(type(v)=='table' and finite(v.Pitch) and finite(v.Yaw) and finite(v.Roll),'finite original rotation required')
    return {Pitch=v.Pitch,Yaw=v.Yaw,Roll=v.Roll}
end
function M.inspect(s,camera,graveyard)
    assert(s.phase=='inspect_entry' and (s.card_status==0 or s.card_status==2),'original Ejected or Graveyard inspect entry required')
    assert(s.current_turn==true and s.binding_matches==1,'exact current original card/turn binding required')
    local location,rotation,aim=vec(camera.location),rot(camera.rotation),rot(camera.base_aim)
    local pitch,yaw=math.rad(aim.Pitch),math.rad(aim.Yaw)
    local result={origin_hand_location=vec(s.location),origin_hand_rotation=rot(s.rotation),
        card_scene_location={X=location.X+16*math.cos(pitch)*math.cos(yaw),
            Y=location.Y+16*math.cos(pitch)*math.sin(yaw),Z=location.Z+16*math.sin(pitch)},
        card_scene_rotation={Pitch=rotation.Pitch+90,Yaw=rotation.Yaw,Roll=rotation.Roll},
        hints=s.card_status==0 and {{'accept','eject_accept','Cabin_Interact'}}
            or {{'accept','eject_accept','Cabin_Interact'},{'cancel','inspect_cancel','Cabin_Secondary'}}}
    if s.card_status==2 then
        assert(type(graveyard)=='table' and math.type(graveyard.index)=='integer' and math.type(graveyard.count)=='integer'
            and graveyard.count>0 and graveyard.index>=0 and graveyard.index<graveyard.count,'current original Graveyard order required')
        local view,right=vec(graveyard.view_location),vec(graveyard.card_root_right)
        local offset=-4*(graveyard.count-1)+8*graveyard.index
        result.graveyard_origin={location={X=view.X+right.X*offset,Y=view.Y+right.Y*offset,Z=view.Z+right.Z*offset},
            rotation=rot(graveyard.view_rotation),scale={X=1,Y=1,Z=1}}
    end
    return result
end
function M.current(marker,current)
    assert(marker.identity==current.identity and marker.epoch==current.epoch,'original observation identity/epoch differs')
    assert(marker.card==current.card and marker.status==current.status and current.binding_matches==1
        and current.current_turn==true,'current original inspect binding differs')
    if marker.status==1 then assert(current.owner==current.pawn,'current Holding owner differs') end
    return true
end
function M.intro(s)
    assert(s.phase=='car_intro' and s.gm_class=='Cabin_GameMode_C' and s.authenticated==true,'current native authenticated gameplay intro required')
    assert(s.seat_matches==1 and s.intro_matches==1 and s.attached==true,'current original car/seat/pawn binding required')
    assert(s.ending==false and type(s.started)=='boolean','current original round lifecycle required')
    assert(s.ui_stage=='initial' or s.ui_stage=='open' or s.ui_stage=='removed','current original intro UI stage required')
    return true
end
function M.action(marker,current)
    assert(marker.phase=='action_pending' and marker.identity==current.identity and marker.epoch==current.epoch,
        'current observed original subclass action required')
    return {phase='action_pending',card=marker.card,card_class=marker.card_class,card_type=marker.card_type,
        current_turn=current.current_turn,complete=false,
        cause='original subclass action remains active; current per-class local interaction evidence required'}
end
return M
