local M = {}
local function valid(object) return object and object:IsValid() end
local function address(object) return valid(object) and object:GetAddress() or 0 end
local MODELS = {
    [false] = {
        class = "AnimBlueprintGeneratedClass /Game/CabinGameContent/PlayerContent/NEW_ANIMS/SurvGirl01/ABP_New_Cabin.ABP_New_Cabin_C",
        montage = "/Game/CabinGameContent/PlayerContent/NEW_ANIMS/GameAnims/Female/Mont_Female_Lantern.Mont_Female_Lantern",
    },
    [true] = {
        class = "AnimBlueprintGeneratedClass /Game/CabinGameContent/PlayerContent/NEW_ANIMS/SurvMan01/ABP_New_Cabin_Male.ABP_New_Cabin_Male_C",
        montage = "/Game/CabinGameContent/PlayerContent/NEW_ANIMS/GameAnims/Male/Male_Lantern_Montage.Male_Lantern_Montage",
    },
}
local PHASES = {"IsInTurn", "InAnimation", "IsInspecting", "IsInMap", "IsInteracting"}
local THIEF_MONTAGES = {
    [false] = "/Game/CabinGameContent/PlayerContent/NEW_ANIMS/GameAnims/Female/Female_ThiefCard_Montage.Female_ThiefCard_Montage",
    [true] = "/Game/CabinGameContent/PlayerContent/NEW_ANIMS/GameAnims/Male/Male_ThiefCardMontage.Male_ThiefCardMontage",
}
local function thief_context(pc, pawn, mode, context, receipt)
    if mode ~= "world_choice" or not context then return false end
    local phase = require("interaction_phase")
    local row = phase.contract(context.snapshot)
    if row.kind ~= "thief" or row.stance ~= "standing" then return false end
    assert(address(context.pc) == address(pc) and address(context.pawn) == address(pawn), "flashlight Thief context owner differs")
    local ready, cause
    if receipt then ready, cause = phase.finish(context, receipt)
    else ready, cause = phase.ready(context, false) end
    if not ready then return nil, cause end
    return true, table.concat({row.kind,row.stance,tostring(row.carry),row.actor,row.board,row.world,row.epoch,
        tostring(row.generation),tostring(row.revision),tostring(row.turn)}, ":")
end

function M.prepare(pc, pawn, mode, interaction)
    assert(valid(pawn), "original flashlight pawn missing")
    assert(type(pawn.IsFlashlightOn) == "boolean", "original replicated flashlight state missing")
    local prepared = {pawn=address(pawn), pc=address(pc), world=address(pawn:GetWorld()), on=pawn.IsFlashlightOn}
    if not pawn.IsFlashlightOn then return prepared end
    local thief, phase = thief_context(pc, pawn, mode, interaction)
    if thief == nil then return nil, "waiting for original flashlight Thief binding: " .. tostring(phase) end
    if mode ~= "standing" and mode ~= "seated" and not thief then return prepared end
    if thief then prepared.interaction, prepared.phase = interaction, phase end
    for _, name in ipairs(PHASES) do
        assert(type(pawn[name]) == "boolean", "original flashlight phase field missing=" .. name)
        if pawn[name] then return prepared end
    end
    assert(valid(pc) and pc:IsLocalController() and pc:GetLocalRole() == 2 and not pawn:IsActorBeingDestroyed()
        and pawn:IsLocallyControlled() and address(pc.Pawn) == address(pawn) and address(pc.AcknowledgedPawn) == address(pawn)
        and address(pawn.Controller) == address(pc), "flashlight local retained ownership differs")
    assert(pawn:GetClass():GetFullName() == "BlueprintGeneratedClass /Game/CabinGameContent/PlayerContent/Cabin_Player.Cabin_Player_C", "original flashlight pawn class differs")
    assert(type(pawn.IsMale) == "boolean", "original flashlight model state missing")
    local mesh, model = pawn.Mesh, MODELS[pawn.IsMale]
    if not valid(mesh) then return nil, "waiting for original flashlight body mesh measured=0 required=current pawn mesh" end
    local owner = address(mesh:GetOwner())
    if owner == 0 then return nil, "waiting for original flashlight mesh owner measured=0 required=" .. address(pawn) end
    assert(owner == address(pawn), "original flashlight body mesh owner differs measured=" .. owner .. " required=" .. address(pawn))
    local anim = mesh:GetAnimInstance()
    if not valid(anim) then return nil, "waiting for original flashlight animation instance measured=0 required=" .. model.class end
    local class = anim:GetClass():GetFullName()
    assert(class == MODELS[false].class or class == MODELS[true].class,
        "original flashlight animation binding class differs measured=" .. class .. " required=" .. model.class)
    local character = address(anim.Cabin_Character)
    assert(character == 0 or character == address(pawn), "original flashlight animation binding character differs measured=" .. character .. " required=" .. address(pawn))
    if class ~= model.class then return nil, "waiting for original flashlight model/animation class measured=" .. class .. " IsMale=" .. tostring(pawn.IsMale) .. " required=" .. model.class end
    if character == 0 then return nil, "waiting for original flashlight animation character measured=0 required=" .. address(pawn) end
    prepared.male, prepared.mesh, prepared.anim, prepared.class = pawn.IsMale, address(mesh), address(anim), class
    return prepared
end

function M.restore(pc, pawn, mode, log, prepared, interaction, interaction_receipt)
    assert(type(prepared) == "table", "original flashlight prepared context missing")
    assert(valid(pawn), "original flashlight prepared pawn missing")
    assert(address(pawn) == prepared.pawn, "original flashlight prepared pawn changed measured=" .. address(pawn) .. " required=" .. tostring(prepared.pawn))
    assert(address(pc) == prepared.pc, "original flashlight prepared controller changed measured=" .. address(pc) .. " required=" .. tostring(prepared.pc))
    assert(address(pawn:GetWorld()) == prepared.world, "original flashlight prepared world changed measured=" .. address(pawn:GetWorld()) .. " required=" .. tostring(prepared.world))
    assert(pawn.IsFlashlightOn == prepared.on, "original flashlight prepared F-state changed measured=" .. tostring(pawn.IsFlashlightOn) .. " required=" .. tostring(prepared.on))
    assert(valid(pawn), "original flashlight pawn missing")
    assert(type(pawn.IsFlashlightOn) == "boolean", "original replicated flashlight state missing")
    if not pawn.IsFlashlightOn then
        log("info", "flashlight montage restore skipped: original F-state off")
        return {status="not_required"}
    end
    local function skip(cause)
        log("warn", "flashlight montage restore skipped: " .. cause)
        return nil, cause
    end
    local thief, phase = thief_context(pc, pawn, mode, interaction, interaction_receipt)
    if thief == nil then return skip("current original flashlight Thief binding: " .. tostring(phase)) end
    if thief then
        assert(interaction_receipt and interaction_receipt.complete, "flashlight original Thief local receipt missing")
        assert(interaction == prepared.interaction and phase == prepared.phase, "flashlight prepared Thief contract changed")
    end
    if mode ~= "standing" and mode ~= "seated" and not thief then return skip("current original phase=" .. tostring(mode)) end
    for _, name in ipairs(PHASES) do
        assert(type(pawn[name]) == "boolean", "original flashlight phase field missing=" .. name)
        if pawn[name] then return skip("current original active phase=" .. name) end
    end
    assert(valid(pc) and pc:IsLocalController() and pc:GetLocalRole() == 2 and valid(pawn) and not pawn:IsActorBeingDestroyed()
        and pawn:IsLocallyControlled() and address(pc.Pawn) == address(pawn) and address(pc.AcknowledgedPawn) == address(pawn)
        and address(pawn.Controller) == address(pc), "flashlight local retained ownership differs")
    assert(pawn:GetClass():GetFullName() == "BlueprintGeneratedClass /Game/CabinGameContent/PlayerContent/Cabin_Player.Cabin_Player_C", "original flashlight pawn class differs")
    assert(pawn.IsMale == prepared.male, "original flashlight prepared model changed measured=" .. tostring(pawn.IsMale) .. " required=" .. tostring(prepared.male))
    local mesh, model = pawn.Mesh, MODELS[pawn.IsMale]
    assert(valid(mesh) and address(mesh) == prepared.mesh,
        "original flashlight prepared mesh binding changed measured=" .. address(mesh) .. " required=" .. tostring(prepared.mesh))
    assert(address(mesh:GetOwner()) == prepared.pawn, "original flashlight prepared mesh owner changed measured=" .. address(mesh:GetOwner()) .. " required=" .. tostring(prepared.pawn))
    local anim = mesh:GetAnimInstance()
    assert(valid(anim) and address(anim) == prepared.anim, "original flashlight prepared animation instance changed measured=" .. address(anim) .. " required=" .. tostring(prepared.anim))
    assert(anim:GetClass():GetFullName() == prepared.class, "original flashlight prepared animation class changed measured=" .. anim:GetClass():GetFullName() .. " required=" .. tostring(prepared.class))
    assert(address(anim.Cabin_Character) == prepared.pawn, "original flashlight prepared animation character changed measured=" .. address(anim.Cabin_Character) .. " required=" .. prepared.pawn)
    if thief and interaction.snapshot.carry then
        local item, card
        for _, row in ipairs(interaction.snapshot.items) do
            if row.owner == "owner" then item, card = row, interaction.items[row.key] end
        end
        assert(item and valid(card) and card:GetClass():GetFullName() == "BlueprintGeneratedClass /Game/CabinGameContent/Event_BPs/Passive_Chance_Stuff/TheThief/ThiefChoiceCard_BP.ThiefChoiceCard_BP_C"
            and address(card["Player Character"]) == prepared.pawn and address(card:GetWorld()) == prepared.world,
            "original flashlight Thief held-card binding differs")
        local root = card.RootComponent
        assert(valid(root), "original flashlight Thief held-card attachment differs: root measured=0 required=current card root")
        assert(address(root:GetOwner()) == address(card), "original flashlight Thief held-card attachment differs: owner measured=" .. address(root:GetOwner()) .. " required=" .. address(card))
        assert(address(root:GetAttachParent()) == prepared.mesh, "original flashlight Thief held-card attachment differs: parent measured=" .. address(root:GetAttachParent()) .. " required=" .. prepared.mesh)
        local socket = root:GetAttachSocketName():ToString()
        assert(socket == "ThiefCard", "original flashlight Thief held-card attachment differs: socket measured=" .. socket .. " required=ThiefCard")
        local montage = StaticFindObject(THIEF_MONTAGES[pawn.IsMale])
        assert(valid(montage), "original Thief montage asset missing=" .. THIEF_MONTAGES[pawn.IsMale])
        local current = pawn:GetCurrentMontage()
        local playing = anim:Montage_IsPlaying(montage)
        if not valid(current) or address(current) ~= address(montage) or not playing then
            return skip("original Thief carry montage current/playing missing measured_current=" .. (valid(current) and current:GetFullName() or "0")
                .. " measured_playing=" .. tostring(playing) .. " required=" .. THIEF_MONTAGES[pawn.IsMale] .. "; Lantern/Thief coexistence unproven")
        end
        log("info", "flashlight Thief original carry montage current/playing and held-card attachment confirmed")
        -- The original pickup requests ThiefCard while F remains on; its Lantern slot contract is not available here.
        return skip("original Thief carry presentation retained; Lantern/Thief coexistence unproven")
    end
    local montage = StaticFindObject(model.montage)
    assert(valid(montage), "original flashlight montage asset missing=" .. model.montage)
    local current = pawn:GetCurrentMontage()
    if valid(current) and address(current) ~= address(montage) then return skip("another current montage=" .. current:GetFullName()) end
    if anim:Montage_IsPlaying(montage) then
        log("info", "flashlight original montage already playing")
        return {status="already_playing", montage=montage}
    end
    local lantern, world = pawn.Cabin_Lantern, address(pawn:GetWorld())
    assert(world ~= 0 and valid(lantern) and not lantern:IsActorBeingDestroyed()
        and lantern:GetClass():GetFullName() == "BlueprintGeneratedClass /Game/OutsideAssets/Lantern/Cabin_Lantern_BP.Cabin_Lantern_BP_C"
        and address(lantern:GetWorld()) == world and address(lantern.Player) == address(pawn)
        and valid(lantern.RootComponent) and address(lantern.RootComponent:GetAttachParent()) == address(mesh), "original flashlight lantern binding differs")
    local before = {pawn=address(pawn), mesh=address(mesh), anim=address(anim), lantern=address(lantern), world=world,
        male=pawn.IsMale, nonrep=pawn.LanternOnNonRep, disable=pawn.DisableFlashlight,
        vars=pawn.GameplayVars["IsFlashlightOn_15_174191FD42F1F675FC1DECA0D13A34EF"], pose=anim["Is Flashlight On"], components={}}
    for _, name in ipairs({"DefaultSceneRoot", "Lantern_Mesh", "SM_Lantern_Flames", "PointLight"}) do
        local item = lantern[name]
        assert(valid(item) and address(item:GetOwner()) == before.lantern, "original flashlight component owner differs=" .. name)
        before.components[name] = {item=item, visible=item:IsVisible(), hidden=item.bHiddenInGame}
    end
    log("info", "flashlight original montage restore attempted pawn=" .. before.pawn .. " asset=" .. model.montage)
    -- The original client montage event also sends a server RPC; only replay its local animation call.
    local duration = pawn:PlayAnimMontage(montage, 1, FName("None"))
    assert(type(duration) == "number" and duration > 0, "flashlight PlayAnimMontage failed duration=" .. tostring(duration))
    assert(anim:Montage_IsPlaying(montage) and address(pawn:GetCurrentMontage()) == address(montage), "flashlight montage current/playing acknowledgement differs")
    assert(pawn.IsFlashlightOn == true and pawn.IsMale == before.male and pawn.LanternOnNonRep == before.nonrep and pawn.DisableFlashlight == before.disable
        and pawn.GameplayVars["IsFlashlightOn_15_174191FD42F1F675FC1DECA0D13A34EF"] == before.vars and anim["Is Flashlight On"] == before.pose, "flashlight montage restore changed original F-state")
    assert(address(pc.Pawn) == before.pawn and address(pc.AcknowledgedPawn) == before.pawn and address(pawn.Controller) == address(pc)
        and address(pawn:GetWorld()) == before.world and address(pawn.Mesh) == before.mesh and address(mesh:GetAnimInstance()) == before.anim
        and address(pawn.Cabin_Lantern) == before.lantern and address(lantern.Player) == before.pawn
        and address(lantern.RootComponent:GetAttachParent()) == before.mesh, "flashlight montage restore changed original bindings")
    for name, row in pairs(before.components) do
        assert(row.item:IsVisible() == row.visible and row.item.bHiddenInGame == row.hidden, "flashlight montage restore changed component flags=" .. name)
    end
    log("info", "flashlight original montage current/playing confirmed; original F-state and lantern flags retained")
    return {status="confirmed", montage=montage}
end

return M
