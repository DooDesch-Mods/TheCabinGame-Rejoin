local M={}
local function valid(v) return v and v:IsValid() end
function M.make_transform(location,rotation,scale)
    local lib=StaticFindObject('/Script/Engine.Default__KismetMathLibrary')
    assert(valid(lib),'original KismetMathLibrary unavailable')
    return lib:MakeTransform(location,rotation,scale)
end
function M.transform_matches(value,wanted)
    local lib=StaticFindObject('/Script/Engine.Default__KismetMathLibrary')
    assert(valid(lib),'original KismetMathLibrary unavailable')
    return lib:NearlyEqual_TransformTransform(value,M.make_transform(wanted.location,wanted.rotation,wanted.scale),0.01,0.01,0.01)
end
function M.server_time(actor)
    local lib=StaticFindObject('/Script/Engine.Default__GameplayStatics')
    assert(valid(lib) and valid(actor),'original clock context unavailable')
    local state=lib:GetGameState(actor)
    assert(valid(state) and state:GetWorld():GetAddress()==actor:GetWorld():GetAddress(),'current original GameState world differs')
    local value=state:GetServerWorldTimeSeconds()
    assert(type(value)=='number' and value==value and value>=0,'original synchronized server time return differs')
    return value
end
function M.animation_position(widget,animation)
    assert(valid(widget) and valid(animation),'original widget animation unavailable')
    local value=widget:GetAnimationCurrentTime(animation)
    assert(type(value)=='number' and value==value and value>=0,'original animation time return differs')
    return value
end
return M
