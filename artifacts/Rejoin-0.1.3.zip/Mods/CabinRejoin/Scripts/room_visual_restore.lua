local M = {}
local ROOM = "BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Rooms/DiningRoom_BP.DiningRoom_BP_C"
local DEFINITIONS = {
    {field="LightSwitch_BP", class="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Lighting/Cabin_LightSwitch_BP.Cabin_LightSwitch_BP_C", name="Cabin_LightSwitch_BP_C", net=true, pose_binding=false, rotation=false, components={"SwitchScene"}},
    {field="GrandfatherClockClueA_BP", class="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Clues/ClueA_Spawn_BP.ClueA_Spawn_BP_C", name="ClueA_Spawn_BP_C", net=true, pose_binding=false, rotation=false, components={"Scene"}},
    {field="DiningBookshelf", class="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Furniture/DiningRoom_Blueprints/DiningBookshelf_BP.DiningBookshelf_BP_C", name="DiningBookshelf_BP_C", net=false, pose_binding=false, rotation=false, components={"Wall2Furniture"}},
    {field="DiningChair", class="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Furniture/DiningRoom_Blueprints/DiningChair_BP.DiningChair_BP_C", name="DiningChair_BP_C", net=false, pose_binding=false, rotation=true, components={"Wall2Furniture"}},
    {field="DiningPlantLarge", class="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Furniture/DiningRoom_Blueprints/DiningLargePlant_BP.DiningLargePlant_BP_C", name="DiningLargePlant_BP_C", net=false, pose_binding=false, anchor_binding=true, rotation=false, components={"Wall2Furniture"}},
    {field="PaintingsWall2", class="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Furniture/DiningRoom_Blueprints/DiningPaintingsWall2_BP.DiningPaintingsWall2_BP_C", name="DiningPaintingsWall2_BP_C", net=false, pose_binding=false, rotation=false, components={"Frame_01", "SM_Painting_C"}},
    {field="WheelTable", class="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Furniture/DiningRoom_Blueprints/DiningWheelTable_BP.DiningWheelTable_BP_C", name="DiningWheelTable_BP_C", net=false, pose_binding=false, rotation=false, components={"Wall0Furniture"}},
    {field="DiningPianoBench", class="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Furniture/DiningRoom_Blueprints/DiningPianoBench_BP.DiningPianoBench_BP_C", name="DiningPianoBench_BP_C", net=false, pose_binding=false, rotation=true, components={"Wall0Furniture"}},
    {field="PaintingsWall0", class="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Furniture/DiningRoom_Blueprints/DiningPaintingsWall0_BP.DiningPaintingsWall0_BP_C", name="DiningPaintingsWall0_BP_C", net=false, pose_binding=false, rotation=false, components={"SM_PaintingLong1", "SM_PaintingLong2"}},
    {field="CoatRackDining", class="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Furniture/DiningRoom_Blueprints/DiningCoatRack_BP.DiningCoatRack_BP_C", name="DiningCoatRack_BP_C", net=false, pose_binding=false, rotation=false, components={"Wall0Furniture"}},
    {field="LampDining", class="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Furniture/DiningRoom_Blueprints/DiningLamp_BP.DiningLamp_BP_C", name="DiningLamp_BP_C", net=false, pose_binding=false, rotation=false, components={"Wall0Furniture"}},
    {field="DiningTable01", class="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Furniture/DiningRoom_Blueprints/DiningTable01_BP.DiningTable01_BP_C", name="DiningTable01_BP_C", net=false, pose_binding=false, rotation=false, components={"Wall0Furniture"}},
    {field="PaintingsWall1", class="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Furniture/DiningRoom_Blueprints/DiningPaintingsWall1_BP.DiningPaintingsWall1_BP_C", name="DiningPaintingsWall1_BP_C", net=false, pose_binding=false, rotation=false, components={"Photo_1", "Photo_2"}},
    {field="DiningHeaters", class="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Furniture/DiningRoom_Blueprints/DiningHeaters_BP.DiningHeaters_BP_C", name="DiningHeaters_BP_C", net=false, pose_binding=false, rotation=false, components={"Heater_1", "Heater_2"}},
    {field="DiningTable02", class="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Furniture/DiningRoom_Blueprints/DiningTable02_BP.DiningTable02_BP_C", name="DiningTable02_BP_C", net=false, pose_binding=false, rotation=false, components={"Wall0Furniture"}},
    {field="DiningWallClock", class="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Furniture/DiningRoom_Blueprints/Dining_WallClock_BP.Dining_WallClock_BP_C", name="Dining_WallClock_BP_C", net=false, pose_binding=false, rotation=false, components={"Scene"}},
    {field="ChickenClue", class="BlueprintGeneratedClass /Game/OutsideAssets/ChickenClue/ChickenClue_BP.ChickenClue_BP_C", name="ChickenClue_BP_C", net=false, pose_binding=true, rotation=false, components={"Scene"}},
    {field="ClueCPainting_BP", class="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Clues/ClueC_Spawn.ClueC_Spawn_C", name="ClueC_Spawn_C", net=false, pose_binding=true, rotation=false, components={"Scene"}},
    {field="PastPlayer_BP", class="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Clues/PastPlayer/PastPlayer_Clue02_BP.PastPlayer_Clue02_BP_C", name="PastPlayer_Clue02_BP_C", net=false, pose_binding=true, rotation=false, components={"Scene"}},
}
local function valid(value) return value and value:IsValid() end
local function address(value) return valid(value) and value:GetAddress() or 0 end
local function same_world(actor, pawn) return address(actor:GetWorld()) ~= 0 and address(actor:GetWorld()) == address(pawn:GetWorld()) end
local function near(a,b) return math.abs(a-b) < 0.0001 end
local function equal(a,b,fields)
    for _, field in ipairs(fields) do if not near(a[field], b[field]) then return false end end
    return true
end
local XYZ, PYR = {"X","Y","Z"}, {"Pitch","Yaw","Roll"}
local function copy(value,fields)
    local row = {}
    for _, field in ipairs(fields) do
        local number = value[field]
        assert(type(number)=="number" and number==number and math.abs(number)<math.huge, "Room visual nonfinite field=" .. field)
        row[field] = number
    end
    return row
end
local function unique(pawn, name, class, authority)
    local found
    for _, actor in ipairs(FindAllOf(name) or {}) do
        if valid(actor) and not actor:IsActorBeingDestroyed() and same_world(actor,pawn) and actor:GetClass():GetFullName()==class then
            assert(not found, "ambiguous DiningRoom visual current-world class=" .. name)
            assert(actor.bReplicates==true,"DiningRoom visual actor replication differs class=" .. name)
            assert(actor:HasAuthority()==authority, "DiningRoom visual authority differs class=" .. name)
            found = actor
        end
    end
    return found
end
local function actor_pose(actor)
    return {location=copy(actor:K2_GetActorLocation(),XYZ),rotation=copy(actor:K2_GetActorRotation(),PYR),scale=copy(actor:GetActorScale3D(),XYZ)}
end
local function pose_equal(a,b)
    -- Match the existing client transform comparison across recreated instances.
    for _,field in ipairs(XYZ) do if math.abs(a.location[field]-b.location[field])>=0.01 or math.abs(a.scale[field]-b.scale[field])>=0.01 then return false end end
    for _,field in ipairs(PYR) do if math.abs((a.rotation[field]-b.rotation[field]+180)%360-180)>=0.01 then return false end end
    return true
end
local function plant_anchor_target(pawn,room,definition)
    local anchor=room.LargePlant
    assert(valid(anchor),"DiningRoom LargePlant anchor unavailable")
    assert(anchor:GetClass():GetFullName()=="Class /Script/Engine.SceneComponent","DiningRoom LargePlant anchor class differs")
    assert(address(anchor:GetOwner())==address(room),"DiningRoom LargePlant anchor owner differs")
    assert(address(anchor:GetWorld())==address(pawn:GetWorld()),"DiningRoom LargePlant anchor world differs")
    local expected={location=copy(anchor:K2_GetComponentLocation(),XYZ),rotation=copy(anchor:K2_GetComponentRotation(),PYR),scale=copy(anchor:K2_GetComponentScale(),XYZ)}
    local system=StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
    assert(valid(system) and system:GetClass():GetFullName()=="Class /Script/Engine.KismetSystemLibrary","DiningRoom spawn quantization library unavailable/class differs")
    for _,entry in ipairs({{"location",XYZ,"net.QuantizeActorLocationOnSpawn"},{"rotation",PYR,"net.QuantizeActorRotationOnSpawn"},{"scale",XYZ,"net.QuantizeActorScaleOnSpawn"}})do
        local quantized=system:GetConsoleVariableBoolValue(entry[3])
        assert(type(quantized)=="boolean","DiningRoom spawn quantization flag differs="..entry[3])
        if quantized then
            for _,field in ipairs(entry[2])do expected[entry[1]][field]=math.floor(expected[entry[1]][field]*10+0.5)/10 end
        end
    end
    local found
    for _,actor in ipairs(FindAllOf(definition.name) or {})do
        if valid(actor) and not actor:IsActorBeingDestroyed() and same_world(actor,pawn) and actor:GetClass():GetFullName()==definition.class
            and pose_equal(actor_pose(actor),expected) then
            assert(not found,"ambiguous DiningRoom LargePlant original-anchor pose match")
            assert(actor.bReplicates==true,"DiningRoom LargePlant actor replication differs")
            assert(not actor:HasAuthority(),"DiningRoom LargePlant authority differs")
            found=actor
        end
    end
    return found
end
local function target(pawn,room,definition,authority,item)
    if authority or definition.net then
        local actor=room[definition.field]
        if not valid(actor) then return nil end
        assert(actor.bReplicates==true,"DiningRoom source/replicated actor replication differs field=" .. definition.field)
        assert(not actor:IsActorBeingDestroyed() and same_world(actor,pawn) and actor:GetClass():GetFullName()==definition.class
            and actor:HasAuthority()==authority,"DiningRoom source/replicated binding differs field=" .. definition.field)
        return actor
    end
    if definition.anchor_binding then return plant_anchor_target(pawn,room,definition) end
    if definition.pose_binding then
        assert(item and item.pose,"DiningRoom Shared binding pose missing=" .. definition.field)
        local found
        for _,actor in ipairs(FindAllOf(definition.name) or {}) do
            if valid(actor) and not actor:IsActorBeingDestroyed() and same_world(actor,pawn) and actor:GetClass():GetFullName()==definition.class
                and pose_equal(actor_pose(actor),item.pose) then
                assert(not found,"ambiguous DiningRoom Shared Actorpose match=" .. definition.field)
                assert(actor.bReplicates==true,"DiningRoom Shared Actorpose actor replication differs=" .. definition.field)
                assert(not actor:HasAuthority(),"DiningRoom Shared Actorpose authority differs=" .. definition.field)
                found=actor
            end
        end
        return found
    end
    if not definition.net then return unique(pawn,definition.name,definition.class,authority) end
end
local function heater_absence(item,n)
    local source=assert(item.wall3,"DiningHeaters component presence source unavailable")
    assert(math.type(source.kind)=="integer" and source.kind>=0 and source.kind<=8 and type(source.flip)=="boolean","DiningHeaters Wall3 type/flip differs")
    return n==1 and source.kind==6 and source.flip or n==2 and ((source.kind==1 or source.kind==6) and not source.flip or source.kind==7)
end
local function heater_wall(pawn,room,authority)
    local anchor=room.Wall3Scene
    assert(valid(anchor) and anchor:GetClass():GetFullName()=="Class /Script/Engine.SceneComponent" and address(anchor:GetOwner())==address(room) and same_world(anchor,pawn),"DiningHeaters Wall3 anchor class/owner/world differs")
    local found
    for _,wall in ipairs(FindAllOf("RoomWall_BP_C") or {}) do
        if valid(wall) and not wall:IsActorBeingDestroyed() and same_world(wall,pawn) and wall:HasAuthority()==authority then
            assert(wall:GetClass():GetFullName()=="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Walls/RoomWall_BP.RoomWall_BP_C" and wall.bReplicates==true,"DiningHeaters Wall3 class/replication differs")
            local root=wall.RootComponent
            if valid(root) and address(root:GetAttachParent())==address(anchor) then
                assert(address(root:GetOwner())==address(wall) and same_world(root,pawn) and address(wall:GetAttachParentActor())==address(room),"DiningHeaters Wall3 root/room binding differs")
                assert(not found,"ambiguous DiningHeaters Wall3 attachment")
                found=wall
            end
        end
    end
    assert(found,"DiningHeaters original Wall3 unavailable")
    local source={kind=found["Doorway Type"],flip=found["Door Flip Side"]}
    heater_absence({wall3=source},1)
    return source
end
local function heater_live(actor,component,pawn)
    assert(valid(actor.RootComponent) and address(actor.RootComponent:GetOwner())==address(actor) and same_world(actor.RootComponent,pawn),"DiningHeaters root owner/world differs")
    if not valid(component) then return false end
    assert(component:GetClass():GetFullName()=="Class /Script/Engine.StaticMeshComponent","DiningHeaters component class differs")
    local destroying=component:IsBeingDestroyed()
    assert(type(destroying)=="boolean","DiningHeaters component destroying getter differs")
    local owner=address(component:GetOwner())
    assert(owner==0 or owner==address(actor),destroying and "DiningHeaters ended component foreign owner" or "DiningHeaters component owner/world differs")
    assert(same_world(component,pawn),"DiningHeaters component owner/world differs")
    if destroying or owner==0 then
        assert(address(component:GetOuter())==address(actor),"DiningHeaters component outer differs")
        local class=StaticFindObject("/Script/Engine.ActorComponent")
        assert(valid(class) and class:GetFullName()=="Class /Script/Engine.ActorComponent","DiningHeaters component enumeration class unavailable")
        local components=actor:K2_GetComponentsByClass(class)
        assert(type(components)=="table","DiningHeaters component enumeration return differs")
        local count=0
        for index in pairs(components) do
            assert(math.type(index)=="integer" and index>=1 and index<=128,"DiningHeaters component enumeration index differs")
            count=count+1
        end
        assert(count>=1 and count<=128,"DiningHeaters component enumeration count differs")
        local seen={}
        for index=1,count do
            local value=components[index]
            assert(type(value)=="userdata" and type(value.get)=="function","DiningHeaters component enumeration parameter differs")
            local member=value:get()
            assert(valid(member),"DiningHeaters component enumeration member invalid")
            local member_class=member:GetClass():GetFullName()
            assert(member_class=="Class /Script/Engine.SceneComponent" or member_class=="Class /Script/Engine.StaticMeshComponent","DiningHeaters component enumeration member class differs")
            local id=address(member)
            assert(not seen[id],"DiningHeaters component enumeration duplicate member")
            seen[id]=true
            assert(id~=address(component),"DiningHeaters removed component remains in owned components")
            assert(address(member:GetOwner())==address(actor) and address(member:GetOuter())==address(actor) and same_world(member,pawn),"DiningHeaters component enumeration member owner/outer/world differs")
        end
        return false
    end
    assert(address(component:GetOwner())==address(actor) and same_world(component,pawn),"DiningHeaters component owner/world differs")
    return true
end
local observed
local function diagnose(pawn,message)
    local world,now = address(pawn:GetWorld()),os.time()
    if not observed or observed.world~=world or observed.message~=message or now-observed.time>=60 then
        print("[CabinRejoin] info: authority DiningRoom visual capture world=" .. world .. " " .. message .. "\n")
        observed={world=world,message=message,time=now}
    end
end
function M.capture(pawn,key_of)
    local room=unique(pawn,"DiningRoom_BP_C",ROOM,true)
    if not room then return nil end
    local row={room=key_of(room),actors={}}
    local states={}
    for index,definition in ipairs(DEFINITIONS) do
        local actor=target(pawn,room,definition,true)
        local item={present=actor~=nil,components={}};row.actors[index]=item
        if actor then
            assert(address(room[definition.field])==address(actor), "authority DiningRoom source binding differs field=" .. definition.field)
            item.actor=key_of(actor)
            if definition.pose_binding then
                item.pose=actor_pose(actor)
                assert(valid(actor.RootComponent) and address(actor.RootComponent)==address(actor.DefaultSceneRoot),"authority DiningRoom Shared original root differs=" .. definition.field)
                states[#states+1]=definition.field .. " Actorpose=" .. item.pose.location.X .. "," .. item.pose.location.Y .. "," .. item.pose.location.Z .. "/" .. item.pose.rotation.Pitch .. "," .. item.pose.rotation.Yaw .. "," .. item.pose.rotation.Roll .. "/" .. item.pose.scale.X .. "," .. item.pose.scale.Y .. "," .. item.pose.scale.Z
            end
            if definition.field=="DiningHeaters" then item.wall3=heater_wall(pawn,room,true) end
            for n,name in ipairs(definition.components) do
                local component=actor[name]
                local present=definition.field~="DiningHeaters" or heater_live(actor,component,pawn)
                if not present then
                    assert(heater_absence(item,n),"authority DiningHeaters unexpected component absence="..name)
                    item.components[n]={present=false}
                    states[#states+1]=definition.field.."."..name.."=absent Wall3="..item.wall3.kind.." flip="..tostring(item.wall3.flip)
                else
                assert(valid(component) and address(component:GetOwner())==address(actor), "authority DiningRoom component unavailable/wrong owner=" .. definition.field .. "." .. name)
                if definition.pose_binding then assert(address(component)~=address(actor.RootComponent),"authority DiningRoom Shared moved component is root=" .. definition.field) end
                local pose={location=copy(component.RelativeLocation,XYZ)}
                if definition.rotation then pose.rotation=copy(component.RelativeRotation,PYR) end
                if definition.field=="DiningHeaters" then pose.present=true end
                item.components[n]=pose
                states[#states+1]=definition.field .. "." .. name .. "=" .. pose.location.X .. "," .. pose.location.Y .. "," .. pose.location.Z
                if pose.rotation then states[#states]=states[#states] .. "/" .. pose.rotation.Pitch .. "," .. pose.rotation.Yaw .. "," .. pose.rotation.Roll end
                end
            end
        end
    end
    diagnose(pawn,"room=" .. row.room .. " components=" .. table.concat(states,";"))
    return row
end
function M.visit(world,reading,api)
    local present=api.flag(reading and nil or world.room_visual~=nil)
    if not present then return end
    local row=world.room_visual or {};world.room_visual=row
    row.room=api.text(row.room)
    assert(api.text("DiningRoom-components-v2")=="DiningRoom-components-v2","snapshot DiningRoom component format differs")
    assert(row.room:match("^DiningRoom_BP_C_%d+$"),"snapshot DiningRoom class differs")
    row.actors=row.actors or {}
    for index,definition in ipairs(DEFINITIONS) do
        local item=row.actors[index] or {};row.actors[index]=item
        item.present=api.flag(item.present)
        item.components=item.components or {}
        if item.present then
            item.actor=api.text(item.actor)
            assert(item.actor:match("^" .. definition.name .. "_%d+$"),"snapshot DiningRoom actor class differs=" .. definition.field)
            if definition.pose_binding then
                item.pose=item.pose or {}
                item.pose.location,item.pose.rotation,item.pose.scale=api.vector(item.pose.location),api.rotation(item.pose.rotation),api.vector(item.pose.scale)
            end
            if definition.field=="DiningHeaters" then
                item.wall3=item.wall3 or {}
                local kind=api.text(reading and nil or tostring(item.wall3.kind))
                assert(kind:match("^[0-8]$"),"snapshot DiningHeaters Wall3 type differs")
                item.wall3.kind=tonumber(kind);item.wall3.flip=api.flag(item.wall3.flip)
            end
            for n in ipairs(definition.components) do
                local pose=item.components[n] or {};item.components[n]=pose
                if definition.field=="DiningHeaters" then pose.present=api.flag(pose.present) end
                if definition.field~="DiningHeaters" or pose.present then
                    pose.location=api.vector(pose.location)
                    if definition.rotation then pose.rotation=api.rotation(pose.rotation) end
                else
                    assert(heater_absence(item,n),"snapshot DiningHeaters unexpected component absence="..definition.components[n])
                    assert(pose.location==nil and pose.rotation==nil,"absent DiningHeaters component has pose")
                end
            end
            assert(#item.components==#definition.components,"snapshot DiningRoom component count differs=" .. definition.field)
        else assert(#item.components==0,"absent snapshot DiningRoom actor has components=" .. definition.field) end
    end
    assert(#row.actors==#DEFINITIONS,"snapshot DiningRoom actor count differs")
end
function M.prepare(pawn,world,key_of)
    local room=unique(pawn,"DiningRoom_BP_C",ROOM,false)
    if not world.room_visual then
        if room then return nil,"waiting for absent authority DiningRoom to leave current world" end
        return {}
    end
    if not room then return nil,"waiting for original DiningRoom actor" end
    local prepared={room=room,room_address=address(room),world_address=address(pawn:GetWorld()),pawn=pawn,key_of=key_of,rows={}}
    for index,definition in ipairs(DEFINITIONS) do
        local item=world.room_visual.actors[index]
        local actor=item.present and target(pawn,room,definition,false,item) or not definition.pose_binding and target(pawn,room,definition,false,item) or nil
        if item.present then
            if not actor then return nil,"waiting for original DiningRoom furniture binding=" .. definition.field .. (definition.pose_binding and " exact authority Actorpose" or "") end
            if definition.pose_binding then assert(valid(actor.RootComponent) and address(actor.RootComponent)==address(actor.DefaultSceneRoot),"DiningRoom Shared original root differs=" .. definition.field) end
            local entry={actor=actor,address=address(actor),key=key_of(actor),definition=definition,item=item,components={}}
            for n,name in ipairs(definition.components) do
                local component=actor[name]
                if definition.field=="DiningHeaters" then
                    local live=heater_live(actor,component,pawn)
                    if not item.components[n].present then
                        assert(heater_absence(item,n),"DiningHeaters unexpected restore absence="..name)
                        entry.components[n]=live and component or false
                    elseif not live then return nil,"waiting for authority-present DiningHeaters component="..name
                    else entry.components[n]=component end
                else
                if not valid(component) then return nil,"waiting for original DiningRoom component=" .. definition.field .. "." .. name end
                assert(address(component:GetOwner())==address(actor),"DiningRoom local component owner differs=" .. definition.field .. "." .. name)
                if definition.pose_binding then assert(address(component)~=address(actor.RootComponent),"DiningRoom Shared moved component is root=" .. definition.field) end
                entry.components[n]=component
                end
            end
            prepared.rows[#prepared.rows+1]=entry
        elseif actor then return nil,"waiting for absent authority DiningRoom furniture to leave=" .. definition.field end
    end
    return prepared
end
function M.apply(prepared,log)
    if not prepared.room then return end
    assert(address(prepared.pawn:GetWorld())==prepared.world_address and address(unique(prepared.pawn,"DiningRoom_BP_C",ROOM,false))==prepared.room_address,"DiningRoom binding changed before restore")
    -- Validate every binding before the first component move.
    for _,entry in ipairs(prepared.rows) do
        assert(address(target(prepared.pawn,prepared.room,entry.definition,false,entry.item))==entry.address and prepared.key_of(entry.actor)==entry.key,"DiningRoom furniture binding changed=" .. entry.definition.field)
        if entry.definition.pose_binding then assert(valid(entry.actor.RootComponent) and address(entry.actor.RootComponent)==address(entry.actor.DefaultSceneRoot),"DiningRoom Shared original root changed=" .. entry.definition.field) end
        for n,component in ipairs(entry.components) do
            if component then
                assert(valid(component) and address(component:GetOwner())==entry.address and address(entry.actor[entry.definition.components[n]])==address(component),"DiningRoom component binding changed=" .. entry.definition.field)
                if entry.definition.field=="DiningHeaters" then assert(heater_live(entry.actor,component,prepared.pawn),"DiningHeaters component ended before apply") end
            else assert(not heater_live(entry.actor,entry.actor[entry.definition.components[n]],prepared.pawn),"DiningHeaters absent component appeared before apply") end
        end
    end
    for _,entry in ipairs(prepared.rows)do
        if entry.definition.anchor_binding then log("info","DiningRoom LargePlant original-anchor binding actor="..entry.key.." address="..entry.address)end
    end
    local changed=0
    log("info","DiningRoom visual restore attempted actors=" .. #prepared.rows)
    for _,entry in ipairs(prepared.rows) do
        for n,component in ipairs(entry.components) do
            local pose=entry.item.components[n]
            if entry.definition.field=="DiningHeaters" and not pose.present then
                if component then
                    log("info","DiningHeaters original component destroy attempted="..entry.definition.components[n].." Wall3="..entry.item.wall3.kind.." flip="..tostring(entry.item.wall3.flip))
                    component:K2_DestroyComponent(entry.actor)
                    changed=changed+1
                end
                assert(not heater_live(entry.actor,entry.actor[entry.definition.components[n]],prepared.pawn),"DiningHeaters component absence not acknowledged="..entry.definition.components[n])
                log("info","DiningHeaters component absence readback confirmed="..entry.definition.components[n])
            else
            if not equal(component.RelativeLocation,pose.location,XYZ) or entry.definition.rotation and not equal(component.RelativeRotation,pose.rotation,PYR) then
                if entry.definition.rotation then component:K2_SetRelativeLocationAndRotation(pose.location,pose.rotation,false,{},false)
                else component:K2_SetRelativeLocation(pose.location,false,{},false) end
                changed=changed+1
            end
            assert(equal(component.RelativeLocation,pose.location,XYZ) and (not entry.definition.rotation or equal(component.RelativeRotation,pose.rotation,PYR)),"DiningRoom visual restore not acknowledged=" .. entry.definition.field .. "." .. entry.definition.components[n])
            end
        end
        if entry.definition.pose_binding then assert(pose_equal(actor_pose(entry.actor),entry.item.pose),"DiningRoom Shared Actorpose changed after component restore=" .. entry.definition.field) end
    end
    log("info","DiningRoom visual component readback confirmed actors=" .. #prepared.rows .. " changed=" .. changed)
end
return M
