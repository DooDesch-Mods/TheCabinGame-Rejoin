local gt_scheduler = require("gt_scheduler")
local function log(level, message)
    print("[CabinRejoinStartup] " .. level .. ": " .. message .. "\n")
end

if _G.CabinRejoinStartup then
    log("info", "entry already loaded; client=" .. _G.CabinRejoinStartup.client.phase .. "; server=" .. _G.CabinRejoinStartup.server.phase .. "; no replay")
    return _G.CabinRejoinStartup
end

local state = {
    client = {phase = "waiting"},
    server = {phase = "waiting"},
    neighbor_flow = {phase = "waiting"},
    authority = {phase = "waiting"},
    normal_join = {phase = "waiting"},
    steam_host_autostart = {phase = "waiting"},
    menu_rejoin = {phase = "waiting"},
    explicit_host_quit = {phase = "waiting"},
    host_options_integration = {phase = "waiting"},
    map_view_gate = {phase = "waiting"},
    initial = {phase = "not_queued"},
}
_G.CabinRejoinStartup = state
log("info", "entry loaded; module startup pending")

local function fail(target, operation, cause)
    target.phase, target.cause = "failed", tostring(cause)
    log("error", operation .. " cause=" .. target.cause .. "; no replay")
end

local function limit_background_frames(context)
    if not os.getenv("CABIN_REJOIN_PROCESS_ID") then return end
    assert(context and context:IsValid() and context:HasAuthority() and context:GetWorld():IsValid(), "current background authority world required for frame limit")
    local library=StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
    assert(library and library:IsValid(), "original frame limit library unavailable")
    for _,path in ipairs({"/Script/Engine.KismetSystemLibrary:ExecuteConsoleCommand", "/Script/Engine.KismetSystemLibrary:GetConsoleVariableFloatValue"}) do
        local fn=StaticFindObject(path);assert(fn and fn:IsValid(), "original frame limit function unavailable="..path)
    end
    local before=library:GetConsoleVariableFloatValue("t.MaxFPS")
    assert(type(before)=="number", "current background frame limit unavailable")
    if before~=30 then
        log("info", "background frame limit attempted previous="..before.." requested30")
        library:ExecuteConsoleCommand(context,"t.MaxFPS 30",nil)
    end
    local actual=library:GetConsoleVariableFloatValue("t.MaxFPS")
    assert(actual==30, "background frame limit readback differs measured="..tostring(actual).." required30")
    local world=context:GetWorld():GetAddress()
    if state.frame_limit_world~=world or before~=30 then
        log("info", "background frame limit readback confirmed30 world="..world.."; actual frame timing requires observation")
        state.frame_limit_world=world
    end
end

local function start_module(name, source)
    local target = state[name]
    if target.phase ~= "waiting" then return end
    -- A failed start can leave registered hooks, so this module instance cannot retry.
    target.phase = "attempted"
    log("info", name .. " start attempted source=" .. source)
    local ok, acknowledged, cause = pcall(function()
        local module = require(name)
        assert(type(module) == "table" and type(module.start) == "function", name .. " module.start unavailable")
        target.module = module
        local options = {log = log}
        if name == "normal_join" then
            options.status_path = os.getenv("CABIN_REJOIN_CLIENT_STATUS_PATH")
            options.expected_endpoint = os.getenv("CABIN_REJOIN_EXPECTED_ENDPOINT")
        end
        if name == "server" or name == "client" then
            local control = require("control")
            local callbacks = name=="server" and control.start_server(log) or control.start_client(log)
            for key,value in pairs(callbacks) do options[key]=value end
        end
        return module.start(options)
    end)
    if not ok then fail(target, name .. " start", acknowledged); return end
    if acknowledged ~= true then fail(target, name .. " start", cause or ("required=true measured=" .. tostring(acknowledged))); return end
    target.phase = "started"
    log("info", name .. " start acknowledged source=" .. source .. "; gameplay acceptance pending")
end

local function start_authority(source)
    local target = state.authority
    if target.phase ~= "waiting" then return end
    target.phase = "attempted"
    local ok, result = pcall(function()
        local authority = require("authority")
        return authority.start({
            log = log,
            process_identity = os.getenv("CABIN_REJOIN_PROCESS_ID"),
            status_path = os.getenv("CABIN_REJOIN_STATUS_PATH"),
            endpoint_path = os.getenv("CABIN_REJOIN_ENDPOINT_PATH"),
            on_ready = function(receipt)
                state.seamless_roster = require("seamless_roster").start({receipt=receipt,log=log,
                    on_error=function(cause) assert(authority.invalidate(receipt,cause),"authority roster failure status unacknowledged") end})
                assert(state.seamless_roster.status().phase=="registered","seamless roster adapter registration failed")
                local gate,cause = require("session_gate").start(receipt,log,function(why)
                    assert(authority.invalidate(receipt,why),"authority session failure status unacknowledged")
                end)
                assert(gate,"session gate startup failed: " .. tostring(cause))
                state.session_gate = gate
                require("host_options_integration").watch(gate,log,gt_scheduler.loop,gt_scheduler.execute)
                state.endpoint = require("lobby_endpoint").start({receipt=receipt, log=log,
                    on_error=function(cause) assert(authority.invalidate(receipt,cause),"authority failure status unacknowledged") end})
                local status_path=assert(os.getenv("CABIN_REJOIN_STATUS_PATH"),"authority status path required")
                local user_dir=assert(status_path:match("^(.*)[/\\][^/\\]+$"),"authority status directory unavailable")
                state.host_server=require("host_options_integration").start_server(log,user_dir,function()
                    return state.authority.module_state and state.authority.module_state.phase=="ready"
                end)
                require("control").register_host_options(state.host_server,log)
            end,
            before_ready = function(receipt)
                limit_background_frames(receipt.lobby)
                assert(type(CabinSteamLobbySnapshot) == "function" and type(CabinSteamPublishLobbyEndpoint) == "function", "native lobby publication unavailable")
                local lobby = assert(tonumber(receipt.session_id), "original session ID is not numeric")
                assert(math.type(lobby) == "integer" and string.format("%d", lobby) == receipt.session_id, "original session ID lost precision")
                local before, owner, _, _, owning_id, name, _, detail = CabinSteamLobbySnapshot(lobby)
                assert(before == 1, "original lobby metadata unavailable cause=" .. tostring(detail))
                log("info", "authority lobby endpoint publication attempted source=" .. source)
                local published, address_ack, port_ack, owner_ack, endpoint, cause = CabinSteamPublishLobbyEndpoint(lobby, receipt.port)
                assert((published == 1 or published == 2) and address_ack > 0 and port_ack > 0 and owner_ack == 1 and endpoint == receipt.endpoint,
                    "authority lobby publication unacknowledged cause=" .. tostring(cause))
                local after, actual_owner, _, _, actual_id, actual_name, actual_endpoint, read_cause = CabinSteamLobbySnapshot(lobby)
                assert(after == 1 and actual_endpoint == receipt.endpoint and actual_owner == owner and actual_id == owning_id and actual_name == name,
                    "authority lobby metadata readback differs cause=" .. tostring(read_cause))
                log("info", "authority lobby endpoint confirmed; original owner/name preserved")
                return true
            end,
        })
    end)
    if not ok then fail(target, "authority startup", result); return end
    target.module_state, target.phase = result, result.phase
    log("info", "authority startup source=" .. source .. " phase=" .. target.phase)
end

local function observe_server(source)
    local target = state.server
    if target.phase ~= "waiting" then return end
    local ok, ready, cause = pcall(function()
        assert(type(FindFirstOf) == "function", "required API unavailable=FindFirstOf")
        local gm, count = nil, 0
        for _, value in ipairs(FindAllOf("Cabin_GameMode_C") or {}) do
            if value:IsValid() and not value:IsActorBeingDestroyed() and value:GetLocalRole() == 3 and value:GetWorld():IsValid() then
                gm, count = value, count + 1
            end
        end
        assert(count <= 1, "live authority GameMode count measured=" .. count .. " required<=1")
        if not gm or not gm:IsValid() then return false, "authority GameMode not loaded" end
        local role = gm:GetLocalRole()
        if role ~= 3 then return false, "authority GameMode role required=3 measured=" .. tostring(role) end
        assert(gm.GameStarted == false, "original round already started; phase history coverage missed")
        for _, path in ipairs({
            "/Game/CabinGameContent/PlayerContent/Cabin_Player.Cabin_Player_C:RepStartTurn_E",
            "/Game/CabinGameContent/BoardGameStuff/Board/GameBoard_BP.GameBoard_BP_C:EndPlayerTurn_E",
            "/Game/CabinGameContent/Cabin_GameMode.Cabin_GameMode_C:K2_OnLogout",
            "/Game/CabinGameContent/Cabin_GameMode.Cabin_GameMode_C:Post_Login_E",
        }) do
            local fn = StaticFindObject(path)
            if not fn or not fn:IsValid() then return false, "original phase function not loaded=" .. path end
        end
        limit_background_frames(gm)
        return true
    end)
    if not ok then fail(target, "server readiness", ready); return end
    if not ready then
        if target.reason ~= cause then log("info", "server waiting source=" .. source .. " cause=" .. cause) end
        target.reason = cause
        return
    end
    if os.getenv("CABIN_REJOIN_PROCESS_ID") and not state.original_sitting then
        local bootstrap=require("authority").status()
        if not bootstrap or bootstrap.phase~="ready" or not bootstrap.receipt then
            if target.reason~="original sitting authority receipt pending" then log("info","original sitting authority receipt pending") end
            target.reason="original sitting authority receipt pending"
            return
        end
        local registered,api,reason=pcall(function()
            local identity=require("authority_identity")
            local current=identity.resolve(identity.capture(bootstrap.receipt),bootstrap.receipt)
            if current.status~="ready" then return nil,current.cause end
            return require("original_sitting").start(bootstrap.receipt,current.game_mode,log)
        end)
        if not registered then fail(target,"original sitting registration",api); return end
        if not api then
            if target.reason~=reason then log("info","original sitting binding waits cause="..tostring(reason)) end
            target.reason=reason; return
        end
        state.original_sitting=api
        log("info","original sitting guard registered from server startup; actual OUT and branch pending")
    end
    start_module("server", source)
    start_module("neighbor_flow", source)
end

local function start_ready(source)
    start_authority(source)
    local protected, receipt = pcall(function()
        return require("map_view_gate").start({log = log, load_missing = true})
    end)
    if not protected then
        if state.map_view_gate.phase ~= "failed" then fail(state.map_view_gate, "early Map protection", receipt) end
        observe_server(source)
        return
    end
    if state.map_view_gate.phase ~= "started" then
        state.map_view_gate.phase, state.map_view_gate.receipt = "started", receipt
        log("info", "early Map protection readback before client/join source=" .. source .. "; slot=" .. receipt.slot)
    end
    start_module("client", source)
    start_module("host_options_integration", source)
    start_module("normal_join", source)
    start_module("steam_host_autostart", source)
    start_module("menu_rejoin", source)
    start_module("explicit_host_quit", source)
    observe_server(source)
end

local observed, observation_cause = pcall(function()
    gt_scheduler.loop(500, function()
        if state.server.phase == "started" or state.server.phase == "failed" then return true end
        if state.readiness_queued then
            local elapsed = os.time() - state.readiness_queued_at
            if elapsed >= 5 and (not state.readiness_warned_at or os.time() - state.readiness_warned_at >= 60) then
                state.readiness_warned_at = os.time()
                log("warn", "authority readiness callback entry pending measured=" .. elapsed .. "s required<5s; no dispatch replay")
            end
            return
        end
        state.readiness_queued, state.readiness_queued_at = true, os.time()
        local queued, cause = pcall(gt_scheduler.execute, function()
            if state.readiness_warned_at then log("info", "authority readiness callback entry recovered"); state.readiness_warned_at = nil end
            observe_server("authority readiness observer")
            state.readiness_queued = false
        end)
        if not queued then state.readiness_queued = false; fail(state.server, "authority readiness dispatch", cause) end
    end)
end)
if not observed then fail(state.server, "authority readiness observer registration", observation_cause) end

-- InitGameState runs on the game thread; it also covers later hosting after menu startup.
local registered, registration_cause = pcall(function()
    assert(type(RegisterInitGameStatePostHook) == "function", "required API unavailable=RegisterInitGameStatePostHook")
    RegisterInitGameStatePostHook(function()
        start_ready("InitGameState")
    end)
end)
state.hook = registered and "registered" or "failed"
if registered then log("info", "InitGameState startup hook registered; event acknowledgement pending")
else log("error", "InitGameState hook registration cause=" .. tostring(registration_cause) .. "; later authority startup unavailable") end

local monitored, monitor_cause = pcall(function()
    assert(type(gt_scheduler.loop) == "function", "required API unavailable=gt_scheduler.loop")
    gt_scheduler.loop(1000, function()
        local initial = state.initial
        if initial.phase == "entered" or initial.phase == "failed" then return true end
        if initial.phase ~= "queued" then return end
        local elapsed = os.time() - initial.queued_at
        if elapsed < 5 then return end
        initial.stalled = true
        log("warn", "initial game-thread callback entry pending measured=" .. elapsed .. "s required<5s; client=" .. state.client.phase .. "; server=" .. state.server.phase .. "; no replay")
        return true
    end)
end)
state.monitor = monitored and "registered" or "failed"
if not monitored then log("error", "startup watchdog registration cause=" .. tostring(monitor_cause) .. "; callback stall detection unavailable") end

state.initial.phase, state.initial.queued_at = "queued", os.time()
log("info", "initial game-thread check attempted; entry acknowledgement required within 5s")
local queued, queue_cause = pcall(function()
    assert(type(gt_scheduler.execute) == "function", "required API unavailable=gt_scheduler.execute")
    gt_scheduler.bootstrap(function()
        state.initial.phase = "entered"
        log("info", state.initial.stalled and "initial game-thread callback entry recovered; once-only guards retained" or "initial game-thread callback entry acknowledged")
        start_ready("initial game-thread callback")
    end)
end)
if not queued then fail(state.initial, "initial game-thread queue", queue_cause) end

return state
