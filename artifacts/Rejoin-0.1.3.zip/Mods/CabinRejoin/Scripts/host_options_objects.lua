local M = {}
local ROOT = "/Game/Cabin_Lobby_Content/Cards/"
local PC = "/Game/CabinGameContent/PlayerContent/Cabin_PC.Cabin_PC_C"
local GI = "/Game/CabinGameContent/CabinAdvanceFriendsGameInstance.CabinAdvanceFriendsGameInstance_C"
local GM = "/Game/Cabin_Lobby_Content/Lobby_Gamemode.Lobby_Gamemode_C"
local FIELDS = {"Difficulty_2_669213C546EFF949AC9E319627DC8920","PlayerCollision_9_98C13B414BE2E7E2DD9A9DBA39FBB0BB","RadioTutorial_7_0B68146A454989FEC1E083934A3643A2","GoodieBag_11_BB1DA55D466BA85F46AFF8A4B7B8EA77"}
M.specs = {
    {card="LobbyDifficultyCard_BP",widget="LobbyDifficulty_WBP",value="DifficultyINT",widget_value="ChosenDifficulty",text="Difficulty",display="SelectedDifficulty_T",labels={[0]="Weenie","First-Timer","Daring","WTF!"}},
    {card="PlayerCollisionCard_BP",widget="PlayerCollision_WBP",value="Enabled",widget_value="Enabled",text="Selection",display="SelectedCollision_T",labels={[0]="Off","On"}},
    {card="IntroTutorialCard_BP",widget="IntroTutorial_WBP",value="Enabled",widget_value="Enabled",text="Selection",display="SelectedCollision_T",labels={[0]="disabled","enabled"}},
    {card="GoodieCard_BP",widget="Goodie_WBP",value="Enabled",widget_value="Enabled",text="Selection",display="SelectedCollision_T",labels={[0]="disabled","enabled"}},
}
local BUTTONS = {[1]={[0]="Weenie_B_K2Node_ComponentBoundEvent_13","Regular_B_K2Node_ComponentBoundEvent_15","Hard_B_K2Node_ComponentBoundEvent_16","WTF_B_K2Node_ComponentBoundEvent_14"}}
local function valid(o) return o and o:IsValid() end
function M.address(o) return valid(o) and o:GetAddress() or 0 end
function M.exact(o, path, kind) return valid(o) and o:GetClass():GetFullName() == (kind or "BlueprintGeneratedClass") .. " " .. path end
function M.integer(text)
    assert(type(text)=="string" and text:match("^[1-9][0-9]*$"), "positive decimal ID required")
    local n=tonumber(text); assert(math.type(n)=="integer" and n>0 and tostring(n)==text,"exact ID roundtrip differs"); return n
end
function M.library(path) local o=StaticFindObject(path); assert(valid(o),"original library unavailable="..path); return o end
function M.context(pc, role)
    assert(M.exact(pc,PC) and pc:GetLocalRole()==role and not pc:IsActorBeingDestroyed(),"live original PC role differs")
    if role==2 then assert(pc:IsLocalController(),"owning local PC required") else assert(valid(pc.NetConnection),"actual remote NetConnection required") end
    local world,pawn=pc:GetWorld(),pc.Pawn
    assert(valid(world) and valid(pawn) and not pawn:IsActorBeingDestroyed() and M.address(pawn.Controller)==pc:GetAddress()
        and M.address(pawn:GetWorld())==world:GetAddress(),"actual PC/Pawn/world binding differs")
    if role==2 then assert(pawn:IsLocallyControlled() and M.address(pc.AcknowledgedPawn)==pawn:GetAddress(),"original local ownership acknowledgement pending") end
    local gameplay=M.library("/Script/Engine.Default__GameplayStatics")
    local gi=gameplay:GetGameInstance(pc); assert(M.exact(gi,GI),"original GI class differs")
    local out={}; M.library("/Script/AdvancedSessions.Default__AdvancedSessionsLibrary"):GetCurrentSessionID_AsString(gi,out)
    assert(out.SessionId~=nil,"original SessionId OUT missing")
    local session=type(out.SessionId)=="string" and out.SessionId or out.SessionId:ToString(); M.integer(session)
    local gm
    if role==3 then
        gm=gameplay:GetGameMode(pc)
        assert(M.exact(gm,GM) and gm:GetLocalRole()==3 and not gm:IsActorBeingDestroyed() and M.address(gm:GetWorld())==world:GetAddress()
            and M.address(gm.AdvancedCabinGameInstance)==gi:GetAddress(),"current original authority Lobby/World/GI required")
    end
    return {pc=pc,pawn=pawn,world=world,gi=gi,gm=gm,session_id=session}
end
function M.authenticate(pc)
    assert(type(CabinAuthenticatedSteamID)=="function","native auth unavailable")
    local id,handle=CabinAuthenticatedSteamID(pc:GetAddress())
    assert(math.type(id)=="integer" and id>0 and math.type(handle)=="integer" and handle>0,"actual native auth ID/handle unavailable")
    return id,handle
end
function M.owner(c)
    assert(type(CabinSteamLobbySnapshot)=="function","native Lobby snapshot unavailable")
    local status,id,_,_,_,_,_,cause=CabinSteamLobbySnapshot(M.integer(c.session_id))
    assert(status==1 and type(id)=="string" and id:match("^[1-9][0-9]*$"),"actual Lobby Owner unavailable cause="..tostring(cause))
    return {status=status,lobby_id=c.session_id,owner_id=id}
end
function M.values(o)
    local out={}; assert(o.LobbyGameSettings~=nil,"original LobbyGameSettings unavailable")
    for i,key in ipairs(FIELDS) do
        local value=o.LobbyGameSettings[key]
        assert((i==1 and math.type(value)=="integer" and value>=0 and value<=3) or (i~=1 and type(value)=="boolean"),"original field type/range differs="..key)
        out[i]=value
    end
    return out
end
function M.choices(values) return {difficulty=values[1],player_collision=values[2],radio_tutorial=values[3],goodie_bag=values[4]} end
function M.array(options) return {options.difficulty,options.player_collision,options.radio_tutorial,options.goodie_bag} end
function M.actors(world,path)
    local out,result,count={},{},0
    M.library("/Script/Engine.Default__GameplayStatics"):GetAllActorsOfClass(world,M.library(path),out)
    for index,parameter in pairs(out) do
        local actor=parameter:get()
        assert(math.type(index)=="integer" and index>=1 and M.exact(actor,path) and M.address(actor:GetWorld())==M.address(world)
            and not actor:IsActorBeingDestroyed(),"original actor OUT binding differs")
        result[index],count=actor,count+1
    end
    assert(count==#out,"original actor OUT is not contiguous"); return result
end
function M.cards(world)
    local out={}
    for i,spec in ipairs(M.specs) do
        local list=M.actors(world,ROOT..spec.card.."."..spec.card.."_C")
        assert(#list==1,"original option card count differs option="..i.." count="..#list); out[i]=list[1]
    end
    return out
end
function M.save(c, isolated_user_dir)
    assert(type(isolated_user_dir)=="string" and isolated_user_dir:match("^%a:[/\\]"),"isolated authority UserDir required")
    local raw=M.library("/Script/Engine.Default__KismetSystemLibrary"):GetCommandLine()
    local command=type(raw)=="string" and raw or raw:ToString()
    local parts,part,quoted={},"",false
    for i=1,#command do
        local ch=command:sub(i,i)
        if ch=='"' then quoted=not quoted
        elseif ch:match("%s") and not quoted then
            if #part>0 then parts[#parts+1],part=part,"" end
        else part=part..ch end
    end
    assert(not quoted,"original commandline quote unmatched")
    if #part>0 then parts[#parts+1]=part end
    local actual,count=nil,0
    for _,token in ipairs(parts) do local value=token:match("^%-UserDir=(.+)$"); if value then actual,count=value,count+1 end end
    local function normalized(p) return p:gsub("\\","/"):gsub("/+$",""):lower() end
    assert(count==1 and normalized(actual)==normalized(isolated_user_dir),"actual authority UserDir differs/ambiguous")
    local gameplay=M.library("/Script/Engine.Default__GameplayStatics")
    assert(gameplay:DoesSaveGameExist("GameData",0)==true,"existing GameData required; no create attempted")
    local save=gameplay:LoadGameFromSlot("GameData",0)
    assert(M.exact(save,"/Game/CabinGameContent/GameplayData_Save.GameplayData_Save_C"),"original GameData load/class failed")
    return M.values(save)
end
function M.current_lobby()
    local found
    for _,gi in ipairs(FindAllOf("CabinAdvanceFriendsGameInstance_C") or {}) do
        if M.exact(gi,GI) and not gi:GetFullName():find("Default__",1,true) and valid(gi:GetWorld()) then
            assert(not found,"original live GI is ambiguous"); found=gi
        end
    end
    if not found then return nil,"original live GI unavailable" end
    local world=found:GetWorld()
    local gm=M.library("/Script/Engine.Default__GameplayStatics"):GetGameMode(found)
    if not M.exact(gm,GM) or gm:IsActorBeingDestroyed() or gm:GetLocalRole()~=3 then return nil,"current original authority Lobby absent" end
    assert(M.address(gm:GetWorld())==world:GetAddress() and M.address(gm.AdvancedCabinGameInstance)==found:GetAddress(),"original Lobby/GI/world differs")
    return {world=world,gm=gm,gi=found}
end
function M.capture(c, cards, save)
    local out={gi=M.values(c.gi),cards={},save=save}
    for i,spec in ipairs(M.specs) do
        local card=cards[i]; local widget=card.Widget:GetWidget()
        assert(M.exact(widget,ROOT..spec.widget.."."..spec.widget.."_C","WidgetBlueprintGeneratedClass") and M.address(widget.LobbyCard)==card:GetAddress(),"original front widget/card binding differs")
        local function text(value) assert(type(value)=="userdata" and value:type()=="FText","native FText required"); return value:ToString() end
        out.cards[i]={address=card:GetAddress(),widget=widget:GetAddress(),value=card[spec.value],widget_value=widget[spec.widget_value],text=text(card[spec.text]),
            display=text(widget[spec.display]:GetText()),in_transition=card.InTransition,is_flipped=card.IsFlipped,can_flip=card.CanFlip}
    end
    return out
end
function M.hooks()
    local result={}
    for i,spec in ipairs(M.specs) do
        local buttons=i==1 and BUTTONS[1] or {[0]="Regular_B_K2Node_ComponentBoundEvent_15","Weenie_B_K2Node_ComponentBoundEvent_13"}
        for index=0,(i==1 and 3 or 1) do result[#result+1]={option=i,index=index,
            path=ROOT..spec.widget.."."..spec.widget.."_C:BndEvt__LobbyDifficulty_WBP_"..buttons[index].."_OnButtonPressedEvent__DelegateSignature"} end
    end
    return result
end
return M
