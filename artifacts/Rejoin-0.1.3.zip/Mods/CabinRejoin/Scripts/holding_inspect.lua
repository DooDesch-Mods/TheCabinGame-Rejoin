local M = {}
local recipe = require('inspect_recipe')
local refs=require('bound_refs')
local function valid(v) return v and v:IsValid() end
local function address(v) return valid(v) and v:GetAddress() or 0 end
local function near(a,b) return math.abs(a-b)<0.01 end
local function vector(v) return {X=v.X,Y=v.Y,Z=v.Z} end
local function rotation(v) return {Pitch=v.Pitch,Yaw=v.Yaw,Roll=v.Roll} end
local function vec_equal(a,b) return near(a.X,b.X) and near(a.Y,b.Y) and near(a.Z,b.Z) end
local function rot_equal(a,b)
    for _,name in ipairs({'Pitch','Yaw','Roll'}) do if math.abs((a[name]-b[name]+180)%360-180)>=0.01 then return false end end
    return true
end
local function count(array,target)
    local n=0; array:ForEach(function(_,p) if address(p:get())==target then n=n+1 end end); return n
end

function M.contract(s,token,current_token)
    assert(type(s)=='table' and s.card_status==1 and s.holding==true and s.card_owner=='owner'
        and s.hand_matches==1,'current Authority Holding inspect snapshot required')
    assert(type(s.card)=='string' and s.card:match('^[%w_]+$') and type(s.board)=='string'
        and s.board:match('^[%w_]+$') and type(s.card_class)=='string','exact original actor keys/class required')
    assert(type(s.epoch)=='string' and s.epoch~='' and math.type(s.turn_index)=='integer' and s.turn_index>=0
        and math.type(s.generation)=='integer' and s.generation>0,'current Holding round/generation/turn required')
    assert(type(token)=='table' and type(current_token)=='table' and token.id==current_token.id
        and token.fingerprint==current_token.fingerprint and math.type(token.id)=='integer' and token.id>0
        and type(token.fingerprint)=='string' and token.fingerprint~='','current authenticated presentation token differs')
    assert(type(s.room_card_disable)=='boolean' and math.type(s.card_type)=='integer' and s.card_type>=0 and s.card_type<=3,
        'current replicated card branch/type required')
    for _,name in ipairs({'pawn_halted','board_halted','special_halted','graveyard_open','in_animation'}) do
        assert(type(s.activity)=='table' and type(s.activity[name])=='boolean','current original activity missing='..name)
    end
    return true
end

function M.ready(c,after_common)
    M.contract(c.snapshot,c.token,c.current_token())
    local pc,pawn,board,card,s=c.pc,c.pawn,c.board,c.card,c.snapshot
    for _,v in ipairs({pc,pawn,board,card}) do
        if not valid(v) or v:IsActorBeingDestroyed() then return nil,'waiting for current Holding actors' end
    end
    if pc:GetLocalRole()~=2 or not pc:IsLocalController() or not pawn:IsLocallyControlled()
        or address(pc.Pawn)~=address(pawn) or address(pc.AcknowledgedPawn)~=address(pawn)
        or address(pawn.Controller)~=address(pc) then return nil,'waiting for original retained owner acknowledgement' end
    local world=address(pawn:GetWorld())
    if world==0 or address(board:GetWorld())~=world or address(card:GetWorld())~=world then return nil,'waiting for current Holding world' end
    if c.key(board)~=s.board or c.key(card)~=s.card or card:GetClass():GetFullName()~=s.card_class then return nil,'waiting for exact Holding actor keys/class' end
    if count(board.PlayerOrder,address(pawn))~=1 or address(board.CurrentPlayerTurn)~=address(pawn)
        or board.PlayerTurn~=s.turn_index or not pawn.IsCurrentTurn then return nil,'waiting for current Board roster/turn' end
    if count(pawn.CurrentCardsObjects,address(card))~=1 or card.Status~=1 or card.CardType~=s.card_type or not card.IsHolding
        or address(card.CurrentOwnedPlayer)~=address(pawn) or card.RoomCardDisable~=s.room_card_disable then
        return nil,'waiting for current replicated Holding owner/status/hand/branch' end
    local slot,slot_cause=refs.holding_slot(pawn,card)
    if not slot then return nil,slot_cause end
    local actual={pawn_halted=pawn.GameHalted,board_halted=board.HaltGame,special_halted=board.SpecialEventHalt,
        graveyard_open=board.GraveyardOpen,in_animation=pawn.InAnimation}
    for name,value in pairs(actual) do if value~=s.activity[name] then return nil,'waiting for current original activity='..name end end
    if after_common and address(pawn.GameBoard)~=address(board) then return nil,'waiting for original SetActors Board binding' end
    if after_common and (not valid(pawn.Camera) or not valid(pawn.CabinHud_WBP) or not valid(card.CardScene)
        or not valid(card.CardMesh) or address(card.CardScene)==address(card.RootComponent)
        or address(card.CardMesh)==address(card.RootComponent)) then return nil,'waiting for local Holding presentation components' end
    return true
end

local function gameplay(c)
    local pawn,board,card=c.pawn,c.board,c.card
    local r={position=vector(pawn:K2_GetActorLocation()),rotation=rotation(pawn:K2_GetActorRotation()),
        chair=address(pawn.Chair),turn=pawn.IsCurrentTurn,turn_index=board.PlayerTurn,total_turns=board.TotalTurns,
        current=address(board.CurrentPlayerTurn),started=board.GameStarted,ending=board.GameEndTime,
        card=address(card),status=card.Status,holding=card.IsHolding,owner=address(card.CurrentOwnedPlayer),
        room_disabled=card.RoomCardDisable,card_location=vector(card:K2_GetActorLocation()),
        card_rotation=rotation(card:K2_GetActorRotation()),hand={},physical={}}
    pawn.CurrentCards:ForEach(function(i,p) r.hand[i]=address(p:get()) end)
    pawn.CurrentCardsObjects:ForEach(function(i,p) r.physical[i]=address(p:get()) end)
    return r
end
local function unchanged(a,b,path)
    for name,value in pairs(a) do
        local observed=b[name]
        if type(value)=='table' then assert(type(observed)=='table','Holding invariant missing='..path..name..' observed_type='..type(observed)..' required_type=table'); unchanged(value,observed,path..name..'.')
        else assert(value==observed,'Holding restore changed gameplay='..path..name..' observed='..tostring(observed)..' required='..tostring(value)) end
    end
    for name in pairs(b) do assert(a[name]~=nil,'Holding invariant added='..path..name..' observed='..tostring(b[name])..' required=absent') end
end
-- Engine ticks own continuous poses; finish retains the exact logical gameplay comparison.
local function logical_gameplay(state)
    local logical={}
    for name,value in pairs(state) do
        if name=='position' or name=='rotation' or name=='card_location' or name=='card_rotation' then
            local axes=(name=='rotation' or name=='card_rotation') and {'Pitch','Yaw','Roll'} or {'X','Y','Z'}
            for _,axis in ipairs(axes) do
                local measured=value[axis]
                assert(type(measured)=='number' and measured==measured and math.abs(measured)<math.huge,
                    'Holding continuous pose invalid='..name..'.'..axis..' observed='..tostring(measured)..' required=finite')
            end
        else logical[name]=value end
    end
    return logical
end
local function hints(c)
    local rows={{'cancel','inspect_cancel','Cabin_Secondary'}}
    if not c.snapshot.room_card_disable then table.insert(rows,1,{'accept','eject_accept','Cabin_Interact'}) end
    c.pawn:AddInputInstruction_E(c.text(''),'',false,true,c.name('None'))
    for _,row in ipairs(rows) do c.pawn:AddInputInstruction_E(c.text(row[1]),row[2],false,false,c.name(row[3])) end
    return rows
end
local function hint_ready(c)
    local keys,widgets={},{}
    local hud=c.pawn.CabinHud_WBP
    hud.UniqueStringsArray:ForEach(function(_,p) keys[p:get():ToString()]=true end)
    hud.InputInstructionsArray:ForEach(function(_,p)
        local v=p:get(); assert(valid(v),'Holding HUD instruction widget unavailable'); widgets[v['Unique String']:ToString()]=true
    end)
    if not keys.inspect_cancel or not widgets.inspect_cancel then return nil,'waiting for original cancel hint' end
    local accept=not c.snapshot.room_card_disable
    if (keys.eject_accept==true)~=accept or (widgets.eject_accept==true)~=accept then return nil,'waiting for original accept hint branch' end
    return true
end

local registration_logs=setmetatable({}, {__mode='k'})
function M.restore(c)
    for _,name in ipairs({'text','name','log','current_token','key'}) do assert(type(c[name])=='function','Holding restore adapter missing='..name) end
    local ready,cause=M.ready(c,true); if not ready then c.log('info',cause); return nil,cause end
    local before=gameplay(c)
    local r={stage='attempted',before=before,input_receipt='incomplete',complete=false}
    registration_logs[r]=c.log
    c.log('info','Holding inspect local presentation attempted card='..c.snapshot.card)
    local ok,failure=pcall(function()
        local pawn,card,s=c.pawn,c.card,c.snapshot
        local cam=pawn.Camera
        local slot,slot_cause=refs.holding_slot(pawn,card); assert(slot,slot_cause)
        local marker={phase='inspect_entry',status=1,pawn=address(pawn),card=address(card),identity=c.token.fingerprint,epoch=s.epoch,card_type=s.card_type}
        local current={card=address(card),owner=address(pawn),status=1,hand_matches=1,turn_matches=true,identity=c.token.fingerprint,epoch=s.epoch,
            card_type=s.card_type,room_card_disable=s.room_card_disable,room_card_disable_proven=true,
            actor_location=slot.location,actor_rotation=slot.rotation,inspect_distance=16}
        local target=recipe.hand(marker,current,{location=vector(cam:K2_GetComponentLocation()),
            rotation=rotation(cam:K2_GetComponentRotation()),base_aim=rotation(pawn:GetBaseAimRotation())})
        card.PlayerNonRep=pawn
        card.GameBoard=c.board
        card.OriginHandLOC=target.origin_hand_location; card.OriginHandROT=target.origin_hand_rotation
        card.InInspect=true; card.InTransition=false; card.CardInspectDistance=16
        card.CardMesh:K2_SetRelativeLocation({X=0,Y=0,Z=0},false,{},false)
        card.CardScene:K2_SetWorldLocationAndRotation(target.card_scene_location,target.card_scene_rotation,false,{},false)
        card.InspectROT_Scare=target.card_scene_rotation
        pawn:Inspect_PP_E(true)
        pawn.IsInTurn=true; pawn.TTurnTransition=false
        card:EnableInput(c.pc)
        local functions=StaticFindObject('/Game/CabinGameContent/Cabin_Functions.Default__Cabin_Functions_C')
        assert(valid(functions),'original Input Mode library unavailable')
        functions['Input Mode'](functions,c.pc,false,false,true,pawn)
        r.hints=hints(c); r.target=target; r.stage='presentation_registered'
        unchanged(before,gameplay(c),'')
        local current_ready,current_cause=M.ready(c,true); assert(current_ready,current_cause)
    end)
    if not ok then
        r.error=tostring(failure);r.stage='failed'
        c.log('error','Holding inspect restore card='..c.snapshot.card..' cause='..r.error..'; local presentation remains incomplete')
        return nil,r
    end
    c.log('info','Holding inspect registered; original PP completion and local readback pending')
    return r
end

local finish_samples=setmetatable({}, {__mode='k'})
local function finish_wait(r,name,observed,required,axes,wrapped)
    local samples=finish_samples[r]; if not samples then samples={}; finish_samples[r]=samples end
    if samples[name] then return samples[name] end
    local function number(value) return type(value)=='number' and string.format('%.17g',value) or tostring(value) end
    local a,b,d={},{},{}
    if axes then
        for _,axis in ipairs(axes) do
            a[#a+1]=axis..'='..number(observed[axis]);b[#b+1]=axis..'='..number(required[axis])
            local x,y=observed[axis],required[axis]
            d[#d+1]=axis..'='..((type(x)=='number' and type(y)=='number')
                and number(wrapped and ((x-y+180)%360-180) or (x-y)) or 'unavailable')
        end
    end
    local reason='waiting for original Holding readback='..name..'; first mismatch sample; observed='
        ..(axes and '('..table.concat(a,',')..')' or tostring(observed))..' required='
        ..(axes and '('..table.concat(b,',')..')' or tostring(required))
        ..(axes and '; '..(wrapped and 'wrapped_delta=' or 'delta=')..'('..table.concat(d,',')..'); per_axis_tolerance<0.01' or '')
    samples[name]=reason; return reason
end
local function finish_pass(r,name)
    local samples=finish_samples[r]; if samples then samples[name]=nil end
end
local pose_observations=setmetatable({}, {__mode='k'})
local qualification_wait='waiting for original Holding evaluated pose observation'
local head_cutoff=9.999999747378752e-05
local anim_classes={
    ['AnimBlueprintGeneratedClass /Game/CabinGameContent/PlayerContent/NEW_ANIMS/SurvMan01/ABP_New_Cabin_Male.ABP_New_Cabin_Male_C']=true,
    ['AnimBlueprintGeneratedClass /Game/CabinGameContent/PlayerContent/NEW_ANIMS/SurvGirl01/ABP_New_Cabin.ABP_New_Cabin_C']=true,
}
local function qualified_pose(c,r)
    local pawn,card=c.pawn,c.card
    local mesh,cam=pawn.Mesh,pawn.Camera
    assert(valid(mesh) and mesh:GetClass():GetFullName()=='Class /Script/Engine.SkeletalMeshComponent',
        'Holding pose observation original own Mesh unavailable')
    local anim=mesh:GetAnimInstance()
    assert(valid(anim) and anim_classes[anim:GetClass():GetFullName()],
        'Holding pose observation original AnimInstance class unavailable')
    assert(address(anim:GetOwningComponent())==address(mesh) and address(anim:TryGetPawnOwner())==address(pawn)
        and address(anim.Cabin_Character)==address(pawn) and address(anim:GetWorld())==address(pawn:GetWorld()),
        'Holding pose observation own AnimInstance binding differs')
    local sitting=pawn.GameplayVars.IsSitting_13_5E5832C3491A59936F87C7A815E64A59
    assert(type(sitting)=='boolean' and type(anim['Is Sitting'])=='boolean', 'Holding pose observation sitting values unavailable')
    assert(type(pawn.AnimStates)=='number' and type(anim['Anim States'])=='number','Holding pose observation animation states unavailable')
    if not sitting or anim['Is Sitting']~=sitting or anim['Anim States']~=pawn.AnimStates then
        pose_observations[r]=nil
        return nil,qualification_wait..'; original seated animation state differs'
    end
    local slot,cause=refs.holding_slot(pawn,card);assert(slot,cause)
    local chair=pawn.Chair
    local hand=chair.PlayerCards
    local socket=hand:GetAttachSocketName()
    assert(socket:ToString()=='PlayerCards' and mesh:GetSocketBoneName(socket):ToString()=='hand_l',
        'Holding pose observation original hand socket bone differs')
    local function axes(v,names,label)
        assert(v~=nil,'Holding pose observation missing='..label)
        for _,name in ipairs(names) do
            local n=v[name]
            assert(type(n)=='number' and n==n and math.abs(n)<math.huge,'Holding pose observation nonfinite='..label..'.'..name)
        end
        return v
    end
    local function rot(v,label) return rotation(axes(v,{'Pitch','Yaw','Roll'},label)) end
    local function vec(v,label) return vector(axes(v,{'X','Y','Z'},label)) end
    local head=rot(anim.HeadRotation,'HeadRotation')
    local current=rot(anim.HeadRotation_Current,'HeadRotation_Current')
    local camera_relative=rot(cam.RelativeRotation,'Camera.RelativeRotation')
    local target={Pitch=head.Pitch,Yaw=head.Yaw,Roll=0}
    for _,row in ipairs({{head,camera_relative,'stored head sample versus Camera.RelativeRotation'},
        {current,target,'HeadRotation_Current versus original seated target'}}) do
        for _,name in ipairs({'Pitch','Yaw','Roll'}) do
            local delta=math.abs((row[1][name]-row[2][name]+180)%360-180)
            if delta>head_cutoff then
                pose_observations[r]=nil
                return nil,finish_wait(r,'Holding.'..row[3]..'.'..name,delta,head_cutoff)
            end
        end
    end
    local token,current_token=c.token,c.current_token()
    assert(math.type(token.generation)=='integer' and token.generation>0 and token.generation==c.snapshot.generation
        and token.generation==current_token.generation and token.nonce==current_token.nonce
        and type(token.nonce)=='string' and #token.nonce==32 and token.nonce:match('^[0-9a-f]+$'),
        'Holding pose observation current authenticated generation/nonce differs')
    local sample={observation=c,
        binding={pc=address(c.pc),pawn=address(pawn),board=address(c.board),card=address(card),world=address(pawn:GetWorld()),
            chair=address(chair),slot=address(chair['Card'..slot.index..'Scene']),root=address(card.RootComponent),hand=address(hand),
            mesh=address(mesh),anim=address(anim),camera=address(cam),scene=address(card.CardScene),input=address(card.InputComponent),
            generation=token.generation,id=token.id,nonce=token.nonce,fingerprint=token.fingerprint,epoch=c.snapshot.epoch,
            sitting=sitting,anim_state=pawn.AnimStates},
        poses={socket={location=vec(hand:K2_GetComponentLocation(),'PlayerCards.location'),rotation=rot(hand:K2_GetComponentRotation(),'PlayerCards.rotation')},
            root={location=vec(slot.location,'Root.location'),rotation=rot(slot.rotation,'Root.rotation')},
            camera={location=vec(cam:K2_GetComponentLocation(),'Camera.location'),rotation=rot(cam:K2_GetComponentRotation(),'Camera.rotation')},
            base_aim={location={X=0,Y=0,Z=0},rotation=rot(pawn:GetBaseAimRotation(),'BaseAim')}}}
    local prior=pose_observations[r]
    if not prior then pose_observations[r]=sample;return nil,qualification_wait..'; first current watch sample retained' end
    for name,value in pairs(sample.binding) do
        if prior.binding[name]~=value then pose_observations[r]=sample;return nil,qualification_wait..'; binding changed='..name end
    end
    for name,pose in pairs(sample.poses) do
        if not vec_equal(pose.location,prior.poses[name].location) or not rot_equal(pose.rotation,prior.poses[name].rotation) then
            pose_observations[r]=sample;return nil,qualification_wait..'; sampled pose changed='..name
        end
    end
    if prior.observation==c then return nil,qualification_wait..'; distinct existing watch callback required' end
    return true
end

local function terminal_pose(c,r)
    if r.terminal_pose_stage=='confirmed' then return true end
    if r.terminal_pose_stage then return nil,r.terminal_pose_error or 'Holding terminal pose already attempted; no setter replay' end
    local pawn,card,s=c.pawn,c.card,c.snapshot
    if not valid(card.InputComponent) then return nil,'waiting for original Holding input registration before terminal pose' end
    if c.pc.bShowMouseCursor~=false then return nil,finish_wait(r,'PC.bShowMouseCursor',c.pc.bShowMouseCursor,false) end
    if not pawn.InspectLight:IsVisible() then return nil,'waiting for original Holding light before terminal pose' end
    if not vec_equal(card.CardMesh.RelativeLocation,{X=0,Y=0,Z=0}) then
        return nil,finish_wait(r,'Card.CardMesh.relative_location',card.CardMesh.RelativeLocation,{X=0,Y=0,Z=0},{'X','Y','Z'},false) end
    local cam=pawn.Camera
    if not valid(cam) or address(cam:GetOwner())~=address(pawn) or address(cam:GetWorld())~=address(pawn:GetWorld()) then
        return nil,'waiting for exact own Holding camera world before terminal pose' end
    local log=registration_logs[r]
    if type(log)~='function' then return nil,'Holding terminal pose registration logger unavailable; no setters attempted' end
    local qualified,qualification_cause=qualified_pose(c,r);if not qualified then return nil,qualification_cause end
    pose_observations[r]=nil
    r.terminal_pose_stage='attempted'
    r.terminal_pose_setters_attempted=false
    local ok,cause=pcall(function()
        local ready,blocker=M.ready(c,true);assert(ready,blocker)
        local slot,slot_cause=refs.holding_slot(pawn,card);assert(slot,slot_cause)
        local prior=r.target
        local actual_location,actual_rotation=vector(card.CardScene:K2_GetComponentLocation()),rotation(card.CardScene:K2_GetComponentRotation())
        local camera={location=vector(cam:K2_GetComponentLocation()),rotation=rotation(cam:K2_GetComponentRotation()),base_aim=rotation(pawn:GetBaseAimRotation())}
        local marker={phase='inspect_entry',status=1,pawn=address(pawn),card=address(card),identity=c.token.fingerprint,epoch=s.epoch,card_type=s.card_type}
        local current={card=address(card),owner=address(pawn),status=1,hand_matches=1,turn_matches=true,identity=c.token.fingerprint,epoch=s.epoch,
            card_type=s.card_type,room_card_disable=s.room_card_disable,room_card_disable_proven=true,
            actor_location=slot.location,actor_rotation=slot.rotation,inspect_distance=16}
        local target=recipe.hand(marker,current,camera)
        local function pose(label,p,a)
            return string.format('%s LOC=(%.17g,%.17g,%.17g) ROT=(%.17g,%.17g,%.17g)',label,p.X,p.Y,p.Z,a.Pitch,a.Yaw,a.Roll)
        end
        log('info','Holding terminal pose attempted card='..s.card..'; '
            ..pose('prior_target',prior.card_scene_location,prior.card_scene_rotation)..'; '
            ..pose('actual_scene',actual_location,actual_rotation)..'; '
            ..pose('current_recipe',target.card_scene_location,target.card_scene_rotation)..'; '
            ..pose('current_root',slot.location,slot.rotation)..'; '..pose('current_camera',camera.location,camera.rotation))
        local before=gameplay(c)
        r.terminal_pose_setters_attempted=true
        card.OriginHandLOC=target.origin_hand_location;card.OriginHandROT=target.origin_hand_rotation
        card.CardScene:K2_SetWorldLocationAndRotation(target.card_scene_location,target.card_scene_rotation,false,{},false)
        card.InspectROT_Scare=target.card_scene_rotation
        unchanged(before,gameplay(c),'')
        ready,blocker=M.ready(c,true);assert(ready,blocker)
        assert(vec_equal(card.OriginHandLOC,target.origin_hand_location) and rot_equal(card.OriginHandROT,target.origin_hand_rotation),
            'Holding terminal local origin assignment not acknowledged')
        assert(vec_equal(card.CardScene:K2_GetComponentLocation(),target.card_scene_location)
            and rot_equal(card.CardScene:K2_GetComponentRotation(),target.card_scene_rotation),
            'Holding terminal local Scene assignment not acknowledged')
        assert(rot_equal(card.InspectROT_Scare,target.card_scene_rotation),'Holding terminal local scare rotation assignment not acknowledged')
        log('info','Holding terminal pose confirmed card='..s.card..'; '..pose('after_target',card.CardScene:K2_GetComponentLocation(),card.CardScene:K2_GetComponentRotation()))
        r.target=target;r.terminal_pose_stage='confirmed'
        finish_samples[r]=nil
    end)
    if not ok then
        r.terminal_pose_stage='failed';r.terminal_pose_error='Holding terminal pose failed card='..s.card..' cause='..tostring(cause)
            ..'; setters_attempted='..tostring(r.terminal_pose_setters_attempted)..'; no setter replay'
        local emitted,log_cause=pcall(log,'error',r.terminal_pose_error)
        if not emitted then r.terminal_pose_error=r.terminal_pose_error..'; error logger failed: '..tostring(log_cause) end
        return nil,r.terminal_pose_error
    end
    return true
end
local function finish(c,r)
    local ready,cause=M.ready(c,true); if not ready then return nil,cause end
    if type(r)~='table' or r.stage~='presentation_registered' then return nil,'Holding restore registration receipt missing' end
    if r.terminal_pose_stage=='failed' then return nil,r.terminal_pose_error end
    unchanged(logical_gameplay(r.before),logical_gameplay(gameplay(c)),'')
    local pawn,card=c.pawn,c.card
    if not valid(pawn.Inspect_PP_TL) or pawn.Inspect_PP_TL:IsPlaying() then return nil,'waiting for original Inspect_PP timeline completion' end
    local length=pawn.Inspect_PP_TL:GetTimelineLength()
    if length<=0 or pawn.Inspect_PP_TL:GetPlaybackPosition()<length-0.001 then return nil,'waiting for original Inspect_PP final timeline position' end
    do
        local observed,required=pawn.IsInspecting,true
        if not observed then return nil,finish_wait(r,'Pawn.IsInspecting',observed,required) end
        finish_pass(r,'Pawn.IsInspecting')
    end
    do
        local observed,required=pawn.IsInTurn,true
        if not observed then return nil,finish_wait(r,'Pawn.IsInTurn',observed,required) end
        finish_pass(r,'Pawn.IsInTurn')
    end
    do
        local observed,required=pawn.TTurnTransition,false
        if observed then return nil,finish_wait(r,'Pawn.TTurnTransition',observed,required) end
        finish_pass(r,'Pawn.TTurnTransition')
    end
    do
        local observed,required=card.InInspect,true
        if not observed then return nil,finish_wait(r,'Card.InInspect',observed,required) end
        finish_pass(r,'Card.InInspect')
    end
    do
        local observed,required=card.InTransition,false
        if observed then return nil,finish_wait(r,'Card.InTransition',observed,required) end
        finish_pass(r,'Card.InTransition')
    end
    do
        local observed,required=address(card.PlayerNonRep),address(pawn)
        if observed~=required then return nil,finish_wait(r,'Card.PlayerNonRep',observed,required) end
        finish_pass(r,'Card.PlayerNonRep')
    end
    do
        local observed,required=address(card.GameBoard),address(c.board)
        if observed~=required then return nil,finish_wait(r,'Card.GameBoard',observed,required) end
        finish_pass(r,'Card.GameBoard')
    end
    local terminal,terminal_cause=terminal_pose(c,r); if not terminal then return nil,terminal_cause end
    do
        local observed,required=card.OriginHandLOC,r.target.origin_hand_location
        if not vec_equal(observed,required) then return nil,finish_wait(r,'Card.OriginHandLOC',observed,required,{'X','Y','Z'},false) end
        finish_pass(r,'Card.OriginHandLOC')
    end
    do
        local observed,required=card.OriginHandROT,r.target.origin_hand_rotation
        if not rot_equal(observed,required) then return nil,finish_wait(r,'Card.OriginHandROT',observed,required,{'Pitch','Yaw','Roll'},true) end
        finish_pass(r,'Card.OriginHandROT')
    end
    do
        local observed,required=card.CardScene:K2_GetComponentLocation(),r.target.card_scene_location
        if not vec_equal(observed,required) then return nil,finish_wait(r,'Card.CardScene.location',observed,required,{'X','Y','Z'},false) end
        finish_pass(r,'Card.CardScene.location')
    end
    do
        local observed,required=card.CardScene:K2_GetComponentRotation(),r.target.card_scene_rotation
        if not rot_equal(observed,required) then return nil,finish_wait(r,'Card.CardScene.rotation',observed,required,{'Pitch','Yaw','Roll'},true) end
        finish_pass(r,'Card.CardScene.rotation')
    end
    do
        local observed,required=card.CardMesh.RelativeLocation,{X=0,Y=0,Z=0}
        if not vec_equal(observed,required) then return nil,finish_wait(r,'Card.CardMesh.relative_location',observed,required,{'X','Y','Z'},false) end
        finish_pass(r,'Card.CardMesh.relative_location')
    end
    do
        local observed,required=valid(card.InputComponent),true
        if not observed then return nil,finish_wait(r,'Card.InputComponent.valid',observed,required) end
        finish_pass(r,'Card.InputComponent.valid')
    end
    do
        local observed,required=c.pc.bShowMouseCursor,false
        if observed~=required then return nil,finish_wait(r,'PC.bShowMouseCursor',observed,required) end
        finish_pass(r,'PC.bShowMouseCursor')
    end
    do
        local observed,required=pawn.InspectLight:IsVisible(),true
        if not observed then return nil,finish_wait(r,'Pawn.InspectLight.visible',observed,required) end
        finish_pass(r,'Pawn.InspectLight.visible')
    end
    local hint,hint_cause=hint_ready(c); if not hint then return nil,hint_cause end
    finish_samples[r]=nil
    r.local_confirmed,r.complete=true,true
    r.input_receipt='original_input_not_exercised'
    return r
end
function M.finish(c,r)
    local ok,receipt,cause=pcall(finish,c,r)
    if not ok then if type(r)=='table' then pose_observations[r]=nil end;error(receipt,0) end
    if not receipt and type(r)=='table' and not (type(cause)=='string' and cause:sub(1,#qualification_wait)==qualification_wait) then
        pose_observations[r]=nil
    end
    return receipt,cause
end
return M
