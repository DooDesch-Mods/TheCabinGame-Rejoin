local M = {}
local PAWN = '/Game/CabinGameContent/PlayerContent/Cabin_Player.Cabin_Player_C:'
local BOARD = '/Game/CabinGameContent/BoardGameStuff/Board/GameBoard_BP.GameBoard_BP_C:'

local function integer(value, label)
    assert(math.type(value) == 'integer' and value > 0, label .. ' must be a positive integer')
    return value
end

function M.new(options)
    for _, name in ipairs({'evidence', 'current_card', 'log'}) do
        assert(type(options[name]) == 'function', 'card observer adapter missing=' .. name)
    end
    local markers, failed, skipped, epoch, active, attempted = {}, {}, {}, nil, false, false
    local api = {}
    local function log(level, message)
        local ok, cause = pcall(options.log, level, 'card observer ' .. message)
        if not ok then
            print('[CabinRejoin] error: card observer log cause=' .. tostring(cause) .. '\n')
            print('[CabinRejoin] ' .. level .. ': ' .. message .. '\n')
        end
    end
    local function evidence(pawn, card)
        local e, reason = options.evidence(pawn, card)
        if not e then return nil, assert(reason, 'missing evidence must state its cause') end
        assert(e.authority == true and e.authenticated == true and e.same_world == true,
            'live authority, native identity and world binding required')
        integer(e.pawn, 'pawn address'); integer(e.board, 'board address')
        integer(e.identity, 'native authenticated Steam ID')
        assert(type(e.epoch) == 'string' and e.epoch ~= '', 'current round epoch required')
        assert(math.type(e.turn) == 'integer', 'current turn index required')
        assert(type(e.ending) == 'boolean', 'current Board.GameEndTime required')
        if epoch ~= e.epoch then
            markers, failed, skipped, epoch = {}, {}, {}, e.epoch
            log('info', 'round epoch changed; earlier observations cleared')
        end
        if e.ending then markers = {}; return nil, 'original round ending' end
        return e
    end
    local function call(operation, pawn, callback)
        local ok, result, reason = pcall(callback)
        if not ok then
            local key = pawn and pawn:GetAddress() or 'observer'
            if failed[key] ~= tostring(result) then
                log('error', operation .. ' target=' .. tostring(key) .. ' cause=' .. tostring(result)
                    .. '; target history invalidated')
            end
            failed[key] = tostring(result)
            markers[key] = nil
            return nil, tostring(result)
        end
        return result, reason
    end
    function api.observe(kind, pawn, card)
        assert(kind == 'inspect' or kind == 'cancel' or kind == 'accept', 'unknown original card event')
        return call(kind, pawn, function()
            local e, reason = evidence(pawn, card)
            if not e then
                local key = pawn:GetAddress()
                if skipped[key] ~= reason then log('info', kind .. ' skipped target=' .. key .. ' cause=' .. reason) end
                skipped[key] = reason
                return nil, reason
            end
            if failed[e.pawn] then return nil, 'target history failed: ' .. failed[e.pawn] end
            assert(e.roster_matches == 1, 'exact retained pawn Board roster binding required')
            integer(e.card, 'original RPC card address')
            local previous = markers[e.pawn]
            if kind == 'cancel' then
                if previous and previous.card == e.card then markers[e.pawn] = nil end
                log('info', 'original cancel observed pawn=' .. e.pawn .. ' card=' .. e.card)
                return true
            end
            if kind == 'inspect' then
                assert(e.current_pawn == e.pawn, 'original inspect has no matching current turn')
                if e.status == 1 then assert(e.card_owner == e.pawn, 'original Holding CurrentOwnedPlayer differs') end
                assert(e.status == 0 or e.status == 1 or e.status == 2, 'original inspect status differs')
                assert(math.type(e.card_type) == 'integer' and e.card_type >= 0 and e.card_type <= 3,
                    'original card type unavailable')
                assert(e.card_binding == true, 'original board, hand or graveyard card membership required')
            elseif e.current_pawn ~= e.pawn then
                markers[e.pawn] = nil
                log('info', 'original accept completed outside this pawn turn; no pending marker created')
                return true
            end
            markers[e.pawn] = {epoch = e.epoch, identity = e.identity, board = e.board,
                pawn = e.pawn, turn = e.turn, card = e.card, status = e.status,
                card_type = e.card_type, card_class = e.card_class or (previous and previous.card == e.card and previous.card_class), phase = kind == 'inspect' and 'inspect_entry' or 'action_pending'}
            log('info', 'original ' .. kind .. ' observed pawn=' .. e.pawn .. ' card=' .. e.card)
            return true
        end)
    end
    function api.room_placed(pawn, card, card_class)
        return call('original Room placement', pawn, function()
            local e, reason = evidence(pawn, card)
            if not e then return nil, reason end
            local marker = markers[e.pawn]
            if not marker or marker.phase ~= 'action_pending' or marker.card ~= e.card then
                local cause = 'Room placement has no matching pending original card'
                if skipped[e.pawn] ~= cause then log('info', cause .. ' pawn=' .. e.pawn) end
                skipped[e.pawn] = cause
                return nil, cause
            end
            assert(not failed.observer and not failed[e.pawn], 'original card observer history failed')
            assert(marker.epoch == e.epoch and marker.identity == e.identity and marker.board == e.board
                and marker.turn == e.turn and e.current_pawn == e.pawn, 'Room placement original epoch/identity/Board/turn differs')
            assert(e.roster_matches == 1 and e.card_type == 0 and marker.card_type == 0 and e.status == 4,
                'Room placement requires original Room/type0/placed status4')
            assert(card:IsValid() and not card:IsActorBeingDestroyed() and card:HasAuthority()
                and card:GetWorld():GetAddress() == pawn:GetWorld():GetAddress(), 'Room placement live Authority card/world differs')
            assert(card_class and card_class:IsValid() and card_class:GetAddress() == card:GetClass():GetAddress()
                and e.card_class == marker.card_class, 'Room placement original card class differs')
            assert(pawn.CurrentCardsObjects ~= nil, 'Room placement current original physical hand unavailable')
            local hand_matches = 0
            pawn.CurrentCardsObjects:ForEach(function(_, parameter)
                local value = parameter:get()
                assert(value and value:IsValid(), 'Room placement current hand contains invalid original card')
                if value:GetAddress() == e.card then hand_matches = hand_matches + 1 end
            end)
            assert(hand_matches == 0, 'Room placement physical hand card matches measured=' .. hand_matches .. ' required=0')
            -- DropCard calls this event after AddRoom and the original hand removal, before clearing its Map card.
            markers[e.pawn] = nil
            log('info', 'original Room placement observed pawn=' .. e.pawn .. ' card=' .. e.card
                .. ' status=' .. e.status .. '; matching pending marker cleared')
            return true
        end)
    end
    function api.inspect(pawn)
        return call('inspect current state', pawn, function()
            local e, reason = evidence(pawn, nil)
            if not e then return {phase = 'unknown', cause = reason, restore_ready = false} end
            if failed.observer then return {phase = 'unknown', cause = failed.observer, restore_ready = false} end
            if failed[e.pawn] then return {phase = 'unknown', cause = failed[e.pawn], restore_ready = false} end
            local marker = markers[e.pawn]
            if marker and (marker.epoch ~= e.epoch or marker.identity ~= e.identity
                or marker.board ~= e.board or marker.turn ~= e.turn or e.current_pawn ~= e.pawn) then
                markers[e.pawn], marker = nil, nil
                log('info', 'original turn or binding changed; card observation cleared')
            end
            if not marker then
                return {phase = 'unknown', cause = 'no complete original card subphase observation', restore_ready = false}
            end
            if marker.phase == 'inspect_entry' then
                local current, blocker = options.current_card(marker.card, pawn)
                if not current then
                    return {phase = 'unknown', cause = blocker or 'current original card evidence unavailable', restore_ready = false}
                end
                if (marker.status == 1 and current.owner ~= e.pawn) or current.status ~= marker.status or current.binding ~= true then
                    markers[e.pawn] = nil
                    return {phase = 'unknown', cause = 'current original inspect binding changed', restore_ready = false}
                end
            end
            local result = {}
            for name, value in pairs(marker) do result[name] = value end
            result.restore_ready = false
            result.cause = marker.phase == 'inspect_entry'
                and 'local inspect pose, cancel origin and input completion require a restore receipt'
                or 'original subclass action continues; no action replay or input release inferred'
            return result
        end)
    end
    function api.end_board(board_address)
        for pawn, marker in pairs(markers) do
            if marker.board == board_address then markers[pawn] = nil end
        end
    end
    function api.ended(address)
        for pawn, marker in pairs(markers) do
            if pawn == address or marker.board == address or marker.card == address then markers[pawn] = nil end
        end
    end
    function api.register()
        assert(not attempted, 'card observer registration already attempted')
        attempted = true
        local ok, cause = pcall(function()
            for _, name in ipairs({'CardInteractRep_E', 'CardAcceptRep_E', 'CancelCard_E'}) do
                assert(StaticFindObject(PAWN .. name):IsValid(), 'original function unavailable=' .. name)
            end
            assert(StaticFindObject(BOARD .. 'EndPlayerTurn_E'):IsValid(), 'original EndPlayerTurn_E unavailable')
            assert(StaticFindObject(PAWN .. 'PlacedRoomCard_E'):IsValid(), 'original PlacedRoomCard_E unavailable')
            local function hook(name, kind)
                local pre, post = RegisterHook(PAWN .. name, function(context, parameter)
                    if not active then return end
                    local pawn = context:get()
                    call('hook ' .. name, pawn, function()
                        if pawn:GetLocalRole() ~= 3 then return true end
                        return api.observe(kind, pawn, parameter:get())
                    end)
                end)
                assert(type(pre) == 'number' and type(post) == 'number' and pre ~= 0 and post ~= 0,
                    'script post-hook IDs unavailable=' .. name)
                log('info', 'Script post-hook registered name=' .. name .. ' ids=' .. pre .. ',' .. post)
            end
            hook('CardInteractRep_E', 'inspect'); hook('CardAcceptRep_E', 'accept'); hook('CancelCard_E', 'cancel')
            local room_pre, room_post = RegisterHook(PAWN .. 'PlacedRoomCard_E', function(context, card_class, card)
                if not active then return end
                local pawn = context:get()
                call('hook PlacedRoomCard_E', pawn, function()
                    if pawn:GetLocalRole() ~= 3 then return true end
                    return api.room_placed(pawn, card:get(), card_class:get())
                end)
            end)
            assert(type(room_pre) == 'number' and type(room_post) == 'number' and room_pre ~= 0 and room_post ~= 0,
                'original PlacedRoomCard_E post-hook IDs unavailable')
            log('info', 'Script post-hook registered name=PlacedRoomCard_E ids=' .. room_pre .. ',' .. room_post)
            local pre, post = RegisterHook(BOARD .. 'EndPlayerTurn_E', function(context)
                if active then
                    call('original EndPlayerTurn_E', nil, function()
                        local board = context:get()
                        if board:GetLocalRole() == 3 then api.end_board(board:GetAddress()) end
                        return true
                    end)
                end
            end)
            assert(type(pre) == 'number' and type(post) == 'number' and pre ~= 0 and post ~= 0,
                'original EndPlayerTurn_E post-hook IDs unavailable')
            RegisterEndPlayPreHook(function(context, reason)
                if active then
                    call('original EndPlay', nil, function()
                        local object = context:get()
                        api.ended(object:GetAddress())
                        return true
                    end)
                end
            end)
            active = true
        end)
        if not ok then active = false; log('error', 'registration cause=' .. tostring(cause) .. '; hooks gated inactive') end
        return ok, cause
    end
    function api.stop() active = false; markers = {}; log('info', 'observer stopped; hooks gated inactive') end
    function api.clear(cause)
        assert(type(cause)=='string' and cause~='', 'observer clear cause required')
        markers,failed,skipped={},{},{}
        log('info','earlier observations cleared cause='..cause)
    end
    return api
end

return M
