local M = {}
local CLASS = "BlueprintGeneratedClass /Game/OutsideAssets/Lantern/Cabin_Lantern_BP.Cabin_Lantern_BP_C"
local PAWN = "BlueprintGeneratedClass /Game/CabinGameContent/PlayerContent/Cabin_Player.Cabin_Player_C"
local function valid(object) return object ~= nil and object:IsValid() end
local function address(object) return valid(object) and object:GetAddress() or 0 end

local function context(item)
    local pawn = item.pawn
    assert(valid(pawn) and not pawn:IsActorBeingDestroyed() and pawn:HasAuthority(), "retained authority pawn unavailable")
    assert(pawn:GetClass():GetFullName() == PAWN, "retained pawn exact class differs")
    assert(address(pawn:GetWorld()) == item.world and address(pawn.Mesh) == item.mesh, "retained pawn world/mesh changed")
    assert(valid(item.pc) and not item.pc:IsActorBeingDestroyed() and item.pc:HasAuthority() and address(item.pc:GetWorld()) == item.world, "retained authority controller unavailable")
    assert(address(item.pc.Pawn) == item.pawn_address and address(pawn.Controller) == address(item.pc), "retained connected ownership differs")
    return pawn
end

local function binding(pawn, actor)
    assert(valid(actor) and not actor:IsActorBeingDestroyed(), "captured lantern unavailable")
    assert(actor:GetClass():GetFullName() == CLASS and actor:HasAuthority() and actor.bReplicates == true, "lantern exact authority class/replication differs")
    assert(address(actor:GetWorld()) == address(pawn:GetWorld()) and address(actor.Player) == address(pawn), "lantern world/player differs")
    local root = actor.RootComponent
    assert(valid(root) and address(root:GetOwner()) == address(actor), "lantern root ownership differs")
    assert(address(root:GetAttachParent()) == address(pawn.Mesh) and root:GetAttachSocketName():ToString() == "Lantern", "lantern original mesh/socket differs")
    return actor:GetAddress()
end

function M.capture(pawn)
    assert(valid(pawn) and pawn:HasAuthority() and pawn:GetClass():GetFullName() == PAWN, "original retained authority pawn required")
    assert(valid(pawn:GetWorld()) and valid(pawn.Mesh), "retained original world/mesh unavailable")
    local actor = pawn.Cabin_Lantern
    if not valid(actor) then return nil, "original lantern has not spawned" end
    local key = binding(pawn, actor)
    return {pawn = pawn, pawn_address = pawn:GetAddress(), world = address(pawn:GetWorld()), mesh = address(pawn.Mesh), previous = actor, previous_address = key, pending = {}}
end

function M.connect(item, pc)
    item.pc = pc
    context(item)
end

function M.observe(item, log)
    assert(not item.failed, "lantern cleanup previously failed; no replay")
    local pawn = context(item)
    local current = pawn.Cabin_Lantern
    if not valid(current) then return false, "waiting for original current lantern" end
    local current_address = binding(pawn, current)
    for key, pending in pairs(item.pending) do
        if pending.endplay_reason ~= nil then
            assert(pending.endplay_reason == 0, "previous lantern EndPlay reason differs measured=" .. pending.endplay_reason .. " required=0")
            assert(current_address ~= key, "destroyed previous lantern is still current")
            log("info", "previous lantern destruction confirmed address=" .. key .. " replacement=" .. current_address .. " Destroyed EndPlay")
            item.pending[key] = nil
        elseif os.time() - pending.attempted >= 5 then
            error("previous lantern destruction not acknowledged after5s address=" .. key .. "; no replay")
        end
    end
    if current_address == item.previous_address then return true end
    local previous, old_address = item.previous, item.previous_address
    if not valid(previous) or previous:IsActorBeingDestroyed() then
        log("info", "previous lantern already ended address=" .. old_address .. "; no destroy attempted")
        item.previous, item.previous_address = current, current_address
        return true
    end
    assert(binding(pawn, previous) == old_address, "previous lantern binding changed")
    assert(not item.pending[old_address], "previous lantern destruction already attempted")
    local pending = {attempted = os.time()}
    item.pending[old_address] = pending
    item.previous, item.previous_address = current, current_address
    log("info", "previous lantern destruction attempted address=" .. old_address .. " replacement=" .. current_address .. " pawn=" .. item.pawn_address)
    previous:K2_DestroyActor()
    context(item)
    assert(address(pawn.Cabin_Lantern) == current_address and binding(pawn, current) == current_address, "current lantern changed during previous destruction")
    return true
end

function M.ended(item, key, reason, log)
    local pending = item.pending[key]
    if not pending then return end
    assert(pending.endplay_reason == nil, "duplicate previous lantern EndPlay acknowledgement address=" .. key)
    pending.endplay_reason = reason
    log("info", "previous lantern EndPlay observed address=" .. key .. " reason=" .. reason)
end

return M
