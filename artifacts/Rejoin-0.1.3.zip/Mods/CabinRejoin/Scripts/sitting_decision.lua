local M={}

function M.decide(row)
    assert(type(row)=="table","current original sitting observation required")
    assert(type(row.original)=="boolean","original AllSitting bool unavailable")
    if row.identity_current~=true then return false,"current authority identity unavailable" end
    if row.game_started~=false then return false,"original round already started or started state unavailable" end
    if row.game_ended~=false then return false,"original round ended or ended state unavailable" end
    for _,name in ipairs({"sitting","chairs","network_players","connections","player_states","local_players"}) do
        assert(math.type(row[name])=="integer" and row[name]>=0,"actual nonnegative integer unavailable="..name)
    end
    assert(row.chairs>0 and row.sitting<=row.chairs,"original Chair roster unavailable")
    assert(row.count_witness_fresh==true,"fresh original native network-count OUT witness unavailable")
    if not row.original then return false,"original AllSitting already false" end
    if row.network_players~=0 then return false,"original network players remain" end
    if row.player_states~=0 then return false,"current GameState players remain" end
    if row.local_players~=0 then return false,"current authority local players remain" end
    if row.sitting~=0 then return false,"original chairs still have seated players" end
    return true,"original true at zero sitting and zero network players before GameStarted"
end

return M
