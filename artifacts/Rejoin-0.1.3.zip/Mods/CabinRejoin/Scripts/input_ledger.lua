local M={}
M.fields={'DisableMovement','DisableAxisYAW','DisableAxisPITCH','DisableInteract','DisableFlashlight'}
local function integer(v) return math.type(v)=='integer' and v>0 end
local function copy(v)
    if type(v)~='table' then return v end
    local result={}; for k,x in pairs(v) do result[k]=copy(x) end; return result
end
local function binding(v)
    assert(type(v)=='table' and v.authenticated==true and v.authority==true,'current native authenticated Authority binding required')
    assert(integer(v.pawn_address) and type(v.pawn_key)=='string' and v.pawn_key~='','exact retained Pawn address/key required')
    assert(type(v.steam_id)=='string' and v.steam_id:match('^%d+$') and type(v.epoch)=='string' and v.epoch~='',
        'original authenticated Steam identity/round epoch required')
    assert(type(v.world_key)=='string' and v.world_key~='','current Authority world required')
end
local function same(a,b)
    return a.pawn_address==b.pawn_address and a.pawn_key==b.pawn_key and a.steam_id==b.steam_id
        and a.epoch==b.epoch and a.world_key==b.world_key
end
function M.new(resolve,log)
    assert(type(resolve)=='function' and type(log)=='function','native reservation resolver and visible logger required')
    local rows={}; local self={}
    function self.ingest(event)
        assert(type(event)=='table' and event.source=='authority_callspace_pre'
            and event.signature_matches==true and event.original_result_confirmed==true,'guarded original callspace sender observation required')
        binding(event)
        assert(integer(event.sequence),'monotonic native sender sequence required')
        local current=resolve(event.pawn_address); binding(current)
        assert(same(current,event),'sender observation differs from current native reservation')
        local flags={}
        for _,name in ipairs(M.fields) do
            assert(type(event.flags)=='table' and type(event.flags[name])=='boolean','actual original sender flag missing='..name)
            flags[name]=event.flags[name]
        end
        local old=rows[event.pawn_address]
        if old and same(old,event) then
            assert(event.sequence>old.sequence,'duplicate or stale original sender sequence')
        end
        local row=copy(current); row.sequence=event.sequence; row.flags=flags; row.source=event.source
        rows[event.pawn_address]=row
        log('info','original Authority input intent recorded pawn='..row.pawn_key..' sequence='..row.sequence)
        return copy(row)
    end
    function self.inspect(pawn_address)
        local current=resolve(pawn_address); binding(current)
        local row=rows[pawn_address]
        if not row then return nil,'original sender intent not observed for current Pawn' end
        if not same(row,current) then return nil,'observed input intent belongs to another world/round/identity' end
        return copy(row)
    end
    function self.end_pawn(pawn_address,reason)
        assert(type(reason)=='string' and reason~='','original Pawn EndPlay reason required')
        rows[pawn_address]=nil
        log('info','original input intent removed pawn_address='..pawn_address..' reason='..reason)
    end
    function self.end_round(epoch)
        assert(type(epoch)=='string' and epoch~='','original ending round epoch required')
        local count=0
        for address,row in pairs(rows) do if row.epoch==epoch then rows[address]=nil;count=count+1 end end
        log('info','original ending round input intent removed count='..count)
    end
    return self
end
function M.fingerprint(row)
    assert(type(row)=='table' and integer(row.sequence),'current sender intent required')
    assert(row.source=='authority_callspace_pre','current guarded callspace sender source required')
    local values={row.steam_id,row.epoch,row.world_key,row.pawn_key,tostring(row.sequence),row.source}
    for _,name in ipairs(M.fields) do
        assert(type(row.flags[name])=='boolean','actual original flag missing='..name)
        values[#values+1]=row.flags[name] and '1' or '0'
    end
    for _,v in ipairs(values) do assert(type(v)=='string' and not v:find('|',1,true),'input fingerprint field invalid') end
    return table.concat(values,'|')
end
return M
