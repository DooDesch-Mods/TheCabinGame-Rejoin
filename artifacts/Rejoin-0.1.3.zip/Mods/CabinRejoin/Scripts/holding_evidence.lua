local refs=require('bound_refs')
local M = {}
local function valid(v) return v and v:IsValid() end
local function address(v) return valid(v) and v:GetAddress() or 0 end
local function live(v) return valid(v) and not v:IsActorBeingDestroyed() end
local function position(v) return {X=v.X,Y=v.Y,Z=v.Z} end
local function rotation(v) return {Pitch=v.Pitch,Yaw=v.Yaw,Roll=v.Roll} end
local function matches(array, wanted)
    local count, selected = 0, nil
    array:ForEach(function(_, parameter)
        local object = parameter:get()
        if address(object)==wanted then count,selected=count+1,object end
    end)
    return count, selected
end

-- The reservation and Board resolver stay owned by the existing server.
function M.new(o)
    for _,name in ipairs({'resolve_reserved','resolve_board','current_round','current_generation','native_identity','key'}) do
        assert(type(o[name])=='function','Holding evidence adapter missing='..name)
    end
    local function context(pawn)
        local r=o.resolve_reserved(pawn)
        if not r then return nil,'pawn has no native authenticated reservation' end
        assert(live(pawn) and pawn:HasAuthority() and address(r.pawn)==address(pawn), 'live retained Authority pawn required')
        assert(live(r.pc) and address(pawn.Controller)==address(r.pc) and address(r.pc.Pawn)==address(pawn),
            'current reserved Authority ownership differs')
        local identity,handle=o.native_identity(r.pc:GetAddress())
        assert(math.type(identity)=='integer' and identity>0 and identity==r.steam_id
            and math.type(handle)=='integer' and handle>0,'current native SDK identity/connection differs')
        local gm,epoch=o.current_round()
        assert(live(gm) and gm:HasAuthority() and type(epoch)=='string' and epoch~='', 'current Authority round required')
        local board,count=o.resolve_board(pawn)
        assert(count==1 and live(board) and board:HasAuthority(),'unique current Authority Board required')
        local world=address(pawn:GetWorld())
        assert(world~=0 and address(board:GetWorld())==world and address(gm:GetWorld())==world,'Authority world differs')
        local roster=matches(board.PlayerOrder,pawn:GetAddress())
        assert(roster==1,'exact retained Pawn roster entry required')
        local generation=o.current_generation()
        assert(math.type(generation)=='integer' and generation>0,'current Authority generation unavailable')
        return {pawn=pawn,pc=r.pc,board=board,identity=identity,epoch=tostring(gm:GetAddress())..':'..epoch,
            generation=generation,roster_matches=roster}
    end
    local function current_card(card_address,pawn)
        local c,cause=context(pawn); if not c then return nil,cause end
        local count,card=matches(pawn.CurrentCardsObjects,card_address)
        if count~=1 or not live(card) then return nil,'exact current Holding actor is not in retained hand' end
        assert(address(card:GetWorld())==address(pawn:GetWorld()),'Holding card world differs')
        return {card=card_address,owner=address(card.CurrentOwnedPlayer),status=card.Status,card_type=card.CardType,
            binding=true,hand_matches=count,holding=card.IsHolding,epoch=c.epoch,identity=c.identity,
            turn_matches=address(c.board.CurrentPlayerTurn)==address(pawn) and pawn.IsCurrentTurn,
            room_card_disable=card.RoomCardDisable,room_card_disable_proven=true,
            actor_location=position(card:K2_GetActorLocation()),actor_rotation=rotation(card:K2_GetActorRotation()),
            inspect_distance=16,object=card,context=c}
    end
    local function evidence(pawn,card)
        local c,cause=context(pawn); if not c then return nil,cause end
        local e={authority=true,authenticated=true,same_world=true,pawn=address(pawn),board=address(c.board),
            identity=c.identity,epoch=c.epoch,turn=c.board.PlayerTurn,ending=c.board.GameEndTime,
            current_pawn=address(c.board.CurrentPlayerTurn),roster_matches=c.roster_matches}
        if card then
            e.card=card:GetAddress()
            if live(card) then
                local count=matches(pawn.CurrentCardsObjects,e.card)
                e.status,e.card_type,e.card_owner=card.Status,card.CardType,address(card.CurrentOwnedPlayer)
                e.card_binding=count==1 or address(c.board.Card)==e.card or matches(c.board.Graveyard,e.card)==1
            end
        end
        return e
    end
    local function capture(pawn,observer)
        local marker,cause=observer.inspect(pawn)
        if not marker then return nil,cause end
        if marker.phase~='inspect_entry' or marker.status~=1 then return nil,marker.cause or 'original Holding inspect not current' end
        local current,blocker=current_card(marker.card,pawn); if not current then return nil,blocker end
        assert(current.owner==address(pawn) and current.status==1 and current.holding and current.turn_matches,
            'current Authority Holding owner/status/hand/turn differs')
        assert(current.epoch==marker.epoch and current.identity==marker.identity,'Holding observation round/identity differs')
        local slot,slot_cause=refs.holding_slot(pawn,current.object)
        if not slot then return nil,slot_cause end
        local c=current.context
        return {board=o.key(c.board),card=refs.card_key(pawn,c.board,current.object),card_class=current.object:GetClass():GetFullName(),
            generation=c.generation,epoch=marker.epoch,turn_index=c.board.PlayerTurn,hand_matches=1,
            card_type=current.card_type,card_status=1,card_owner='owner',holding=current.holding,
            room_card_disable=current.room_card_disable,location=slot.location,rotation=slot.rotation,
            activity={pawn_halted=pawn.GameHalted,board_halted=c.board.HaltGame,special_halted=c.board.SpecialEventHalt,
                graveyard_open=c.board.GraveyardOpen,in_animation=pawn.InAnimation}}
    end
    return {evidence=evidence,current_card=current_card,capture=capture}
end
return M
