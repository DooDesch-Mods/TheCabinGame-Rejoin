local refs=require('bound_refs')
local M={}
local function valid(v) return v and v:IsValid() end
local function address(v) return valid(v) and v:GetAddress() or 0 end
local function find(array,target)
    local count=0; array:ForEach(function(_,p) if address(p:get())==target then count=count+1 end end); return count
end
function M.new(o)
    for _,name in ipairs({'context','resolve_spline','key'}) do assert(type(o[name])=='function','Intro evidence adapter missing='..name) end
    local function capture(pawn,observer)
        local c,cause=o.context(pawn); if not c then return nil,assert(cause,'Intro context absence must state cause') end
        assert(c.authority and c.authenticated and c.same_world and c.gm_class=='Cabin_GameMode_C'
            and c.roster_matches==1,'current native authenticated gameplay GM roster required before Intro reservation')
        assert(c.started==false and c.entered_gameplay==false,'current original pre-GameStarted Intro lifecycle required')
        assert(pawn:HasAuthority() and valid(pawn.Mesh),'current retained Authority Intro pawn/mesh required')
        local seat=pawn.Mesh:GetAttachParent()
        if not valid(seat) or address(seat)==address(pawn.CapsuleComponent) then return nil,'current original Pawn mesh is not in a car seat' end
        local car=seat:GetOwner()
        assert(valid(car) and car:HasAuthority() and car:GetClass():GetFullName():match('EndGameCar_BP_C$'),
            'original Authority Intro car required')
        assert(address(car:GetWorld())==address(pawn:GetWorld()) and find(car.Seats,address(seat))==1
            and find(car.IntroPlayers,address(pawn))==1,'exact original current car/seat/IntroPlayers binding required')
        assert(c.ending==false,'original Intro and round ending disagree')
        local spline,count=o.resolve_spline(car)
        assert(count==1 and valid(spline) and spline:HasAuthority() and address(spline.Car)==address(car)
            and address(spline:GetWorld())==address(car:GetWorld()),'unique current original CarSpline binding required')
        local progress,blocker=observer.inspect(spline,c.epoch)
        if not progress then return nil,blocker end
        local loc,rot=pawn.Mesh.RelativeLocation,pawn.Mesh.RelativeRotation
        return {phase='car_intro',gm_class=c.gm_class,authenticated=true,epoch=c.epoch,generation=c.generation,
            car='intro_car',seat='seat_'..refs.ordinal(car.Seats,seat),car_class=car:GetClass():GetFullName(),seat_matches=1,intro_matches=1,
            attached=true,ending=false,started=c.started,ui_stage=progress.ui_stage,
            opened_at=progress.opened_at,removed_at=progress.removed_at,started_at=progress.started_at,
            mesh_location={X=loc.X,Y=loc.Y,Z=loc.Z},mesh_rotation={Pitch=rot.Pitch,Yaw=rot.Yaw,Roll=rot.Roll}}
    end
    return {capture=capture}
end
return M
