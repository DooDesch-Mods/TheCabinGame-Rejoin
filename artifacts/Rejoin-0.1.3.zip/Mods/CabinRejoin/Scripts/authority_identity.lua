local M = {}
local CLASS = "BlueprintGeneratedClass /Game/CabinGameContent/CabinAdvanceFriendsGameInstance.CabinAdvanceFriendsGameInstance_C"
local function valid(o) return o and o:IsValid() end
local function address(o) return valid(o) and o:GetAddress() or 0 end
local function text(v) return type(v)=="string" and v or v:ToString() end

function M.capture(receipt)
    local gi=receipt.game_instance
    assert(valid(gi),"authority GI identity capture requires valid original wrapper")
    assert(gi:GetClass():GetFullName()==CLASS,"authority GI identity capture class differs")
    assert(type(receipt.session_id)=="string" and receipt.session_id:match("^[1-9]%d*$"),"authority identity requires exact original session ID")
    assert(math.type(receipt.server_id)=="integer" and receipt.server_id>0,"authority identity requires actual SDK server ID")
    return {gi_address=gi:GetAddress(),gi_name=gi:GetFullName(),session_id=receipt.session_id,server_id=receipt.server_id}
end

function M.resolve(lease,receipt)
    assert(receipt.session_id==lease.session_id and receipt.server_id==lease.server_id,"authority identity receipt changed")
    local before={cached_gi_valid=valid(receipt.game_instance)==true}
    if before.cached_gi_valid then
        before.cached_gi_address=receipt.game_instance:GetAddress()
        local world=receipt.game_instance:GetWorld()
        before.cached_world_valid=valid(world)==true
        before.cached_world_address=address(world)
    end
    local sdk,server=CabinSteamServerState()
    assert(sdk==2 and server==lease.server_id,"resolved original SDK authority differs state="..tostring(sdk).." server="..tostring(server).." required="..lease.server_id)
    local function result(status,cause,fields)
        fields=fields or {}; fields.status=status; fields.cause=cause; fields.cached_before_resolution=before
        fields.sdk_state=sdk; fields.server_id=server
        return fields
    end
    local gi,count=nil,0
    for _,candidate in ipairs(FindAllOf("CabinAdvanceFriendsGameInstance_C") or {}) do
        if valid(candidate) and candidate:GetAddress()==lease.gi_address then
            assert(candidate:GetClass():GetFullName()==CLASS,"resolved authority GI class differs at original address")
            assert(candidate:GetFullName()==lease.gi_name,"resolved authority GI name differs at original address")
            gi,count=candidate,count+1
        end
    end
    assert(count<=1,"original authority GI enumeration ambiguous count="..count)
    if not gi then return result("waiting","original GI identity not currently resolved") end
    local fields={game_instance=gi,gi_address=gi:GetAddress(),gi_name=gi:GetFullName()}
    local world=gi:GetWorld(); fields.world=world; fields.world_address=address(world)
    local library=StaticFindObject("/Script/AdvancedSessions.Default__AdvancedSessionsLibrary")
    local gameplay=StaticFindObject("/Script/Engine.Default__GameplayStatics")
    assert(valid(library) and valid(gameplay),"authority identity original getters unavailable")
    local id={}; library:GetCurrentSessionID_AsString(gi,id)
    fields.session_id=id.SessionId and text(id.SessionId)
    fields.local_players=gi.LocalPlayers:GetArrayNum(); fields.private=gi["Should Advertise"]==false; fields.lan=gi["Use LAN"]
    assert(fields.local_players==0,"resolved background authority acquired local ownership")
    assert(fields.private==(receipt.private_session~=false) and fields.lan==false,"resolved original Steam preferences differ")
    if not fields.session_id or fields.session_id=="" then return result("waiting","resolved original SessionId OUT unavailable",fields) end
    if fields.session_id~=lease.session_id then return result("session_changed","original session ended/changed measured="..fields.session_id,fields) end
    if not valid(world) then return result("waiting","resolved original GI current World unavailable",fields) end
    local gm=gameplay:GetGameMode(gi); fields.game_mode=gm
    if not valid(gm) then return result("waiting","resolved original current GameMode unavailable",fields) end
    if address(gameplay:GetGameInstance(gm))~=lease.gi_address or address(gm:GetWorld())~=fields.world_address then
        return result("waiting","resolved original GI/GameMode/World binding pending",fields)
    end
    fields.role=gm:GetLocalRole(); assert(fields.role==3,"resolved original GameMode is not authority role3")
    local driver,drivers=nil,0
    for _,candidate in ipairs(FindAllOf("SteamSocketsNetDriver") or {}) do
        if valid(candidate) and not candidate:GetFullName():find("Default__",1,true) and address(candidate.World)==fields.world_address then
            driver,drivers=candidate,drivers+1
        end
    end
    if drivers==0 then return result("waiting","resolved current World Steam driver unavailable",fields) end
    assert(drivers==1 and not valid(driver.ServerConnection),"resolved current authority Steam driver differs count="..drivers)
    fields.driver=driver; fields.authority_driver=true
    return result("ready","same original GI/session/SDK identity and current authority World confirmed",fields)
end

return M
