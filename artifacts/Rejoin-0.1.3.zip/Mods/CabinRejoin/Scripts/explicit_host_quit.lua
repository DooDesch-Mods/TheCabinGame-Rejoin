local M={}
local gt=require("gt_scheduler")
local current
local MENU="World /Game/CabinGameContent/Menu.Menu"
local CLASS="WidgetBlueprintGeneratedClass /Game/MenuContent/Widgets/Menu_WBP.Menu_WBP_C"
local QUIT="/Game/MenuContent/Widgets/Menu_WBP.Menu_WBP_C:BndEvt__Menu_WBP_Quit_B_K2Node_ComponentBoundEvent_3_OnButtonPressedEvent__DelegateSignature"
local function valid(v) return v and v:IsValid() end
local function reason(s,cause)
    s.repeats=s.reason==cause and (s.repeats or 0)+1 or 1
    if s.reason~=cause then s.reason=cause; s.log("info","original Quit binding waits: "..cause) end
end
local function clear(s)
    if not s.widget then return end
    local ack,cause=CabinHostQuitDisarm()
    assert(ack==1,"original Quit disarm cause="..tostring(cause))
    s.widget=nil; s.function_address=nil
    if s.phase~="failed" then s.phase="waiting" end
    s.log("info","old original Quit menu binding cleared; no authority action")
end
local function advance(s)
    local root
    for _,value in ipairs(FindAllOf("Menu_WBP_C") or {}) do
        if valid(value) and not value:GetFullName():find("Default__",1,true) and valid(value:GetWorld()) and value:GetWorld():GetFullName()==MENU and value:IsInViewport() then
            assert(not root,"original Quit current Menu root ambiguous"); root=value
        end
    end
    if not root then clear(s); reason(s,"current Menu root/viewport pending"); return end
    assert(root:GetClass():GetFullName()==CLASS and valid(root.Quit_B),"original Quit Menu class/button differs")
    local world=root:GetWorld()
    local gameplay=StaticFindObject("/Script/Engine.Default__GameplayStatics")
    assert(valid(gameplay),"original Quit GameplayStatics unavailable")
    local pc=gameplay:GetPlayerController(world,0)
    if not valid(pc) or pc:IsActorBeingDestroyed() then clear(s); reason(s,"current local PC pending"); return end
    assert(pc:IsLocalController() and valid(pc:GetWorld()) and pc:GetWorld():GetAddress()==world:GetAddress(),"original Quit local PC/world differs")
    local owner=root:GetOwningPlayer()
    if not valid(owner) then clear(s); reason(s,"original Menu owner pending"); return end
    assert(owner:GetAddress()==pc:GetAddress(),"original Quit Menu owner differs")
    local mode=gameplay:GetGameMode(world)
    if not valid(mode) or not valid(mode.MenuWidget) then clear(s); reason(s,"original Menu GameMode root pending"); return end
    assert(mode.MenuWidget:GetAddress()==root:GetAddress(),"original Quit current GameMode MenuWidget differs")
    local fn=StaticFindObject(QUIT)
    assert(valid(fn) and fn:GetFullName()=="Function "..QUIT,"original Quit_B Pressed function unavailable/differs")
    local count=0; fn:ForEachProperty(function() count=count+1 end)
    assert(count==0,"original Quit_B Pressed parameter count differs measured="..count.." required0")
    if s.widget==root:GetAddress() and s.function_address==fn:GetAddress() then return end
    clear(s)
    s.log("info","original Menu Quit_B binding attempted; no authority stop or exit")
    local ack,cause=CabinHostQuitArm(root:GetAddress(),fn:GetAddress())
    assert(ack==1,"original Quit_B native binding cause="..tostring(cause))
    s.widget=root:GetAddress(); s.function_address=fn:GetAddress(); s.phase="armed"; s.reason=nil
    s.log("info","original Menu Quit_B binding acknowledged widget="..s.widget.." function="..s.function_address.." world="..world:GetAddress().." owner="..pc:GetAddress())
end
function M.start(options)
    assert(not current,"explicit host Quit module already started")
    local s={log=assert(options.log),phase="waiting"}; current=s
    if os.getenv("CABIN_REJOIN_PROCESS_ID") then s.phase="skipped"; s.log("info","explicit Menu Quit observer skipped for background authority"); return true end
    assert(type(CabinHostQuitArm)=="function" and type(CabinHostQuitDisarm)=="function","explicit original Quit native APIs unavailable")
    gt.loop(100,function()
        if s.phase=="failed" then return true end
        local ok,cause=xpcall(function() assert(IsInGameThread()==true,"original Quit binding outside GameThread"); advance(s) end,debug.traceback)
        if not ok then
            s.phase="failed"; s.cause=tostring(cause); s.log("error","original Quit observer cause="..s.cause.."; original exit remains; no stop replay")
            local cleared,why=pcall(clear,s)
            if not cleared then s.log("error","original Quit failure disarm cause="..tostring(why)) end
            return true
        end
    end)
    s.log("info","explicit original Quit observer registered; no authority stop or exit")
    return true
end
function M.status() return current end
return M
