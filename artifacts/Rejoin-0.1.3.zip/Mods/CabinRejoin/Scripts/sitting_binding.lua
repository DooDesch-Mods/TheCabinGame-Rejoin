local M={}
local GM="BlueprintGeneratedClass /Game/CabinGameContent/Cabin_GameMode.Cabin_GameMode_C"
local function valid(o) return o~=nil and o:IsValid() end
local function address(o) return valid(o) and o:GetAddress() or 0 end

function M.resolver(identity,receipt,expected_gm)
    assert(type(identity)=="table" and type(identity.capture)=="function" and type(identity.resolve)=="function","existing authority identity adapter required")
    assert(valid(expected_gm) and expected_gm:GetClass():GetFullName()==GM,"exact original Round GameMode required")
    local lease=identity.capture(receipt)
    local gm_address=expected_gm:GetAddress()
    local world_address=address(expected_gm:GetWorld())
    assert(world_address>0,"original Round World unavailable")
    return function(context)
        local current=identity.resolve(lease,receipt)
        if current.status~="ready" then return {status=current.status,cause=current.cause} end
        if address(context)~=gm_address or address(current.game_mode)~=gm_address or current.world_address~=world_address then
            return {status="epoch_changed",cause="original GameMode/World binding changed"}
        end
        assert(context:GetClass():GetFullName()==GM and context:GetLocalRole()==3,"original Round authority class/role differs")
        assert(not context:IsActorBeingDestroyed(),"original Round GameMode is being destroyed")
        assert(address(current.world.AuthorityGameMode)==gm_address,"actual World authority GameMode differs")
        assert(address(context:GetWorld())==world_address,"hook context World differs")
        assert(address(current.world.NetDriver)==address(current.driver) and address(current.driver)>0,"actual World authority driver differs")
        assert(not valid(current.driver.ServerConnection),"actual driver is a client")
        return {status="ready",game_mode=context,world=current.world,driver=current.driver,
                game_instance=current.game_instance,game_state=context.GameState,
                gm_address=gm_address,world_address=world_address,session_id=current.session_id,server_id=current.server_id}
    end
end

return M
