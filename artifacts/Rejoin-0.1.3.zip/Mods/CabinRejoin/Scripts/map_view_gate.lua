local M = {}
local state = {phase = 'idle'}

local function log(callback, level, message)
    local ok, cause = pcall(callback, level, message)
    if not ok then error('MapViewGate logging failed cause=' .. tostring(cause) .. '; operation=' .. message, 0) end
end

local function address(value, name)
    assert(value ~= nil, 'MapViewGate reflection missing=' .. name)
    local pointer = value:GetAddress()
    assert(math.type(pointer) == 'integer' and pointer > 0 and pointer % 8 == 0,
        'MapViewGate reflection address invalid=' .. name)
    return pointer
end

local function property(class, name)
    local found
    class:ForEachProperty(function(value)
        if value:GetFName():ToString() == name then
            assert(found == nil, 'MapViewGate duplicate original property=' .. name)
            found = value
        end
    end)
    address(found, name)
    return found
end

function M.status()
    assert(type(CabinMapViewGateStatus) == 'function', 'MapViewGate native status API missing')
    local enabled, faulted, confirmed, blocked, failures, releases, slot, cdo = CabinMapViewGateStatus()
    assert((enabled == 0 or enabled == 1) and (faulted == 0 or faulted == 1) and (confirmed == 0 or confirmed == 1),
        'MapViewGate native status response missing')
    for _, value in ipairs({blocked, failures, releases, slot, cdo}) do
        assert(math.type(value) == 'integer' and value >= 0, 'MapViewGate native status counter/address invalid')
    end
    assert(blocked ~= nil and failures ~= nil and releases ~= nil and slot ~= nil and cdo ~= nil,
        'MapViewGate native status field missing')
    return {enabled = enabled, faulted = faulted, confirmed = confirmed,
        blocked = blocked, failures = failures, releases = releases, slot = slot, cdo = cdo}
end

-- Call synchronously on the game thread before the owned join path starts.
function M.start(options)
    assert(type(options) == 'table' and type(options.log) == 'function', 'MapViewGate start requires log')
    if state.phase == 'started' then
        local receipt = M.status()
        assert(receipt.enabled == 1 and receipt.faulted == 0 and receipt.confirmed == 1,
            'MapViewGate existing installation lost protection')
        return receipt
    end
    assert(state.phase == 'idle', 'MapViewGate start phase=' .. state.phase .. '; no automatic replay')
    state.phase = 'attempted'
    local ok, result = pcall(function()
        assert(type(StaticFindObject) == 'function' and type(CabinMapViewGateStart) == 'function',
            'MapViewGate exact reflection/native API missing')
        local function exact(path)
            local value = StaticFindObject(path)
            assert(value and value:IsValid(), 'MapViewGate exact object unavailable=' .. path)
            address(value, path)
            return value
        end
        local function class(path, asset)
            local value = StaticFindObject(path)
            if not value or not value:IsValid() then
                assert(options.load_missing == true and type(LoadAsset) == 'function',
                    'MapViewGate class unavailable before join=' .. path .. '; explicit asset preparation required')
                log(options.log, 'info', 'MapViewGate original asset load attempted=' .. asset)
                local loaded, found, completed = LoadAsset(asset)
                assert(found == true and completed == true and loaded and loaded:IsValid(),
                    'MapViewGate original asset load unacknowledged=' .. asset .. '; found=' .. tostring(found) .. '; completed=' .. tostring(completed))
                value = exact(path)
            end
            address(value, path)
            return value
        end
        local pawn = class('/Game/CabinGameContent/PlayerContent/Cabin_Player.Cabin_Player_C',
            '/Game/CabinGameContent/PlayerContent/Cabin_Player.Cabin_Player')
        local map = class('/Game/CabinGameContent/BoardGameStuff/CardMapLayout_BP.CardMapLayout_BP_C',
            '/Game/CabinGameContent/BoardGameStuff/CardMapLayout_BP.CardMapLayout_BP')
        local cdo = pawn:GetCDO()
        assert(cdo and cdo:IsValid() and address(cdo:GetClass(), 'CDO class') == pawn:GetAddress(),
            'MapViewGate exact current class CDO missing')
        local values = {cdo, pawn, map,
            exact('/Game/CabinGameContent/PlayerContent/Cabin_Player.Cabin_Player_C:DragRoomCard_E'),
            property(pawn, 'MapLayout'), property(map, 'CurrentPlayer'), property(map, 'HasCard'),
            exact('/Script/Engine.Pawn:IsLocallyControlled'),
            exact('/Script/Engine.Pawn:GetController'), exact('/Script/Engine.Controller:GetViewTarget')}
        local pointers = {}
        for index, value in ipairs(values) do pointers[index] = address(value, 'binding=' .. index) end
        assert(CabinMapViewGateStart(table.unpack(pointers)) == 1, 'MapViewGate native install failed; missing early protection')
        local receipt = M.status()
        assert(receipt.enabled == 1 and receipt.faulted == 0 and receipt.confirmed == 1 and
            receipt.cdo == cdo:GetAddress() and math.type(receipt.slot) == 'integer' and receipt.slot > 0,
            'MapViewGate installed slot readback differs')
        state.binding = values
        return receipt
    end)
    if not ok then
        state.phase, state.cause = 'failed', tostring(result)
        log(options.log, 'error', 'MapViewGate start cause=' .. state.cause .. '; no join protection ACK/no replay')
        error(state.cause, 0)
    end
    state.phase = 'started'
    log(options.log, 'info', 'MapViewGate startup acknowledged cdo=' .. result.cdo .. '; slot=' .. result.slot .. '; before join receipt required')
    return result
end

function M.stop(callback)
    assert(type(callback) == 'function' and type(CabinMapViewGateStop) == 'function', 'MapViewGate stop log/native API missing')
    assert(CabinMapViewGateStop() == 1, 'MapViewGate stop original slot restoration unacknowledged')
    state = {phase = 'idle'}
    log(callback, 'info', 'MapViewGate stopped; InputIntent owners remain independent')
end

return M
