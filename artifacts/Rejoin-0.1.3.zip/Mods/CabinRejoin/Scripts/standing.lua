local M = {}
local SITTING = "IsSitting_13_5E5832C3491A59936F87C7A815E64A59"
local FLAGS = {"DisableMovement", "DisableAxisYAW", "DisableAxisPITCH", "DisableInteract", "DisableFlashlight", "DisablePeeking"}
local PRESERVE = {"IsCurrentTurn", "IsInTurn", "TTurnTransition", "GameHalted", "FinishSittingCanStartTurn", "InAnimation"}
local function valid(value) return value and value:IsValid() end
local function address(value) return valid(value) and value:GetAddress() or 0 end
local function near(a, b) return math.abs(a - b) <= 0.001 end
local function vec(value) return {X=value.X, Y=value.Y, Z=value.Z} end
local function rot(value) return {Pitch=value.Pitch, Yaw=value.Yaw, Roll=value.Roll} end
local function vec_equal(a, b) return near(a.X, b.X) and near(a.Y, b.Y) and near(a.Z, b.Z) end
local function angle(a, b) return math.abs((a - b + 180) % 360 - 180) <= 0.001 end
local function rot_equal(a, b) return angle(a.Pitch, b.Pitch) and angle(a.Yaw, b.Yaw) and angle(a.Roll, b.Roll) end
local function boolean(value, name)
    assert(type(value) == "boolean", "standing property not decoded=" .. name)
    return value
end
local function list(array)
    local values = {count=array:GetArrayNum()}
    array:ForEach(function(index, parameter)
        local value = parameter:get()
        assert(valid(value), "standing invariant array item missing index=" .. index)
        values[index] = value:GetAddress()
    end)
    return values
end
local function same_list(before, after, name)
    for key, value in pairs(before) do assert(after[key] == value, "standing changed " .. name .. " index=" .. key) end
end

function M.is_standing(pawn)
    assert(valid(pawn), "standing classifier pawn missing")
    if boolean(pawn.GameplayVars[SITTING], "GameplayVars.IsSitting") then return false, "GameplayVars.IsSitting=true" end
    local chair = pawn.Chair
    if valid(chair) then
        if boolean(chair.PlayerSitting, "Chair.PlayerSitting") then return false, "Chair.PlayerSitting=true" end
        if boolean(chair.SitTransitioning, "Chair.SitTransitioning") then return false, "Chair.SitTransitioning=true" end
    end
    return true
end

local function token_equal(a, b)
    return type(a) == "table" and type(b) == "table"
        and math.type(a.generation) == "integer" and a.generation > 0
        and math.type(a.id) == "integer" and a.id > 0
        and type(a.nonce) == "string" and #a.nonce == 32 and a.nonce:match("^[0-9a-f]+$") ~= nil
        and a.generation == b.generation and a.id == b.id and a.nonce == b.nonce
end

function M.ready(pc, pawn, job, current_token)
    assert(type(job) == "table" and type(job.snapshot) == "table" and job.snapshot.mode == "standing", "current Standing snapshot required")
    assert(token_equal(job.control_token, current_token) and current_token.id == job.id, "Standing job token is not current")
    if not valid(pc) or not valid(pawn) or not valid(pawn.RootComponent) then return false, "waiting for original controller/pawn/root" end
    if pc:IsActorBeingDestroyed() or pawn:IsActorBeingDestroyed() then return false, "controller/pawn ended" end
    if not pc:IsLocalController() or pc:GetLocalRole() ~= 2 or not pawn:IsLocallyControlled() then return false, "waiting for retained remote owner" end
    if address(pc.Pawn) ~= pawn:GetAddress() or address(pawn.Controller) ~= pc:GetAddress() or address(pc.AcknowledgedPawn) ~= pawn:GetAddress() then return false, "waiting for retained ownership acknowledgement" end
    local standing, cause = M.is_standing(pawn)
    if not standing then return false, "waiting for stable standing: " .. cause end
    for _, name in ipairs({"InAnimation", "TTurnTransition", "IsInTurn", "IsInMenu"}) do
        if boolean(pawn[name], name) then return false, "waiting for current local phase " .. name .. "=false" end
    end
    local board = pawn.GameBoard
    if valid(board) then
        if boolean(board.GraveyardOpen, "Board.GraveyardOpen") then return false, "waiting for current original graveyard input" end
        if boolean(board.GameEndTime, "Board.GameEndTime") then return false, "original Board round ending" end
    end
    if not valid(pawn.Camera) or not valid(pawn.CamFwd_SpringArm) or not valid(pc.PlayerCameraManager) then return false, "waiting for original camera/arm/manager" end
    return true
end

local function capture(pc, pawn)
    local board, chair = pawn.GameBoard, pawn.Chair
    assert(valid(board) and valid(pawn:GetWorld()) and address(board:GetWorld()) == address(pawn:GetWorld()), "current local original Board/world required")
    local state = {position=vec(pawn:K2_GetActorLocation()), rotation=rot(pawn:K2_GetActorRotation()), world=address(pawn:GetWorld()), pawn=address(pc.Pawn), controller=address(pawn.Controller),
        acknowledged=address(pc.AcknowledgedPawn), chair=address(chair), sitting=pawn.GameplayVars[SITTING],
        cards=list(pawn.CurrentCards), physical=list(pawn.CurrentCardsObjects), board=address(board),
        turn=board.PlayerTurn, turn_pawn=address(board.CurrentPlayerTurn), started=board.GameStarted,
        halted=boolean(board.HaltGame, "Board.HaltGame"), special_halt=boolean(board.SpecialEventHalt, "Board.SpecialEventHalt"), graveyard=boolean(board.GraveyardOpen, "Board.GraveyardOpen"), ending=boolean(board.GameEndTime, "Board.GameEndTime"), order=list(board.PlayerOrder), fields={}}
    for _, name in ipairs(PRESERVE) do state.fields[name] = boolean(pawn[name], name) end
    if valid(chair) then
        state.chair_sitting, state.chair_transition = chair.PlayerSitting, chair.SitTransitioning
        state.chair_pawn = address(chair.PlayerCharacter)
    end
    return state
end

local function unchanged(pc, pawn, before)
    local after = capture(pc, pawn)
    assert(vec_equal(before.position, after.position), "standing restore changed current actor position")
    assert(rot_equal(before.rotation, after.rotation), "standing restore changed current actor rotation")
    for _, name in ipairs({"world", "graveyard", "ending", "pawn", "controller", "acknowledged", "chair", "sitting", "board", "turn", "turn_pawn", "started", "halted", "special_halt", "chair_sitting", "chair_transition", "chair_pawn"}) do
        assert(before[name] == after[name], "standing restore changed invariant=" .. name)
    end
    same_list(before.cards, after.cards, "ordered hand")
    same_list(before.physical, after.physical, "ordered physical hand")
    same_list(before.order, after.order, "original player order")
    for name, value in pairs(before.fields) do assert(after.fields[name] == value, "standing restore changed pawn field=" .. name) end
end

local function view_ack(pc, pawn, target)
    local camera, arm, manager = pawn.Camera, pawn.CamFwd_SpringArm, pc.PlayerCameraManager
    assert(address(pc:GetViewTarget()) == pawn:GetAddress(), "standing view target not acknowledged")
    assert(camera.bUsePawnControlRotation and pawn.bUseControllerRotationYaw, "standing camera/controller flags not acknowledged")
    assert(vec_equal(camera.RelativeLocation, {X=0, Y=0, Z=0}), "standing camera location not acknowledged")
    assert(vec_equal(arm.RelativeLocation, {X=0, Y=0, Z=173}) and rot_equal(arm.RelativeRotation, {Pitch=0, Yaw=-90, Roll=0}), "standing spring arm not acknowledged")
    assert(near(manager.ViewPitchMin, -80) and near(manager.ViewPitchMax, 80) and near(manager.ViewYawMin, target.clamp_yaw - 179) and near(manager.ViewYawMax, target.clamp_yaw + 179), "standing camera clamp not acknowledged")
    assert(pc.bShowMouseCursor == false and pawn.JournalOpen == false and pawn.IsInTableCamInspect == false, "normal local view flags not acknowledged")
    for _, name in ipairs(FLAGS) do assert(pawn[name] == false, "standing input flag not acknowledged=" .. name) end
    assert(valid(pawn.InputComponent), "standing input component not acknowledged")
    assert(pc:IsMoveInputIgnored() == false and pc:IsLookInputIgnored() == false, "standing ignore-input state not acknowledged")
end

local function apply(pc, pawn)
    assert(address(pc.PlayerCharacter) == pawn:GetAddress() and address(pawn.CabinPlayerController) == pc:GetAddress(), "common local references differ before standing restore")
    local hud = pawn.CabinHud_WBP
    assert(valid(hud) and address(hud.PlayerCharacter) == pawn:GetAddress() and address(hud:GetOwningPlayer()) == pc:GetAddress() and hud:IsInViewport(), "common owned HUD differs before standing restore")
    local camera, arm = pawn.Camera, pawn.CamFwd_SpringArm
    if valid(pawn.PlayerJournal) and pawn.PlayerJournal:IsVisible() then
        pawn.PlayerJournal:ToggleWidgetVisibility_E(false)
        assert(not pawn.PlayerJournal:IsVisible(), "journal close not acknowledged")
    end
    pc:SetIgnoreMoveInput(false); pc:SetIgnoreLookInput(false)
    pawn.JournalOpen, pawn.IsInTableCamInspect = false, false
    -- DefaultPlayer_C transfers the original component view before control rotation is enabled.
    camera.bUsePawnControlRotation = false
    camera:K2_SetRelativeRotation({Pitch=0, Yaw=-180, Roll=0}, false, {}, false)
    local view = rot(camera:K2_GetComponentRotation())
    pc:SetControlRotation(view)
    assert(rot_equal(pc:GetControlRotation(), view), "standing control rotation not acknowledged")
    pawn.bUseControllerRotationYaw, camera.bUsePawnControlRotation = true, true
    for _, name in ipairs(FLAGS) do pawn[name] = false end
    pawn:EnableInput(pc)
    local clamp_yaw = camera:K2_GetComponentRotation().Yaw
    pawn:ClampCameraFunction(80, -80, 179, -179)
    pawn:HideSelfHead_C(false)
    for _, name in ipairs({"Head", "Cosmetic", "SkeletalMeshhair"}) do
        assert(valid(pawn[name]) and not pawn[name]:IsVisible(), "standing owner head not hidden=" .. name)
    end
    camera:K2_SetRelativeLocation({X=0, Y=0, Z=0}, false, {}, false)
    arm:K2_SetRelativeLocation({X=0, Y=0, Z=173}, false, {}, false)
    arm:K2_SetRelativeRotation({Pitch=0, Yaw=-90, Roll=0}, false, {}, false)
    if address(pc:GetViewTarget()) ~= pawn:GetAddress() then pc:SetViewTargetWithBlend(pawn, 0, 0, 0, false) end
    local functions = StaticFindObject("/Game/CabinGameContent/Cabin_Functions.Default__Cabin_Functions_C")
    assert(valid(functions), "original local Input Mode helper missing")
    functions["Input Mode"](functions, pc, false, false, true, pawn)
    -- The common restore must construct the owned HUD before applying these local settings.
    pawn:SetBeginPlaySettings()
    local settings = pawn.PlayerSettings
    assert(near(camera.FieldOfView, settings["FOV_30_B7C277BD42CEFF96BE19039F86E1F05F"]), "standing saved FOV not acknowledged")
    assert(near(pawn.MouseSensitivity, settings["LookSensitivity_10_0A91E29240B23667747440A57A004547"]), "standing saved sensitivity not acknowledged")
    local invert_x = boolean(settings["InvertMouseX_13_ABAD9564456C5E7CA9A24CBA3876BC29"], "PlayerSettings.InvertMouseX")
    local invert_y = boolean(settings["InvertMouseY_15_BE20EB9A48437228C42E83819F843E90"], "PlayerSettings.InvertMouseY")
    assert(pawn.InvertMouseX == (invert_x and -1 or 1), "standing saved invert X not acknowledged")
    assert(pawn.InvertMouseY == (invert_y and -1 or 1), "standing saved invert Y not acknowledged")
    local icons = boolean(settings["EnableIcons_27_0B013D0743848EC1467CBDB52AFDD856"], "PlayerSettings.EnableIcons")
    assert(valid(pawn.CabinHud_WBP.Instructions_VB) and pawn.CabinHud_WBP.Instructions_VB:IsVisible() == icons, "standing saved HUD icons visibility not acknowledged")
    return {clamp_yaw=clamp_yaw, control=view}
end

function M.restore(job, pc, pawn, current_token)
    local ready, cause = M.ready(pc, pawn, job, current_token)
    assert(ready, cause)
    assert(not job.standing_attempted, "Standing local mutation already attempted; no replay")
    local board = pawn.GameBoard
    assert(valid(board), "current local original Board missing after RestoreCommon")
    assert(not boolean(board.GraveyardOpen, "Board.GraveyardOpen"), "Standing normal view cannot replace current graveyard input")
    local before = capture(pc, pawn)
    assert(not before.ending, "original Board round ending")
    job.standing_attempted = true
    local target = apply(pc, pawn)
    view_ack(pc, pawn, target)
    unchanged(pc, pawn, before)
    return {id=job.id, pc=pc, pawn=pawn, target=target,
        control_token={generation=current_token.generation,id=current_token.id,nonce=current_token.nonce},
        standing_confirmed=true, input_registration_confirmed=true, input_delivery_confirmed=false,
        invariants_confirmed=true, before=before}
end

function M.verify_view(receipt, current_token)
    assert(receipt.standing_confirmed and valid(receipt.pc) and valid(receipt.pawn), "Standing local receipt missing")
    assert(token_equal(receipt.control_token, current_token), "Standing receipt token is not current")
    assert(address(receipt.pc.Pawn) == receipt.pawn:GetAddress() and address(receipt.pawn.Controller) == receipt.pc:GetAddress()
        and address(receipt.pc.AcknowledgedPawn) == receipt.pawn:GetAddress(), "Standing ownership changed after receipt")
    local standing, cause = M.is_standing(receipt.pawn)
    assert(standing, cause)
    view_ack(receipt.pc, receipt.pawn, receipt.target)
    return {view_state_confirmed=true,input_registration_confirmed=true,input_delivery_confirmed=false}
end

return M
