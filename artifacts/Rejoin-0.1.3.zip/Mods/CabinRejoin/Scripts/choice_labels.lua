local M={}
local labels={
    NeighborChoice_BP_C={
        [0]={"Extra Time","Rewinds the clock 1 hour"},
        [1]={"Remove Graveyard Wipe","Removes 1 Graveyard Wipe card from the deck"},
        [2]={"Delay Visitor","Prevents The Visitor from progressing for 3 turns"},
        [3]={"Create Hiding Spot","Clears a closet of junk -allowing players to hide in it"},
        [4]={"Extra Clues","Adds 3 extra, random clue cards into the deck"},
        [5]={"Stop The Thief","When playing The Thief card, prevents the thief from actually stealing anything"},
    },
    ThiefChoiceCard_BP_C={
        [0]={"Clues","3 random clue cards will be removed from the deck"},
        [1]={"Time","Lose 1 hour of game time"},
        [2]={"The Graveyard","Graveyard Wipe!"},
        [3]={"A Room","One random room card is removed from the deck"},
    },
}
function M.values(class,index)
    local row=labels[class] and labels[class][index]
    assert(row,"original choice labels unavailable class="..tostring(class).." type="..tostring(index))
    return row[1],row[2]
end
return M
