local M = {}
local PATH="/Script/AdvancedSessions.UpdateSessionCallbackProxyAdvanced:UpdateSession"
local GI_CLASS="BlueprintGeneratedClass /Game/CabinGameContent/CabinAdvanceFriendsGameInstance.CabinAdvanceFriendsGameInstance_C"
local function valid(o) return o and o:IsValid() end
local function address(o) return valid(o) and o:GetAddress() or 0 end
local function text(v) return type(v)=="string" and v or v:ToString() end

function M.new(receipt,log,on_error,observe,settings,original_gi_address)
    assert(type(receipt)=="table" and receipt.bootstrap_confirmed==true and receipt.lobby_publication_confirmed==true,"confirmed own background authority receipt required")
    assert(address(receipt.game_instance)>0 and type(receipt.session_id)=="string" and receipt.session_id:match("^[1-9]%d*$"),"exact GI/current original session receipt required")
    assert(math.type(receipt.server_id)=="integer" and receipt.server_id>0,"exact actual SDK server ID required")
    assert(type(log)=="function" and type(on_error)=="function" and type(observe)=="function" and type(settings)=="function","explicit log/error/read-only observers required")
    local gi_address=original_gi_address or address(receipt.game_instance)
    assert(math.type(gi_address)=="integer" and gi_address>0,"original authority GI identity anchor required")
    local s={phase="armed",sequence=0,receipt=receipt,reasons={}}
    local api={}
    local function reason(level,cause)
        local n=(s.reasons[cause] or 0)+1; s.reasons[cause]=n
        if n==1 or n%60==0 then log(level,"session gate "..cause.." observations="..n) end
    end
    local function failed(operation,cause)
        s.phase="failed"; api.stopped=true; s.cause=operation.." cause="..tostring(cause)
        log("error","session gate "..s.cause.."; original call is not replayed; gate dormant")
        local ok,handler_cause=pcall(on_error,s.cause)
        if not ok then log("error","session gate error handler cause="..tostring(handler_cause).."; original="..s.cause) end
        return {status="failed",cause=s.cause}
    end
    local function protected(operation,fn)
        local ok,result=xpcall(fn,debug.traceback)
        if not ok then return failed(operation,result) end
        return result
    end
    local function current()
        local c=observe(receipt)
        assert(c.bootstrap_current==true,"own authority receipt is no longer the current ready bootstrap")
        local prior=c.cached_before_resolution
        if prior and (prior.cached_gi_valid~=true or prior.cached_world_valid~=true) then
            reason("warn","same-VM before resolution cachedGI="..tostring(prior.cached_gi_valid).." cachedWorld="..tostring(prior.cached_world_valid).." freshGI="..tostring(c.gi_address).." currentWorld="..tostring(c.world_address).."; original invalid predicate cause remains unproved")
        end
        local missing={}
        local function measured(key,required,label)
            if c[key]==nil then missing[#missing+1]=key; return end
            assert(c[key]==required,label.." measured="..tostring(c[key]).." required="..tostring(required))
        end
        measured("gi_address",gi_address,"current authority GI changed")
        measured("sdk_state",2,"current original SDK state differs")
        measured("server_id",receipt.server_id,"current original SDK server identity differs")
        measured("local_players",0,"actual background authority acquired local ownership")
        measured("private",receipt.private_session~=false,"original Steam preferences differ")
        measured("lan",false,"original LAN preference differs")
        measured("session_id",receipt.session_id,"current original session differs")
        measured("role",3,"actual background authority role differs")
        measured("authority_driver",true,"actual background authority driver differs")
        if c.readiness then
            assert(type(c.readiness)=="string" and #c.readiness>0,"measured readiness cause required")
            s.readiness=c.readiness
            local why=c.readiness.." unobserved="..table.concat(missing,",")
            reason("info","current authority readiness pending="..why.."; no settings ACK or setter")
            return nil,{status="waiting",cause=why,settings_confirmed=false}
        end
        assert(#missing==0,"current authority fields unobserved without readiness cause="..table.concat(missing,","))
        if s.readiness then log("info","session gate authority readiness recovered="..s.readiness); s.readiness=nil end
        return c
    end
    function api.pre(world,extra,public,private,lan,invites,join,refresh,dedicated,advertise)
        if s.phase=="failed" or s.phase=="stopped" then return {status="dormant"} end
        return protected("native factory PRE",function()
            if address(world:get())~=gi_address then reason("info","foreign original GI skipped"); return {status="skipped"} end
            local c,waiting=current(); if not c then return waiting end
            local args={public=public:get(),private=private:get(),lan=lan:get(),invites=invites:get(),join=join:get(),refresh=refresh:get(),dedicated=dedicated:get(),advertise=advertise:get()}
            assert(math.type(args.public)=="integer" and math.type(args.private)=="integer","original connection counts are not integers")
            for _,key in ipairs({"lan","invites","join","refresh","dedicated","advertise"}) do assert(type(args[key])=="boolean","original bool parameter missing="..key) end
            assert(args.lan==false,"original factory LAN differs measured="..tostring(args.lan).." required=false")
            local round_start=args.invites==false and args.join==false and args.refresh==true and args.dedicated==false
            local expected_advertise=receipt.private_session==false
            if round_start then expected_advertise=false end
            local flags="lan="..tostring(args.lan).." invites="..tostring(args.invites).." join="..tostring(args.join).." refresh="..tostring(args.refresh).." dedicated="..tostring(args.dedicated).." advertise="..tostring(args.advertise)
            assert(args.advertise==expected_advertise,"original factory advertisement differs measured="..tostring(args.advertise).." required="..tostring(expected_advertise).." roundStart="..tostring(round_start).." "..flags)
            log("info","session gate original factory flags roundStart="..tostring(round_start).." "..flags)
            if s.pending then log("info","session gate newer original factory supersedes local readback sequence="..s.pending.sequence) end
            s.sequence=s.sequence+1
            s.pending={sequence=s.sequence,args=args,substituted=false,factory_returned=false}
            s.phase="parameter_pending"
            if args.join==false then
                log("info","session gate original join-in-progress parameter substitution attempted sequence="..s.sequence)
                join:set(true)
                assert(join:get()==true,"native original bool parameter readback is not true")
                s.pending.substituted=true
            else log("info","session gate original join-in-progress already true; setter skipped sequence="..s.sequence) end
            for key,param in pairs({public=public,private=private,lan=lan,invites=invites,refresh=refresh,dedicated=dedicated,advertise=advertise}) do
                assert(param:get()==args[key],"another original factory argument changed="..key)
            end
            s.phase="original_pending"
            return {status=args.join and "already_true" or "parameter_confirmed",sequence=s.sequence,settings_confirmed=false}
        end)
    end
    function api.post(world,original_return)
        if s.phase=="failed" or s.phase=="stopped" or not s.pending then return {status="dormant"} end
        return protected("native factory POST",function()
            if address(world:get())~=gi_address then return {status="skipped"} end
            local proxy=original_return:get()
            assert(valid(proxy) and proxy:GetClass():GetFullName()=="Class /Script/AdvancedSessions.UpdateSessionCallbackProxyAdvanced","original UpdateSession proxy return missing/class differs")
            s.pending.factory_returned=true; s.pending.proxy_address=proxy:GetAddress(); s.phase="settings_pending"
            local c,waiting=current(); if not c then return waiting end
            log("info","session gate original factory returned sequence="..s.pending.sequence.."; settings ACK pending")
            return {status="factory_returned",sequence=s.pending.sequence,settings_confirmed=false}
        end)
    end
    function api.poll()
        if s.phase=="failed" or s.phase=="stopped" then return {status=s.phase,cause=s.cause} end
        return protected("original settings getter ACK",function()
            local c,waiting=current(); if not c then return waiting end
            if not s.pending then return s.last or {status="waiting",cause="original factory PRE not observed"} end
            if not s.pending.factory_returned then return {status="waiting",cause="original factory POST not observed"} end
            local values=settings(c.game_instance); local p=s.pending
            assert(values.result==0,"original GetSessionSettings failed Result="..tostring(values.result))
            assert(type(values.join)=="boolean","original join settings OUT missing")
            if not values.join then reason("info","original join-in-progress settings readback pending; no update replay"); return {status="waiting"} end
            for _,key in ipairs({"public","private","lan","invites","dedicated"}) do assert(values[key]==p.args[key],"original requested settings readback differs="..key) end
            s.phase="local_settings_confirmed"
            s.last={status="local_settings_confirmed",sequence=p.sequence,substituted=p.substituted,session_id=receipt.session_id,server_id=receipt.server_id,join=true,settings_confirmed=true,remote_join_confirmed=false}
            s.pending=nil
            log("info","session gate actual original settings ACK sequence="..p.sequence.."; remote join unconfirmed")
            return s.last
        end)
    end
    function api.original_failed(world,family)
        if s.phase=="failed" or s.phase=="stopped" then return {status="dormant"} end
        return protected("original UpdateSession failure observer",function()
            if address(world)~=gi_address then return {status="skipped"} end
            current()
            if not s.pending and not s.last then return {status="skipped",cause="no bound original factory observed"} end
            return failed("original UpdateSession OnFailure",family.."; original callback has no error payload; inspect original OSS log; sequence attribution is unconfirmed")
        end)
    end
    function api.stop() s.phase="stopped"; api.stopped=true; log("info","session gate stopped; original factory hooks dormant") end
    function api.status() return s end
    return api
end

function M.start(receipt,log,on_error)
    assert(not M.active,"session gate start already attempted; no registration replay")
    assert(type(log)=="function" and type(on_error)=="function","explicit log/error handlers required")
    M.active=true
    local api
    local ok,result=xpcall(function()
    local authority=require("authority")
    local library=StaticFindObject("/Script/AdvancedSessions.Default__AdvancedSessionsLibrary")
    local gameplay=StaticFindObject("/Script/Engine.Default__GameplayStatics")
    assert(valid(library) and valid(gameplay) and valid(StaticFindObject(PATH)),"original native session factory/getters unavailable")
    assert(receipt.game_instance:GetClass():GetFullName()==GI_CLASS,"original bootstrapped GI class differs")
    local identity=require("authority_identity")
    local lease=identity.capture(receipt)
    local function observe(r)
        local state=authority.status()
        local c=identity.resolve(lease,r)
        c.bootstrap_current=state and state.phase=="ready" and state.receipt==r
        if c.status=="waiting" then c.readiness=c.cause end
        return c
    end
    local function settings(gi)
        local n,p,lan,ded,invites,join,anti,build,extra,result={},{},{},{},{},{},{},{},{},{}
        library:GetSessionSettings(gi,n,p,lan,ded,invites,join,anti,build,extra,result)
        return {public=n.NumConnections,private=p.NumPrivateConnections,lan=lan.bIsLAN,dedicated=ded.bIsDedicated,invites=invites.bAllowInvites,join=join.bAllowJoinInProgress,result=result.Result}
    end
    api=M.new(receipt,log,on_error,observe,settings,lease.gi_address)
    local ok,a,b=pcall(RegisterHook,PATH,function(_,...) api.pre(...) end,function(_,original_return,world) api.post(world,original_return) end)
    if not ok or type(a)~="number" or type(b)~="number" then
        local cause="native UpdateSession PRE/POST registration cause="..tostring(not ok and a or "hook IDs missing")
        error(cause)
    end
    local base="/Game/CabinGameContent/CabinAdvanceFriendsGameInstance.CabinAdvanceFriendsGameInstance_C:"
    for _,family in ipairs({"8C1759104B126878ACF8C6BE67D8C3CA","2DBCC2A64577C59762C9A99EE6C0D149"}) do
        local path=base.."OnFailure_"..family
        assert(valid(StaticFindObject(path)),"original UpdateSession failure callback unavailable="..path)
        local a,b=RegisterHook(path,function(context) api.original_failed(context:get(),family) end)
        assert(type(a)=="number" and type(b)=="number","original failure hook IDs missing="..path)
    end
    log("info","session gate native original UpdateSession PRE/POST registered; no session call performed")
    return api
    end,debug.traceback)
    if not ok then
        if api then api.stop() end
        log("error","session gate start cause="..tostring(result).."; gate dormant; no registration replay")
        local handled,cause=pcall(on_error,result)
        if not handled then log("error","session gate startup error handler cause="..tostring(cause).."; original="..tostring(result)) end
        return nil,result
    end
    return result
end
return M
