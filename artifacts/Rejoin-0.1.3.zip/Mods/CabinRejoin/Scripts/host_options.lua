local M = {}
local PREFIX = "__CABIN_OWNER1__"
local server_started, client_started = false, false
local nonce_counter = 0
local KEYS = {"difficulty","player_collision","radio_tutorial","goodie_bag"}
local function copy(t) local out={}; for key,value in pairs(t) do out[key]=value end; return out end
local function same_bind(a,b)
    for _,key in ipairs({"pc_address","pawn_address","world_address","gm_address","gi_address","session_id","steam_id","connection_handle","generation"}) do
        if a[key]~=b[key] then return false end
    end
    return true
end
function M.change(before, wanted, codec)
    assert(codec.valid_options(before) and codec.valid_options(wanted),"four original options required")
    local changed
    for i,key in ipairs(KEYS) do
        if before[key]~=wanted[key] then assert(not changed,"O request changes more than one original choice"); changed=i end
    end
    return changed, changed and (changed==1 and wanted.difficulty or (wanted[KEYS[changed]] and 1 or 0)) or nil
end
function M.postcondition(before,after,option,index,specs)
    local expected=option==1 and index or index==1
    for i=1,4 do
        local a,b=after.cards[i],before.cards[i]
        assert(a.address==b.address and a.widget==b.widget,"original option binding replaced="..i)
        if i==option then
            assert(after.gi[i]==expected and after.save[i]==expected and a.value==expected and a.widget_value==expected,"selected original GI/save/card/widget mismatch="..i)
            assert(a.text==a.display and a.text:lower()==specs[i].labels[index]:lower(),"selected original FText/display mismatch="..i)
        else
            assert(after.gi[i]==before.gi[i] and after.save[i]==before.save[i] and a.value==b.value and a.widget_value==b.widget_value
                and a.text==b.text and a.display==b.display,"unselected original state changed="..i)
        end
    end
    return true
end
function M.client_selection_matches(row,option,index,specs)
    local expected=option==1 and index or index==1
    local label=assert(specs[option].labels[index],"original client option/index label unavailable")
    for _,key in ipairs({"value","widget_value"}) do
        assert(type(row[key])==type(expected),"original client selection scalar type differs="..key)
        if row[key]~=expected then return false,"selected client "..key.." measured="..tostring(row[key]).." required="..tostring(expected) end
    end
    for _,key in ipairs({"text","display"}) do
        assert(type(row[key])=="string","original client FText/display readback missing="..key)
        if row[key]:lower()~=label:lower() then return false,"selected client "..key.." measured="..row[key].." required="..label end
    end
    return true
end
function M.client_postcondition(before,after,option,index,specs)
    local expected=option==1 and index or index==1
    for i=1,4 do
        local a,b=after.cards[i],before.cards[i]
        assert(a.address==b.address and a.widget==b.widget,"original client option binding replaced="..i)
        assert(after.gi[i]==before.gi[i],"original remote client GI changed="..i)
        if i==option then
            assert(after.save[i]==expected,"selected original client GameData mismatch="..i)
            local matched,cause=M.client_selection_matches(a,option,index,specs); assert(matched,cause)
        else
            assert(after.save[i]==before.save[i] and a.value==b.value and a.widget_value==b.widget_value and a.text==b.text and a.display==b.display,"unselected original client state changed="..i)
        end
    end
    return true
end
local function setup(options)
    assert(type(options)=="table" and type(options.log)=="function" and type(options.codec)=="table" and type(options.objects)=="table","host options dependencies required")
    local s={options=options,running=true,reasons={}}
    function s.log(level,message)
        local ok,cause=pcall(options.log,level,"host options: "..message)
        if not ok then error("host options logger cause="..tostring(cause).."; original="..message,0) end
    end
    function s.reason(key,level,cause)
        local old=s.reasons[key]; local n=old and old.cause==cause and old.count+1 or 1
        if not old or old.cause~=cause or n%60==0 then s.log(level,cause.." observations="..n) end
        s.reasons[key]={cause=cause,count=n}
    end
    function s.protect(name,fn)
        local ok,result=xpcall(fn,debug.traceback)
        if not ok then s.reason(name,"error",name.." cause="..tostring(result)); return nil,tostring(result) end
        if s.reasons[name] then s.log("info",name.." recovered"); s.reasons[name]=nil end
        return result
    end
    return s
end
local function hex(text) return (text:gsub(".",function(c) return string.format("%02x",c:byte()) end)) end
local function unhex(text)
    if text=="-" then return "" end
    assert(#text<=512 and #text%2==0 and text:match("^[0-9a-f]+$"),"reply cause encoding differs")
    return (text:gsub("..",function(c) return string.char(tonumber(c,16)) end))
end
function M.reply(codec,kind,g,sequence,option,index,values,cause)
    assert(kind=="G" or kind=="R" or kind=="F" or kind=="V","host reply kind differs")
    assert(codec.valid_options(values) and codec.valid_nonce(g.nonce),"host reply values/nonce differ")
    local reason=(cause or ""):sub(1,256)
    return table.concat({PREFIX,kind,tostring(g.generation),g.session_id,g.owner_id,g.nonce,tostring(sequence),tostring(option),tostring(index),
        tostring(values.difficulty),values.player_collision and "1" or "0",values.radio_tutorial and "1" or "0",values.goodie_bag and "1" or "0",#reason>0 and hex(reason) or "-"},"|")
end
function M.decode_reply(codec,wire)
    if type(wire)~="string" or wire:sub(1,#PREFIX+1)~=PREFIX.."|" then return nil,"unmarked" end
    assert(#wire<1024,"host reply envelope oversized")
    local p={}; for value in wire:gmatch("[^|]+") do p[#p+1]=value end
    assert(#p==14,"host reply fields differ")
    local generation,sequence,option,index=tonumber(p[3]),tonumber(p[7]),tonumber(p[8]),tonumber(p[9])
    assert(math.type(generation)=="integer" and generation>0 and generation<=2147483647
        and math.type(sequence)=="integer" and sequence>=0 and sequence<=2147483647
        and math.type(option)=="integer" and option>=0 and option<=4 and math.type(index)=="integer" and index>=0 and index<=3,"host reply integer fields differ")
    assert(p[4]:match("^[1-9][0-9]*$") and p[5]:match("^[1-9][0-9]*$"),"host reply Session/Owner differs")
    local packet=assert(codec.decode(table.concat({codec.prefix,"O",p[3],"1",p[6],p[10],p[11],p[12],p[13]},"|")))
    local g={generation=generation,session_id=p[4],owner_id=p[5],nonce=p[6]}
    local cause=unhex(p[14])
    assert(M.reply(codec,p[2],g,sequence,option,index,packet.options,cause)==wire,"noncanonical host reply")
    g.kind,g.sequence,g.option,g.index,g.values,g.cause=p[2],sequence,option,index,packet.options,cause
    return g
end

function M.start_server(options)
    assert(not server_started,"host server start already attempted; no replay"); server_started=true
    local s=setup(options); local o,codec=options.objects,options.codec
    assert(type(options.original_click)=="table" and type(options.dispatcher)=="table" and type(options.current_lobby)=="function","server original click/dispatcher/lobby adapters required")
    local api,peers,grants,pending,queued,active={}, {}, {}, {}, {}, nil
    local epoch,signature,owner_stamp=0,nil,nil
    local function binding(pc)
        assert(s.running,"host server stopped")
        local c=o.context(pc,3); local id,handle=o.authenticate(pc); local owner=o.owner(c)
        assert(owner.owner_id==tostring(id),"native authenticated remote PC is not current Lobby Owner")
        local sig=table.concat({o.address(c.world),o.address(c.gm),o.address(c.gi),c.session_id},":")
        if sig~=signature then
            assert(epoch<2147483647,"Lobby epoch exhausted"); epoch,signature=epoch+1,sig
            s.log("info","actual Lobby epoch observed="..epoch.."; old grants invalidated")
            peers,grants,pending,queued={},{},{},{}
            owner_stamp=nil
        end
        local key=pc:GetAddress()
        local stamp=table.concat({key,id,handle,o.address(c.pawn)},":")
        if owner_stamp and owner_stamp~=stamp then
            assert(epoch<2147483647,"Lobby connection epoch exhausted"); epoch=epoch+1
            peers,grants,pending,queued={},{},{},{}
            s.log("info","actual owner PC/Pawn/identity/connection changed; epoch="..epoch.."; old grants invalidated")
        end
        owner_stamp=stamp
        local current={pc=pc,pc_address=key,pawn_address=o.address(c.pawn),world_address=o.address(c.world),gm_address=o.address(c.gm),
            gi_address=o.address(c.gi),session_id=c.session_id,lobby_id=c.session_id,steam_id=id,connection_handle=handle,generation=epoch,context=c}
        local old=peers[key]
        if old and same_bind(old,current) then old.context=c; return old end
        if old then s.log("info","current owner connection/pawn changed; old grant/pending invalidated pc="..key) end
        peers[key],grants[key],pending[key],queued[key]=current,nil,nil,nil
        return current
    end
    local function read(peer)
        local cards=o.cards(peer.context.world)
        return o.capture(peer.context,cards,o.save(peer.context,options.authority_user_dir))
    end
    local function send(peer,kind,g,sequence,option,index,values,cause)
        local wire=M.reply(codec,kind,g,sequence,option,index,values,cause)
        assert(#wire<1024,"original FName reply too large")
        s.log(kind=="F" and "error" or "info","reply "..kind.." attempted sequence="..sequence)
        peer.pc:ClientMessage("",FName(wire),0)
        s.log("info","reply "..kind.." call returned; actual client receipt unconfirmed")
    end
    local click=options.original_click.new({log=options.log,context=function(pc) return binding(pc).context end,authenticate=o.authenticate,lobby_owner=o.owner,
        resolve_cards=o.cards,read_gi=o.values,read_save=function(c) return o.save(c,options.authority_user_dir) end,
        validate_request=function(pc,c,request,id,handle)
            local peer=binding(pc); local g=grants[peer.pc_address]
            assert(active and active.request==request and g and g.ready and request.grant_nonce==g.nonce
                and same_bind(peer,active.peer) and c.session_id==g.session_id and id==peer.steam_id and handle==peer.connection_handle,"current OwnerGrant original callback binding differs")
            return true
        end})
    local function begin(peer,packet)
        local before=read(peer); local option,index=M.change(o.choices(before.gi),packet.options,codec)
        if not option then return {unchanged=true,values=o.choices(before.gi)} end
        local action={peer=peer,before=before,option=option,index=index,packet=packet,callback_seen=false,
            request={option=option,index=index,sequence=packet.sequence,grant_nonce=grants[peer.pc_address].nonce}}
        pending[peer.pc_address],active=action,action
        local receipt,cause=click.apply(peer.pc,option,index,action.request)
        active=nil
        action.immediate_receipt,action.immediate_cause=receipt,cause
        if cause then s.log("error","original immediate receipt cause="..cause.."; no callback replay; delayed read-only condition remains explicit") end
        if not action.callback_seen then pending[peer.pc_address]=nil; error("original callback entry was not observed; delayed receipt cannot claim execution",0) end
        return action
    end
    local dispatch=options.dispatcher.new({log=options.log,authenticate=o.authenticate,current_peer=binding,lobby_owner=function(peer) return o.owner(peer.context) end,
        on_options4=function(peer,packet)
            local g=assert(grants[peer.pc_address],"server-issued OwnerGrant unavailable")
            assert(packet.nonce==g.nonce and same_bind(g.binding,peer),"current OwnerGrant nonce/epoch/binding differs")
            local previous=pending[peer.pc_address]
            if previous then
                local list=queued[peer.pc_address] or {}; queued[peer.pc_address]=list
                local last=#list>0 and list[#list].options or previous.packet.options
                M.change(last,packet.options,codec)
                list[#list+1]=packet
                s.log("info","later original click queued sequence="..packet.sequence.."; prior callback is not replayed")
                return {pending=true,cause="ordered original click waits for prior readback"}
            end
            local before=read(peer); local current=o.choices(before.gi)
            if not g.ready then
                assert(codec.same_options(packet.options,g.values) and codec.same_options(current,g.values),"OwnerGrant baseline changed before acknowledgement")
                g.ready=true
                send(peer,"R",g,packet.sequence,0,0,current)
                return {confirmed=true,options=current,owner_grant_acknowledged=true}
            end
            local option,index=M.change(current,packet.options,codec)
            if not option then
                send(peer,"R",g,packet.sequence,0,0,current)
                return {confirmed=true,options=current,deliberate_skip="original choices unchanged"}
            end
            begin(peer,packet)
            return {pending=true,cause="original callback observed; separate delayed readback pending"}
        end})
    assert(type(dispatch.complete_options)=="function","pending O dispatcher completion extension required")
    local witness_ready,witness_attempted=false,false
    local function witnesses()
        if witness_ready then return true end
        assert(not witness_attempted,"previous original witness registration failed; no replay")
        local hooks=o.hooks()
        for _,hook in ipairs(hooks) do if o.address(StaticFindObject(hook.path))==0 then return false,"original widget callback not loaded="..hook.path end end
        witness_attempted=true
        for _,hook in ipairs(hooks) do
            local a,b=RegisterHook(hook.path,function(context)
                if active and hook.option==active.option and hook.index==active.index and o.address(context:get())==active.before.cards[hook.option].widget then active.callback_seen=true end
            end)
            assert(type(a)=="number" and type(b)=="number","original callback witness hook IDs unavailable")
        end
        witness_ready=true; return true
    end
    function api.offer(pc)
        return s.protect("owner offer",function()
            local ready,why=witnesses(); if not ready then s.reason("witness","info",why); return {status="waiting"} end
            local peer=binding(pc); local old=grants[peer.pc_address]
            if old then return {status=old.ready and "ready" or "offered",calls_returned=old.calls_returned} end
            local baseline=read(peer); assert(nonce_counter<math.maxinteger,"OwnerGrant nonce exhausted"); nonce_counter=nonce_counter+1
            local g={binding=copy(peer),generation=peer.generation,session_id=peer.session_id,owner_id=tostring(peer.steam_id),
                nonce=string.format("%016x%016x",peer.pc_address,nonce_counter),values=o.choices(baseline.gi),ready=false,calls_returned=false}
            grants[peer.pc_address]=g
            send(peer,"G",g,0,0,0,g.values); g.calls_returned=true
            return {status="offered",calls_returned=true,client_acknowledged=false}
        end)
    end
    function api.dispatch(pc,wire)
        local packet,cause=codec.decode(wire)
        if not packet or packet.kind~="options4" then return nil,cause or "not O" end
        local result=dispatch.dispatch(pc,wire)
        if result.status=="failed" or result.status=="rejected" then
            s.protect("failure reply",function()
                local peer=binding(pc); local g=grants[peer.pc_address]
                if g and g.nonce==packet.nonce then send(peer,"F",g,packet.sequence,0,0,o.choices(o.values(peer.context.gi)),result.cause) end
                return {status="observed"}
            end)
        end
        return result
    end
    function api.poll()
        if not s.running then return {status="stopped"} end
        return s.protect("host server poll",function()
            local lobby,why=options.current_lobby()
            if not lobby then
                if next(grants) then s.log("info","original Lobby ended; all grants/pending invalidated cause="..tostring(why)) end
                peers,grants,pending,queued,signature,owner_stamp={},{},{},{},nil,nil
                s.reason("lobby","info","waiting for original Lobby cause="..tostring(why)); return {status="waiting"}
            end
            local ready,why=witnesses()
            if not ready then s.reason("witness","info",why); return {status="waiting"} end
            for _,pc in ipairs(o.actors(lobby.world,"/Game/CabinGameContent/PlayerContent/Cabin_PC.Cabin_PC_C")) do
                if pc:GetLocalRole()==3 and o.address(pc.NetConnection)>0 and o.address(pc.Pawn)>0 then
                    s.protect("peer readiness pc="..pc:GetAddress(),function()
                        local id=o.authenticate(pc); local owner=o.owner(o.context(pc,3))
                        if tostring(id)==owner.owner_id then
                            local offered,cause=api.offer(pc); assert(offered,cause)
                        end
                        return {status="observed"}
                    end)
                end
            end
            for key,action in pairs(pending) do
                s.protect("readback pc="..key,function()
                    local peer=binding(action.peer.pc)
                    assert(same_bind(peer,action.peer),"original callback binding changed before delayed readback")
                    local after=read(peer)
                    local ok,cause=pcall(M.postcondition,action.before,after,action.option,action.index,o.specs)
                    if not ok then
                        s.reason("postcondition pc="..key,"error","actual delayed readback cause="..tostring(cause).."; no mutation replay")
                        if action.last_failure~=tostring(cause) then
                            action.last_failure=tostring(cause)
                            send(peer,"F",grants[key],action.packet.sequence,action.option,action.index,o.choices(after.gi),tostring(cause))
                        end
                        return {status="waiting"}
                    end
                    local values=o.choices(after.gi)
                    assert(codec.same_options(values,action.packet.options),"actual delayed GI values differ from O request")
                    local completed=dispatch.complete_options(peer.pc,action.packet.sequence,action.packet.nonce,{confirmed=true,options=values})
                    assert(completed.status=="confirmed",completed.cause)
                    if action.immediate_cause then s.log("warn","delayed original state confirmed after immediate failure; initial cause remains unresolved="..action.immediate_cause) end
                    send(peer,"R",grants[key],action.packet.sequence,action.option,action.index,values,action.immediate_cause)
                    pending[key]=nil
                    s.log("info","actual delayed GI/save/card/widget/FText readback confirmed; flip_pending="..tostring(after.cards[action.option].in_transition))
                    local list=queued[key]
                    while list and #list>0 and not pending[key] do
                        local packet=table.remove(list,1)
                        local next_action=begin(peer,packet)
                        if next_action.unchanged then
                            local skipped=dispatch.complete_options(peer.pc,packet.sequence,packet.nonce,{confirmed=true,options=next_action.values})
                            assert(skipped.status=="confirmed",skipped.cause)
                            send(peer,"R",grants[key],packet.sequence,0,0,next_action.values)
                        end
                    end
                    return completed
                end)
            end
            return {status="observed"}
        end)
    end
    function api.stop() s.running=false; api.stopped=true; peers,grants,pending,queued={},{},{},{}; s.log("info","host server stopped; callbacks dormant") end
    return api
end

function M.start_client(options)
    assert(not client_started,"host client start already attempted; no replay"); client_started=true
    local s=setup(options); local o,codec=options.objects,options.codec
    local api,g,sequence,components,pending,incoming={},nil,0,{},nil,nil
    local function disable(cause)
        if not g then return end
        g.enabled=false
        for _,entry in ipairs(components) do
            if o.address(entry.card)>0 and o.address(entry.component)>0 and o.address(entry.card:GetWorld())==g.world then
                entry.component:SetCollisionEnabled(entry.before)
                assert(entry.component:GetCollisionEnabled()==entry.before,"original client collision restoration not acknowledged")
            else s.log("info","old widget/card ended; original collision restoration skipped") end
        end
        g,components,pending=nil,{},nil; s.log("info","OwnerGrant invalidated cause="..cause)
    end
    local function current()
        assert(s.running and g,"current OwnerGrant unavailable")
        local c=o.context(g.pc,2); assert(o.address(c.world)==g.world and o.address(c.pawn)==g.pawn and o.address(c.gi)==g.gi
            and c.session_id==g.session_id and o.owner(c).owner_id==g.owner_id,"local OwnerGrant PC/Pawn/GI/world/session/Owner changed")
        return c
    end
    local function send(values)
        local c=current(); assert(sequence<2147483647,"host control sequence exhausted"); sequence=sequence+1
        local packet={kind="options4",generation=g.generation,sequence=sequence,nonce=g.nonce,options=copy(values)}
        local wire,cause=codec.encode(packet); assert(wire,cause)
        pending={packet=packet,pc=c.pc,server_acknowledged=false}
        s.log("info","O call attempted sequence="..sequence)
        c.pc:ServerExecRPC(wire)
        s.log("info","O call returned; authority readback/ClientMessage receipt pending")
    end
    local hooks_ready,hooks_attempted=false,false
    local function clicked(widget,option,index)
        if not s.running or not g or not g.enabled then return end
        s.protect("original local click",function()
            local c=current(); local cards=o.cards(c.world); local card=cards[option]
            assert(o.address(widget.LobbyCard)==card:GetAddress() and (o.address(widget)==o.address(card.Widget:GetWidget()) or o.address(widget)==o.address(card.WidgetBackside:GetWidget())),"clicked widget is not current bound original option")
            g.desired[KEYS[option]]=option==1 and index or index==1
            send(g.desired)
            return {status="call_returned",server_acknowledged=false}
        end)
    end
    local function click_hooks()
        if hooks_ready then return true end
        assert(not hooks_attempted,"previous original click registration failed; no replay")
        local hooks=o.hooks()
        for _,hook in ipairs(hooks) do if o.address(StaticFindObject(hook.path))==0 then return false,"original local widget callback not loaded="..hook.path end end
        hooks_attempted=true
        for _,hook in ipairs(hooks) do
            local a,b=RegisterHook(hook.path,function(context) clicked(context:get(),hook.option,hook.index) end)
            assert(type(a)=="number" and type(b)=="number","original click hook IDs unavailable")
        end
        hooks_ready=true; return true
    end
    local function accept_grant(pc,reply)
        local c=o.context(pc,2); assert(c.session_id==reply.session_id and o.owner(c).owner_id==reply.owner_id,"actual local Lobby Session/Owner differs from grant")
        if g and g.nonce==reply.nonce and g.generation==reply.generation then return {status="duplicate"} end
        if g then
            assert(reply.generation>g.generation or c.session_id~=g.session_id or o.address(c.world)~=g.world or o.address(pc)~=o.address(g.pc),"same-epoch OwnerGrant replacement rejected")
            disable("new original Lobby epoch")
        end
        local cards,prepared=o.cards(c.world),{}
        for _,card in ipairs(cards) do
            for _,name in ipairs({"Widget","WidgetBackside"}) do
                local component=card[name]; assert(o.address(component)>0,"original widget component unavailable")
                local before=component:GetCollisionEnabled(); assert(before==0 or before==1,"original component collision outside0/1")
                prepared[#prepared+1]={card=card,component=component,before=before}
            end
        end
        local ready,why=click_hooks(); if not ready then s.reason("click readiness","info",why); return {status="waiting"} end
        g={pc=pc,pawn=o.address(c.pawn),gi=o.address(c.gi),world=o.address(c.world),session_id=reply.session_id,owner_id=reply.owner_id,generation=reply.generation,nonce=reply.nonce,desired=copy(reply.values),enabled=false}
        sequence,components=0,prepared
        send(reply.values)
        return {status="grant_received",server_ready=false}
    end
    function api.receive(pc,message,wire)
        return s.protect("OwnerGrant receive",function()
            assert(message=="","OwnerGrant requires empty ClientMessage text")
            local reply,cause=M.decode_reply(codec,wire); assert(reply,cause)
            if reply.kind=="G" then
                assert(o.address(pc)>0 and pc:IsLocalController() and pc:GetLocalRole()==2 and not pc:IsActorBeingDestroyed(),"Grant target is not current owning remote PC")
                incoming={pc=pc,reply=reply}
                s.log("info","OwnerGrant queued; original local ownership/widgets/handshake pending")
                return {status="grant_queued",server_ready=false}
            end
            local c=current(); assert(c.pc:GetAddress()==pc:GetAddress() and c.session_id==reply.session_id and o.owner(c).owner_id==reply.owner_id,"actual local Lobby Session/Owner differs from server receipt")
            assert(g.nonce==reply.nonce and g.generation==reply.generation,"server receipt nonce/epoch differs")
            if reply.kind=="V" then disable(reply.cause); return {status="revoked"} end
            if reply.kind=="F" then
                if pending and pending.packet.sequence==reply.sequence then pending.server_failure=reply.cause end
                s.log("error","authority option failure cause="..reply.cause.."; full original cause remains in authority log")
                return {status="failed",cause=reply.cause}
            end
            assert(reply.kind=="R" and pending and reply.sequence<=sequence,"server receipt has no matching outstanding O call")
            if reply.sequence<sequence then s.log("info","older option receipt observed sequence="..reply.sequence.."; newer local click remains pending"); return {status="superseded"} end
            assert(reply.sequence==pending.packet.sequence and codec.same_options(reply.values,pending.packet.options),"server receipt options/sequence differ")
            pending.server_acknowledged=true
            pending.reply=reply
            if #reply.cause>0 then s.log("warn","authority delayed state matched after immediate failure cause="..reply.cause.."; full unresolved cause remains in authority log") end
            g.desired=copy(reply.values)
            if not g.enabled then
                for _,entry in ipairs(components) do entry.component:SetCollisionEnabled(1); assert(entry.component:GetCollisionEnabled()==1,"original host widget collision1 unacknowledged") end
                current(); g.enabled=true
                s.log("info","actual OwnerGrant handshake acknowledged; original option widgets enabled")
            else
                local cards=o.cards(c.world)
                if reply.option>0 then
                    local card,spec=cards[reply.option],o.specs[reply.option]; local widget=card.Widget:GetWidget()
                    local matched,cause=M.client_selection_matches({value=card[spec.value],widget_value=widget[spec.widget_value],text=card[spec.text]:ToString(),display=widget[spec.display]:GetText():ToString()},reply.option,reply.index,o.specs)
                    if not matched then
                        pending.client_display_confirmed=false
                        s.reason("display","info",cause.."; authority ACK received; original client projection pending; no click replay")
                        return {status="client_projection_pending",server_acknowledged=true,client_display_confirmed=false,replication_delivery_confirmed=false}
                    end
                end
                s.log("info","actual authority receipt and current client card/widget/FText/display matched; client GI/save and replication delivery provenance unconfirmed")
            end
            pending.client_display_confirmed=reply.option>0
            return {status="acknowledged",server_acknowledged=true,client_display_confirmed=reply.option>0,replication_delivery_confirmed=false}
        end)
    end
    local a,b=RegisterHook("/Script/Engine.PlayerController:ClientMessage",function(context,message,kind)
        local wire=kind:get():ToString()
        if wire:sub(1,#PREFIX+1)==PREFIX.."|" then api.receive(context:get(),message:get():ToString(),wire) end
    end)
    assert(type(a)=="number" and type(b)=="number","original ClientMessage hook IDs unavailable")
    function api.poll()
        if not s.running then return {status="stopped"} end
        if incoming then
            local pc=incoming.pc
            if o.address(pc)==0 or pc:IsActorBeingDestroyed() then incoming=nil; s.log("info","queued OwnerGrant PC ended")
            elseif o.address(pc.Pawn)==0 or not pc.Pawn:IsLocallyControlled() or o.address(pc.AcknowledgedPawn)~=o.address(pc.Pawn) then
                s.reason("grant ownership","info","waiting for original local pawn ownership acknowledgement")
            else
                local result,cause=s.protect("grant readiness",function() return accept_grant(pc,incoming.reply) end)
                if result and result.status~="waiting" then incoming=nil end
                if not result then return nil,cause end
            end
        end
        if not g then return {status="waiting"} end
        local c,cause=s.protect("current local grant",current)
        if not c then return s.protect("grant revoke",function() disable(cause); return {status="revoked"} end) end
        if pending and pending.reply and pending.reply.option>0 and not pending.client_display_confirmed then
            local reply=pending.reply; local cards=o.cards(c.world); local card,spec=cards[reply.option],o.specs[reply.option]
            local widget=card.Widget:GetWidget()
            local matched,cause=M.client_selection_matches({value=card[spec.value],widget_value=widget[spec.widget_value],text=card[spec.text]:ToString(),display=widget[spec.display]:GetText():ToString()},reply.option,reply.index,o.specs)
            if matched then
                pending.client_display_confirmed=true
                s.log("info","actual authority receipt and delayed client card/widget/FText/display matched; client GI/save and replication delivery provenance unconfirmed")
            else s.reason("display","info",cause.."; authority ACK received; original client projection pending; no click replay") end
        end
        return {status=g.enabled and "enabled" or "handshake_pending"}
    end
    function api.stop() disable("module stopped"); incoming=nil; s.running=false; api.stopped=true end
    return api
end
return M
