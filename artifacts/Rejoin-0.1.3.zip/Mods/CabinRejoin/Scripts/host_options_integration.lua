local gt_scheduler = require("gt_scheduler")
local M = {}
local started = {}
function M.watch(api,log,loop,execute)
    assert(type(log)=="function" and type(loop)=="function" and type(execute)=="function","original poll scheduler/log functions required")
    local state={queued=false,failed=false,skipped=0}
    api.poll_watch=state
    local function fail(operation,cause)
        state.failed=true; state.cause=operation.." cause="..tostring(cause)
        log("error",state.cause.."; poll stopped; no automatic replay")
        local ok,stop_cause=pcall(api.stop)
        if not ok then log("error","host options stop after poll failure cause="..tostring(stop_cause).."; poll remains stopped") end
    end
    local function tick()
        if state.failed or api.stopped then return true end
        if state.queued then
            state.skipped=state.skipped+1
            if state.skipped==1 or state.skipped%60==0 then log("info","host options poll waiting for original game-thread callback; skipped="..state.skipped) end
            return
        end
        if state.skipped>0 then log("info","host options game-thread callback recovered; skipped="..state.skipped); state.skipped=0 end
        state.queued=true
        local ok,result=pcall(execute,function()
            if state.failed or api.stopped then state.queued=false; return end
            local called,receipt,cause=pcall(api.poll)
            state.queued=false
            if not called then fail("host options poll callback",receipt)
            elseif not receipt then fail("host options poll callback",cause or "failed poll omitted its cause")
            elseif type(receipt)~="table" or type(receipt.status)~="string" then fail("host options poll callback","actual poll receipt is missing status")
            else state.last_receipt=receipt end
        end)
        if not ok or result==false then
            state.queued=false
            fail("host options gt_scheduler.execute scheduling",not ok and result or "original scheduler returned false")
        end
    end
    local ok,result=pcall(loop,1000,tick)
    if not ok or result==false then fail("host options gt_scheduler.loop scheduling",not ok and result or "original scheduler returned false") end
    return state
end
function M.start_server(log,authority_user_dir,authority_ready)
    assert(not started.server,"host server integration start already attempted"); started.server=true
    assert(type(authority_ready)=="function","actual authority readiness guard required")
    local objects=require("host_options_objects")
    local api=require("host_options").start_server({log=log,codec=require("control_codec"),objects=objects,
        dispatcher=require("host_options_dispatcher"),original_click=require("original_click"),authority_user_dir=authority_user_dir,
        current_lobby=function()
            if not authority_ready() then return nil,"own authority bootstrap not ready" end
            return objects.current_lobby()
        end})
    M.watch(api,log,gt_scheduler.loop,gt_scheduler.execute)
    return api
end
function M.start_client(log)
    assert(not started.client,"host client integration start already attempted"); started.client=true
    local api=require("host_options").start_client({log=log,codec=require("control_codec"),objects=require("host_options_objects")})
    M.watch(api,log,gt_scheduler.loop,gt_scheduler.execute)
    return api
end
function M.start(options)
    M.start_client(assert(options.log,"host client logger required"))
    return true
end
return M
