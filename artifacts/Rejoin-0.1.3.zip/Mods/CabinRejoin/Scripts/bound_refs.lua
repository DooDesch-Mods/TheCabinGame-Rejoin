local M={}
local function valid(v) return v and v:IsValid() end
local function addr(v) return valid(v) and v:GetAddress() or 0 end
local function live(v) return valid(v) and not v:IsActorBeingDestroyed() end
local function class(v) return v:GetClass():GetFullName():match('([^%.]+)$') end
local function world(a,b) return addr(a:GetWorld())~=0 and addr(a:GetWorld())==addr(b:GetWorld()) end
function M.values(array)
    local rows,n={},0
    array:ForEach(function(i,p)
        assert(math.type(i)=='integer' and i>=1 and i<=64,'bounded original array index required')
        assert(rows[i]==nil,'duplicate original array index')
        rows[i]=p:get();n=n+1
    end)
    for i=1,n do assert(rows[i]~=nil,'original array member unavailable index='..i) end
    return rows
end
function M.ordinal(array,target)
    local selected,n=nil,0
    for i,v in ipairs(M.values(array)) do if addr(v)==addr(target) and addr(target)~=0 then selected,n=i,n+1 end end
    assert(n==1,'exact original array binding required matches='..n)
    return selected
end
function M.member_key(prefix,index,v)
    assert(math.type(index)=='integer' and index>=1 and index<=64 and live(v),'current original member required')
    return prefix..'_'..index..'_'..class(v)
end
function M.card_key(pawn,board,card)
    assert(live(card),'live original card required')
    if card.Status==0 then assert(addr(board.Card)==addr(card),'original ejected Card binding differs');return 'ejected' end
    if card.Status==1 then return M.member_key('hand',M.ordinal(pawn.CurrentCardsObjects,card),card) end
    if card.Status==2 then return M.member_key('grave',M.ordinal(board.Graveyard,card),card) end
    error('current original Inspect status unavailable='..tostring(card.Status))
end
function M.owner_key(pawn,board,owner)
    if addr(owner)==0 then return 'none' end
    if addr(owner)==addr(pawn) then return 'owner' end
    return 'roster_'..M.ordinal(board.PlayerOrder,owner)
end
function M.resolve_card(pawn,board,key,status)
    if status==0 then
        if key~='ejected' or not live(board.Card) or board.Card.Status~=0 then return nil,'waiting for original ejected Board.Card' end
        return board.Card
    end
    local prefix=status==1 and 'hand' or status==2 and 'grave' or nil
    assert(prefix,'unsupported original Inspect status')
    local index,wanted=key:match('^'..prefix..'_(%d+)_([%w_]+)$')
    assert(index,'current original card selector malformed')
    local array=status==1 and pawn.CurrentCardsObjects or board.Graveyard
    local rows=M.values(array);local card=rows[tonumber(index)]
    if not live(card) or class(card)~=wanted or card.Status~=status or not world(card,pawn) then
        return nil,'waiting for original '..prefix..' ordinal/class/status/world index='..index
    end
    M.ordinal(array,card)
    return card
end
function M.card_context_key(pawn,board,original)
    return function(v)
        if not valid(v) then return 'none' end
        if addr(v)==addr(pawn) then return 'owner' end
        local in_roster=0
        for _,p in ipairs(M.values(board.PlayerOrder)) do if addr(p)==addr(v) then in_roster=in_roster+1 end end
        if in_roster>0 then return M.owner_key(pawn,board,v) end
        local in_card=addr(board.Card)==addr(v)
        for _,array in ipairs({pawn.CurrentCardsObjects,board.Graveyard}) do
            for _,card in ipairs(M.values(array)) do if addr(card)==addr(v) then in_card=true end end
        end
        if in_card then return M.card_key(pawn,board,v) end
        return original(v)
    end
end
function M.unique(candidates,predicate,label)
    local selected,n=nil,0
    for _,v in ipairs(candidates) do if live(v) and predicate(v) then selected,n=v,n+1 end end
    if n==0 then return nil,'waiting for original '..label..' binding' end
    assert(n==1,'ambiguous original '..label..' binding matches='..n)
    return selected
end
function M.resolve_intro(pawn,candidates,seat_key,car_class)
    local index=assert(tonumber(seat_key:match('^seat_(%d+)$')),'original Intro seat ordinal required')
    local car,cause=M.unique(candidates,function(v)
        if not world(v,pawn) or v:GetClass():GetFullName()~=car_class then return false end
        local n=0;for _,p in ipairs(M.values(v.IntroPlayers)) do if addr(p)==addr(pawn) then n=n+1 end end
        return n==1
    end,'Intro car/IntroPlayers')
    if not car then return nil,nil,cause end
    local seat=M.values(car.Seats)[index]
    if not valid(seat) or addr(seat:GetOwner())~=addr(car) or not world(seat,pawn) then
        return nil,nil,'waiting for current original Intro seat owner/world'
    end
    M.ordinal(car.Seats,seat)
    return car,seat
end
function M.pose(v)
    local p,r=v:K2_GetActorLocation(),v:K2_GetActorRotation()
    return {p.X,p.Y,p.Z,r.Pitch,r.Yaw,r.Roll}
end
function M.pose_matches(v,row)
    local current=M.pose(v)
    for i=1,6 do
        assert(type(row[i])=='number' and row[i]==row[i],'original finite pose required')
        local delta=i<=3 and math.abs(current[i]-row[i]) or math.abs((current[i]-row[i]+180)%360-180)
        if delta>=0.01 then return false end
    end
    return true
end

-- Holding roots follow original hand slots; each machine evaluates its own mesh socket pose.
function M.holding_slot(pawn,card)
    if not live(pawn) or not live(card) then return nil,'waiting for live original Holding pawn/card' end
    local index=M.ordinal(pawn.CurrentCardsObjects,card)
    local field=({[1]='Card_One',[2]='Card_Two',[3]='Card_Three'})[index]
    if not field then return nil,'original Holding slot unavailable index='..index end
    local chair=pawn.Chair
    if not live(chair) or chair:GetClass():GetFullName():match('^[^ ]+ (.+)$')~=
        '/Game/CabinGameContent/BoardGameStuff/Cards/PlayerCards_BP.PlayerCards_BP_C' or not world(chair,pawn) then
        return nil,'waiting for original Holding Chair class/world' end
    if addr(chair.PlayerCharacter)~=addr(pawn) then return nil,'waiting for original Holding Chair.PlayerCharacter' end
    if addr(card.CurrentOwnedPlayer)~=addr(pawn) or card.Status~=1 or not card.IsHolding then
        return nil,'waiting for original Holding card owner/status' end
    local matches=0
    for _,name in ipairs({'Card_One','Card_Two','Card_Three'}) do if addr(chair[name])==addr(card) then matches=matches+1 end end
    if addr(chair[field])~=addr(card) or matches~=1 then return nil,'waiting for exact original Holding Chair slot card index='..index end
    local slot,root,hand,mesh=chair['Card'..index..'Scene'],card.RootComponent,chair.PlayerCards,pawn.Mesh
    for _,row in ipairs({{slot,chair,'slot'},{root,card,'root'},{hand,chair,'hand'},{mesh,pawn,'mesh'}}) do
        if not valid(row[1]) or not world(row[1],pawn) or addr(row[1]:GetOwner())~=addr(row[2]) then
            return nil,'waiting for original Holding component owner/world='..row[3] end
    end
    if slot:GetClass():GetFullName()~='Class /Script/Engine.SceneComponent'
        or root:GetClass():GetFullName()~='Class /Script/Engine.SceneComponent' then
        return nil,'waiting for original Holding slot/root component class' end
    if addr(root:GetAttachParent())~=addr(slot) or root:GetAttachSocketName():ToString()~='None' then
        return nil,'waiting for original Holding root slot attachment' end
    if addr(slot:GetAttachParent())~=addr(hand) then return nil,'waiting for original Holding slot PlayerCards attachment' end
    if addr(hand:GetAttachParent())~=addr(mesh) or hand:GetAttachSocketName():ToString()~='PlayerCards' then
        return nil,'waiting for original Holding PlayerCards mesh socket attachment' end
    local function finite(value) return type(value)=='number' and value==value and math.abs(value)<math.huge end
    for _,row in ipairs({{root.RelativeLocation,{'X','Y','Z'},0,false,'location'},
        {root.RelativeRotation,{'Pitch','Yaw','Roll'},0,true,'rotation'},{root.RelativeScale3D,{'X','Y','Z'},1,false,'scale'}}) do
        for _,name in ipairs(row[2]) do
            local value=row[1] and row[1][name]
            if not finite(value) then return nil,'waiting for finite original Holding relative '..row[5]..'.'..name end
            local delta=row[4] and math.abs((value-row[3]+180)%360-180) or math.abs(value-row[3])
            if delta>=0.01 then return nil,'waiting for original Holding SnapToTarget relative '..row[5]..'.'..name end
        end
    end
    local p,r=root:K2_GetComponentLocation(),root:K2_GetComponentRotation()
    for _,row in ipairs({{p,{'X','Y','Z'},'location'},{r,{'Pitch','Yaw','Roll'},'rotation'}}) do
        for _,name in ipairs(row[2]) do if not finite(row[1] and row[1][name]) then
            return nil,'waiting for finite original Holding root world '..row[3]..'.'..name end end
    end
    return {index=index,chair=chair,slot=slot,root=root,
        location={X=p.X,Y=p.Y,Z=p.Z},rotation={Pitch=r.Pitch,Yaw=r.Yaw,Roll=r.Roll}}
end
return M
