local M = {}
local function valid(object) return object and object:IsValid() end

function M.create(gi, pc, log)
    local lib = StaticFindObject("/Script/AdvancedSessions.Default__AdvancedSessionsLibrary")
    assert(valid(gi) and valid(pc) and valid(lib) and type(log)=="function", "original session settings dependencies missing")
    assert(gi["Extra Settings"]:GetArrayNum()==0, "fresh original session settings required before creation")
    local request = require("steam_host_autostart").read_request()
    local specs, max_players, advertise
    if request then
        require("steam_host_autostart").seed(gi,request,log)
        max_players, advertise = request.max_players, not request.invite_only
        specs = {
            {"Bool", "IsPasswordProtected", request.password_protected},
            {"String", "Password", request.password},
            {"String", "LobbyName", request.lobby_name},
            {"String", "LobbyCode", request.code},
            {"Bool", "IsPrivate", request.is_private},
            {"Int", "CurrentPlayerCount", 0},
            {"Int", "MaxPlayers", max_players},
            {"Int", "BuildVersionID", gi.BuildVersionID},
        }
    else
    local widget, count = nil, 0
    for _, value in ipairs(FindAllOf("HostOptions_WBP_C") or {}) do
        if valid(value) and not value:GetFullName():find("Default__", 1, true)
            and valid(value:GetOwningPlayer()) and value:GetOwningPlayer():GetAddress()==pc:GetAddress() then
            widget, count = value, count+1
        end
    end
    assert(count==1 and valid(widget.AdvanceCabinGameInstance) and widget.AdvanceCabinGameInstance:GetAddress()==gi:GetAddress(),
        "original owned HostOptions widget count measured="..count.." required1")
    assert(widget["Build Version ID"]==gi.BuildVersionID and math.type(gi.BuildVersionID)=="integer", "original host build version differs")
    assert(valid(widget.Code_TextBox), "original lobby code widget missing")
    specs = {
        {"Bool", "IsPasswordProtected", widget.IsPasswordProtected},
        {"String", "Password", widget.Password:ToString()},
        {"String", "LobbyName", widget.LobbyName:ToString()},
        {"String", "LobbyCode", widget.Code_TextBox:GetText():ToString()},
        {"Bool", "IsPrivate", widget.IsPrivate},
        {"Int", "CurrentPlayerCount", 0},
        {"Int", "MaxPlayers", 4},
        {"Int", "BuildVersionID", gi.BuildVersionID},
    }
        max_players, advertise = 4, false
    end
    local hooks, expected, copied = {}, nil, false
    local function cleanup()
        for _, hook in ipairs(hooks) do
            local ok, cause = pcall(UnregisterHook, hook[1], hook[2], hook[3])
            if not ok then log("warn", "session property observer cleanup target="..hook[1].." cause="..tostring(cause)) end
        end
        expected = nil
    end
    local ok, cause = xpcall(function()
        for _, kind in ipairs({"Bool", "String", "Int"}) do
            local path = "/Script/AdvancedSessions.AdvancedSessionsLibrary:MakeLiteralSessionProperty"..kind
            local pre, post = RegisterHook(path, function() end, function(context, original_return, key)
                if not expected or key:get():ToString()~=expected[2] then return end
                assert(not copied, "original session property callback duplicated key="..expected[2])
                local raw = original_return:get()
                assert(type(raw)=="userdata", "native session property return missing key="..expected[2])
                gi["Extra Settings"][expected.index] = raw
                assert(gi["Extra Settings"]:GetArrayNum()==expected.index, "native session property storage count differs key="..expected[2])
                copied = true
            end)
            hooks[#hooks+1] = {path, pre, post}
        end
        for index, spec in ipairs(specs) do
            assert(type(spec[3])==({Bool="boolean", String="string", Int="number"})[spec[1]], "original session property type differs key="..spec[2])
            spec.index, expected, copied = index, spec, false
            lib["MakeLiteralSessionProperty"..spec[1]](lib, FName(spec[2]), spec[3])
            assert(copied, "native session property callback missing key="..spec[2])
        end
    end, debug.traceback)
    cleanup()
    if not ok then error("original session settings construction cause="..tostring(cause).."; session creation not requested; no replay") end
    local settings = {}
    gi["Extra Settings"]:ForEach(function(index, item) settings[index]=item:get() end)
    assert(#settings==#specs, "original session property count differs")
    for _, spec in ipairs(specs) do
        local search, value = {}, {}
        lib["GetSessionProperty"..spec[1]](lib, settings, FName(spec[2]), search, value)
        local actual = value.SettingValue
        if spec[1]=="String" then actual = actual:ToString() end
        assert(search.SearchResult==0 and actual==spec[3], "native stored session property readback differs key="..spec[2])
    end
    log("info", "original eight host session properties stored and read back; build="..gi.BuildVersionID)
    gi:SetInfo_E(max_players, specs[4][3], advertise, false)
    assert(gi["Should Advertise"]==advertise and gi["Use LAN"]==false, "original Steam session preferences not acknowledged")
    gi:Create_Session_E(settings, pc, max_players, false, true, advertise)
end

return M
