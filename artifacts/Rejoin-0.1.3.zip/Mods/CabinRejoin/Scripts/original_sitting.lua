local M = {}
function M.start(receipt, gm, log)
    assert(IsInGameThread()==true,"original sitting registration requires GameThread")
    local resolve=require("sitting_binding").resolver(require("authority_identity"),receipt,gm)
    local initial=resolve(gm)
    assert(initial.status=="ready","original sitting authority binding cause="..tostring(initial.cause))
    local api=require("sitting_observer").start({mode="guard",context_address=gm:GetAddress(),
        resolve_current=resolve,log=log,is_game_thread=IsInGameThread,register_hook=RegisterHook},require("sitting_decision"))
    assert(api.status().phase=="registered","original sitting registration cause="..tostring(api.status().last_error))
    return api
end
return M
