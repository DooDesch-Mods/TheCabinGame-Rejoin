local M = {}

local function valid(o) return o ~= nil and o:IsValid() end
local function address(o) return valid(o) and o:GetAddress() or 0 end
local function live(o, label)
    assert(valid(o) and not o:IsActorBeingDestroyed(), label .. " actor unavailable")
    return o
end
local function finite(n, label)
    assert(type(n) == "number" and n == n and math.abs(n) < math.huge, label .. " is not finite")
    return n
end
local function vector(v) return {X=finite(v.X,"X"),Y=finite(v.Y,"Y"),Z=finite(v.Z,"Z")} end
local function rotation(v) return {Pitch=finite(v.Pitch,"Pitch"),Yaw=finite(v.Yaw,"Yaw"),Roll=finite(v.Roll,"Roll")} end
local function boolean(v, label) assert(type(v)=="boolean",label .. " is not Boolean"); return v end
local function ordered(a)
    local r = {count=a:GetArrayNum(),items={}}
    a:ForEach(function(i, v) local o=v:get(); assert(valid(o),"ordered object unavailable index=" .. tostring(i)); r.items[i]=o:GetAddress() end)
    return r
end
local function card_state(card)
    return {address=card:GetAddress(),class=address(card:GetClass()),status=card.Status,type=card.CardType,
        player=address(card.Player),owner=address(card.CurrentOwnedPlayer),holding=card.IsHolding,
        ports=(function() local r={}; card.OpenPorts:ForEach(function(i,v) r[i]=v:get() end); return r end)(),
        location=vector(card:K2_GetActorLocation()),rotation=rotation(card:K2_GetActorRotation())}
end

local function inspect(c)
    assert(type(c.same_world)=="function" and type(c.world_id)=="function", "world read adapters required")
    local pawn,board,map=live(c.pawn,"pawn"),live(c.board,"board"),live(c.map,"map")
    assert(map:GetClass():GetFullName()=="BlueprintGeneratedClass /Game/CabinGameContent/BoardGameStuff/CardMapLayout_BP.CardMapLayout_BP_C", "original Map class differs")
    assert(c.same_world(pawn,board)==true and c.same_world(pawn,map)==true,"pawn/board/map world differs")
    local s={world=c.world_id(pawn),pawn=pawn:GetAddress(),board=board:GetAddress(),map=map:GetAddress(),
        has_card=boolean(map.HasCard,"Map.HasCard"),card=address(map.CurrentCard),current_player=address(map.CurrentPlayer),
        board_card=address(board.Card),current_turn_pawn=address(board.CurrentPlayerTurn),turn_index=board.PlayerTurn,
        assigned=boolean(pawn.IsCurrentTurn,"Pawn.IsCurrentTurn"),ending=boolean(board.GameEndTime,"Board.GameEndTime"),
        board_started=board.GameStarted,halted=board.HaltGame,pawn_halted=pawn.GameHalted,
        pawn_position=vector(pawn:K2_GetActorLocation()),pawn_rotation=rotation(pawn:K2_GetActorRotation()),
        chair=address(pawn.Chair),hand=ordered(pawn.CurrentCards),physical_hand=ordered(pawn.CurrentCardsObjects),cards={},
        card_class=address(map["Card Class"]),rotation_basis=finite(map.CurrentCardROT,"Map.CurrentCardROT"),
        detector=address(map["As Map Detector BP"]),map_board=address(map.GameBoard),pawn_board=address(pawn.GameBoard),
        local_only={snapped=boolean(map.IsSnapped,"Map.IsSnapped"),rotating=boolean(map.IsRotating,"Map.IsRotating"),
            disable_drag=boolean(map.DisableDrag,"Map.DisableDrag"),in_turn=pawn.IsInTurn,inspect=pawn.IsInspecting},
        tick_enabled=boolean(map:IsActorTickEnabled(),"Map tick enabled")}
    assert(math.type(s.world)=="integer" and s.world~=0,"world adapter returned no valid address")
    pawn.CurrentCardsObjects:ForEach(function(i,v)
        local card=live(v:get(),"hand card"); assert(c.same_world(pawn,card)==true,"hand card world differs"); s.cards[i]=card_state(card)
    end)
    local matches=0
    board.PlayerOrder:ForEach(function(_,v) if address(v:get())==s.pawn then matches=matches+1 end end)
    s.roster_matches=matches
    if valid(map.CurrentCard) then
        local card=live(map.CurrentCard,"current card")
        assert(c.same_world(pawn,card)==true,"current card world differs")
        s.current_card=card_state(card)
        s.card_transition=boolean(card.InTransition,"Card.InTransition")
        s.card_inspect=boolean(card.InInspect,"Card.InInspect")
    end
    if valid(map["As Map Detector BP"]) then
        local detector=live(map["As Map Detector BP"],"detector")
        assert(c.same_world(pawn,detector)==true,"detector world differs")
        s.detector_has_card=boolean(detector.HasCard,"Detector.HasCard")
    end
    assert(valid(map.Rotate_Card),"original rotation timeline unavailable")
    s.rotation_timeline_playing=boolean(map.Rotate_Card:IsPlaying(),"rotation timeline playing")
    return s
end

function M.inspect(c)
    local ok,s=pcall(inspect,c)
    if not ok then return nil,"Map phase inspect failed: " .. tostring(s) end
    return s
end

local function binding(s)
    assert(s.has_card and s.card~=0 and s.current_player==s.pawn,"current replicated room Map binding unavailable")
    assert(s.current_card.type==0 and s.current_card.status==4,"current Map card differs from original Room/4")
    assert(s.roster_matches==1 and s.assigned and s.current_turn_pawn==s.pawn,"current board roster/turn binding differs")
    assert(not s.ending,"original round is ending")
    assert(s.current_card.owner==0 or s.current_card.owner==s.pawn,"current card owner is foreign")
    assert(s.card_class~=0,"Map Card Class unavailable")
end

-- The adapter ties this observation to the retained authenticated owner and current round.
function M.authority(c)
    local ok,result=pcall(function()
        assert(c.pawn:HasAuthority() and c.board:HasAuthority() and c.map:HasAuthority(),"authority actors required")
        assert(type(c.confirm_owner)=="function" and c.confirm_owner(c)==true,"retained authenticated owner not established")
        assert(type(c.current_round)=="function","current round adapter required")
        local round=c.current_round(c)
        assert(type(round)=="string" and #round>0,"current round key unavailable")
        local s=inspect(c)
        if not s.has_card then return {phase="other",round_key=round,observed=s,source="current authority Map.HasCard=false"} end
        binding(s)
        assert(address(c.map.CurrentCard.CardClass)==s.card_class,"current Map/Card class differs")
        return {phase="room_map",round_key=round,observed=s,source="current authenticated authority Map/card/board binding",
            rotation_active=s.rotation_timeline_playing,
            snap_history="not_proved",local_only_history="not_proved"}
    end)
    if not ok then return nil,"Map authority detection failed: " .. tostring(result) end
    return result
end

local function ready(c)
    local s=inspect(c)
    binding(s)
    local pc=live(c.pc,"controller")
    assert(c.same_world(c.pawn,pc)==true,"controller world differs")
    s.pc=pc:GetAddress()
    assert(c.pawn:IsLocallyControlled() and c.pawn:GetLocalRole()==2 and pc:IsLocalController(),"local autonomous owner required")
    assert(address(pc.Pawn)==s.pawn and address(c.pawn.Controller)==s.pc,"controller/pawn possession differs")
    assert(s.pawn_board==s.board,"Pawn.GameBoard differs from current Board")
    local board_card=live(c.board.Card,"Board.Card")
    assert(c.same_world(c.pawn,board_card)==true and address(board_card.CardLayout)==s.map,"Board.Card.CardLayout differs from current Map")
    assert(address(c.map.CurrentCard.CardClass)==s.card_class,"current Map/Card class differs")
    assert(valid(c.gameplay_statics) and address(c.gameplay_statics:GetPlayerController(c.pawn,0))==s.pc,"original PC0 differs")
    assert(type(c.confirm_current)=="function","current authority receipt adapter required")
    local proof=c.confirm_current(c,s)
    assert(type(proof)=="table" and proof.phase=="room_map" and proof.current==true,"current authority room Map receipt unavailable")
    assert(type(proof.source)=="string" and #proof.source>0 and type(proof.round_key)=="string" and #proof.round_key>0,"authority receipt source/round unavailable")
    for _,key in ipairs({"world","pawn","board","map","card","turn_index"}) do
        assert(proof[key]==s[key],"mapped current authority receipt differs=" .. key)
    end
    assert(proof.card_pose_matches==true,"current authority/client card pose not established")
    assert(proof.rotation_active==false,"current authority rotation timeline unsettled or unavailable")
    assert(not s.rotation_timeline_playing,"local rotation timeline is currently running")
    assert(s.tick_enabled,"original Map tick is disabled")
    assert(valid(c.map.Camera) and address(c.map.Camera:GetOwner())==s.map,"Map camera ownership differs")
    assert(c.map.CameraSpots:GetArrayNum()==4,"original Map camera spot count differs")
    c.map.CameraSpots:ForEach(function(i,v) assert(valid(v:get()) and address(v:get():GetOwner())==s.map,"Map camera spot unavailable/foreign index=" .. tostring(i)) end)
    assert(valid(c.pawn.CabinHud_WBP) and c.pawn.CabinHud_WBP:IsInViewport() and address(c.pawn.CabinHud_WBP:GetOwningPlayer())==s.pc,"original local HUD unavailable/foreign")
    assert(valid(pc.UserInputSettings) and valid(pc.UserInputSettings:GetCurrentKeyProfile()),"original input key profile unavailable")
    s.phase=proof
    return s
end

function M.ready(c)
    local ok,s=pcall(ready,c)
    if not ok then return nil,"Map phase ready blocked: " .. tostring(s) end
    return s
end

function M.presentation_ready(c)
    local ok,result=pcall(function()
        local current=ready(c)
        assert(address(c.pc:GetViewTarget())==current.map,"original Map camera blend acknowledgement pending")
        assert(c.pc.bShowMouseCursor==true and valid(c.map.InputComponent),"original Map cursor/input registration unavailable")
        assert(c.pawn.IsInTurn==true and c.pawn.TTurnTransition==false,"original Map active local turn flags unavailable")
        for _,name in ipairs({"DisableMovement","DisableAxisYAW","DisableAxisPITCH","DisableInteract","DisableFlashlight"}) do
            assert(c.pawn[name]==true,"original Map active input flag unavailable=" .. name)
        end
        assert(valid(c.pawn.CabinHud_WBP.CrosshairOverlay) and c.pawn.CabinHud_WBP.CrosshairOverlay:GetVisibility()==2,
            "original Map crosshair visibility differs")
        local keys,widgets={},{}
        c.pawn.CabinHud_WBP.UniqueStringsArray:ForEach(function(_,v) keys[v:get():ToString()]=true end)
        c.pawn.CabinHud_WBP.InputInstructionsArray:ForEach(function(_,v)
            local widget=v:get(); assert(valid(widget),"Map HUD instruction widget unavailable")
            widgets[widget["Unique String"]:ToString()]=true
        end)
        for _,key in ipairs({"confirm_place_card","rotate_room_card","ZoomIn_room_layout","ZoomOut_room_layout"}) do
            assert(keys[key] and widgets[key],"Map HUD key/widget unavailable=" .. key)
        end
        return current
    end)
    if not ok then return nil,"Map presentation readback blocked: " .. tostring(result) end
    return result
end

local function invariant(s)
    local r={}
    for _,k in ipairs({"world","pawn","board","map","has_card","card","current_player","current_turn_pawn","turn_index","assigned",
        "ending","board_started","halted","pawn_halted","pawn_position","pawn_rotation","chair","hand","physical_hand","cards",
        "card_class","rotation_basis","detector","current_card","detector_has_card","map_board","pawn_board","card_transition","card_inspect","local_only"}) do r[k]=s[k] end
    return r
end
local function equal(a,b,path)
    assert(type(a)==type(b),"invariant type differs=" .. path)
    if type(a)~="table" then assert(a==b,"restore changed=" .. path .. " before=" .. tostring(a) .. " after=" .. tostring(b)); return end
    for k,v in pairs(a) do equal(v,b[k],path .. "." .. tostring(k)) end
    for k in pairs(b) do assert(a[k]~=nil,"invariant field added=" .. path .. "." .. tostring(k)) end
end

function M.restore(c)
    assert(type(c.log)=="function","restore logger required")
    local before,blocker=M.ready(c)
    if not before then c.log("info",blocker); return nil,blocker end
    local receipt={stage="prepared",input_receipt="incomplete",before=before,
        gap="new owner original drag/snap/rotate/place/turn-end input requires actual acknowledgement"}
    local ok,cause=pcall(function()
        assert(type(c.text)=="function" and type(c.name)=="function","original FText/FName adapters required")
        local labels={{"place card","confirm_place_card","Cabin_Interact"},{"rotate card","rotate_room_card","Cabin_RotateCard"},
            {"zoom in","ZoomIn_room_layout","Cabin_ZoomIn"},{"zoom out","ZoomOut_room_layout","Cabin_ZoomOut"}}
        local texts,names={},{}
        for i,row in ipairs(labels) do texts[i],names[i]=c.text(row[1]),c.name(row[3]); assert(texts[i]~=nil and names[i]~=nil,"text/name adapter returned nil=" .. row[2]) end
        local empty,none=c.text(""),c.name("None")
        assert(empty~=nil and none~=nil,"empty text/None name adapter returned nil")
        receipt.stage="camera_attempted"
        c.map:EnterMapCamera_E(c.pawn)
        assert(c.pc.bShowMouseCursor==true and valid(c.map.InputComponent),"original Map cursor/input registration not acknowledged")
        receipt.stage="hud_attempted"
        c.pawn:AddInputInstruction_E(empty,"",false,true,none)
        for i,row in ipairs(labels) do c.pawn:AddInputInstruction_E(texts[i],row[2],false,false,names[i]) end
        local keys,widgets={},{}
        c.pawn.CabinHud_WBP.UniqueStringsArray:ForEach(function(_,v) keys[v:get():ToString()]=true end)
        c.pawn.CabinHud_WBP.InputInstructionsArray:ForEach(function(_,v)
            local widget=v:get(); assert(valid(widget),"Map HUD instruction widget unavailable"); widgets[widget["Unique String"]:ToString()]=true
        end)
        for _,row in ipairs(labels) do assert(keys[row[2]] and widgets[row[2]],"Map HUD key/widget not acknowledged=" .. row[2]) end
        local after=inspect(c)
        equal(invariant(before),invariant(after),"gameplay")
        local current=ready(c)
        assert(current.phase.round_key==before.phase.round_key,"current round epoch changed during restore")
        receipt.after=after
        receipt.stage="presentation_registered"
        receipt.camera_receipt=address(c.pc:GetViewTarget())==before.map and "destination_observed" or "blend_pending"
    end)
    if not ok then
        receipt.error=tostring(cause)
        c.log("error","Map phase restore failed stage=" .. receipt.stage .. " cause=" .. receipt.error .. "; partial local presentation may remain")
        local checked,check_cause=pcall(function() receipt.after=inspect(c); equal(invariant(before),invariant(receipt.after),"gameplay_after_failure") end)
        if not checked then receipt.invariant_error=tostring(check_cause); c.log("error","Map phase failure invariant check failed cause=" .. receipt.invariant_error) end
        return nil,receipt
    end
    c.log("info","Map phase presentation registered; camera=" .. receipt.camera_receipt .. "; input receipt incomplete")
    return receipt
end

return M
