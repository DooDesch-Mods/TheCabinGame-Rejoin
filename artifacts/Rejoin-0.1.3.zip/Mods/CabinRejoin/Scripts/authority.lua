local gt_scheduler = require("gt_scheduler")
local M = {}
local current
local GI_CLASS = "/Game/CabinGameContent/CabinAdvanceFriendsGameInstance.CabinAdvanceFriendsGameInstance_C"
local PC_CLASS = "/Game/CabinGameContent/PlayerContent/Cabin_PC.Cabin_PC_C"
local LOBBY_CLASS = "/Game/Cabin_Lobby_Content/Lobby_Gamemode.Lobby_Gamemode_C"
local PREFIX = GI_CLASS .. ":"
local SUCCESS = PREFIX .. "OnSuccess_EAA453CB461EDAC1341C84B61C4533EB"
local FAILURE = PREFIX .. "OnFailure_EAA453CB461EDAC1341C84B61C4533EB"
local NATIVES = {"CabinSteamServerLogOnAnonymous", "CabinSteamServerLoginStatus", "CabinSteamServerState", "CabinSteamSelectServerSockets", "CabinSteamListenerPort"}
local function valid(value) return value and value:IsValid() end
local function address(value) return valid(value) and value:GetAddress() or 0 end
local function terminal(s) return s.phase == "ready" or s.phase == "failed" or s.phase == "stopped" or s.phase == "skipped" end
local function class_is(value, path) return valid(value) and value:GetClass():GetFullName() == "BlueprintGeneratedClass " .. path end
local function integer(value, name)
    assert(math.type(value) == "integer" and value > 0, name .. " must be an exact positive Lua integer")
    return value
end
local function text(value) return type(value) == "string" and value or value:ToString() end
local function clean(value) return tostring(value):gsub("[\r\n]", " | ") end
local function emit(s, level, message)
    local ok, cause = pcall(s.log, level, "authority " .. message)
    if not ok then
        print("[CabinRejoin] error: authority logger cause=" .. tostring(cause) .. "; message=" .. message)
        error("authority logger failed: " .. tostring(cause), 0)
    end
end
local function write_checked(path, bytes)
    local file, cause = io.open(path, "wb")
    assert(file, "open destination=" .. path .. " cause=" .. tostring(cause))
    local wrote, write_cause = file:write(bytes)
    local closed, close_cause = file:close()
    assert(wrote and closed, "write/close destination=" .. path .. " write=" .. tostring(write_cause) .. " close=" .. tostring(close_cause))
    local read, read_cause = io.open(path, "rb")
    assert(read, "readback open destination=" .. path .. " cause=" .. tostring(read_cause))
    local actual, actual_cause = read:read("*a")
    local read_closed, read_close_cause = read:close()
    assert(actual and read_closed, "readback/close destination=" .. path .. " read=" .. tostring(actual_cause) .. " close=" .. tostring(read_close_cause))
    assert(actual == bytes, "destination readback differs=" .. path)
end
local function status(s)
    local rows = {"schema=CabinRejoinAuthority_v1", "process_identity=" .. clean(s.options.process_identity),
        "process_identity_source=launcher", "phase=" .. s.phase, "observations=" .. s.repeats}
    for _, name in ipairs({"reason", "cause", "server_id_text", "session_id", "endpoint"}) do
        if s[name] ~= nil then rows[#rows + 1] = name .. "=" .. clean(s[name]) end
    end
    rows[#rows + 1] = "complete_record=1"
    write_checked(s.options.status_path, table.concat(rows, "\n") .. "\n")
end
local function waiting(s, reason, level)
    s.repeats = s.reason == reason and s.repeats + 1 or 1
    if s.reason ~= reason or s.repeats % 64 == 0 then
        s.reason = reason
        emit(s, level or "info", "phase=" .. s.phase .. " waiting=" .. reason .. " observations=" .. s.repeats)
        status(s)
    end
end
local function transition(s, phase, message)
    if s.reason then emit(s, "info", "recovered=" .. s.reason) end
    s.phase, s.reason, s.repeats = phase, nil, 0
    emit(s, "info", "phase=" .. phase .. " " .. message)
    status(s)
end
local function fail(s, operation, cause)
    if s.phase == "failed" then return end
    s.phase, s.cause = "failed", operation .. ": " .. tostring(cause)
    local logged, log_cause = pcall(emit, s, "error", s.cause .. "; no mutation replay")
    if not logged then print("[CabinRejoin] error: authority failure logger cause=" .. tostring(log_cause) .. "; original=" .. s.cause) end
    local saved, save_cause = pcall(status, s)
    if not saved then print("[CabinRejoin] error: authority failure status cause=" .. tostring(save_cause) .. "; original=" .. s.cause) end
end
local function protected(s, operation, action)
    local ok, cause = xpcall(action, debug.traceback)
    if not ok then fail(s, operation, cause) end
    return ok
end
local function instance(s)
    if s.options.game_instance then
        assert(class_is(s.options.game_instance, GI_CLASS), "supplied original game instance class differs")
        return s.options.game_instance
    end
    local found, count
    count = 0
    for _, value in ipairs(FindAllOf("CabinAdvanceFriendsGameInstance_C") or {}) do
        if valid(value) and not value:GetFullName():find("Default__", 1, true) and valid(value:GetWorld()) then
            assert(class_is(value, GI_CLASS), "game instance class differs")
            found, count = value, count + 1
        end
    end
    assert(count <= 1, "original game instance ambiguous measured=" .. count .. " required1")
    return found
end
local function drivers(world)
    local found, count = nil, 0
    for _, value in ipairs(FindAllOf("SteamSocketsNetDriver") or {}) do
        if valid(value) and not value:GetFullName():find("Default__", 1, true) and (not world or address(value.World) == world:GetAddress()) then
            found, count = value, count + 1
        end
    end
    return found, count
end
local function actors(s, context)
    local out = {}
    s.gameplay:GetAllActorsOfClass(context, s.pc_class, out)
    local count = 0
    local decoded = {}
    for index, parameter in pairs(out) do
        local actor = parameter:get()
        assert(math.type(index) == "integer" and index >= 1 and valid(actor), "original controller enumeration output differs index=" .. tostring(index))
        assert(class_is(actor, PC_CLASS), "original controller enumeration class differs")
        decoded[index] = actor
        count = count + 1
    end
    assert(count == #out, "original controller enumeration is not a contiguous Lua array")
    return decoded, count
end
local function session_id(s)
    local out = {}
    s.sessions:GetCurrentSessionID_AsString(s.gi, out)
    assert(out.SessionId ~= nil, "original session ID output missing")
    local id = text(out.SessionId)
    assert(id:match("^%d+$") and id ~= "0", "original session ID invalid=" .. id)
    return id
end
local function add_hook(s, path, callback)
    assert(valid(StaticFindObject(path)), "original callback missing=" .. path)
    local a, b = RegisterHook(path, function(context)
        if terminal(s) then return end
        protected(s, "callback=" .. path, function()
            assert(valid(s.gi), "original game instance ended before session callback")
            if address(context:get()) == s.gi:GetAddress() then callback() end
        end)
    end)
    assert(type(a) == "number" and type(b) == "number", "original callback registration returned no IDs=" .. path)
    s.hooks[#s.hooks + 1] = {path, a, b}
end
local function cleanup(s)
    for _, hook in ipairs(s.hooks) do
        local ok, cause = pcall(UnregisterHook, hook[1], hook[2], hook[3])
        if not ok then emit(s, "warn", "observer cleanup target=" .. hook[1] .. " cause=" .. tostring(cause) .. "; terminal-state callback remains dormant") end
    end
    s.hooks = {}
end
local function no_owner(s)
    if s.no_owner and valid(s.temporary) then
        assert(address(s.temporary.Pawn) == 0 and address(s.temporary.PlayerState) == 0, "ended temporary PC reacquired Pawn/PlayerState")
    end
    if not s.no_owner then
        assert(valid(s.temporary), "temporary PC wrapper ended before NoPawn/PlayerState observation")
        if address(s.temporary.Pawn) ~= 0 or address(s.temporary.PlayerState) ~= 0 then return false end
        s.no_owner = true
        emit(s, "info", "exact temporary PC NoPawn/NoPlayerState acknowledged address=" .. s.temporary_address)
    end
    return true
end
local function advance(s)
    if terminal(s) then return end
    if s.phase == "preparing" then
        s.host_request = require("steam_host_autostart").read_request()
        s.private_session = not s.host_request or s.host_request.invite_only
        for _, name in ipairs(NATIVES) do
            if type(_G[name]) ~= "function" then waiting(s, "declared native dependency=" .. name); return end
        end
        s.gi = instance(s)
        if not valid(s.gi) or not valid(s.gi:GetWorld()) then waiting(s, "original game instance/world"); return end
        if s.gi.LocalPlayers:GetArrayNum() ~= 1 then waiting(s, "fresh LocalPlayers measured=" .. s.gi.LocalPlayers:GetArrayNum() .. " required1"); return end
        local pc = s.gameplay:GetPlayerController(s.gi, 0)
        if not valid(pc) or not pc:IsLocalController() then waiting(s, "initial original local controller"); return end
        local _, count = drivers()
        assert(count == 0, "fresh pre-listener context required actual Steam driver count=" .. count)
        local login, result, retrying = CabinSteamServerLoginStatus()
        assert(login == 0, "native anonymous login already used/unavailable state=" .. tostring(login) .. " result=" .. tostring(result) .. " retrying=" .. tostring(retrying))
        local sdk_state, id, interface, user = CabinSteamServerState()
        assert(sdk_state == 1 and id == 0 and interface and interface > 0 and user and user > 0, "original logged-off SDK initialization required state=" .. tostring(sdk_state) .. " user=" .. tostring(user) .. "; no SDK initialization replay")
        add_hook(s, SUCCESS, function()
            if s.phase == "session_pending" then s.session_success = true; emit(s, "info", "original CreateSession success callback acknowledged") end
        end)
        add_hook(s, FAILURE, function()
            if s.phase == "session_pending" then error("original CreateSession failure callback; inspect original OSS/native log for cause") end
        end)
        transition(s, "login_pending", "anonymous SDK login attempted once; original callback pump")
        assert(CabinSteamServerLogOnAnonymous() == 1, "anonymous SDK login attempt failed; native log preserves cause")
        return
    end
    assert(valid(s.gi), "original game instance ended during bootstrap")
    if s.phase == "login_pending" then
        local login, result, retrying = CabinSteamServerLoginStatus()
        assert(login ~= nil, "native login status returned no result")
        if login == 1 then waiting(s, "original Steam callback101"); return end
        if login == 3 and retrying == 1 then waiting(s, "original SDK retry pending result=" .. tostring(result), "warn"); return end
        assert(login == 2, "Steam login failed state=" .. login .. " result=" .. tostring(result) .. " retrying=" .. tostring(retrying))
        local logged, id = CabinSteamServerState()
        assert(logged == 2, "SDK BLoggedOn acknowledgement differs state=" .. tostring(logged))
        s.server_id = integer(id, "anonymous Steam server ID")
        s.server_id_text = string.format("%d", s.server_id)
        transition(s, "select_attempted", "original server socket context selection attempted once")
        local selected, selected_id = CabinSteamSelectServerSockets()
        assert(selected == 1 and selected_id == s.server_id, "actual server socket selection not acknowledged status=" .. tostring(selected) .. " ID=" .. tostring(selected_id))
        local pc = s.gameplay:GetPlayerController(s.gi, 0)
        assert(valid(pc) and pc:IsLocalController() and s.gi.LocalPlayers:GetArrayNum() == 1, "initial original local controller changed before session")
        transition(s, "session_pending", "original private four-slot session creation attempted once")
        require("session_settings").create(s.gi, pc, function(level, message) emit(s, level, message) end)
        return
    end
    if s.phase == "session_pending" then
        if not s.session_success then waiting(s, "original CreateSession success callback"); return end
        local lobby = s.gameplay:GetGameMode(s.gi)
        if not class_is(lobby, LOBBY_CLASS) then waiting(s, "original Lobby travel/current GameMode"); return end
        local world = lobby:GetWorld()
        assert(valid(world), "original Lobby world unavailable")
        local driver, count = drivers(world)
        if count ~= 1 then waiting(s, "original Lobby Steam driver count=" .. count .. " required1"); return end
        assert(address(driver.ServerConnection) == 0, "authority driver has client ServerConnection")
        local pc = s.gameplay:GetPlayerController(s.gi, 0)
        if not class_is(pc, PC_CLASS) or not pc:IsLocalController() or s.gi.LocalPlayers:GetArrayNum() ~= 1 then waiting(s, "original temporary Lobby controller"); return end
        assert(address(pc:GetWorld()) == world:GetAddress(), "temporary PC belongs to a different Lobby world")
        s.pc_class = StaticFindObject(PC_CLASS)
        assert(valid(s.pc_class), "exact original PC class missing=" .. PC_CLASS)
        local before, actor_count = actors(s, lobby)
        assert(actor_count == 1 and address(before[1]) == pc:GetAddress(), "original controller enumerator witness differs count=" .. actor_count .. " required exactly temporary PC")
        s.lobby, s.world, s.driver = lobby, world, driver
        s.session_id = session_id(s)
        s.temporary, s.temporary_address, s.temporary_name = pc, pc:GetAddress(), pc:GetFullName()
        RegisterEndPlayPreHook(function(context, reason)
            if s.phase ~= "removing" then return end
            protected(s, "temporary PC EndPlay", function()
                if address(context:get()) ~= s.temporary_address then return end
                assert(context:get():GetFullName() == s.temporary_name, "temporary EndPlay instance name changed")
                assert(address(context:get():GetWorld()) == s.world:GetAddress(), "temporary EndPlay world changed")
                local actual = reason:get()
                assert(actual == 0, "temporary PC EndPlay reason=" .. tostring(actual) .. " required Destroyed0")
                s.endplay_reason = actual
                emit(s, "info", "exact temporary PC EndPlay reason0 acknowledged address=" .. s.temporary_address)
            end)
        end)
        transition(s, "removing", "original RemovePlayer(exact temporary PC,true) attempted once")
        s.gameplay:RemovePlayer(pc, true)
        assert(s.gi.LocalPlayers:GetArrayNum() == 0, "immediate original LocalPlayers removal not acknowledged")
        if not no_owner(s) then waiting(s, "exact temporary PC Pawn/PlayerState detach") end
        return
    end
    if s.phase == "removing" then
        assert(s.gi.LocalPlayers:GetArrayNum() == 0, "authority LocalPlayer reappeared")
        assert(address(s.gameplay:GetGameMode(s.gi)) == s.lobby:GetAddress() and address(s.lobby:GetWorld()) == s.world:GetAddress(), "original Lobby/world ended during cleanup")
        local state = s.gameplay:GetGameState(s.gi)
        if not valid(state) then waiting(s, "original Lobby GameState"); return end
        if state.PlayerArray:GetArrayNum() ~= 0 then waiting(s, "original PlayerStates count=" .. state.PlayerArray:GetArrayNum() .. " required0"); return end
        if s.endplay_reason ~= 0 then waiting(s, "exact temporary PC EndPlay reason0 acknowledgement"); return end
        if not no_owner(s) then waiting(s, "exact temporary PC Pawn/PlayerState detach"); return end
        local _, count = actors(s, s.lobby)
        if count ~= 0 then waiting(s, "original world controller enumeration measured=" .. count .. " required0"); return end
        assert(session_id(s) == s.session_id, "original private session changed during cleanup")
        assert(s.gi["Should Advertise"] == not s.private_session and s.gi["Use LAN"] == false, "original private Steam preferences changed")
        local driver, driver_count = drivers(s.world)
        assert(driver_count == 1 and address(driver) == s.driver:GetAddress() and address(driver.ServerConnection) == 0, "actual authority Steam driver changed during cleanup")
        transition(s, "listener_attempted", "native/SDK actual listener read attempted once")
        local result, port, handle, sdk, detail = CabinSteamListenerPort(driver:GetAddress())
        assert((result == 1 or result == 2) and sdk == result, "listener read failed result=" .. tostring(result) .. " handle=" .. tostring(handle) .. " SDK=" .. tostring(sdk) .. " cause=" .. tostring(detail) .. "; no replay")
        integer(port, "actual virtual port"); integer(handle, "actual listener handle")
        assert(port <= 65535, "actual virtual port exceeds65535")
        s.endpoint = "steam." .. s.server_id_text .. ":" .. port
        s.receipt = {process_identity=s.options.process_identity, process_identity_source="launcher", server_id=s.server_id,
            server_id_text=s.server_id_text, session_id=s.session_id, endpoint=s.endpoint, port=port, listener_handle=handle,
            sdk_result=sdk, game_instance=s.gi, lobby=s.lobby, world=s.world, driver=driver, private_session=s.private_session,
            temporary_pc=s.temporary_address, endplay_reason=0, no_pawn=true, no_player_state=true,
            local_players=0, player_states=0, original_controller_count=0, bootstrap_confirmed=true, client_join_confirmed=false}
        transition(s, "publication_attempted", "lobby endpoint publication/readback prerequisite attempted once; destination not published")
        assert(s.options.before_ready(s.receipt) == true, "before_ready did not acknowledge actual lobby endpoint publication/readback; no endpoint publication/replay")
        assert(session_id(s) == s.session_id and s.gi["Should Advertise"] == not s.private_session and s.gi["Use LAN"] == false, "original private session changed during publication prerequisite")
        assert(s.gi.LocalPlayers:GetArrayNum() == 0 and address(s.gameplay:GetGameMode(s.gi)) == s.lobby:GetAddress(), "authority Lobby/local owner changed during publication prerequisite")
        s.receipt.lobby_publication_confirmed = true
        write_checked(s.options.endpoint_path, s.endpoint .. "\n")
        transition(s, "ready", "original private Lobby/listener/cleanup and before_ready publication acknowledged; endpoint file readback confirmed; client join pending")
        cleanup(s)
        if s.options.on_ready then
            emit(s, "info", "ready handoff callback attempted")
            local ok, cause = pcall(s.options.on_ready, s.receipt)
            if not ok then
                if s.phase == "ready" then fail(s, "ready handoff callback", cause)
                else emit(s, "error", "ready handoff callback cause=" .. tostring(cause) .. "; authority already=" .. s.phase .. "; no handoff replay") end
            else emit(s, "info", "ready handoff callback returned; launcher consumption/client join unconfirmed") end
        end
    end
end

function M.invalidate(receipt, cause)
    assert(current and current.receipt == receipt and current.phase == "ready", "current acknowledged authority receipt required")
    fail(current, "endpoint monitor", cause)
    return current.phase == "failed"
end

function M.start(options)
    if current then return current end
    options = options or {}
    assert(options.log == nil or type(options.log) == "function", "authority options.log must be a function")
    local s = {phase="preparing", options=options, hooks={}, repeats=0, queued=false,
        log=options.log or function(level, message) print("[CabinRejoin] " .. level .. ": " .. message) end}
    current = s
    local started = protected(s, "start", function()
        local system = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
        assert(valid(system) and valid(StaticFindObject("/Script/Engine.KismetSystemLibrary:GetCommandLine")), "native reflected GetCommandLine unavailable")
        local enabled = false
        for token in text(system:GetCommandLine()):gmatch("%S+") do
            if token:lower() == "-cabinrejoinauthority" or token:lower() == '"-cabinrejoinauthority"' then enabled = true end
        end
        if not enabled then s.phase="skipped"; emit(s, "info", "command flag absent; bootstrap not run"); return end
        for _, name in ipairs({"process_identity", "status_path", "endpoint_path"}) do
            assert(type(options[name]) == "string" and options[name] ~= "" and not options[name]:find("[\r\n]"), "authority option required=" .. name)
        end
        assert(options.status_path:lower() ~= options.endpoint_path:lower(), "authority status/endpoint destinations must differ")
        assert(type(options.before_ready) == "function", "authority options.before_ready publication/readback prerequisite required")
        assert(options.on_ready == nil or type(options.on_ready) == "function", "authority options.on_ready must be a function")
        for _, name in ipairs({"FindAllOf", "RegisterHook", "UnregisterHook", "RegisterEndPlayPreHook", "LoopInGameThreadWithDelay", "IsInGameThread"}) do assert(type(_G[name]) == "function", "UE4SS dependency missing=" .. name) end
        s.gameplay = StaticFindObject("/Script/Engine.Default__GameplayStatics")
        s.sessions = StaticFindObject("/Script/AdvancedSessions.Default__AdvancedSessionsLibrary")
        assert(valid(s.gameplay) and valid(s.sessions), "original gameplay/session library unavailable")
        status(s)
        gt_scheduler.loop(500, function()
            if terminal(s) then return true end
            if s.queued then
                s.queue_observations = (s.queue_observations or 0) + 1
                if s.queue_observations == 1 or s.queue_observations % 64 == 0 then emit(s, "info", "GameThread callback entry pending observations=" .. s.queue_observations .. "; no dispatch replay") end
                return false
            end
            s.queued, s.queue_observations = true, 0
            local queued, cause = pcall(gt_scheduler.execute, function()
                if not terminal(s) then protected(s, "advance phase=" .. s.phase, function() advance(s) end) end
                s.queued = false
                if s.phase == "failed" then cleanup(s) end
            end)
            if not queued then fail(s, "GameThread dispatch", cause); s.queued=false end
            return terminal(s)
        end)
        emit(s, "info", "observer loop registration returned; first GameThread entry unconfirmed")
    end)
    if not started then cleanup(s) end
    return s
end

function M.stop()
    if not current or terminal(current) then return current end
    transition(current, "stopped", "bootstrap observer stopped; native login/session/removal are not rolled back")
    cleanup(current)
    return current
end

function M.status() return current end
return M
