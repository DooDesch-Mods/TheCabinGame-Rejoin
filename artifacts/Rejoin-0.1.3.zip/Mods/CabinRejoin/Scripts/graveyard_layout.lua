local M={}
local refs=require('bound_refs')
local function valid(v) return v and v:IsValid() end
local function addr(v) return valid(v) and v:GetAddress() or 0 end
local function near(a,b) return math.abs(a-b)<0.01 end
local function pose(v) return refs.pose(v) end
function M.target(view,right,index,count)
    assert(math.type(index)=='integer' and math.type(count)=='integer' and index>=1 and index<=count and count<=64,
        'bounded original Graveyard index/count required')
    local amount=-4*(count-1)+8*(index-1)
    return {X=view.X+right.X*amount,Y=view.Y+right.Y*amount,Z=view.Z+right.Z*amount}
end
function M.restore(c)
    assert(c.snapshot.card_status==2 and c.snapshot.phase=='inspect_entry','current original Graveyard Inspect marker required')
    assert(valid(c.board.ViewGraveyard) and addr(c.board.CurrentPlayerTurn)==addr(c.pawn),'current original Graveyard view/turn required')
    local rows=refs.values(c.board.Graveyard)
    assert(#rows==#c.snapshot.graveyard_order and #rows>0,'current original Graveyard list differs')
    local view,rot=c.board.ViewGraveyard:K2_GetComponentLocation(),c.board.ViewGraveyard:K2_GetComponentRotation()
    local before,targets={},{}
    for i,card in ipairs(rows) do
        assert(valid(card) and card.Status==2 and c.key(card)==c.snapshot.graveyard_order[i],'current original Graveyard member differs index='..i)
        assert(valid(card.CardScene) and valid(card.DefaultSceneRoot) and addr(card.CardScene)~=addr(card.RootComponent)
            and addr(card.CardScene:GetOwner())==addr(card),'original Graveyard visual component required index='..i)
        assert(valid(card.Graveyard_TL) and not card.Graveyard_TL:IsPlaying(),
            'current local Graveyard transition still running index='..i)
        before[i]=pose(card)
        targets[i]=M.target(view,card.DefaultSceneRoot:GetRightVector(),i,#rows)
    end
    for i,card in ipairs(rows) do
        if addr(card)~=addr(c.card) then
            card.CardScene:K2_SetWorldLocationAndRotation(targets[i],rot,false,{},false)
            local p,r=card.CardScene:K2_GetComponentLocation(),card.CardScene:K2_GetComponentRotation()
            assert(near(p.X,targets[i].X) and near(p.Y,targets[i].Y) and near(p.Z,targets[i].Z),
                'local Graveyard expanded visual pose not acknowledged index='..i)
            for _,k in ipairs({'Pitch','Yaw','Roll'}) do assert(math.abs((r[k]-rot[k]+180)%360-180)<0.01,'local Graveyard visual rotation differs index='..i) end
        end
        local after=pose(card)
        for n=1,6 do assert(after[n]==before[i][n],'local Graveyard visual restore changed actor root index='..i) end
    end
    c.board:EnableInput(c.pc)
    assert(valid(c.board.InputComponent),'original local Graveyard Board input registration not acknowledged')
    c.log('info','Graveyard local expanded visuals and Board input registered; original input not exercised')
    return {visuals=#rows,input_receipt='original_input_not_exercised'}
end
return M
