local M={}
local fields=require('input_ledger').fields
local function valid(v) return v and v:IsValid() end
local function address(v) return valid(v) and v:GetAddress() or 0 end
local function positive(v,label) assert(math.type(v)=='integer' and v>0,label..' must be an exact positive integer'); return v end
function M.new(o)
    for _,name in ipairs({'arm','status','stop','stop_all','epoch','resolve','current_epoch','key','log'}) do
        assert(type(o[name])=='function','native input adapter unavailable='..name)
    end
    local api={}
    function api.set_epoch(world,epoch)
        assert(o.epoch(positive(world,'world'),positive(epoch,'native epoch'))==1,'native input epoch not acknowledged')
    end
    function api.arm(r,fn)
        assert(valid(fn),'reflected original input function unavailable')
        local epoch=o.current_epoch()
        local index=positive(fn:GetFName():GetComparisonIndex(),'original function FName index')
        r.input_epoch,r.input_generation=positive(epoch,'native epoch'),positive(r.input_generation,'reservation input generation')
        assert(o.arm(r.pawn:GetAddress(),fn:GetAddress(),r.pawn:GetWorld():GetAddress(),epoch,r.input_generation,
            positive(r.steam_id,'authenticated native Steam ID'),index)==1,'native original input observer ARM not acknowledged')
        local state={o.status(r.pawn:GetAddress())}
        assert(#state==22 and state[1]==1 and state[2]==1 and state[13]==epoch and state[14]==r.input_generation
            and state[15]==r.steam_id,'native ARM status binding not acknowledged')
        o.log('info','native input observer armed pawn='..o.key(r.pawn)..' epoch='..epoch..' generation='..r.input_generation)
    end
    function api.inspect(target)
        local r=o.resolve(target)
        if not r then return nil,'native input has no current authenticated reservation' end
        local pawn=r.pawn
        assert(valid(pawn) and not pawn:IsActorBeingDestroyed() and pawn:HasAuthority() and pawn:GetAddress()==target,
            'live reserved Authority input Pawn required')
        assert(not r.failed and r.input_epoch==o.current_epoch(),'native input belongs to an ended Pawn/epoch')
        local s={o.status(target)}
        assert(#s==22,'native input status expected22 measured'..#s)
        assert(s[13]==r.input_epoch and s[14]==r.input_generation and s[15]==r.steam_id,
            'native input status epoch/generation/identity differs')
        if s[1]~=1 or s[2]~=1 or s[4]~=1 or s[5]~=1 then
            return nil,'original input sender unavailable found='..s[1]..' enabled='..s[2]..' sequence='..s[3]
                ..' known='..s[4]..' confirmed='..s[5]..' reason='..s[7]
        end
        positive(s[3],'original input sequence')
        assert(s[7]==1 and math.type(s[6])=='integer','native literal input observation required')
        local flags={}
        for i,name in ipairs(fields) do assert(s[7+i]==0 or s[7+i]==1,'native input Bool value differs='..name);flags[name]=s[7+i]==1 end
        return {authority=true,authenticated=true,pawn_address=target,pawn_key=o.key(pawn),
            steam_id=tostring(r.steam_id),epoch=tostring(r.input_epoch)..':'..tostring(r.input_generation),
            world_key=o.key(pawn:GetWorld()),sequence=s[3],flags=flags,source='authority_callspace_pre',
            signature_matches=true,original_result_confirmed=true,callspace=s[6]}
    end
    function api.end_pawn(r,cause)
        if not r.input_epoch then return true end
        assert(o.stop(r.pawn:GetAddress(),r.input_epoch,r.input_generation)==1,'native input STOP unconfirmed cause='..cause)
        r.input_epoch=nil
        o.log('info','native input observer stopped pawn='..o.key(r.pawn)..' cause='..cause)
        return true
    end
    function api.stop_all(cause)
        assert(o.stop_all()==1,'native input STOP_ALL unconfirmed cause='..cause)
        o.log('info','native input observers stopped cause='..cause)
        return true
    end
    return api
end
return M
