local M={}
local ledger=require('input_ledger')
local function valid(v) return v and v:IsValid() end
local function address(v) return valid(v) and v:GetAddress() or 0 end
function M.ready(c)
    assert(type(c)=='table' and type(c.current_token)=='function' and type(c.key)=='function'
        and type(c.current_intent)=='function' and type(c.phase_matches)=='function','current input restore adapters required')
    local token=c.current_token()
    assert(type(token)=='table' and type(c.token)=='table' and token.id==c.token.id
        and token.fingerprint==c.token.fingerprint,'input presentation token superseded')
    local current=c.current_intent()
    assert(ledger.fingerprint(current)==ledger.fingerprint(c.intent),'original input intent superseded')
    local pc,pawn=c.pc,c.pawn
    if not valid(pc) or not valid(pawn) or pc:IsActorBeingDestroyed() or pawn:IsActorBeingDestroyed() then return nil,'waiting for retained input owner actors' end
    if pc:GetLocalRole()~=2 or not pc:IsLocalController() or not pawn:IsLocallyControlled()
        or address(pc.Pawn)~=address(pawn) or address(pc.AcknowledgedPawn)~=address(pawn)
        or address(pawn.Controller)~=address(pc) then return nil,'waiting for retained input ownership acknowledgement' end
    if c.key(pawn)~=c.intent.pawn_key or c.key(pawn:GetWorld())~=c.intent.world_key
        or address(pc:GetWorld())~=address(pawn:GetWorld()) then return nil,'waiting for exact current input Pawn/world' end
    local matches,cause=c.phase_matches()
    if matches~=true then return nil,cause or 'waiting for current authoritative action/world actor binding' end
    if not valid(pawn.CabinHud_WBP) or address(pawn.CabinHud_WBP.PlayerCharacter)~=address(pawn)
        or address(pawn.CabinHud_WBP:GetOwningPlayer())~=address(pc) then return nil,'waiting for original common HUD binding' end
    return true
end
function M.restore(c)
    for _,name in ipairs({'log','invariants','assert_invariants','reset_normal_view'}) do
        assert(type(c[name])=='function','input restore adapter missing='..name)
    end
    local ready,cause=M.ready(c);if not ready then return nil,cause end
    local receipt={attempted=true,complete=false,input_receipt='original_input_not_exercised',before=c.invariants(),
        intent_fingerprint=ledger.fingerprint(c.intent)}
    c.log('info','retained action local view/input restore attempted pawn='..c.intent.pawn_key)
    local ok,failure=pcall(function()
        assert(c.reset_normal_view()==true,'ordinary local view reset unconfirmed')
        local p=c.pawn
        for _,name in ipairs(ledger.fields) do p[name]=c.intent.flags[name] end
        p:EnableInput(c.pc)
        local functions=StaticFindObject('/Game/CabinGameContent/Cabin_Functions.Default__Cabin_Functions_C')
        assert(valid(functions),'original Input Mode library unavailable')
        functions['Input Mode'](functions,c.pc,false,false,true,p)
        c.assert_invariants(receipt.before,c.invariants())
        local still_ready,changed=M.ready(c);assert(still_ready,changed)
        for _,name in ipairs(ledger.fields) do assert(p[name]==c.intent.flags[name],'local input flag readback differs='..name) end
        assert(valid(p.InputComponent) and not c.pc.bShowMouseCursor,'original Pawn input registration/mode unconfirmed')
    end)
    if not ok then
        receipt.cause=tostring(failure)
        c.log('error','retained action local restore cause='..receipt.cause..'; local receipt incomplete')
        return nil,receipt
    end
    receipt.local_confirmed=true;receipt.complete=true
    c.log('info','retained action local flags/input mode acknowledged; original input acceptance pending')
    return receipt
end
function M.finish(c,receipt)
    assert(type(receipt)=='table' and receipt.local_confirmed==true,'registered local input receipt required')
    local ready,cause=M.ready(c);if not ready then return nil,cause end
    c.assert_invariants(receipt.before,c.invariants())
    assert(receipt.intent_fingerprint==ledger.fingerprint(c.intent),'registered input receipt superseded')
    for _,name in ipairs(ledger.fields) do
        if c.pawn[name]~=c.intent.flags[name] then return nil,'current local input intent readback differs='..name end
    end
    if not valid(c.pawn.InputComponent) or c.pc.bShowMouseCursor then return nil,'current original Pawn input mode differs' end
    return receipt
end
return M
