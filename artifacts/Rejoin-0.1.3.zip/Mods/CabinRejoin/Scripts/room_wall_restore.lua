local M = {}
local ROOM="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Rooms/DiningRoom_BP.DiningRoom_BP_C"
local WALL="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Walls/RoomWall_BP.RoomWall_BP_C"
local WINDOWS={
    ["BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Windows/DoubleWindow.DoubleWindow_C"]=true,
    ["BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Windows/SingleWindow.SingleWindow_C"]=true,
    ["BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Windows/LivingRoom_Window.LivingRoom_Window_C"]=true,
    ["BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Windows/Sm_Kitchen_Window.Sm_Kitchen_Window_C"]=true,
    ["BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Windows/Study_Windows.Study_Windows_C"]=true,
}
local DOOR="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Furniture/Shared/CabinDoor_BP.CabinDoor_BP_C"
local ASSETS = {
    ["/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"]="Material",
    ["/Engine/BasicShapes/Cube.Cube"]="StaticMesh",
    ["/Game/AtmoHouse/Materials/Tiled/Worn/MI_Wall_B_plaster_worn.MI_Wall_B_plaster_worn"]="MaterialInstanceConstant",
    ["/Game/AtmoHouse/Materials/Tiled/Worn/MI_Wall_B_wallpaper_D_worn.MI_Wall_B_wallpaper_D_worn"]="MaterialInstanceConstant",
    ["/Game/AtmoHouse/Materials/Worn/MI_Doors_white_worn.MI_Doors_white_worn"]="MaterialInstanceConstant",
    ["/Game/AtmoHouse/Materials/Worn/MI_Molding_white_worn.MI_Molding_white_worn"]="MaterialInstanceConstant",
    ["/Game/AtmoHouse/Materials/Worn/MI_Windowframe_worn.MI_Windowframe_worn"]="MaterialInstanceConstant",
    ["/Game/AtmoHouse/Materials/Worn/MI_Windowglass_worn.MI_Windowglass_worn"]="MaterialInstanceConstant",
    ["/Game/AtmoHouse/Meshes/Meshes_building/SM_Doorframe_single_MID.SM_Doorframe_single_MID"]="StaticMesh",
    ["/Game/AtmoHouse/Meshes/Meshes_building/SM_Doorframe_single_TOP.SM_Doorframe_single_TOP"]="StaticMesh",
    ["/Game/AtmoHouse/Meshes/Meshes_doors/SM_Door_mesh_A_L.SM_Door_mesh_A_L"]="StaticMesh",
    ["/Game/AtmosphericHouse/Materials/Worn/MI_Windowframe_worn.MI_Windowframe_worn"]="MaterialInstanceConstant",
    ["/Game/AtmosphericHouse/Meshes/Meshes_building/SM_WallIn_C_6x.SM_WallIn_C_6x"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/Furniture/Clues_Furniture/CurvedHallway/CurvedHall_Basement_1.CurvedHall_Basement_1"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/Furniture/Clues_Furniture/CurvedHallway/CurvedHall_Basement_2.CurvedHall_Basement_2"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/Basement/BasementSingleDoor.BasementSingleDoor"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/Basement/BuzzGuy_WallHole.BuzzGuy_WallHole"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/Basement/CornerPillar.CornerPillar"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/CellarWallBot_Left.CellarWallBot_Left"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/CellarWallBot_Right.CellarWallBot_Right"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/CellarWallMid_Left.CellarWallMid_Left"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/CellarWallMid_Right.CellarWallMid_Right"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/CellarWallTop_Left.CellarWallTop_Left"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/CellarWallTop_Right.CellarWallTop_Right"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/CenterDoorSingle_Bot.CenterDoorSingle_Bot"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/CenterDoorSingle_Mid.CenterDoorSingle_Mid"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/CenterDoorSingle_Top.CenterDoorSingle_Top"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/CenterDoubleWindow_Bot.CenterDoubleWindow_Bot"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/CenterDoubleWindow_Mid.CenterDoubleWindow_Mid"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/CenterDoubleWindow_Top.CenterDoubleWindow_Top"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/CenterSingleWindow_Bot.CenterSingleWindow_Bot"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/CenterSingleWindow_Mid.CenterSingleWindow_Mid"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/CenterSingleWindow_Top.CenterSingleWindow_Top"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/DoubleDoor_Bot_Left.DoubleDoor_Bot_Left"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/DoubleDoor_Bot_Right.DoubleDoor_Bot_Right"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/DoubleDoor_Mid_Left.DoubleDoor_Mid_Left"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/DoubleDoor_Mid_Right.DoubleDoor_Mid_Right"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/DoubleDoor_Top_Left.DoubleDoor_Top_Left"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/DoubleDoor_Top_Right.DoubleDoor_Top_Right"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/DoubleWindowRight_Bot.DoubleWindowRight_Bot"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/DoubleWindowRight_Mid.DoubleWindowRight_Mid"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/DoubleWindowRight_Top.DoubleWindowRight_Top"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/HallOpening_Bot.HallOpening_Bot"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/HallOpening_Mid.HallOpening_Mid"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/HallOpening_Top.HallOpening_Top"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/SingleWindow_Right_Bot.SingleWindow_Right_Bot"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/SingleWindow_Right_Mid.SingleWindow_Right_Mid"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/SingleWindow_Right_Top.SingleWindow_Right_Top"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/SmallWindowCenter_Bot.SmallWindowCenter_Bot"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/SmallWindowCenter_Mid.SmallWindowCenter_Mid"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/SmallWindowCenter_Top.SmallWindowCenter_Top"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/Study_Crooked_Windows_GROWPIECE.Study_Crooked_Windows_GROWPIECE"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/Study_Crooked_Windows_MID.Study_Crooked_Windows_MID"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/Study_Crooked_Windows_Top.Study_Crooked_Windows_Top"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/TripleWindows_Bot.TripleWindows_Bot"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/TripleWindows_Mid.TripleWindows_Mid"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/TripleWindows_Top.TripleWindows_Top"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/WallB_2Windows_Bot.WallB_2Windows_Bot"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/WallB_2Windows_Mid.WallB_2Windows_Mid"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/WallB_2Windows_Top.WallB_2Windows_Top"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/WallB_Bent_Bot.WallB_Bent_Bot"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/WallB_Bent_Bot_LDoor.WallB_Bent_Bot_LDoor"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/WallB_Bent_Bot_RDoor.WallB_Bent_Bot_RDoor"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/WallB_Bent_Mid.WallB_Bent_Mid"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/WallB_Bent_Mid_LDoor.WallB_Bent_Mid_LDoor"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/WallB_Bent_Mid_RDoor.WallB_Bent_Mid_RDoor"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/WallB_Bent_Top.WallB_Bent_Top"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/WallB_Bent_Top_LDoor.WallB_Bent_Top_LDoor"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/WallB_Bent_Top_RDoor.WallB_Bent_Top_RDoor"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/window_sides.window_sides"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/WallComponents/window_top.window_top"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/Windows/Components/WindowsSingle_BOT.WindowsSingle_BOT"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/Windows/Components/WindowsSingle_BOT_SHORT.WindowsSingle_BOT_SHORT"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/Windows/Components/WindowsSingle_MID.WindowsSingle_MID"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/Windows/Components/WindowsSingle_TOP.WindowsSingle_TOP"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/Windows/Components/WindowsTriple_BOT.WindowsTriple_BOT"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/Windows/Components/WindowsTriple_MID.WindowsTriple_MID"]="StaticMesh",
    ["/Game/CabinGameContent/CabinBuildingMeshes/Windows/Components/WindowsTriple_TOP.WindowsTriple_TOP"]="StaticMesh",
    ["/Game/CabinGameContent/Event_BPs/The_Visitor/Visitor_Room_M.Visitor_Room_M"]="Material",
    ["/Game/HQRetroFarmhouse/Meshes/Props/SM_BilliardBall_15.SM_BilliardBall_15"]="StaticMesh",
}
local GROUPS={wall={"Mid","Bot","Top","DoorTrace"},window={"Bottom","Middle","Top","ForestPlaneScene"},door={"SM_Door","SM_Doorframe_single_MID","SM_Doorframe_single_TOP"}}
local XYZ,PYR={"X","Y","Z"},{"Pitch","Yaw","Roll"}
local function valid(v)return v and v:IsValid() end
local function address(v)return valid(v)and v:GetAddress()or 0 end
local function name(v)return valid(v)and v:GetFullName()or "unavailable" end
local function current(v,pawn,authority)
    return valid(v)and not v:IsActorBeingDestroyed()and address(v:GetWorld())==address(pawn:GetWorld())and v:HasAuthority()==authority
end
local function copy(v,fields)
    local out={}
    for _,field in ipairs(fields)do local n=v[field];assert(type(n)=="number"and n==n and math.abs(n)<math.huge,"wall component value not finite="..field);out[field]=n end
    return out
end
local function equal(a,b,fields)
    for _,field in ipairs(fields)do
        local delta=a[field]-b[field]
        if fields==PYR then delta=(delta+180)%360-180 end
        if math.abs(delta)>=0.0001 then return false end
    end
    return true
end
local function room_of(pawn,authority)
    local room
    for _,v in ipairs(FindAllOf("DiningRoom_BP_C")or{})do
        if current(v,pawn,authority)and name(v:GetClass())==ROOM then assert(not room,"ambiguous current DiningRoom for walls");assert(v.bReplicates==true,"DiningRoom wall source not replicated");room=v end
    end
    return room
end
local function walls_of(pawn,room,authority)
    local anchors,rows={},{}
    for index=1,4 do
        local anchor=room["Wall"..(index-1).."Scene"]
        if not valid(anchor)then return nil,"waiting for DiningRoom wall anchor="..(index-1)end
        assert(name(anchor:GetClass())=="Class /Script/Engine.SceneComponent"and address(anchor:GetOwner())==address(room)and address(anchor:GetWorld())==address(pawn:GetWorld()),"DiningRoom wall anchor class/owner/world differs="..(index-1))
        for _,old in ipairs(anchors)do assert(address(old)~=address(anchor),"DiningRoom wall anchor duplicated")end
        anchors[index]=anchor
    end
    for _,wall in ipairs(FindAllOf("RoomWall_BP_C")or{})do
        if current(wall,pawn,authority)then
            assert(name(wall:GetClass())==WALL and wall.bReplicates==true,"original RoomWall class/replication differs")
            local root=wall.RootComponent
            if valid(root)then
                assert(address(root:GetOwner())==address(wall)and address(root:GetWorld())==address(pawn:GetWorld()),"RoomWall root owner/world differs")
                for index,anchor in ipairs(anchors)do
                    if address(root:GetAttachParent())==address(anchor)then
                        assert(address(wall:GetAttachParentActor())==address(room),"RoomWall attached room differs")
                        assert(not rows[index],"ambiguous RoomWall original anchor="..(index-1));rows[index]=wall
                    end
                end
            end
        end
    end
    for index=1,4 do if not rows[index]then return nil,"waiting for original RoomWall attachment="..(index-1)end end
    return rows
end
local function component(actor,field,pawn)
    local v=actor[field]
    if not valid(v)then return nil end
    local mesh=field~="DoorTrace"and field~="ForestPlaneScene"
    assert(name(v:GetClass())==(mesh and "Class /Script/Engine.StaticMeshComponent"or "Class /Script/Engine.SceneComponent"),"wall component exact class differs="..field)
    assert(address(v:GetOwner())==address(actor)and address(v:GetWorld())==address(pawn:GetWorld()),"wall component owner/world differs="..field)
    return v,mesh
end
local function asset_path(v,mesh)
    assert(valid(v),"authority wall asset unavailable")
    local kind,path=name(v):match("^(%w+) (.+)$")
    assert(ASSETS[path]==kind and name(v:GetClass())=="Class /Script/Engine."..kind,"wall original asset path/class not allowed="..name(v))
    assert(mesh and kind=="StaticMesh"or not mesh and(kind=="Material"or kind=="MaterialInstanceConstant"),"wall original asset type differs="..name(v))
    return path
end
local function load_asset(path,mesh)
    local kind=assert(ASSETS[path],"snapshot wall asset not allowed="..tostring(path))
    assert(mesh and kind=="StaticMesh"or not mesh and(kind=="Material"or kind=="MaterialInstanceConstant"),"snapshot wall asset type differs="..path)
    local value=StaticFindObject(path)
    if not valid(value)then
        assert(IsInGameThread()==true,"wall original asset load requires GameThread")
        local system=StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
        assert(valid(system),"wall original soft loader unavailable")
        print("[CabinRejoin] info: wall fixed original soft load attempted path="..path)
        value=system:LoadAsset_Blocking(system:Conv_SoftObjPathToSoftObjRef(system:MakeSoftObjectPath(path)))
        assert(valid(value),"wall fixed original soft load returned no object="..path)
        assert(address(StaticFindObject(path))==address(value),"wall fixed original soft load path/address differs="..path)
        print("[CabinRejoin] info: wall fixed original soft load confirmed path="..path.." address="..address(value))
    end
    assert(name(value)==kind.." "..path and name(value:GetClass())=="Class /Script/Engine."..kind,"wall asset exact object/class differs="..path)
    return value
end
local function capture_components(actor,group,pawn)
    local rows={}
    for index,field in ipairs(GROUPS[group])do
        local v,mesh=component(actor,field,pawn);assert(v,"authority wall component unavailable="..field)
        local row={location=copy(v.RelativeLocation,XYZ),rotation=copy(v.RelativeRotation,PYR),scale=copy(v.RelativeScale3D,XYZ),visible=v:IsVisible(),hidden=v.bHiddenInGame}
        if mesh then
            row.mesh=asset_path(v.StaticMesh,true);row.materials={}
            local count=v:GetNumMaterials();assert(math.type(count)=="integer"and count>=0,"authority wall material count differs")
            for n=0,count-1 do local material=v:GetMaterial(n);row.materials[n+1]={present=valid(material)==true};if valid(material)then row.materials[n+1].path=asset_path(material,false)end end
        end
        rows[index]=row
    end
    return rows
end
local function child_of(wall,group,pawn,authority)
    local v
    if group=="window"then v=wall.ParentWindow else v=wall.CabinDoor_BP end
    if not valid(v)then return nil end
    assert(current(v,pawn,authority)and address(v:GetAttachParentActor())==address(wall),"wall linked "..group.." world/lifetime/attachment differs")
    local cls=name(v:GetClass());assert(group=="window"and WINDOWS[cls]or group=="door"and cls==DOOR,"wall linked "..group.." exact class differs="..cls)
    return v
end
local function door_idle(door,pawn)
    for _,field in ipairs({"OpenClose_TL","Slam_TL"})do
        local timeline=door[field]
        if not valid(timeline)then return false,"waiting for original door timeline="..field end
        assert(name(timeline:GetClass())=="Class /Script/Engine.TimelineComponent"and address(timeline:GetOwner())==address(door)and address(timeline:GetWorld())==address(pawn:GetWorld()),"door original timeline binding differs="..field)
        if timeline:IsPlaying()then return false,"waiting for original door animation="..field end
    end
    return true
end
function M.capture(pawn)
    local room=room_of(pawn,true);if not room then return nil end
    local walls,cause=walls_of(pawn,room,true);assert(walls,cause)
    local rows={}
    for index,wall in ipairs(walls)do
        local row={components=capture_components(wall,"wall",pawn)};rows[index]=row
        for _,group in ipairs({"window","door"})do
            local v=child_of(wall,group,pawn,true)
            if v then
                row[group]={class=name(v:GetClass()),components=capture_components(v,group,pawn)}
                if group=="door"then row[group].open=v.IsOpen end
            end
        end
        print("[CabinRejoin] info: authority DiningRoom wall capture slot="..(index-1).." Mid="..row.components[1].mesh.." Bot="..row.components[2].mesh.." Top="..row.components[3].mesh)
    end
    return {walls=rows}
end
function M.visit(world,reading,api)
    local present=api.flag(reading and nil or world.wall_visual~=nil);if not present then return end
    local data=world.wall_visual or {};world.wall_visual=data;data.walls=data.walls or {}
    local function visit_components(rows,group)
        for index,field in ipairs(GROUPS[group])do
            local row=rows[index]or {};rows[index]=row
            row.location,row.rotation,row.scale=api.vector(row.location),api.rotation(row.rotation),api.vector(row.scale)
            row.visible,row.hidden=api.flag(row.visible),api.flag(row.hidden)
            if field~="DoorTrace"and field~="ForestPlaneScene"then
                row.mesh=api.text(row.mesh);assert(ASSETS[row.mesh]=="StaticMesh","snapshot wall mesh path differs")
                local count=api.count(reading and nil or #(row.materials or {}));row.materials=row.materials or {}
                for n=1,count do
                    local material=row.materials[n]or {};row.materials[n]=material;material.present=api.flag(material.present)
                    if material.present then material.path=api.text(material.path);assert(ASSETS[material.path]=="Material"or ASSETS[material.path]=="MaterialInstanceConstant","snapshot wall material path differs")end
                end
            end
        end
        assert(#rows==#GROUPS[group],"snapshot wall component count differs="..group)
    end
    for index=1,4 do
        local row=data.walls[index]or {};data.walls[index]=row;row.components=row.components or {};visit_components(row.components,"wall")
        for _,group in ipairs({"window","door"})do
            local has=api.flag(reading and nil or row[group]~=nil)
            if has then
                local item=row[group]or {};row[group]=item;item.class=api.text(item.class)
                assert(group=="window"and WINDOWS[item.class]or group=="door"and item.class==DOOR,"snapshot wall child class differs="..group)
                if group=="door"then item.open=api.flag(item.open)end
                item.components=item.components or {};visit_components(item.components,group)
            end
        end
    end
    assert(#data.walls==4,"snapshot DiningRoom wall count differs")
end
function M.prepare(pawn,world)
    local room=room_of(pawn,false)
    if not world.wall_visual then if room then return nil,"waiting for authority DiningRoom wall snapshot"end;return {}end
    if not room then return nil,"waiting for original DiningRoom walls"end
    local walls,cause=walls_of(pawn,room,false);if not walls then return nil,cause end
    local prepared={pawn=pawn,world=address(pawn:GetWorld()),room=room,room_address=address(room),walls=walls,rows={},children={}}
    local function prepare_components(actor,data,group)
        for index,field in ipairs(GROUPS[group])do
            local value,mesh=component(actor,field,pawn);if not value then return nil,"waiting for original wall component="..field end
            local item={actor=actor,address=address(actor),component=value,component_address=address(value),field=field,data=data[index],mesh=mesh,materials={}}
            if mesh then
                item.asset=load_asset(item.data.mesh,true)
                for n,material in ipairs(item.data.materials)do if material.present then item.materials[n]=load_asset(material.path,false)end end
            end
            prepared.rows[#prepared.rows+1]=item
        end
        return true
    end
    for index,wall in ipairs(walls)do
        local row=world.wall_visual.walls[index]
        local ok;ok,cause=prepare_components(wall,row.components,"wall");if not ok then return nil,cause end
        for _,group in ipairs({"window","door"})do
            local actor=child_of(wall,group,pawn,false);local wanted=row[group]
            if wanted then
                if not actor then return nil,"waiting for original wall "..group.." slot="..(index-1)end
                assert(name(actor:GetClass())==wanted.class,"wall child class differs from authority="..group)
                if group=="door"then
                    if actor.IsOpen~=wanted.open then return nil,"waiting for original replicated door state"end
                    ok,cause=door_idle(actor,pawn);if not ok then return nil,cause end
                end
                ok,cause=prepare_components(actor,wanted.components,group);if not ok then return nil,cause end
            elseif actor then return nil,"waiting for absent authority wall "..group end
            prepared.children[#prepared.children+1]={wall=wall,group=group,actor=actor,address=address(actor),wanted=wanted}
        end
    end
    return prepared
end
function M.apply(prepared,log)
    if not prepared.room then return end
    assert(address(prepared.pawn:GetWorld())==prepared.world and address(room_of(prepared.pawn,false))==prepared.room_address,"DiningRoom walls changed before apply")
    local walls,cause=walls_of(prepared.pawn,prepared.room,false);assert(walls,cause)
    for index,wall in ipairs(walls)do assert(address(wall)==address(prepared.walls[index]),"DiningRoom wall binding changed before apply")end
    for _,item in ipairs(prepared.children)do
        local actor=child_of(item.wall,item.group,prepared.pawn,false);assert(address(actor)==item.address,"wall child binding changed before apply")
        if actor and item.group=="door"then local idle,why=door_idle(actor,prepared.pawn);assert(idle,why);assert(actor.IsOpen==item.wanted.open,"door replicated state changed before apply")end
    end
    for _,item in ipairs(prepared.rows)do
        local value=component(item.actor,item.field,prepared.pawn)
        assert(address(value)==item.component_address and address(item.actor)==item.address,"wall component binding changed before apply="..item.field)
        if item.mesh then assert(asset_path(item.asset,true)==item.data.mesh,"wall prepared mesh changed")end
        for index,material in pairs(item.materials)do assert(asset_path(material,false)==item.data.materials[index].path,"wall prepared material changed")end
    end
    local changed=0;log("info","DiningRoom wall visual restore attempted components="..#prepared.rows)
    for _,item in ipairs(prepared.rows)do
        local v,row=item.component,item.data;local moved=false
        if item.mesh then
            if address(v.StaticMesh)~=address(item.asset)then assert(v:SetStaticMesh(item.asset)==true,"wall SetStaticMesh rejected="..item.field);moved=true end
            assert(address(v.StaticMesh)==address(item.asset),"wall mesh readback differs="..item.field)
            for index,material in ipairs(row.materials)do
                local desired=material.present and item.materials[index]or nil
                if address(v:GetMaterial(index-1))~=address(desired)then v:SetMaterial(index-1,desired);moved=true end
                assert(address(v:GetMaterial(index-1))==address(desired),"wall material readback differs="..item.field.." slot="..(index-1))
            end
            assert(v:GetNumMaterials()==#row.materials,"wall material count readback differs="..item.field.." measured="..v:GetNumMaterials().." required="..#row.materials)
        end
        if not equal(v.RelativeLocation,row.location,XYZ)or not equal(v.RelativeRotation,row.rotation,PYR)then v:K2_SetRelativeLocationAndRotation(row.location,row.rotation,false,{},false);moved=true end
        if not equal(v.RelativeScale3D,row.scale,XYZ)then v:SetRelativeScale3D(row.scale);moved=true end
        if v:IsVisible()~=row.visible then v:SetVisibility(row.visible,false);moved=true end
        if v.bHiddenInGame~=row.hidden then v:SetHiddenInGame(row.hidden,false);moved=true end
        assert(equal(v.RelativeLocation,row.location,XYZ)and equal(v.RelativeRotation,row.rotation,PYR)and equal(v.RelativeScale3D,row.scale,XYZ)and v:IsVisible()==row.visible and v.bHiddenInGame==row.hidden,"wall component pose/visibility readback differs="..item.field)
        if moved then changed=changed+1 end
    end
    log("info","DiningRoom wall visual readback confirmed slots=4 components="..#prepared.rows.." changed="..changed)
end
return M
