local M={}

-- One native delayed-loop reference replaces the async-to-game-thread poll queue.
function M.start(options)
    assert(type(options)=="table" and type(options.name)=="string" and options.name~="","watch name required")
    assert(math.type(options.delay_ms)=="integer" and options.delay_ms>=0,"nonnegative integer watch delay required")
    assert(type(options.observe)=="function" and type(options.log)=="function","watch observe/log required")
    local s={phase="registering",handle=0,registration_confirmed=false,entry_confirmed=false,entries=0,
        cancel_confirmed=false,cause=nil,cancel_cause=nil}
    local api={}
    local function emit(level,message) options.log(level,"watch="..options.name.." "..message) end
    local function fail(operation,cause)
        s.phase="failed"; s.cause=operation..": "..tostring(cause)
        emit("error",s.cause)
    end
    local function cancel()
        if s.cancel_confirmed then return true end
        if s.handle==0 then return false end
        emit("info","cancel attempted handle="..s.handle)
        local ok,result=pcall(CancelDelayedAction,s.handle)
        if not ok or result~=true then
            s.cancel_cause="cancel handle="..s.handle.." cause="..tostring(not ok and result or "original return="..tostring(result))
            emit("error",s.cancel_cause.."; observer dormant, native removal unconfirmed")
            return false
        end
        s.cancel_confirmed=true
        emit("info","cancel confirmed handle="..s.handle)
        return true
    end
    function api.status()
        local copy={}; for key,value in pairs(s) do copy[key]=value end; return copy
    end
    function api.stop()
        if s.phase~="failed" then s.phase="stopped" end
        return cancel()
    end
    local function tick()
        if s.phase=="failed" or s.phase=="stopped" or s.phase=="completed" then return end
        local ok,result=xpcall(function()
            assert(IsInGameThread()==true,"original callback is outside GameThread")
            assert(s.registration_confirmed,"callback entered before registration ACK")
            s.entries=s.entries+1
            if not s.entry_confirmed then
                s.entry_confirmed=true; s.phase="running"
                emit("info","original GameThread callback entry confirmed handle="..s.handle)
            end
            return options.observe()
        end,debug.traceback)
        if not ok then fail("callback",result); cancel(); return end
        if result==true then s.phase="completed"; emit("info","observation completed"); cancel() end
    end
    local ok,cause=xpcall(function()
        for _,name in ipairs({"IsInGameThread","LoopInGameThreadWithDelay","CancelDelayedAction","IsValidDelayedActionHandle"}) do
            assert(type(_G[name])=="function","original API missing="..name)
        end
        emit("info","registration attempted delay_ms="..options.delay_ms)
        local handle=LoopInGameThreadWithDelay(options.delay_ms,tick)
        assert(math.type(handle)=="integer" and handle>0,"original registration handle invalid="..tostring(handle))
        s.handle=handle
        assert(IsValidDelayedActionHandle(handle)==true,"original handle readback failed handle="..handle)
        s.registration_confirmed=true; s.phase="registered"
        emit("info","registration confirmed handle="..handle.."; callback entry pending")
    end,debug.traceback)
    if not ok then
        fail("registration",cause)
        if s.handle~=0 then cancel() end
    end
    return api
end

M.jobs={}
local function caller()
    local info=debug.getinfo(3,"Sl")
    return info and (info.short_src..":"..info.currentline) or "original observer"
end
function M.loop(delay_ms,callback)
    local name=caller()
    local watch=M.start({name=name,delay_ms=delay_ms,observe=callback,
        log=function(level,message) print("[CabinGameThreadScheduler] "..level..": "..message.."\n") end})
    M.jobs[#M.jobs+1]=watch
    local status=watch.status()
    assert(status.registration_confirmed and status.phase~="failed",status.cause or "original loop registration unconfirmed")
    return status.handle
end
function M.execute(callback)
    assert(type(callback)=="function","original GameThread callback required")
    assert(IsInGameThread()==true,"direct observer entry outside original GameThread")
    callback()
end
function M.after(delay_ms,callback)
    assert(type(callback)=="function","original delayed callback required")
    return M.loop(delay_ms,function() M.execute(callback); return true end)
end
function M.bootstrap(callback)
    return M.after(0,callback)
end
return M
