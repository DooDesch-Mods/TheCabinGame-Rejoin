local gt_scheduler = require("gt_scheduler")
local M = {}
local active
local GI = "/Game/CabinGameContent/CabinAdvanceFriendsGameInstance.CabinAdvanceFriendsGameInstance_C"
local PC = "/Game/CabinGameContent/PlayerContent/Cabin_PC.Cabin_PC_C"
local MENU = "World /Game/CabinGameContent/Menu.Menu"
local PREFIX = GI .. ":"
local SUCCESS = PREFIX .. "OnSuccess_907351674B09FAB4E70055ACB2EBF62A"
local FAILURE = PREFIX .. "OnFailure_907351674B09FAB4E70055ACB2EBF62A"

local function valid(value) return value ~= nil and value:IsValid() end
local function address(value) return valid(value) and value:GetAddress() or 0 end
local function text(value) return type(value) == "string" and value or value:ToString() end
local function class(value, path) return valid(value) and value:GetClass():GetFullName() == "BlueprintGeneratedClass " .. path end
local function terminal(s) return s.phase == "admitted" or s.phase == "failed" or s.phase == "skipped" or s.phase == "stopped" end
local function clean(value) return tostring(value):gsub("[\r\n]", " | ") end
local function integer(value, name)
    assert(math.type(value) == "integer" and value >= 0, name .. " requires an exact nonnegative integer")
    return value
end
local function lobby_integer(value)
    assert(type(value) == "string" and value:match("^[1-9][0-9]*$"), "startup lobby must be decimal")
    local number = tonumber(value, 10)
    assert(math.type(number) == "integer" and number > 0 and tostring(number) == value, "startup lobby lost precision")
    return number
end
local function emit(s, level, message)
    local ok, cause = pcall(s.log, level, "join " .. message)
    if not ok then
        print("[CabinRejoin] error: join logger cause=" .. tostring(cause) .. "; original=" .. message .. "\n")
        error("join logger failed: " .. tostring(cause), 0)
    end
end
local function status(s)
    if not s.options.status_path then return end
    local rows = {"schema=CabinRejoinJoin_v1", "phase=" .. s.phase, "observations=" .. s.repeats,
        "dispatch_ack=" .. (s.dispatch_ack and "1" or "0"), "original_success=" .. (s.original_success and "1" or "0"),
        "lobby_admission_confirmed=" .. (s.phase == "admitted" and "1" or "0"), "retained_ownership_confirmed=0"}
    for _, key in ipairs({"lobby_text", "expected_endpoint", "endpoint", "reason", "cause", "pc_address", "pawn_address", "driver_address"}) do
        if s[key] ~= nil then rows[#rows + 1] = key .. "=" .. clean(s[key]) end
    end
    rows[#rows + 1] = "complete_record=1"
    local bytes = table.concat(rows, "\n") .. "\n"
    local file, cause = io.open(s.options.status_path, "wb"); assert(file, "join status open cause=" .. tostring(cause))
    local wrote, write_cause = file:write(bytes); local closed, close_cause = file:close()
    assert(wrote and closed, "join status write/close cause=" .. tostring(write_cause) .. "/" .. tostring(close_cause))
    local check, read_cause = io.open(s.options.status_path, "rb"); assert(check, "join status readback open cause=" .. tostring(read_cause))
    local actual, actual_cause = check:read("*a"); local checked, checked_cause = check:close()
    assert(actual and checked and actual == bytes, "join status readback differs cause=" .. tostring(actual_cause) .. "/" .. tostring(checked_cause))
end
local function transition(s, phase, message)
    if s.reason then emit(s, "info", "recovered=" .. s.reason) end
    s.phase, s.reason, s.repeats = phase, nil, 0
    emit(s, "info", "phase=" .. phase .. " " .. message)
    status(s)
end
local function waiting(s, reason)
    local now = os.time()
    s.repeats = s.reason == reason and s.repeats + 1 or 1
    if s.reason ~= reason or now - (s.last_wait_log or 0) >= 60 then
        s.reason, s.last_wait_log = reason, now
        emit(s, "info", "phase=" .. s.phase .. " waiting=" .. reason .. " observations=" .. s.repeats)
        status(s)
    end
end
local function fail(s, operation, cause)
    if s.phase == "failed" then return end
    s.phase, s.cause = "failed", operation .. ": " .. tostring(cause)
    local logged, log_cause = pcall(emit, s, "error", s.cause .. "; no Join replay")
    if not logged then print("[CabinRejoin] error: join failure logger cause=" .. tostring(log_cause) .. "; original=" .. s.cause .. "\n") end
    local saved, save_cause = pcall(status, s)
    if not saved then print("[CabinRejoin] error: join failure status cause=" .. tostring(save_cause) .. "; original=" .. s.cause .. "\n") end
end
local function protected(s, operation, callback)
    local ok, cause = xpcall(callback, debug.traceback)
    if not ok then fail(s, operation, cause) end
    return ok
end

local function startup_lobby(command)
    local tokens = {}
    for token in command:gmatch("%S+") do tokens[#tokens + 1] = token:gsub('^"(.*)"$', "%1") end
    local lobby, authority
    for index, token in ipairs(tokens) do
        if token:lower() == "-cabinrejoinauthority" then authority = true end
        if token == "+connect_lobby" then
            assert(not lobby, "multiple original +connect_lobby arguments")
            lobby = assert(tokens[index + 1], "original +connect_lobby value missing")
            lobby_integer(lobby)
        end
    end
    assert(not (authority and lobby), "authority and graphical lobby startup arguments conflict")
    return lobby
end

local function instance()
    local found
    for _, candidate in ipairs(FindAllOf("CabinAdvanceFriendsGameInstance_C") or {}) do
        if valid(candidate) and valid(candidate:GetWorld()) and not candidate:GetFullName():find("Default__", 1, true) then
            assert(class(candidate, GI), "original game instance class differs")
            assert(not found, "multiple current original game instances")
            found = candidate
        end
    end
    return found
end
local function hook(s, path, callback)
    if s.hooks[path] then return true end
    local fn = StaticFindObject(path)
    if not valid(fn) then waiting(s, "original callback not loaded=" .. path); return false end
    local pre, post = RegisterHook(path, function(context, ...)
        if terminal(s) then return end
        local args = table.pack(...)
        protected(s, "original observer=" .. path, function()
            local owner = context:get()
            if not valid(s.gi) or address(owner) ~= s.gi:GetAddress() then return end
            callback(table.unpack(args, 1, args.n))
        end)
    end)
    assert(type(pre) == "number" and type(post) == "number", "original hook IDs unavailable=" .. path)
    s.hooks[path] = {pre, post}
    emit(s, "info", "original callback observer registered=" .. path)
    return true
end
local function arm(s)
    local complete = true
    local function add(path, callback) if not hook(s, path, callback) then complete = false end end
    add(PREFIX .. "JoinSession", function()
        s.original_join_observed = true
        if not s.dispatch_attempted then s.external_join_observed = true end
        emit(s, "info", "original GI.JoinSession entry acknowledged source=" .. (s.dispatch_attempted and "cached adapter" or "original game"))
    end)
    add(SUCCESS, function()
        s.original_success = true
        transition(s, "callback_success", "original Join OnSuccess acknowledged; actual admission pending")
    end)
    add(FAILURE, function() s.original_failure=true; error("original Join OnFailure; inspect original OSS/native cause") end)
    for _, path in ipairs({PREFIX .. "HandleNetworkError", PREFIX .. "HandleTravelError"}) do
        add(path, function(kind)
            local cause = kind and tostring(kind:get()) or "original error parameter unavailable"
            error("original " .. path:match("([^:]+)$") .. " cause=" .. cause)
        end)
    end
    return complete
end
local function session(s)
    local state, id = {}, {}
    s.sessions:GetSessionState(s.gi, state)
    assert(state.SessionState ~= nil, "original SessionState OUT missing")
    s.sessions:GetCurrentSessionID_AsString(s.gi, id)
    assert(id.SessionId ~= nil, "original SessionId OUT missing")
    return integer(state.SessionState, "original SessionState"), text(id.SessionId)
end
local function prepared(s, pc)
    local fn = StaticFindObject(PREFIX .. "JoinSession")
    assert(valid(fn), "original JoinSession UFunction unavailable")
    local result, controller, count
    count = 0
    fn:ForEachProperty(function(property)
        count = count + 1
        local name = property:GetFName():ToString()
        if name == "SearchResult" then
            assert(not result and property:GetClass():GetFName():ToString() == "StructProperty" and property:GetOffset_Internal() == 8, "original SearchResult property differs")
            result = property
        elseif name == "PlayerController" then
            assert(not controller and property:GetClass():GetFName():ToString() == "ObjectProperty" and property:GetOffset_Internal() == 0, "original PlayerController property differs")
            controller = property
        else error("unexpected original JoinSession parameter=" .. name) end
    end)
    assert(count == 2 and result and controller, "original JoinSession parameter set differs")
    local structure = result:GetStruct()
    assert(valid(structure) and structure:GetFullName() == "ScriptStruct /Script/OnlineSubsystemUtils.BlueprintSessionResult", "original BlueprintSessionResult differs")
    return fn, result, structure, integer(s.gi.BuildVersionID, "original GI BuildVersionID")
end
local function cache(s, build)
    if os.time() < (s.next_cache_at or 0) then return false end
    s.next_cache_at = os.time() + 2
    local ack, _, address_text, port, _, _, endpoint, cause = CabinSteamLobbySnapshot(s.lobby)
    if ack == 0 and cause == "cached endpoint absent/invalid; no metadata request attempted" then waiting(s, cause); return false end
    assert(ack == 1, "native lobby snapshot failed cause=" .. tostring(cause))
    assert(type(endpoint) == "string" and endpoint == "steam." .. address_text .. ":" .. port, "native cached endpoint readback differs")
    if endpoint ~= s.expected_endpoint then
        waiting(s, "cached endpoint differs actual=" .. endpoint .. " expected=" .. s.expected_endpoint .. "; authority publication/readback pending")
        return false
    end
    local metadata_ack, body = CabinSteamLobbyRequiredMetadata(s.lobby)
    assert(metadata_ack == 1 and type(body) == "string", "native required metadata failed cause=" .. tostring(body))
    local rows = {}
    for line in body:gmatch("[^\n]+") do
        local key, value = line:match("^([%w_]+)=(.*)$")
        assert(key and rows[key] == nil, "native required metadata row invalid/duplicate")
        rows[key] = value
    end
    for _, key in ipairs({"NUMPUBCONN", "NUMPRIVCONN", "SESSIONFLAGS", "BUILDID", "OWNINGID", "OWNINGNAME", "NUMOPENPRIVCONN", "NUMOPENPUBCONN", "CONMETHOD", "P2PADDR", "P2PPORT", "BuildVersionID_i"}) do
        if rows[key] == nil or rows[key] == "" then waiting(s, "original cached metadata missing=" .. key); return false end
    end
    if rows.original_build_cache_flag == "0" then waiting(s, "original native BuildID cache not initialized"); return false end
    assert(rows.original_build_cache_flag == "1" and rows.BUILDID == rows.original_build_cache_value, "original native BUILDID differs; original version guard retained")
    assert(rows.BuildVersionID_i == tostring(build), "original BP BuildVersionID differs cached=" .. rows.BuildVersionID_i .. " actual=" .. build)
    assert(rows.P2PADDR == address_text and rows.P2PPORT == port, "native cached endpoint changed between getters")
    s.endpoint = endpoint
    emit(s, "info", "original cached metadata confirmed lobby=" .. s.lobby_text .. " endpoint=" .. endpoint .. "; original parser remains required")
    return true
end
local function admission(s, pc, id)
    if id == "" then waiting(s, "actual named session ID pending"); return false end
    assert(id == s.lobby_text, "existing named session differs actual=" .. id .. " requested=" .. s.lobby_text .. "; no duplicate Join")
    if not valid(pc) or not pc:IsLocalController() or pc:GetLocalRole() ~= 2 then waiting(s, "actual remote local controller role2 pending"); return false end
    local pawn = pc.Pawn
    if not valid(pawn) or not valid(pc.PlayerState) or pawn:IsActorBeingDestroyed() or not pawn:IsLocallyControlled()
        or address(pawn.Controller) ~= pc:GetAddress() or address(pc.AcknowledgedPawn) ~= pawn:GetAddress() then
        waiting(s, "actual remote pawn/PlayerState/ownership acknowledgement pending"); return false
    end
    local driver, count
    count = 0
    for _, candidate in ipairs(FindAllOf("SteamSocketsNetDriver") or {}) do
        if valid(candidate) and valid(candidate:GetWorld()) and candidate:GetWorld():GetAddress() == pc:GetWorld():GetAddress()
            and not candidate:GetFullName():find("Default__", 1, true) then driver, count = candidate, count + 1 end
    end
    assert(count <= 1, "multiple actual SteamSockets drivers for current client world")
    if not driver or not valid(driver.ServerConnection) then waiting(s, "actual SteamSockets client ServerConnection pending"); return false end
    s.pc_address, s.pawn_address, s.driver_address = pc:GetAddress(), pawn:GetAddress(), driver:GetAddress()
    transition(s, "admitted", "actual named lobby/SteamConnection/local remote pawn acknowledged; retained ownership remains separate")
    return true
end
local function startup_idle(s)
    local observed, pending, search, task, user_pump, _, cause = CabinSteamJoinStartupState()
    if observed == 0 then waiting(s, "native original startup observation pending cause=" .. tostring(cause)); return false end
    assert(observed == 1, "native original startup observation failed cause=" .. tostring(cause))
    integer(pending, "actual PendingType"); integer(search, "actual CurrentSessionSearch"); integer(task, "actual current original task")
    if pending ~= 0 or search ~= 0 or task ~= 0 or user_pump ~= 1 then
        waiting(s, "original startup active pending=" .. pending .. " search=" .. search .. " task=" .. task .. " userPump=" .. tostring(user_pump)); return false
    end
    return true
end
local function advance(s)
    if terminal(s) then return end
    s.gi = instance()
    if not s.gi then waiting(s, "current original game instance"); return end
    if not arm(s) then return end
    local pc = s.gameplay:GetPlayerController(s.gi, 0)
    local state, id = session(s)
    if state ~= 0 then admission(s, pc, id); return end
    if s.dispatch_attempted or s.external_join_observed or s.original_success then waiting(s, "original Join/actual named session admission pending; no dispatch replay"); return end
    if not valid(pc) or pc:IsActorBeingDestroyed() or not pc:IsLocalController() then waiting(s, "current live original local controller"); return end
    assert(class(pc, PC) and pc:GetWorld():GetAddress() == s.gi:GetWorld():GetAddress(), "actual original local PC class/world differs")
    if s.gi:GetWorld():GetFullName() ~= MENU then waiting(s, "original Menu world required before startup Join"); return end
    assert(id == "", "original SessionState0 has a nonempty named session ID; no Join")
    if not startup_idle(s) then return end
    local fn, result, structure, build = prepared(s, pc)
    if not cache(s, build) then return end
    local current_state, current_id = session(s)
    if current_state ~= 0 then admission(s, pc, current_id); return end
    assert(current_id == "" and address(s.gameplay:GetPlayerController(s.gi, 0)) == pc:GetAddress()
        and not pc:IsActorBeingDestroyed() and s.gi:GetWorld():GetFullName() == MENU, "current session/controller/world changed before dispatch")
    if not startup_idle(s) then return end
    s.dispatch_attempted, s.pc_address = true, pc:GetAddress()
    transition(s, "dispatching", "cached original GI.JoinSession attempted once; native dispatch acknowledgement pending")
    local returned = CabinJoinCachedSteamLobby(s.gi:GetAddress(), pc:GetAddress(), fn:GetAddress(), result:GetAddress(), structure:GetAddress(), s.lobby, build)
    assert(returned == 1, "native original Join dispatch not acknowledged returned=" .. tostring(returned) .. "; inspect native original cause")
    s.dispatch_ack = true
    if not terminal(s) then transition(s, s.original_success and "callback_success" or "dispatched", "native original Join dispatch acknowledged; original success and actual admission observed separately")
    else status(s) end
end

function M.start(options)
    if active and active.phase == "skipped" and options and options.lobby_id then active = nil end
    if active then return active.phase ~= "failed", active.cause end
    local s = {options = options or {}, phase = "waiting", hooks = {}, repeats = 0}
    s.log = s.options.log or function(level, message) print("[CabinRejoin] " .. level .. ": " .. message .. "\n") end
    active = s
    local ok = protected(s, "startup", function()
        assert(type(s.log) == "function", "join log must be callable")
        assert(s.options.status_path == nil or (type(s.options.status_path) == "string" and s.options.status_path ~= "" and not s.options.status_path:find("[\r\n]")), "join status path invalid")
        local system = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
        assert(valid(system), "original GetCommandLine library unavailable")
        s.lobby_text = s.options.lobby_id or startup_lobby(text(system:GetCommandLine()))
        if not s.lobby_text then transition(s, "skipped", "original +connect_lobby absent; no Join adapter action"); return end
        s.lobby = lobby_integer(s.lobby_text)
        if s.options.expected_endpoint == nil then transition(s, "skipped", "starter endpoint receipt absent; cached fallback not requested"); return end
        assert(type(s.options.expected_endpoint) == "string", "starter endpoint receipt must be a string")
        local expected_id, expected_port = s.options.expected_endpoint:match("^steam%.([1-9][0-9]*):([1-9][0-9]*)$")
        assert(expected_id and expected_port, "starter endpoint receipt syntax differs")
        local port = tonumber(expected_port, 10)
        assert(math.type(port) == "integer" and port <= 65535 and tostring(port) == expected_port, "starter endpoint receipt port differs")
        s.expected_endpoint = s.options.expected_endpoint
        for _, name in ipairs({"FindAllOf", "RegisterHook", "LoopInGameThreadWithDelay", "IsInGameThread", "CabinSteamJoinStartupState", "CabinSteamLobbySnapshot", "CabinSteamLobbyRequiredMetadata", "CabinJoinCachedSteamLobby"}) do
            assert(type(_G[name]) == "function", "join dependency missing=" .. name)
        end
        s.gameplay = StaticFindObject("/Script/Engine.Default__GameplayStatics")
        s.sessions = StaticFindObject("/Script/AdvancedSessions.Default__AdvancedSessionsLibrary")
        assert(valid(s.gameplay) and valid(s.sessions), "original gameplay/session libraries unavailable")
        s.gi = instance()
        if s.gi then arm(s) end
        status(s)
        gt_scheduler.loop(500, function()
            if terminal(s) then return true end
            if s.queued then
                if os.time() - s.queued_at >= 5 then waiting(s, "GameThread callback entry pending; no queue replay") end
                return false
            end
            s.queued, s.queued_at = true, os.time()
            local queued, cause = pcall(gt_scheduler.execute, function()
                if not terminal(s) then protected(s, "advance phase=" .. s.phase, function() advance(s) end) end
                s.queued = false
            end)
            if not queued then s.queued = false; fail(s, "GameThread queue", cause) end
            return terminal(s)
        end)
        emit(s, "info", "startup observer registered lobby=" .. s.lobby_text .. "; original cache/idle and actual dispatch remain pending")
    end)
    return ok and s.phase ~= "failed", s.cause
end
function M.status() return active end
function M.retry_measure()
    local measured={}
    local ok,cause=xpcall(function()
        local gi=assert(instance(),"manual retry requires current original GI")
        local world=gi:GetWorld()
        measured.world=world:GetFullName()
        assert(measured.world==MENU,"manual retry world measured="..measured.world.." required="..MENU)
        local gameplay=StaticFindObject("/Script/Engine.Default__GameplayStatics")
        local sessions=StaticFindObject("/Script/AdvancedSessions.Default__AdvancedSessionsLibrary")
        assert(valid(gameplay) and valid(sessions),"manual retry original libraries unavailable")
        local pc=gameplay:GetPlayerController(gi,0)
        assert(class(pc,PC) and not pc:IsActorBeingDestroyed() and pc:IsLocalController() and pc:GetWorld():GetAddress()==world:GetAddress(),"manual retry live original same-world local PC unavailable")
        measured.session_state,measured.session_id=session({gi=gi,sessions=sessions})
        local observed,pending,search,task,user_pump,_,native_cause=CabinSteamJoinStartupState()
        measured.observed,measured.pending,measured.search,measured.task,measured.user_pump=observed,pending,search,task,user_pump
        measured.native_cause=native_cause
        assert(observed==1,"manual retry native observation measured="..tostring(observed).." required1 cause="..tostring(native_cause))
        for _,key in ipairs({"session_state","pending","search","task","user_pump"}) do integer(measured[key],"manual retry "..key) end
        local values="session_state="..measured.session_state.." session_id="..measured.session_id.." pending="..pending.." search="..search.." task="..task.." userPump="..user_pump
        measured.values=values
        assert(measured.session_state==0 and measured.session_id=="" and pending==0 and search==0 and task==0 and user_pump==1,"manual retry blocked "..values.." required=NoSession0/emptyID/Idle0,0,0/userPump1; no session mutation")
        local after_state,after_id=session({gi=gi,sessions=sessions})
        assert(after_state==0 and after_id=="" and address(gameplay:GetPlayerController(gi,0))==pc:GetAddress() and gi:GetWorld():GetAddress()==world:GetAddress(),"manual retry original session/controller/world changed during readback")
    end,debug.traceback)
    return ok,ok and measured.values or tostring(cause),measured
end
function M.retry_after_create(source)
    source=source or "Create"
    local ready,cause,measured=M.retry_measure()
    if active then active.retry_snapshot=measured end
    if not ready then return false,cause end
    if active then
        if active.phase~="failed" and active.phase~="skipped" and active.phase~="admitted" then return false,"manual retry observer phase="..active.phase.." required=failed/skipped/admitted; no Join reset" end
        if active.queued then return false,"manual retry prior game-thread callback still queued; no observer reset" end
        if active.phase~="admitted" and active.dispatch_attempted and not active.original_failure then return false,"manual retry prior Join dispatched without original OnFailure acknowledgement; cause="..tostring(active.cause).."; original cleanup unproved" end
        for path,ids in pairs(active.hooks) do
            local removed,remove_cause=pcall(UnregisterHook,path,ids[1],ids[2])
            if not removed then return false,"manual retry observer unregister target="..path.." cause="..tostring(remove_cause).."; failed observer remains dormant" end
            active.hooks[path]=nil
        end
        emit(active,"info","manual "..source.." retry guard passed "..cause.." original_failure="..tostring(active.original_failure==true).."; previous cause="..tostring(active.cause).."; observer reset only")
        active=nil
    end
    return true,cause
end
function M.stop()
    if active and not terminal(active) then transition(active, "stopped", "observer stopped; original Join/session effects remain") end
    return true
end
return M
