local M = {}

local function finite(value, label)
    assert(type(value) == 'number' and value == value and math.abs(value) < math.huge,
        label .. ' must be finite')
    return value
end

local function vector(value, label)
    assert(type(value) == 'table', label .. ' must be an explicit vector')
    return {X = finite(value.X, label .. '.X'), Y = finite(value.Y, label .. '.Y'), Z = finite(value.Z, label .. '.Z')}
end

local function rotation(value, label)
    assert(type(value) == 'table', label .. ' must be an explicit rotation')
    return {Pitch = finite(value.Pitch, label .. '.Pitch'), Yaw = finite(value.Yaw, label .. '.Yaw'),
        Roll = finite(value.Roll, label .. '.Roll')}
end

-- This recipe uses the original Eject_TL target and actor pose used by the hand cancel path.
function M.hand(marker, current, camera)
    assert(type(marker) == 'table' and marker.phase == 'inspect_entry', 'original inspect entry receipt required')
    assert(marker.status == 1, 'this recipe requires original Holding status')
    assert(type(current) == 'table' and current.card == marker.card and current.owner == marker.pawn,
        'current authoritative exact card and owner required')
    assert(current.status == 1 and current.hand_matches == 1 and current.turn_matches == true,
        'current Holding, hand membership and turn required')
    assert(current.epoch == marker.epoch and current.identity == marker.identity,
        'current authenticated round binding required')
    assert(current.card_type == marker.card_type, 'card type changed')
    assert(type(current.room_card_disable) == 'boolean', 'current original RoomCardDisable required')
    assert(current.room_card_disable_proven == true, 'original RoomCardDisable branch needs independent current evidence')
    local origin = vector(current.actor_location, 'current card actor location')
    local origin_rot = rotation(current.actor_rotation, 'current card actor rotation')
    local position = vector(camera.location, 'restored current owner camera location')
    local aim = rotation(camera.base_aim, 'restored current owner base aim')
    local cam_rot = rotation(camera.rotation, 'restored current owner camera rotation')
    local distance = finite(current.inspect_distance, 'original CardInspectDistance')
    assert(distance > 0, 'original inspect distance must be positive')
    local pitch, yaw = math.rad(aim.Pitch), math.rad(aim.Yaw)
    local horizontal = math.cos(pitch)
    local target = {X = position.X + horizontal * math.cos(yaw) * distance,
        Y = position.Y + horizontal * math.sin(yaw) * distance,
        Z = position.Z + math.sin(pitch) * distance}
    return {phase = 'card_inspect', card = marker.card, pawn = marker.pawn,
        card_scene_location = target,
        card_scene_rotation = {Pitch = cam_rot.Pitch + 90, Yaw = cam_rot.Yaw, Roll = cam_rot.Roll},
        origin_hand_location = origin, origin_hand_rotation = origin_rot,
        local_player_nonrep = marker.pawn, local_in_inspect = true,
        input_actor = marker.card, input_mode = {game_only = true, ui_only = false, show_mouse_cursor = false},
        hints = current.room_card_disable and {'inspect_cancel'} or {'eject_accept', 'inspect_cancel'},
        server_writes = false, gameplay_replay = false, restore_ready = false,
        cause = 'recipe only; CardScene, cancel origin, HUD, original cancel/accept and unchanged gameplay need runtime receipt'}
end

return M
