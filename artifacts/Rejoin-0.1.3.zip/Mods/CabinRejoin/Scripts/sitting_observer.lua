local M={}
local SITTING="/Game/CabinGameContent/Cabin_GameMode.Cabin_GameMode_C:CheckAllSitting"
local COUNT="/Script/AdvancedSessions.AdvancedSessionsLibrary:GetNumberOfNetworkPlayers"
local function valid(o) return o~=nil and o:IsValid() end
local function address(o) return valid(o) and o:GetAddress() or 0 end
local function integer(value,name)
    assert(math.type(value)=="integer" and value>=0,"actual nonnegative integer unavailable="..name)
    return value
end
local function bool(value,name)
    assert(type(value)=="boolean","actual bool unavailable="..name)
    return value
end

function M.start(options,decision)
    assert(type(options)=="table" and type(options.log)=="function" and type(options.resolve_current)=="function","log and exact current authority resolver required")
    assert(type(options.is_game_thread)=="function" and options.is_game_thread()==true,"register observer on original GameThread")
    assert(type(options.register_hook)=="function" and type(decision)=="table" and type(decision.decide)=="function","original hook and pure decision adapter required")
    assert(options.mode=="observe" or options.mode=="guard","explicit observe or guard mode required")
    assert(math.type(options.context_address)=="integer" and options.context_address>0,"exact original Round GameMode address required")
    local state={phase="registering",mode=options.mode,count_hits=0,sitting_hits=0,attempted=0,confirmed=0,errors=0,
                 native_serial=0,consumed_serial=0,repeat_count=0}
    local witness=nil
    local function emit(level,key,message)
        if state.last_key~=key then
            state.last_key,state.repeat_count=key,1
            options.log(level,"original sitting "..message)
        else
            state.repeat_count=state.repeat_count+1
            if state.repeat_count%120==0 then options.log(level,"original sitting "..message.." repeats="..state.repeat_count) end
        end
    end
    local function failure(operation,cause)
        state.errors=state.errors+1;state.last_error=operation..": "..tostring(cause)
        emit("error",state.last_error,state.last_error.." sittingHits="..state.sitting_hits.." countHits="..state.count_hits.."; original output retained unless an attempted OUT write is reported")
    end
    local function current(context)
        assert(options.is_game_thread()==true,"original callback outside GameThread")
        local object=context:get()
        if not valid(object) then return nil,"original context ended" end
        if object:GetAddress()~=options.context_address then return nil,"unrelated original context" end
        local binding=options.resolve_current(object)
        assert(type(binding)=="table" and type(binding.status)=="string","authority resolver status unavailable")
        if binding.status~="ready" then return nil,binding.status..": "..tostring(binding.cause) end
        assert(address(binding.game_mode)==object:GetAddress(),"resolver GameMode differs from callback context")
        return binding
    end
    local function count_post(_,world_context,number_out)
        if state.phase~="registered" then return end
        local ok,cause=xpcall(function()
            local binding,reason=current(world_context)
            if not binding then
                if reason~="unrelated original context" then emit("info","count-skip:"..reason,"native count skipped "..reason) end
                return
            end
            local count=integer(number_out:get(),"native NumNetPlayers OUT")
            state.count_hits=state.count_hits+1;state.native_serial=state.native_serial+1
            witness={serial=state.native_serial,gm=binding.gm_address,world=binding.world_address,number=count}
        end,debug.traceback)
        if not ok then witness=nil;failure("native count POST",cause) end
    end
    local function sitting_post(context,all_sitting_out)
        if state.phase~="registered" then return end
        local ok,cause=xpcall(function()
            local binding,reason=current(context)
            if not binding then
                if reason~="unrelated original context" then emit("info","sitting-skip:"..reason,"Blueprint POST skipped "..reason) end
                return
            end
            state.sitting_hits=state.sitting_hits+1
            local gm=binding.game_mode
            local original=bool(all_sitting_out:get(),"original AllSitting OUT")
            local started,ended=bool(gm.GameStarted,"GameStarted"),bool(gm.GameEnd,"GameEnd")
            local chairs,sitting=0,0
            local total=integer(gm.Chairs:GetArrayNum(),"Chairs count")
            gm.Chairs:ForEach(function(index,param)
                assert(index==chairs+1,"original Chair array enumeration order differs")
                local chair=param:get()
                assert(valid(chair) and not chair:IsActorBeingDestroyed() and address(chair:GetWorld())==binding.world_address,"original Chair ended or World differs")
                chairs=chairs+1
                if bool(chair.PlayerSitting,"Chair.PlayerSitting") then sitting=sitting+1 end
            end)
            assert(chairs==total,"original Chair array count differs")
            assert(valid(binding.game_state) and address(binding.game_state:GetWorld())==binding.world_address,"current original GameState unavailable")
            local row={original=original,identity_current=true,game_started=started,game_ended=ended,sitting=sitting,chairs=chairs,
                       connections=integer(binding.driver.ClientConnections:GetArrayNum(),"Driver.ClientConnections count"),
                       player_states=integer(binding.game_state.PlayerArray:GetArrayNum(),"GameState.PlayerArray count"),
                       local_players=integer(binding.game_instance.LocalPlayers:GetArrayNum(),"GI.LocalPlayers count"),
                       gm=binding.gm_address,world=binding.world_address}
            local fresh=witness~=nil and witness.serial>state.consumed_serial and witness.gm==row.gm and witness.world==row.world
            row.count_witness_fresh=fresh
            if fresh then row.network_players=witness.number;row.native_serial=witness.serial;state.consumed_serial=witness.serial end
            state.last_observation=row
            assert(fresh,"fresh original NumNetPlayers OUT not observed before Blueprint POST")
            local block,why=decision.decide(row)
            state.last_decision={block=block,reason=why}
            local measured="AllSitting="..tostring(original).." sitting="..sitting.." network="..row.network_players.." connections="..row.connections.." PlayerStates="..row.player_states.." LocalPlayers="..row.local_players.." GameStarted="..tostring(started).." GameEnded="..tostring(ended).." gm="..row.gm.." world="..row.world.." calls="..state.sitting_hits
            emit("info",table.concat({tostring(original),sitting,row.network_players,row.connections,row.player_states,row.local_players,tostring(started),tostring(ended),why},":"),measured.." decision="..why)
            if block and options.mode=="guard" then
                state.attempted=state.attempted+1
                state.write_pending=true
                if state.attempted==1 or state.attempted%120==0 then options.log("info","original sitting OUT false attempted count="..state.attempted.." "..measured) end
                all_sitting_out:set(false)
                assert(all_sitting_out:get()==false,"original AllSitting OUT write readback differs")
                state.confirmed=state.confirmed+1
                state.write_pending=false
                if state.confirmed==1 or state.confirmed%120==0 then options.log("info","original sitting OUT false readback confirmed count="..state.confirmed.."; original caller branch pending") end
            end
        end,debug.traceback)
        if not ok then
            if state.write_pending then state.phase="failed" end
            failure("Blueprint sitting POST",cause)
        end
    end
    local api={}
    function api.status()
        local copy={}
        for key,value in pairs(state) do
            if type(value)=="table" then local row={};for k,v in pairs(value) do row[k]=v end;copy[key]=row else copy[key]=value end
        end
        return copy
    end
    function api.stop()
        state.phase="stopped";witness=nil
        options.log("info","original sitting observer stopped; callbacks dormant")
        return api.status()
    end
    local ok,cause=xpcall(function()
        local count_pre,count_post_id=options.register_hook(COUNT,function() end,count_post)
        assert(math.type(count_pre)=="integer" and count_pre>0 and math.type(count_post_id)=="integer" and count_post_id>0 and count_pre~=count_post_id,"original count hook must be native PRE/POST")
        state.count_pre,state.count_post=count_pre,count_post_id
        local sitting_id,sitting_post_id=options.register_hook(SITTING,sitting_post)
        assert(math.type(sitting_id)=="integer" and sitting_id>0 and sitting_id==sitting_post_id,"original CheckAllSitting must be script POST with shared IDs")
        state.sitting_pre,state.sitting_post=sitting_id,sitting_post_id
        state.phase="registered"
        options.log("info","original sitting registered mode="..state.mode.." nativeIDs="..count_pre..","..count_post_id.." scriptIDs="..sitting_id..","..sitting_post_id.."; actual callback and branch pending")
    end,debug.traceback)
    if not ok then state.phase="failed";failure("registration",cause) end
    return api
end

return M
