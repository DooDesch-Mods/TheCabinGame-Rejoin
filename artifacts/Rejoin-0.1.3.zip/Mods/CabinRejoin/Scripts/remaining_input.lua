local M={}
local ledger=require('input_ledger')
local codec=require('input_codec')
local restore=require('input_restore')
local function copy(v) if type(v)~='table' then return v end;local r={};for k,x in pairs(v) do r[k]=copy(x) end;return r end
function M.attach(receipt,current_ledger,current_phase)
    assert(type(receipt)=='table' and type(current_ledger)=='table' and type(current_phase)=='function','existing on_rejoined integration adapters required')
    local row,cause=current_ledger.inspect(receipt.pawn:GetAddress())
    if not row then return nil,cause end
    local phase,phase_cause=current_phase(receipt)
    if not phase then return nil,phase_cause end
    assert(phase.authority==true and phase.authenticated==true and phase.same_world==true
        and phase.pawn_address==row.pawn_address and phase.steam_id==row.steam_id
        and phase.epoch==row.epoch and phase.world_key==row.world_key,'current original phase/native reservation binding differs')
    assert(phase.kind=='timed_action' or phase.kind=='world_event' or phase.kind=='radio','current original resumable action phase required')
    assert(type(phase.key)=='string' and phase.key:match('^[%w_]+$') and type(phase.class)=='string' and phase.class:match('_C$')
        and math.type(phase.revision)=='integer' and phase.revision>0,'actual original phase actor key/class/revision required')
    local result=copy(row)
    result.phase,result.phase_key,result.phase_class,result.phase_revision=phase.kind,phase.key,phase.class,phase.revision
    result.input_fingerprint=ledger.fingerprint(result)
    receipt.original_input=result
    return result
end
function M.capture(result,receipt)
    assert(type(result)=='table' and type(receipt)=='table','existing presentation capture required')
    local row=receipt.original_input
    if not row then return result end
    assert(ledger.fingerprint(row)==row.input_fingerprint,'current original input capture was mutated')
    assert(result.mode~='room_map' and result.mode~='holding_inspect' and result.mode~='card_inspect'
        and result.mode~='car_intro','current original action marker conflicts with present interactive view')
    result.mode=row.phase=='radio' and 'radio_resume' or 'action_resume'
    result.original_input=copy(row)
    return result
end
function M.visit(snapshot,reading,fields) return codec.visit(snapshot,reading,fields) end
function M.ready(context) return restore.ready(context) end
function M.restore(context) return restore.restore(context) end
function M.finish(context,receipt) return restore.finish(context,receipt) end
return M
