local M = {}
local PAWN = "/Game/CabinGameContent/PlayerContent/Cabin_Player.Cabin_Player_C:"
local BOARD = "/Game/CabinGameContent/BoardGameStuff/Board/GameBoard_BP.GameBoard_BP_C:"

local function valid(object)
    return object ~= nil and object:IsValid()
end

local function address(object)
    return valid(object) and object:GetAddress() or 0
end

function M.new(options)
    assert(type(options) == "table", "phase ledger options required")
    for _, name in ipairs({"log", "resolve_reserved", "current_round", "now"}) do
        assert(type(options[name]) == "function", "phase ledger adapter missing=" .. name)
    end
    assert(options.resolve_board == nil or type(options.resolve_board) == "function", "resolve_board must be a function")
    local s = {active = false, attempted = false, markers = {}, card_locks = {}, ended = {}, tracked = {}, reasons = {}, hooks = {}, failures = {}, blocked = {}}
    local api = {}

    local function now()
        local value = options.now()
        assert(type(value) == "number" and value == value and value >= 0 and value < math.huge,
            "phase clock must return finite nonnegative seconds")
        return value
    end

    local function log(level, message)
        local ok, cause = pcall(options.log, level, "phase ledger " .. message)
        if not ok then
            print("[CabinRejoin] error: phase ledger log cause=" .. tostring(cause) .. "\n")
            print("[CabinRejoin] " .. level .. ": " .. message .. "\n")
        end
    end

    local function clear(cause)
        local count = 0
        for _ in pairs(s.markers) do count = count + 1 end
        s.markers = {}
        if count > 0 then log("info", "markers cleared count=" .. count .. " cause=" .. cause) end
    end

    local function round()
        local gm, epoch = options.current_round()
        if not valid(gm) then
            clear("authority round unavailable")
            if s.round and s.round.status == "active" then
                s.round.failure = "authority round unavailable during active observation"
            end
            return nil, "authority round unavailable"
        end
        assert(gm:GetLocalRole() == 3, "GameMode authority required")
        assert(type(epoch) == "string" and epoch ~= "", "explicit round epoch required")
        local key = tostring(gm:GetAddress()) .. ":" .. epoch
        if not s.round or s.round.key ~= key then
            local previous = s.round
            local before_start = gm.GameStarted == false or (previous
                and previous.address == gm:GetAddress() and previous.observed_idle
                and not previous.failure and not s.ended[previous.address])
            local initial_locks = previous and previous.address == gm:GetAddress()
                and previous.observed_idle and previous.status == "waiting" and not previous.failure
                and not s.ended[previous.address] and s.card_locks or {}
            clear("round epoch changed")
            s.card_locks = {}
            for pawn, row in pairs(initial_locks) do
                if valid(row.object) and not row.object:IsActorBeingDestroyed() and not s.ended[pawn]
                    and address(row.object.Controller) == row.owner and not s.ended[row.owner] then
                    row.round = key; s.card_locks[pawn] = row
                else log("warn", "initial card lock discarded cause=original pawn/controller ended or changed") end
            end
            s.ended, s.tracked, s.reasons, s.blocked = {}, {}, {}, {}
            s.round = {key = key, gm = gm, address = gm:GetAddress(),
                coverage = before_start == true, status = "waiting", observed_idle = gm.GameStarted == false}
            log("info", "round observed coverage_from_start=" .. tostring(s.round.coverage))
        end
        local r = s.round
        if s.ended[r.address] then return nil, "GameMode EndPlay observed" end
        if gm.GameStarted == true then
            if r.status == "ended" then return nil, "round epoch reused after round end" end
            r.status = "active"
            r.observed_idle = false
            return r
        end
        assert(gm.GameStarted == false, "GameMode GameStarted boolean unavailable")
        r.observed_idle = true
        if r.status == "active" then
            r.status = "ended"
            clear("original GameMode round ended")
        end
        return nil, r.status == "ended" and "original round ended" or "original round not started"
    end

    local function live(object, label)
        assert(valid(object), label .. " unavailable")
        assert(not s.ended[object:GetAddress()], label .. " EndPlay observed")
        assert(not object:IsActorBeingDestroyed(), label .. " being destroyed")
        assert(object:GetLocalRole() == 3, label .. " authority required")
    end

    local function evidence(pawn)
        local r, blocker = round()
        if not r then return nil, blocker end
        live(pawn, "retained pawn")
        local reservation = options.resolve_reserved(pawn)
        assert(type(reservation) == "table" and not reservation.failed, "authenticated reservation unavailable")
        assert(address(reservation.pawn) == pawn:GetAddress(), "reservation pawn differs")
        assert(reservation.gm_address == r.address, "reservation round differs")
        assert(math.type(reservation.steam_id) == "integer" and reservation.steam_id > 0,
            "authenticated exact Steam identity required")
        local board, chair = pawn.GameBoard, pawn.Chair
        if options.resolve_board then
            local count
            board, count = options.resolve_board(pawn)
            assert(count == 1, "matching live authority Board count differs measured=" .. tostring(count) .. " required=1")
        end
        live(board, "original board")
        live(chair, "original chair")
        local world = r.gm:GetWorld()
        assert(valid(world), "authority GameMode world unavailable")
        assert(address(board:GetWorld()) == world:GetAddress(), "Board and GameMode world differ")
        assert(address(pawn:GetWorld()) == world:GetAddress(), "retained pawn and GameMode world differ")
        assert(address(chair:GetWorld()) == world:GetAddress(), "original chair and GameMode world differ")
        assert(not r.board_address or r.board_address == board:GetAddress(), "Board replaced within original round epoch")
        local matches = 0
        board.PlayerOrder:ForEach(function(_, parameter)
            if address(parameter:get()) == pawn:GetAddress() then matches = matches + 1 end
        end)
        assert(matches == 1, "original Board PlayerOrder pawn matches measured=" .. matches .. " required=1")
        r.board_address = board:GetAddress()
        assert(address(chair.PlayerCharacter) == pawn:GetAddress(), "chair player differs")
        assert(type(board.GameStarted) == "boolean", "Board GameStarted boolean unavailable")
        assert(type(board.GameEndTime) == "boolean", "Board GameEndTime boolean unavailable")
        if board.GameEndTime then clear("original Board GameEndTime"); return nil, "original Board round ending" end
        assert(math.type(board.PlayerTurn) == "integer", "original Board PlayerTurn unavailable")
        assert(type(chair.PlayerSitting) == "boolean", "original chair PlayerSitting unavailable")
        assert(type(chair.SitTransitioning) == "boolean", "original chair SitTransitioning unavailable")
        assert(type(pawn.FinishSittingCanStartTurn) == "boolean", "original seating readiness unavailable")
        assert(type(pawn.IsCurrentTurn) == "boolean", "original turn assignment unavailable")
        assert(not pawn.IsCurrentTurn or address(board.CurrentPlayerTurn) == pawn:GetAddress(),
            "assigned pawn and original Board CurrentPlayerTurn differ")
        assert(type(pawn.GameHalted) == "boolean" and type(board.HaltGame) == "boolean", "original halt state unavailable")
        s.tracked[pawn:GetAddress()], s.tracked[board:GetAddress()], s.tracked[chair:GetAddress()] = true, true, true
        return {round = r.key, identity = reservation.steam_id, pawn = pawn:GetAddress(),
            board = board:GetAddress(), board_object = board, chair = chair:GetAddress(), turn_index = board.PlayerTurn,
            current_pawn = address(board.CurrentPlayerTurn), assigned = pawn.IsCurrentTurn,
            sitting = chair.PlayerSitting, transitioning = chair.SitTransitioning,
            seating_ready = pawn.FinishSittingCanStartTurn, halted = pawn.GameHalted or board.HaltGame,
            board_started = board.GameStarted, coverage = r.coverage}
    end

    local function card_lock(pawn, e)
        local row = s.card_locks[e.pawn]
        if row then
            if row.identity == nil then return nil, "original card lock awaits authenticated reservation" end
            if row.round ~= e.round or row.identity ~= e.identity then
                return nil, "original card lock owner/round differs"
            end
            return row.disabled
        end
        return nil,"original E intent unavailable; effective owner readback required"
    end

    local function inspect(pawn)
        local e, blocker = evidence(pawn)
        if not e then return {phase = "unknown", blocker = blocker} end
        local marker = s.markers[e.board]
        if marker and (marker.round ~= e.round or marker.pawn ~= e.current_pawn or marker.turn_index ~= e.turn_index or marker.board_started ~= e.board_started) then
            s.markers[e.board] = nil
            log("info", "turn marker cleared cause=original turn assignment or Board start state changed")
            marker = nil
        end
        local result = {phase = "unknown", evidence = e, started = false,
            action_subphase = "not observed by phase ledger", playability_confirmed = false}
        if s.round.failure then result.blocker = "round observer failed: " .. s.round.failure
        elseif s.blocked[e.pawn] or s.blocked[e.board] then result.blocker = "target observer failed: " .. (s.blocked[e.pawn] or s.blocked[e.board])
        elseif e.transitioning then result.blocker = "original seat transition still active"
        elseif not e.sitting then
            if marker and marker.pawn == e.pawn then
                if not e.assigned or marker.identity ~= e.identity or marker.chair ~= e.chair then
                    result.blocker = "standing begin marker identity/seat/turn assignment differs"
                else
                    local fields = {disable_standing = pawn.Chair.DisableStanding,
                        board_halted = e.board_object.HaltGame, special_halted = e.board_object.SpecialEventHalt,
                        graveyard_open = e.board_object.GraveyardOpen, in_animation = pawn.InAnimation}
                    -- IsInTurn is owner-only; the original standing RPC clears replicated seating readiness.
                    for _, name in ipairs({"disable_standing", "board_halted", "special_halted", "graveyard_open", "in_animation"}) do
                        assert(type(fields[name]) == "boolean", "standing authority flag unavailable=" .. name)
                    end
                    local elapsed = now() - marker.at
                    assert(elapsed >= 0, "phase clock moved backwards within original round")
                    result.standing_evidence = fields
                    if e.seating_ready then result.blocker = "standing original seating readiness still active"
                    elseif fields.disable_standing then result.blocker = "standing original chair DisableStanding=true"
                    elseif fields.board_halted then result.blocker = "standing original Board HaltGame=true"
                    elseif fields.special_halted then result.blocker = "standing original Board SpecialEventHalt=true"
                    elseif fields.graveyard_open then result.blocker = "standing original Board GraveyardOpen=true"
                    elseif fields.in_animation then result.blocker = "standing original pawn InAnimation=true"
                    elseif elapsed < 1 then result.blocker = "standing original one-second turn transition may be pending"
                    else result.phase = "standing" end
                end
            else
                result.phase = "standing"
            end
        elseif marker and marker.pawn == e.pawn then
            if not e.assigned or marker.identity ~= e.identity or marker.chair ~= e.chair then
                result.blocker = "begin marker identity/seat/turn assignment differs"
            else
                result.started = true
                result.phase = "turn_started"
                result.started_at = marker.at
                local elapsed = now() - marker.at
                assert(elapsed >= 0, "phase clock moved backwards within original round")
                result.transition_elapsed = elapsed >= 1
                if e.halted then result.blocker = "original gameplay halt active during begun turn"
                elseif not result.transition_elapsed then result.blocker = "original one-second local turn transition may be pending" end
            end
        elseif e.assigned and e.current_pawn == e.pawn then
            if e.coverage then
                result.phase = "turn_assigned"
                if e.halted then result.blocker = "original BeginTurn blocked by gameplay halt" end
            else result.blocker = "turn-start history missing; attached after original round start" end
        elseif e.assigned or e.current_pawn == e.pawn then
            result.blocker = "original pawn and Board turn assignment disagree"
        else
            result.phase = "seated"
        end
        if result.phase == "seated" or result.phase == "turn_assigned" then
            result.card_lock, result.card_lock_blocker = card_lock(pawn, e)
            local original=s.card_locks[e.pawn]
            result.card_lock_intent_at=original and original.at
        end
        return result
    end

    local function protect(operation, fn, scope)
        local ok, result = pcall(fn)
        if not ok then
            local target = scope and scope.key
            if target then
                s.blocked[target] = operation .. ": " .. tostring(result)
                for board, marker in pairs(s.markers) do
                    if marker.pawn == target or marker.board == target or marker.chair == target then s.markers[board] = nil end
                end
            else
                clear("unscoped round observer failure")
                if s.round then s.round.failure = operation .. ": " .. tostring(result) end
            end
            local key = operation .. ":" .. tostring(target or "round")
            local previous, time = s.failures[key], os.time()
            local cause = tostring(result)
            local count = previous and previous.cause == cause and previous.count + 1 or 1
            if not previous or previous.cause ~= cause or time - previous.at >= 60 then
                log("error", operation .. " target=" .. tostring(target or "round") .. " cause=" .. cause .. "; phase reconstruction blocked; observations=" .. count)
                s.failures[key] = {cause = cause, count = count, at = time}
            else
                previous.count = count
            end
        else
            local key = operation .. ":" .. tostring(scope and scope.key or "round")
            if s.failures[key] then
                log("info", operation .. " call recovered; invalidated target history remains blocked")
                s.failures[key] = nil
            end
        end
        return ok, result
    end

    function api.inspect(pawn)
        if not s.active then return {phase = "unknown", blocker = "phase observer inactive"} end
        local scope = {}
        local ok, result = protect("inspect", function()
            scope.key = pawn:GetAddress()
            return inspect(pawn)
        end, scope)
        if not ok then return {phase = "unknown", blocker = tostring(result)} end
        local key = address(pawn)
        local reason = result.blocker or result.phase
        if s.reasons[key] ~= reason then
            local measured = ""
            if result.standing_evidence then
                local e, f = result.evidence, result.standing_evidence
                measured = " pawn=" .. e.pawn .. " board=" .. e.board .. " chair=" .. e.chair
                    .. " sitting=" .. tostring(e.sitting) .. " transitioning=" .. tostring(e.transitioning)
                    .. " seating_ready=" .. tostring(e.seating_ready) .. " pawn_or_board_halted=" .. tostring(e.halted)
                    .. " disable_standing=" .. tostring(f.disable_standing) .. " board_halted=" .. tostring(f.board_halted)
                    .. " special_halted=" .. tostring(f.special_halted) .. " graveyard_open=" .. tostring(f.graveyard_open)
                    .. " in_animation=" .. tostring(f.in_animation)
            end
            log(result.blocker and "warn" or "info", "observation=" .. reason .. measured)
            s.reasons[key] = reason
        end
        return result
    end

    function api.hand_intent(pawn)
        assert(s.active,"original hand intent observer inactive")
        live(pawn,"original hand intent pawn")
        local r,cause=round()
        if not r and cause=="original round not started" then r=s.round end
        assert(r,cause)
        local row=s.card_locks[pawn:GetAddress()]
        if not row then return nil end
        assert(not r.failure,"original hand intent round observer failed")
        local reservation=options.resolve_reserved(pawn)
        assert(type(reservation)=="table" and not reservation.failed
            and address(reservation.pawn)==pawn:GetAddress() and reservation.gm_address==r.address,
            "original hand intent reservation differs")
        assert(row.round==r.key and row.identity==reservation.steam_id and address(row.object)==pawn:GetAddress()
            and address(pawn:GetWorld())==address(r.gm:GetWorld()),"original hand intent owner/round differs")
        assert(type(row.at)=="number" and row.at>=0 and row.at<math.huge,"original hand intent time unavailable")
        return row
    end

    function api.hand_intent_at(pawn)
        local row=api.hand_intent(pawn)
        return row and row.at
    end

    function api.tick()
        if not s.active then return false, "phase observer inactive" end
        local ok, cause = protect("round observation", function()
            local r = round()
            if not r then return end
            for key, row in pairs(s.card_locks) do
                if row.identity == nil then
                    local observed, error = protect("original card lock reservation", function()
                        live(row.object, "pending card lock pawn")
                        assert(row.round == r.key and address(row.object:GetWorld()) == address(r.gm:GetWorld()),
                            "pending card lock round/world differs")
                        assert(address(row.object.Controller) == row.owner and not s.ended[row.owner],
                            "pending card lock original controller changed")
                        local reservation = options.resolve_reserved(row.object)
                        if reservation == nil then return end
                        assert(not reservation.failed and address(reservation.pawn) == key
                            and reservation.gm_address == r.address, "pending card lock reservation differs")
                        assert(math.type(reservation.steam_id) == "integer" and reservation.steam_id > 0,
                            "pending card lock Steam identity unavailable")
                        row.identity = reservation.steam_id
                        log("info", "original card lock reservation confirmed pawn=" .. key)
                    end, {key=key})
                    if not observed then return error end
                end
            end
            local failure
            for key, marker in pairs(s.markers) do
                local observed, error = protect("marker observation", function()
                    local e, blocker = evidence(marker.object)
                    if not e or e.round ~= marker.round or e.current_pawn ~= marker.pawn or e.turn_index ~= marker.turn_index or e.board_started ~= marker.board_started then
                        s.markers[key] = nil
                        log("info", "turn marker cleared cause=" .. (blocker or "original turn assignment or Board start state changed"))
                    end
                end, {key = marker.pawn})
                if not observed then failure = failure or error end
            end
            return failure
        end)
        if not ok or cause then return false, cause end
        return true
    end

    function api.register()
        assert(not s.attempted, "phase registration already attempted; reuse this instance")
        s.attempted = true
        local ok, cause = protect("registration", function()
            assert(type(RegisterHook) == "function" and type(RegisterEndPlayPreHook) == "function"
                and type(StaticFindObject) == "function", "UE4SS observer API unavailable")
            for _, path in ipairs({PAWN .. "RepStartTurn_E", PAWN .. "DisableOwnCards_E", BOARD .. "EndPlayerTurn_E"}) do
                assert(valid(StaticFindObject(path)), "original phase function unavailable=" .. path)
            end
            local function hook(path, callback)
                local pre, post = RegisterHook(path, callback)
                assert(type(pre) == "number" and type(post) == "number" and pre ~= 0 and post ~= 0,
                    "Script hook registration IDs unavailable=" .. path)
                s.hooks[path] = {pre = pre, post = post}
                log("info", "Script post-hook registered path=" .. path .. " ids=" .. pre .. "," .. post)
            end
            hook(PAWN .. "RepStartTurn_E", function(context)
                if not s.active then return end
                local scope = {}
                protect("original RepStartTurn_E", function()
                    local pawn = context:get()
                    scope.key = pawn:GetAddress()
                    if pawn:GetLocalRole() ~= 3 then return end
                    local e, blocker = evidence(pawn)
                    assert(e, blocker)
                    assert(not s.round.failure, "round history already invalidated")
                    assert(not s.blocked[e.pawn] and not s.blocked[e.board], "target history already invalidated")
                    assert(e.assigned and e.current_pawn == e.pawn, "begin event has no matching original turn assignment")
                    assert(e.sitting and not e.transitioning and e.seating_ready and not e.halted,
                        "begin event seat/readiness/halt evidence differs")
                    local previous = s.markers[e.board]
                    if previous and previous.round == e.round and previous.pawn == e.pawn
                        and previous.turn_index == e.turn_index and previous.identity == e.identity
                        and previous.board_started == e.board_started then
                        previous.duplicates = (previous.duplicates or 0) + 1
                        local time = os.time()
                        if not previous.duplicate_log or time - previous.duplicate_log >= 60 then
                            log("warn", "repeated original begin event; first marker retained; observations=" .. previous.duplicates)
                            previous.duplicate_log = time
                        end
                        return
                    end
                    s.markers[e.board] = {round = e.round, pawn = e.pawn, board = e.board,
                        chair = e.chair, turn_index = e.turn_index, identity = e.identity,
                        board_started = e.board_started, at = now(), object = pawn}
                    log("info", "original begin marker confirmed board=" .. e.board .. " pawn=" .. e.pawn
                        .. " turn=" .. e.turn_index .. " board_started=" .. tostring(e.board_started))
                end, scope)
            end)
            hook(PAWN .. "DisableOwnCards_E", function(context, disable)
                if not s.active then return end
                local scope = {}
                protect("original DisableOwnCards_E", function()
                    local pawn = context:get()
                    scope.key = pawn:GetAddress()
                    if pawn:GetLocalRole() ~= 3 then return end
                    round()
                    local r = s.round
                    assert(r and r.status ~= "ended" and not r.failure, "original card lock round unavailable")
                    live(pawn, "original card lock pawn")
                    local reservation = options.resolve_reserved(pawn)
                    local identity
                    if reservation ~= nil then
                        assert(type(reservation) == "table" and not reservation.failed
                            and address(reservation.pawn) == pawn:GetAddress() and reservation.gm_address == r.address,
                            "original card lock reservation differs")
                        assert(math.type(reservation.steam_id) == "integer" and reservation.steam_id > 0,
                            "original card lock Steam identity unavailable")
                        identity = reservation.steam_id
                    end
                    assert(address(pawn:GetWorld()) == address(r.gm:GetWorld()), "original card lock world differs")
                    local owner = address(pawn.Controller)
                    assert(owner ~= 0, "original card lock controller unavailable")
                    local value = disable:get()
                    assert(type(value) == "boolean", "original card lock parameter is not boolean")
                    local targets,target_cause
                    if options.describe_hand then targets,target_cause=options.describe_hand(pawn) end
                    if target_cause then log("info","original hand decision has no settled target hand cause="..target_cause) end
                    s.card_locks[pawn:GetAddress()] = {round=r.key, gm=r.address, identity=identity, object=pawn, owner=owner,
                        disabled=value, targets=targets, at=now(), source="original DisableOwnCards_E"}
                    s.tracked[pawn:GetAddress()], s.tracked[owner] = true, true
                    log("info", "original card lock observed pawn=" .. pawn:GetAddress() .. " disabled=" .. tostring(value))
                end, scope)
            end)
            hook(BOARD .. "EndPlayerTurn_E", function(context)
                if not s.active then return end
                local scope = {}
                protect("original EndPlayerTurn_E", function()
                    local board = context:get()
                    scope.key = board:GetAddress()
                    if board:GetLocalRole() ~= 3 then return end
                    local r = round()
                    if not r then return end
                    local key = board:GetAddress()
                    local marker = s.markers[key]
                    s.markers[key] = nil
                    log("info", "original end observed board=" .. key .. " marker_removed=" .. tostring(marker ~= nil))
                end, scope)
            end)
            RegisterEndPlayPreHook(function(context, reason)
                if not s.active then return end
                local scope = {}
                protect("EndPlay", function()
                    local object = context:get()
                    local key = object:GetAddress()
                    scope.key = key
                    local tracked = s.tracked[key]
                    if not tracked then
                        local reservation = options.resolve_reserved(object)
                        tracked = type(reservation) == "table" and address(reservation.pawn) == key
                    end
                    if tracked then
                        s.ended[key] = true
                        log("warn", "tracked actor EndPlay address=" .. key .. " reason=" .. reason:get())
                    end
                    if s.round and key == s.round.address then
                        s.ended[key] = true
                        clear("GameMode EndPlay reason=" .. reason:get())
                        log("info", "GameMode EndPlay observed; round reconstruction blocked")
                    end
                    for board, marker in pairs(s.markers) do
                        if key == marker.pawn or key == marker.board or key == marker.chair then
                            s.ended[key] = true
                            s.markers[board] = nil
                            log("warn", "marker actor EndPlay reason=" .. reason:get() .. "; marker removed")
                        end
                    end
                end, scope)
            end)
            s.active = true
            round()
            log("info", "observer active; gameplay unchanged; local completion acknowledgements still required")
        end)
        if not ok then s.active = false end
        return ok, cause
    end

    function api.stop()
        s.active = false
        clear("explicit stop")
        log("info", "observer inactive; process-lifetime hooks gated")
    end

    return api
end

return M
