local M = {}
local gt = require("gt_scheduler")
local current
local HOST = "/Game/MenuContent/Widgets/HostOptions_WBP.HostOptions_WBP_C"
local PRESSED = HOST .. ":BndEvt__HostOptions_WBP_Create_B_K2Node_ComponentBoundEvent_11_OnButtonPressedEvent__DelegateSignature"
local GI = "/Game/CabinGameContent/CabinAdvanceFriendsGameInstance.CabinAdvanceFriendsGameInstance_C"
local MENU = "World /Game/CabinGameContent/Menu.Menu"
local FIELDS = {"Difficulty_2_669213C546EFF949AC9E319627DC8920","PlayerCollision_9_98C13B414BE2E7E2DD9A9DBA39FBB0BB","RadioTutorial_7_0B68146A454989FEC1E083934A3643A2","GoodieBag_11_BB1DA55D466BA85F46AFF8A4B7B8EA77"}
local function valid(o) return o and o:IsValid() end
local function text(v) return type(v)=="string" and v or v:ToString() end
local function hex(value) return (value:gsub(".",function(c) return string.format("%02x",c:byte()) end)) end
local function unhex(value)
    assert(#value%2==0 and (#value==0 or value:match("^[0-9a-f]+$")),"host request string encoding differs")
    return (value:gsub("..",function(c) return string.char(tonumber(c,16)) end))
end
function M.explicit_join(command)
    for token in command:gmatch("%S+") do
        token=token:gsub('^"(.*)"$',"%1")
        if token=="+connect_lobby" then return true end
    end
    return false
end
function M.capture(widget)
    local selected,cause=M.find_widget()
    assert(valid(selected) and selected:GetAddress()==widget:GetAddress(),"current original nested Host context changed cause="..tostring(cause))
    assert(valid(widget) and widget:GetClass():GetFullName()=="WidgetBlueprintGeneratedClass "..HOST,"exact original HostOptions widget required")
    local gi=widget.AdvanceCabinGameInstance
    assert(valid(gi) and gi:GetClass():GetFullName()=="BlueprintGeneratedClass "..GI and gi:GetWorld():GetFullName()==MENU,"current original Menu GI required")
    assert(widget["Build Version ID"]==gi.BuildVersionID,"original host build version differs")
    assert(math.type(widget.MaxPlayers)=="integer","original MaxPlayers integer required")
    local r={max_players=math.max(1,math.min(4,widget.MaxPlayers)),build=gi.BuildVersionID,
        password=text(widget.Password),lobby_name=text(widget.LobbyName),code=text(widget.Code_TextBox:GetText()),
        password_protected=widget.IsPasswordProtected,is_private=widget.IsPrivate,invite_only=widget.InviteOnly,use_lan=widget.UseLan,
        choices=require("host_options_objects").values(gi)}
    local handle,online,id,app,owns,owns_app=CabinSteamClientState()
    assert(handle>0 and online==1 and math.type(id)=="integer" and id>0 and app==4406280 and owns==1 and owns_app==1,"current original Steam host identity/ownership unavailable")
    r.owner_id=tostring(id)
    for _,key in ipairs({"password_protected","is_private","invite_only","use_lan"}) do assert(type(r[key])=="boolean","original host bool unavailable="..key) end
    for _,key in ipairs({"password","lobby_name","code"}) do assert(#r[key]<=4096,"original host string exceeds4096 bytes="..key) end
    return r
end
function M.encode(r)
    local out={"schema=CabinRejoinHostRequest_v1","max_players="..r.max_players,"build="..r.build,"owner_id="..r.owner_id}
    for _,key in ipairs({"password","lobby_name","code"}) do out[#out+1]=key.."="..hex(r[key]) end
    for _,key in ipairs({"password_protected","is_private","invite_only","use_lan"}) do out[#out+1]=key.."="..(r[key] and "1" or "0") end
    for i,value in ipairs(r.choices) do out[#out+1]="choice"..i.."="..(i==1 and tostring(value) or value and "1" or "0") end
    out[#out+1]="host_mods="..(r.host_mods or "")
    out[#out+1]="complete_record=1"; return table.concat(out,"\n").."\n"
end
function M.read_request()
    local path=os.getenv("CABIN_REJOIN_HOST_REQUEST_PATH"); if not path then return nil end
    local file,cause=io.open(path,"rb"); assert(file,"host request open cause="..tostring(cause))
    local bytes,read_cause=file:read("*a"); local closed,close_cause=file:close()
    assert(bytes and closed and #bytes<=16384,"host request read/close cause="..tostring(read_cause).."/"..tostring(close_cause))
    local r={}; for row in bytes:gmatch("([^\n]+)\n") do
        row=row:gsub("\r$","")
        local key,value=row:match("^([a-z_0-9]+)=(.*)$"); assert(key and r[key]==nil,"host request row/duplicate key differs"); r[key]=value
    end
    assert(bytes:sub(-1)=="\n" and r.schema=="CabinRejoinHostRequest_v1" and r.complete_record=="1","complete host request schema differs")
    r.max_players=tonumber(r.max_players); r.build=tonumber(r.build)
    require("host_options_objects").integer(r.owner_id)
    assert(math.type(r.max_players)=="integer" and r.max_players>=1 and r.max_players<=4 and math.type(r.build)=="integer","host request max/build differs")
    for _,key in ipairs({"password","lobby_name","code"}) do r[key]=unhex(assert(r[key],"host request field missing="..key)) end
    for _,key in ipairs({"password_protected","is_private","invite_only","use_lan"}) do assert(r[key]=="0" or r[key]=="1","host request bool differs="..key); r[key]=r[key]=="1" end
    assert(not r.use_lan,"persistent Steam authority received LAN request")
    r.choices={tonumber(r.choice1)}; assert(math.type(r.choices[1])=="integer" and r.choices[1]>=0 and r.choices[1]<=3,"host difficulty range differs")
    for i=2,4 do local v=r["choice"..i]; assert(v=="0" or v=="1","host choice bool differs"); r.choices[i]=v=="1" end
    return r
end
function M.seed(gi,request,log)
    if not request then return end
    assert(gi.BuildVersionID==request.build,"authority original build differs from host request")
    local handle,online,id,app,owns,owns_app=CabinSteamClientState()
    assert(handle>0 and online==1 and tostring(id)==request.owner_id and app==4406280 and owns==1 and owns_app==1,"authority original Steam owner differs from host request")
    local gameplay=StaticFindObject("/Script/Engine.Default__GameplayStatics")
    assert(valid(gameplay),"authority original gameplay library unavailable")
    local save
    if gameplay:DoesSaveGameExist("GameData",0) then save=gameplay:LoadGameFromSlot("GameData",0)
    else
        local class=StaticFindObject("/Game/CabinGameContent/GameplayData_Save.GameplayData_Save_C")
        assert(valid(class),"authority original GameData class unavailable")
        save=gameplay:CreateSaveGameObject(class)
    end
    assert(valid(save) and save:GetClass():GetFullName()=="BlueprintGeneratedClass /Game/CabinGameContent/GameplayData_Save.GameplayData_Save_C","authority original GameData object unavailable")
    for i,key in ipairs(FIELDS) do
        gi.LobbyGameSettings[key]=request.choices[i]; save.LobbyGameSettings[key]=request.choices[i]
        assert(gi.LobbyGameSettings[key]==request.choices[i] and save.LobbyGameSettings[key]==request.choices[i],"authority host choice assignment differs="..i)
    end
    assert(gameplay:SaveGameToSlot(save,"GameData",0)==true,"authority own GameData save failed")
    local after=gameplay:LoadGameFromSlot("GameData",0); assert(valid(after),"authority own GameData readback failed")
    for i,key in ipairs(FIELDS) do assert(after.LobbyGameSettings[key]==request.choices[i],"authority own GameData choice readback differs="..i) end
    log("info","authority original four host choices stored and read back in own UserDir")
end
local function menu_instance()
    local found
    for _,o in ipairs(FindAllOf("CabinAdvanceFriendsGameInstance_C") or {}) do
        if valid(o) and not o:GetFullName():find("Default__",1,true) and valid(o:GetWorld()) and o:GetWorld():GetFullName()==MENU then
            assert(not found,"current original Menu GI ambiguous"); found=o
        end
    end
    return found
end
function M.find_widget()
    local measured={}
    local ok,cause=xpcall(function()
        local gi=menu_instance(); assert(valid(gi),"original Host current Menu GI pending")
        local world=gi:GetWorld()
        local gameplay=StaticFindObject("/Script/Engine.Default__GameplayStatics")
        assert(valid(gameplay),"original Host GameplayStatics unavailable")
        local pc=gameplay:GetPlayerController(gi,0)
        assert(valid(pc) and pc:IsLocalController() and not pc:IsActorBeingDestroyed() and valid(pc:GetWorld()) and pc:GetWorld():GetAddress()==world:GetAddress(),"original Host live same-world local PC pending")
        measured.gi=gi:GetAddress(); measured.pc=pc:GetAddress(); measured.world=world:GetAddress()
        local mode=gameplay:GetGameMode(gi)
        assert(valid(mode) and valid(mode:GetWorld()) and mode:GetWorld():GetAddress()==world:GetAddress(),"original Host same-world Menu GameMode pending")
        local root=mode.MenuWidget
        assert(valid(root) and root:GetClass():GetFullName()=="WidgetBlueprintGeneratedClass /Game/MenuContent/Widgets/Menu_WBP.Menu_WBP_C","original Host live GameMode MenuWidget pending")
        measured.root=root:GetAddress(); measured.root_viewport=root:IsInViewport()
        assert(measured.root_viewport and valid(root:GetWorld()) and root:GetWorld():GetAddress()==world:GetAddress(),"original Host root Menu viewport/world pending")
        assert(valid(root:GetOwningPlayer()) and root:GetOwningPlayer():GetAddress()==pc:GetAddress() and valid(root:GetOuter()) and root:GetOuter():GetAddress()==gi:GetAddress(),"original Host root Menu owner/GI differs")
        local host=root.HostOptions_WBP
        assert(valid(host) and host:GetClass():GetFullName()=="WidgetBlueprintGeneratedClass "..HOST,"original Host bound HostOptions child pending")
        measured.host=host:GetAddress(); measured.host_visibility=host:GetVisibility()
        assert(valid(host:GetWorld()) and host:GetWorld():GetAddress()==world:GetAddress() and valid(host:GetOwningPlayer()) and host:GetOwningPlayer():GetAddress()==pc:GetAddress(),"original Host child world/owner differs")
        assert(valid(host.MainMenuWidget) and host.MainMenuWidget:GetAddress()==root:GetAddress() and valid(host.AdvanceCabinGameInstance) and host.AdvanceCabinGameInstance:GetAddress()==gi:GetAddress(),"original Host child Menu/GI binding pending")
        local tree=host:GetOuter()
        assert(valid(tree) and valid(tree:GetOuter()) and tree:GetOuter():GetAddress()==root:GetAddress(),"original Host child WidgetTree/root differs")
        local parent=host:GetParent()
        assert(valid(parent) and valid(root.Canvas) and parent:GetAddress()==root.Canvas:GetAddress(),"original Host child original Canvas parent differs")
        measured.canvas_visibility=parent:GetVisibility()
        assert(measured.host_visibility==0 and measured.canvas_visibility==4,"original Host panel visibility measured="..tostring(measured.host_visibility).." canvas="..tostring(measured.canvas_visibility).." required=0/4")
        assert(valid(host.Create_B),"original Host Create_B pending")
        measured.create_visibility=host.Create_B:GetVisibility()
        assert(measured.create_visibility==0,"original Host Create_B visibility measured="..tostring(measured.create_visibility).." required0")
        measured.widget=host
    end,debug.traceback)
    return ok and measured.widget or nil,ok and "original live nested Menu Host context matched" or tostring(cause),measured
end
local function widget(s)
    local found,cause,measured=M.find_widget()
    s.ui_snapshot=measured
    if not found then
        s.ui_wait_repeats=(s.ui_wait_repeats or 0)+1
        if s.ui_wait_reason~=cause then s.ui_wait_reason=cause; s.log("info","original Host interception waits cause="..cause) end
    elseif s.ui_wait_reason then
        s.log("info","original Host nested UI context recovered repeats="..s.ui_wait_repeats)
        s.ui_wait_reason=nil; s.ui_wait_repeats=0
    end
    return found
end
local function arm_widget(s,w)
    if s.armed and valid(s.widget) and s.widget:GetAddress()==w:GetAddress() then return end
    local fn=StaticFindObject(PRESSED); assert(valid(fn),"original Create_B pressed UFunction unavailable")
    local parameters=0; fn:ForEachProperty(function() parameters=parameters+1 end)
    assert(parameters==0,"original Create_B pressed parameter set differs measured="..parameters.." required0")
    local lan
    w:GetClass():ForEachProperty(function(p)
        if p:GetFName():ToString()=="UseLan" then
            assert(not lan and p:GetClass():GetFName():ToString()=="BoolProperty","exact original UseLan property differs"); lan=p
        end
    end)
    assert(lan,"exact original UseLan reflection property unavailable")
    local ack,cause=CabinHostCreateArm(w:GetAddress(),fn:GetAddress(),lan:GetAddress(),w.UseLan and 1 or 0); assert(ack==1,"host UI arm cause="..tostring(cause))
    if not valid(s.widget) or s.widget:GetAddress()~=w:GetAddress() then s.create_enabled_at_arm=w.Create_B:GetIsEnabled() end
    s.widget=w; s.armed=true; s.log("info","original HostOptions Create_B interception armed")
end
local function cleanup(s,operation,fn)
    local ok,cause=xpcall(fn,debug.traceback)
    if not ok then s.log("error","Host failure cleanup operation="..operation.." cause="..tostring(cause)); return false end
    s.log("info","Host failure cleanup acknowledged operation="..operation); return true
end
local function fail(s,cause)
    s.phase="failed"; s.cause=tostring(cause)
    s.armed=false
    s.log("error","original Host autostart cause="..s.cause.."; no replay; live authority preserved")
    cleanup(s,"interception disarm",function() assert(CabinHostCreateDisarm()==1,"native disarm acknowledgement differs") end)
    cleanup(s,"original creating popup removal",function()
        if valid(s.popup) then s.popup:RemoveFromParent(); assert(not s.popup:IsInViewport(),"creating popup remains in viewport") end
    end)
    cleanup(s,"original Create_B disable",function()
        if valid(s.widget) and valid(s.widget.Create_B) then
            s.widget.Create_B:SetIsEnabled(false); assert(not s.widget.Create_B:GetIsEnabled(),"original Create_B remains enabled")
        end
    end)
    cleanup(s,"original dismissible failure popup",function()
        local context=valid(s.widget) and s.widget or menu_instance()
        assert(valid(context),"original Menu failure context unavailable")
        local library=StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary")
        local class=StaticFindObject("/Game/MenuContent/Widgets/JoinFailed_WBP.JoinFailed_WBP_C")
        local texts=StaticFindObject("/Script/Engine.Default__KismetTextLibrary")
        assert(valid(library) and valid(class) and valid(texts),"original failure popup dependencies unavailable")
        s.failure_popup=library:Create(context,class,nil); assert(valid(s.failure_popup),"original failure popup creation failed")
        s.failure_popup:SetTitle_E(texts:Conv_StringToText("failed to join"),texts:Conv_StringToText(""),texts:Conv_StringToText(""))
        s.failure_popup:AddToViewport(3); assert(s.failure_popup:IsInViewport(),"original failure popup viewport acknowledgement missing")
    end)
end
function M.start(options)
    if current then return current.phase~="failed",current.cause end
    local s={phase="waiting",log=assert(options.log),requests=0}; current=s
    if os.getenv("CABIN_REJOIN_PROCESS_ID") then s.phase="skipped"; return true end
    for _,name in ipairs({"CabinHostCreateArm","CabinHostCreateRequests","CabinHostAuthorityEnsure","CabinHostAuthorityStatus","CabinHostCreateDisarm","CabinHostAuthorityResume","CabinSteamClientState"}) do assert(type(_G[name])=="function","host native dependency unavailable="..name) end
    local system=StaticFindObject("/Script/Engine.Default__KismetSystemLibrary"); assert(valid(system),"host original commandline library missing")
    local command=text(system:GetCommandLine())
    if M.explicit_join(command) then s.phase="skipped"; s.log("info","explicit original +connect_lobby preserves user-selected session; owned authority resume skipped"); return true end
    local function advance()
        if s.phase=="admitted" then
            if not menu_instance() then return end
            local w=widget(s); if w then arm_widget(s,w) end
            local ready,cause,measured=require("normal_join").retry_measure()
            s.departure_snapshot=measured
            if not ready then
                local count=CabinHostCreateRequests()
                if count~=s.requests then
                    s.requests=count
                    fail(s,"new explicit Create departure guard cause="..tostring(cause).."; no Ensure/Join")
                    return
                end
                if s.departure_reason~=cause then s.departure_reason=cause; s.log("info","admitted host departure readback pending cause="..tostring(cause).."; no Ensure/Join") end
                return
            end
            s.phase="host_idle"; s.popup=nil; s.failure_popup=nil
            s.departure_reason=nil
            s.log("info","original Menu departure readback confirmed "..cause.."; Host rearm pending; new explicit Create required; no Ensure/Join")
        end
        if s.phase=="waiting" or s.phase=="failed" or s.phase=="host_idle" then
            if s.phase=="failed" and valid(s.failure_popup) and s.failure_popup:IsInViewport() then return end
            local w=widget(s); if not w then return end
            arm_widget(s,w)
            if (s.phase=="failed" or s.phase=="host_idle") and s.create_enabled_at_arm and not w.Create_B:GetIsEnabled() then
                w.Create_B:SetIsEnabled(true); assert(w.Create_B:GetIsEnabled(),"manual retry original Create_B restoration acknowledgement missing")
            end
            local count=CabinHostCreateRequests(); if count==s.requests then return end
            s.requests=count; s.phase="launch_attempted"
            local requested=M.capture(w); assert(not requested.use_lan,"original LAN state changed after Steam press interception; no Steam launch attempted")
            local safe,reset_cause=require("normal_join").retry_after_create()
            assert(safe==true,"explicit Create retry state cause="..tostring(reset_cause))
            s.log("info","new explicit Create request="..count.." original client retry guard="..tostring(reset_cause))
            s.previous_cause=s.cause; s.cause=nil; s.reason=nil
            local library=StaticFindObject("/Script/UMG.Default__WidgetBlueprintLibrary")
            local popup_class=StaticFindObject("/Game/MenuContent/Widgets/AttemptingJoin_WBP.AttemptingJoin_WBP_C")
            local texts=StaticFindObject("/Script/Engine.Default__KismetTextLibrary")
            assert(valid(library) and valid(popup_class) and valid(texts),"original creating-session popup dependencies unavailable")
            s.popup=library:Create(w,popup_class,nil); assert(valid(s.popup),"original creating-session popup creation failed")
            s.popup:SetTitle_E(texts:Conv_StringToText("creating session")); s.popup:AddToViewport(3)
            assert(s.popup:IsInViewport(),"original creating-session popup viewport acknowledgement missing")
            w.Create_B:SetIsEnabled(false)
            assert(not w.Create_B:GetIsEnabled(),"original Create_B disable acknowledgement missing")
            s.mod_settings,requested.host_mods=require("small_mods").publish(requested.owner_id,s.log)
            s.mod_settings_started=os.time()
            local ack,identity,reused=CabinHostAuthorityEnsure(M.encode(requested)); assert(ack==1,"host authority launch/reuse cause="..tostring(identity))
            s.identity=identity; s.phase="authority_pending"; s.log("info","host authority OS receipt acknowledged identity="..identity.." reused="..reused.."; listener readiness pending")
        elseif s.phase=="authority_pending" then
            local ready,lobby,endpoint,cause=CabinHostAuthorityStatus(); assert(ready~=-1,"host authority readiness cause="..tostring(cause))
            if ready==0 then
                if s.reason~=cause then s.reason=cause; s.log("info",cause) end
                return
            end
            local mods_ready,mods_cause=require("small_mods").ready(s.mod_settings,s.identity,s.mod_settings_started,s.log)
            if not mods_ready then
                if s.reason~=mods_cause then s.reason=mods_cause;s.log("info",mods_cause) end
                return
            end
            s.phase="join_attempted"
            assert(CabinHostCreateDisarm()==1,"host UI interception disarm not acknowledged"); s.armed=false
            local ack,why=require("normal_join").start({log=s.log,lobby_id=lobby,expected_endpoint=endpoint,source="original Host Create_B"})
            assert(ack==true,"host same-client original Join start cause="..tostring(why)); s.phase="join_pending"
        elseif s.phase=="join_pending" then
            local result=require("normal_join").status(); assert(result and result.phase~="failed","host original Join failed cause="..tostring(result and result.cause))
            if result.phase=="admitted" then s.phase="admitted"; s.log("info","original Steam graphical host admitted to persistent authority") end
        end
    end
    gt.loop(100,function()
        if s.phase=="skipped" then return true end
        if s.queued then return end; s.queued=true
        local ack,cause=pcall(gt.execute,function()
            if s.phase=="failed" and s.failure_cleanup_pending then s.failure_cleanup_pending=false; fail(s,s.cause) end
            local ok,why=xpcall(advance,debug.traceback); s.queued=false
            if not ok then fail(s,why) end
        end)
        if not ack then
            s.queued=false; s.phase="failed"; s.cause=tostring(cause)
            s.failure_cleanup_pending=true
            s.log("error","Host game-thread dispatch cause="..s.cause.."; engine UI cleanup awaits game-thread recovery")
            cleanup(s,"interception disarm after dispatch failure",function() assert(CabinHostCreateDisarm()==1,"native disarm acknowledgement differs") end)
        end
    end)
    return true
end
function M.status() return current end
return M
