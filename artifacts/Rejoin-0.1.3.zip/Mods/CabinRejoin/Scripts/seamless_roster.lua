local M={}
local PC="BlueprintGeneratedClass /Game/CabinGameContent/PlayerContent/Cabin_PC.Cabin_PC_C"
local ROUND="BlueprintGeneratedClass /Game/CabinGameContent/Cabin_GameMode.Cabin_GameMode_C"
local PATH="/Script/Engine.GameplayStatics:GetAllActorsOfClass"
local function valid(o) return o~=nil and o:IsValid() end
local function address(o) return valid(o) and o:GetAddress() or 0 end
local function class(o) return valid(o) and o:GetClass():GetFullName() or "" end
local function detached_old(o,world)
    return o.valid and o.class==PC and o.world==world and o.role==3 and not o.destroying
        and o.player==0 and o.pawn==0 and o.player_state==0 and o.connection>0
        and o.connection_pc>0 and o.connection_pc==o.connection_owner and o.connection_pc~=o.address
end
local function replacement(old,new,observation)
    local connection=observation.connections[old.connection]
    return new and new.valid and new.class==PC and new.world==observation.world and new.role==3 and not new.destroying
        and new.connection==old.connection and new.player==old.connection and new.pawn>0 and new.player_state>0
        and new.pawn_controller==new.address and new.connection_pc==new.address and new.connection_owner==new.address
        and connection and connection.player_controller==new.address and connection.owning_actor==new.address
        and connection.driver==observation.driver and new.driver==observation.driver and old.driver==observation.driver
end
function M.plan(observation)
    assert(type(observation)=="table" and math.type(observation.world)=="integer" and observation.world>0,"actual current World required")
    assert(type(observation.actors)=="table" and type(observation.connections)=="table","actual actors/connections required")
    local result={keep={},exclude={},blocked={}}
    if observation.game_started==true then
        for index in ipairs(observation.actors) do result.keep[#result.keep+1]=index end
        result.skipped="started round";return result
    end
    assert(observation.game_started==false,"actual GameStarted bool required")
    local by_address={}
    for index,o in ipairs(observation.actors) do
        assert(math.type(o.address)=="integer" and o.address>0 and not by_address[o.address],"original actor identity missing/duplicate")
        by_address[o.address]=o
    end
    for index,old in ipairs(observation.actors) do
        local exclude=false
        if detached_old(old,observation.world) then
            local new=by_address[old.connection_pc]
            if replacement(old,new,observation) then
                if math.type(new.steam_id)=="integer" and new.steam_id>0 and math.type(new.handle)=="integer" and new.handle>0 then
                    result.exclude[#result.exclude+1]={index=index,old=old.address,new=new.address,connection=old.connection,steam_id=new.steam_id,handle=new.handle}
                    exclude=true
                else result.blocked[#result.blocked+1]={old=old.address,new=new.address,connection=old.connection,cause="replacement SDK authentication ACK unavailable"} end
            end
        end
        if not exclude then result.keep[#result.keep+1]=index end
    end
    return result
end
function M.start(options)
    assert(type(options)=="table" and type(options.log)=="function" and type(options.on_error)=="function","original receipt/log/on_error required")
    assert(IsInGameThread()==true,"register seamless roster adapter from original GT")
    assert(type(CabinAuthenticatedSteamID)=="function","original authenticated Steam getter unavailable")
    local identity=require("authority_identity")
    local lease=identity.capture(options.receipt)
    local pc_class=StaticFindObject("/Game/CabinGameContent/PlayerContent/Cabin_PC.Cabin_PC_C")
    assert(valid(pc_class) and valid(StaticFindObject(PATH)),"original PC class/actor getter unavailable")
    local state={phase="registering",attempts=0,confirmed=0,excluded=0,skipped_started=0}
    local api={}
    local function log(level,message) options.log(level,"seamless roster "..message) end
    local function fail(operation,cause)
        state.phase="failed";state.cause=operation..": "..tostring(cause)
        log("error",state.cause.."; adapter dormant; no retry or roster cleanup")
        local ok,error_cause=pcall(options.on_error,state.cause)
        if not ok then log("error","failure handoff cause="..tostring(error_cause).."; original="..state.cause) end
    end
    local function capture(pc,world)
        local connection=pc.NetConnection;local pawn=pc.Pawn
        local row={object=pc,address=pc:GetAddress(),valid=valid(pc),class=class(pc),world=address(pc:GetWorld()),role=pc:GetLocalRole(),
            destroying=pc:IsActorBeingDestroyed(),player=address(pc.Player),pawn=address(pawn),player_state=address(pc.PlayerState),connection=address(connection)}
        if valid(connection) then row.connection_pc=address(connection.PlayerController);row.connection_owner=address(connection.OwningActor);row.driver=address(connection.Driver) end
        if valid(pawn) then row.pawn_controller=address(pawn.Controller) end
        assert(row.valid and row.class==PC and row.world==world,"original current actor output identity differs")
        return row
    end
    local function post(_,world_context,actor_class,out_actors)
        if state.phase~="registered" then return end
        local ok,cause=xpcall(function()
            local gm=world_context:get()
            if class(gm)~=ROUND or address(actor_class:get())~=address(pc_class) then return end
            assert(IsInGameThread()==true,"original actor getter POST outside GT")
            if gm.GameStarted==true then state.skipped_started=state.skipped_started+1;return end
            assert(gm.GameStarted==false,"original GameStarted bool unavailable")
            local current=identity.resolve(lease,options.receipt)
            assert(current.status=="ready","current authority binding unavailable status="..tostring(current.status).." cause="..tostring(current.cause))
            assert(address(current.game_mode)==address(gm) and gm.bUseSeamlessTravel==true,"current seamless Round GameMode binding differs")
            local output=out_actors:get();local before=output:GetArrayNum()
            local observation={world=current.world_address,driver=address(current.driver),game_started=false,actors={},connections={}}
            output:ForEach(function(index,p)
                assert(index==#observation.actors+1,"original actor output order differs")
                observation.actors[index]=capture(p:get(),observation.world)
            end)
            assert(#observation.actors==before,"original actor output count differs")
            current.driver.ClientConnections:ForEach(function(_,p)
                local connection=p:get();local key=address(connection)
                assert(key>0 and not observation.connections[key],"actual connection absent/duplicate")
                observation.connections[key]={player_controller=address(connection.PlayerController),owning_actor=address(connection.OwningActor),driver=address(connection.Driver)}
            end)
            local by_address={};for _,row in ipairs(observation.actors) do by_address[row.address]=row end
            for _,old in ipairs(observation.actors) do
                if detached_old(old,observation.world) then
                    local new=by_address[old.connection_pc]
                    if replacement(old,new,observation) and new.steam_id==nil then
                        new.steam_id,new.handle=CabinAuthenticatedSteamID(new.address)
                    end
                end
            end
            local plan=M.plan(observation)
            assert(#plan.blocked==0,"observed replacement SDK ACK missing old="..tostring(plan.blocked[1] and plan.blocked[1].old).." new="..tostring(plan.blocked[1] and plan.blocked[1].new))
            if #plan.exclude==0 then return end
            local excluded={};for _,row in ipairs(plan.exclude) do excluded[#excluded+1]=row.old.."->"..row.new.." connection="..row.connection end
            state.attempts=state.attempts+1
            log("info","original getter OUT filter attempted world="..observation.world.." before="..before.." after="..#plan.keep.." swaps="..table.concat(excluded,","))
            output:Empty()
            assert(output:GetArrayNum()==0,"original getter OUT Empty unacknowledged")
            for index,source_index in ipairs(plan.keep) do output[index]=observation.actors[source_index].object end
            assert(output:GetArrayNum()==#plan.keep,"original getter OUT count readback differs")
            local observed=0
            output:ForEach(function(index,p)
                observed=observed+1
                assert(address(p:get())==observation.actors[plan.keep[index]].address,"original getter OUT ordered pointer readback differs")
            end)
            assert(observed==#plan.keep,"original getter OUT readback enumeration differs")
            state.confirmed=state.confirmed+1;state.excluded=state.excluded+#plan.exclude
            log("info","original getter OUT filter confirmed count="..observed.."; original Blueprint assignment/NumJoined pending")
        end,debug.traceback)
        if not ok then fail("native getter POST",cause) end
    end
    function api.status() local copy={};for key,value in pairs(state) do copy[key]=value end;return copy end
    function api.stop() state.phase="stopped";log("info","adapter stopped; registered callback dormant");return api.status() end
    local ok,cause=xpcall(function()
        local pre,post_id=RegisterHook(PATH,function() end,post)
        assert(math.type(pre)=="integer" and pre>0 and math.type(post_id)=="integer" and post_id>0,"original native hook IDs unavailable")
        state.pre_id,state.post_id=pre,post_id;state.phase="registered"
        log("info","native getter POST registration returned ids="..pre..","..post_id.."; actual filtering unconfirmed")
    end,debug.traceback)
    if not ok then fail("registration",cause) end
    return api
end
return M
