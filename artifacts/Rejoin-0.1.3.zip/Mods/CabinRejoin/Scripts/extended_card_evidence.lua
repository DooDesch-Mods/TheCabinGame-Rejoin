local refs=require('bound_refs')
local M={}
local function valid(v) return v and v:IsValid() end
local function address(v) return valid(v) and v:GetAddress() or 0 end
local function live(v) return valid(v) and not v:IsActorBeingDestroyed() end
local function vector(v) return {X=v.X,Y=v.Y,Z=v.Z} end
local function rotation(v) return {Pitch=v.Pitch,Yaw=v.Yaw,Roll=v.Roll} end
local function find(array,target)
    local count,object=0,nil
    array:ForEach(function(_,p) local v=p:get(); if address(v)==target then count,object=count+1,v end end)
    return count,object
end
function M.new(o)
    for _,name in ipairs({'context','key','resolve_actor'}) do assert(type(o[name])=='function','extended card adapter missing='..name) end
    local function current(target,pawn)
        local c,cause=o.context(pawn); if not c then return nil,assert(cause,'missing Authority context cause') end
        assert(c.authority and c.authenticated and c.same_world and c.roster_matches==1,
            'current native authenticated original Board context required')
        local card=o.resolve_actor(target,pawn,c.board)
        if not live(card) then return nil,'current original card actor ended or unresolved' end
        assert(card:HasAuthority() and address(card:GetWorld())==address(pawn:GetWorld()),'Authority card world differs')
        local status,count=card.Status,0
        if status==0 then count=address(c.board.Card)==target and 1 or 0
        elseif status==1 then count=find(pawn.CurrentCardsObjects,target)
        elseif status==2 then count=find(c.board.Graveyard,target)
        else return nil,'current original card status is not Inspect status='..tostring(status) end
        assert(count==1,'exact original card membership required status='..status..' count='..count)
        if status==1 then assert(address(card.CurrentOwnedPlayer)==address(pawn),'current Holding owner differs') end
        return {card=target,object=card,context=c,status=status,owner=address(card.CurrentOwnedPlayer),
            pawn=address(pawn),card_type=card.CardType,card_class=card:GetClass():GetFullName(),
            identity=c.identity,epoch=c.epoch,binding=true,binding_matches=count,
            current_turn=address(c.board.CurrentPlayerTurn)==address(pawn) and pawn.IsCurrentTurn,
            location=vector(card:K2_GetActorLocation()),rotation=rotation(card:K2_GetActorRotation())}
    end
    local function evidence(pawn,card)
        local c,cause=o.context(pawn); if not c then return nil,assert(cause,'missing Authority context cause') end
        local e={authority=c.authority,authenticated=c.authenticated,same_world=c.same_world,
            roster_matches=c.roster_matches,pawn=address(pawn),board=address(c.board),identity=c.identity,epoch=c.epoch,
            current_pawn=address(c.board.CurrentPlayerTurn),turn=c.board.PlayerTurn,ending=c.board.GameEndTime}
        if card then
            e.card=card:GetAddress()
            if live(card) then
                e.status,e.card_type,e.card_owner,e.card_class=card.Status,card.CardType,address(card.CurrentOwnedPlayer),card:GetClass():GetFullName()
                e.card_binding=address(c.board.Card)==e.card or find(pawn.CurrentCardsObjects,e.card)==1 or find(c.board.Graveyard,e.card)==1
            end
        end
        return e
    end
    local function capture(pawn,observer)
        local marker,cause=observer.inspect(pawn)
        if not marker then return nil,cause end
        if marker.phase=='action_pending' then
            local c,blocker=o.context(pawn); assert(c,blocker)
            return {phase='action_pending',card_class=marker.card_class,card_type=marker.card_type,
                epoch=marker.epoch,turn_index=marker.turn,generation=c.generation,
                complete=false,cause=marker.cause}
        end
        if marker.phase~='inspect_entry' or (marker.status~=0 and marker.status~=2) then
            return nil,marker.cause or 'no current original Ejected/Graveyard Inspect observation'
        end
        local v,blocker=current(marker.card,pawn); if not v then return nil,blocker end
        assert(v.epoch==marker.epoch and v.identity==marker.identity and v.status==marker.status and v.current_turn,
            'original Inspect marker no longer matches current round/card/turn')
        local c,card=v.context,v.object
        local s={phase='inspect_entry',board=o.key(c.board),card=refs.card_key(pawn,c.board,card),card_class=v.card_class,
            generation=c.generation,epoch=v.epoch,turn_index=c.board.PlayerTurn,current_turn=true,
            card_type=v.card_type,card_status=v.status,binding_matches=1,
            holding=card.IsHolding,card_owner=refs.owner_key(pawn,c.board,card.CurrentOwnedPlayer),
            room_card_disable=card.RoomCardDisable,location=v.location,rotation=v.rotation,
            activity={pawn_halted=pawn.GameHalted,board_halted=c.board.HaltGame,special_halted=c.board.SpecialEventHalt,
                graveyard_open=c.board.GraveyardOpen,in_animation=pawn.InAnimation},graveyard_order={}}
        if v.status==2 then
            c.board.Graveyard:ForEach(function(_,p) local item=p:get(); assert(live(item),'current original Graveyard actor unavailable'); s.graveyard_order[#s.graveyard_order+1]=refs.card_key(pawn,c.board,item) end)
        end
        return s
    end
    return {current_card=current,evidence=evidence,capture=capture}
end
return M
