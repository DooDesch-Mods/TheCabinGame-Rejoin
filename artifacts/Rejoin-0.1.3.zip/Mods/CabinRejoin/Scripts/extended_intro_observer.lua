local M={}
local PATH='/Game/CabinGameContent/CabinBuildingMeshes/RealDiningContent/CarSpline_BP.CarSpline_BP_C:'
function M.new(o)
    for _,name in ipairs({'context','now','log'}) do assert(type(o[name])=='function','Intro observer adapter missing='..name) end
    local records,active,attempted={},false,false
    local function log(level,message)
        local ok,cause=pcall(o.log,level,message)
        if not ok then print('[CabinRejoin] error: Intro log cause='..tostring(cause)..'\n'); print('[CabinRejoin] '..level..': '..message..'\n') end
    end
    local function event(actor,kind)
        local ok,cause=pcall(function()
            if not actor:HasAuthority() then return end
            local c,skip=o.context(actor)
            if not c then log('info','Intro observer skipped cause='..assert(skip)); return end
            assert(c.authority and c.same_world and type(c.epoch)=='string','current Authority intro context required')
            local now=o.now(actor)
            assert(type(now)=='number' and now==now and now>=0,'actual Authority world time required')
            local key=actor:GetAddress()
            if kind=='start' then records[key]={epoch=c.epoch,started_at=now}
            else
                local r=records[key]
                assert(r and r.epoch==c.epoch,'original intro finished without current original MoveCar observation')
                r.finished_at=now
            end
            log('info','original Intro '..kind..' actor='..key)
        end)
        if not ok then
            records[actor:GetAddress()]=nil
            log('error','Intro observer '..kind..' actor='..actor:GetAddress()..' cause='..tostring(cause)..'; progress observation invalidated')
        end
    end
    local api={}
    function api.inspect(actor,epoch)
        local r=records[actor:GetAddress()]
        if not r or r.epoch~=epoch then return nil,'current original MoveCar observation unavailable' end
        local now=o.now(actor)
        assert(type(now)=='number' and now>=r.started_at,'actual current Authority time differs')
        local stage='initial'
        if r.finished_at then
            if now>=r.finished_at+7 then stage='removed'
            elseif now>=r.finished_at+4 then stage='open' end
        end
        return {ui_stage=stage,opened_at=r.finished_at and r.finished_at+4 or -1,
            removed_at=r.finished_at and r.finished_at+7 or -1,started_at=r.started_at}
    end
    function api.released(pawn,gm)
        if not active or not pawn:IsValid() or not gm:IsValid() or gm.GameEnd then return false end
        if not pawn.Mesh:IsValid() or not pawn.CapsuleComponent:IsValid() then return false end
        local parent=pawn.Mesh:GetAttachParent()
        if not parent:IsValid() or parent:GetAddress()~=pawn.CapsuleComponent:GetAddress() then return false end
        local world=pawn:GetWorld():GetAddress()
        if gm:GetWorld():GetAddress()~=world then return false end
        local prefix=tostring(gm:GetAddress())..':'
        local selected=0
        for _,spline in ipairs(FindAllOf('CarSpline_BP_C') or {}) do
            if spline:IsValid() and not spline:IsActorBeingDestroyed() and spline:GetWorld():GetAddress()==world then
                local r,car=records[spline:GetAddress()],spline.Car
                if r and r.epoch:sub(1,#prefix)==prefix and r.finished_at
                    and o.now(spline)>=r.finished_at+7 and car:IsValid() and not car:IsActorBeingDestroyed()
                    and car:GetWorld():GetAddress()==world then
                    local matches=0
                    car.IntroPlayers:ForEach(function(_,v) if v:get():IsValid() and v:get():GetAddress()==pawn:GetAddress() then matches=matches+1 end end)
                    assert(matches<=1,'duplicate original post-Intro player binding')
                    if matches==1 then selected=selected+1 end
                end
            end
        end
        assert(selected<=1,'ambiguous current original post-Intro spline')
        return selected==1
    end
    function api.register()
        assert(not attempted,'Intro observer registration already attempted'); attempted=true
        local ok,cause=pcall(function()
            for name,kind in pairs({MoveCar_E='start',Timeline__FinishedFunc='finish'}) do
                local a,b=RegisterHook(PATH..name,function(ctx) if active then event(ctx:get(),kind) end end)
                assert(type(a)=='number' and a~=0 and type(b)=='number' and b~=0,'original Intro Script hook IDs unavailable='..name)
                log('info','Intro Script post-hook registered name='..name..' ids='..a..','..b)
            end
            RegisterEndPlayPreHook(function(context)
                if active then
                    local ok,ended=pcall(function() records[context:get():GetAddress()]=nil end)
                    if not ok then records={}; log('error','Intro EndPlay cause='..tostring(ended)..'; observations invalidated') end
                end
            end)
            active=true
        end)
        if not ok then active=false; log('error','Intro observer registration cause='..tostring(cause)..'; callbacks gated inactive') end
        return ok,cause
    end
    function api.clear(reason) assert(type(reason)=='string' and reason~=''); records={}; log('info','Intro observations cleared cause='..reason) end
    function api.stop() active=false; records={}; log('info','Intro observer stopped') end
    return api
end
return M
