local M={}
local function valid(v) return v and v:IsValid() end
local function address(v) return valid(v) and v:GetAddress() or 0 end
local function live(v) return valid(v) and not v:IsActorBeingDestroyed() end
local function matches(array,target)
    local n=0; array:ForEach(function(_,p) if address(p:get())==target then n=n+1 end end); return n
end
function M.new(o)
    for _,name in ipairs({'resolve_reserved','current_round','current_generation','resolve_board','native_identity','entered_gameplay'}) do
        assert(type(o[name])=='function','current phase Authority adapter missing='..name)
    end
    local function base(pawn)
        local r=o.resolve_reserved(pawn)
        if not r then return nil,'pawn has no current native authenticated reservation' end
        assert(live(pawn) and pawn:HasAuthority() and address(r.pawn)==address(pawn),'current retained Authority pawn required')
        assert(live(r.pc) and address(r.pc.Pawn)==address(pawn) and address(pawn.Controller)==address(r.pc),
            'current retained Authority ownership differs')
        local id,handle=o.native_identity(r.pc:GetAddress())
        assert(math.type(id)=='integer' and id>0 and id==r.steam_id and math.type(handle)=='integer' and handle>0,
            'current native SDK identity/connection differs')
        local gm,epoch=o.current_round()
        assert(live(gm) and gm:HasAuthority() and type(epoch)=='string' and epoch~='','current Authority gameplay GM required')
        assert(gm:GetClass():GetFullName():match('Cabin_GameMode_C$'),'current original gameplay GM class differs')
        local world=address(pawn:GetWorld())
        assert(world~=0 and address(gm:GetWorld())==world,'current Authority gameplay world differs')
        local count=matches(gm.AllPlayerControllers,address(r.pc))
        assert(count==1,'current original gameplay GM controller roster differs count='..count)
        local generation=o.current_generation()
        assert(math.type(generation)=='integer' and generation>0,'current phase generation required')
        assert(type(gm.GameEnd)=='boolean','original GM GameEnd boolean required')
        return {pawn=pawn,pc=r.pc,gm=gm,identity=id,authority=true,authenticated=true,same_world=true,
            gm_class='Cabin_GameMode_C',epoch=tostring(gm:GetAddress())..':'..epoch,generation=generation,
            roster_matches=count,started=gm.GameStarted,entered_gameplay=o.entered_gameplay(),ending=gm.GameEnd}
    end
    local function card(pawn)
        local c,cause=base(pawn); if not c then return nil,cause end
        local board,count=o.resolve_board(pawn)
        if count~=1 or not live(board) then return nil,'current original Board roster not available count='..tostring(count) end
        assert(board:HasAuthority() and address(board:GetWorld())==address(pawn:GetWorld()),'current Authority Board world differs')
        local n=matches(board.PlayerOrder,address(pawn))
        assert(n==1,'current original Board pawn roster differs count='..n)
        c.board,c.roster_matches=board,n
        return c
    end
    return {base=base,card=card}
end
return M
