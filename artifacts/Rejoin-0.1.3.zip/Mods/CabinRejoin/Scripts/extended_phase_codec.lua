local M={}
local function key(v) assert(type(v)=='string' and v:match('^[%w_]+$'),'exact original actor/component key required'); return v end
function M.visit(snapshot,reading,f)
    local extra=f.flag(reading and nil or snapshot.card_inspect~=nil)
    assert(extra==(snapshot.mode=='card_inspect'),'extended card mode/data differs')
    if extra then
        local s=snapshot.card_inspect or {}; snapshot.card_inspect=s
        s.phase,s.board,s.card,s.card_class,s.epoch=f.text(s.phase),key(f.text(s.board)),key(f.text(s.card)),f.text(s.card_class),f.text(s.epoch)
        s.generation,s.turn_index,s.binding_matches=f.count(s.generation),f.count(s.turn_index),f.count(s.binding_matches)
        s.current_turn,s.card_status,s.card_type=f.flag(s.current_turn),f.count(s.card_status),f.count(s.card_type)
        s.holding,s.card_owner,s.room_card_disable=f.flag(s.holding),f.text(s.card_owner),f.flag(s.room_card_disable)
        assert(s.card_owner=='none' or s.card_owner:match('^[%w_]+$'),'current Card owner key differs')
        s.location,s.rotation=f.vector(s.location),f.rotation(s.rotation)
        s.activity=s.activity or {}
        for _,name in ipairs({'pawn_halted','board_halted','special_halted','graveyard_open','in_animation'}) do s.activity[name]=f.flag(s.activity[name]) end
        local n=f.count(reading and nil or #(s.graveyard_order or {}))
        s.graveyard_order=s.graveyard_order or {}; local matches=0
        for i=1,n do s.graveyard_order[i]=key(f.text(s.graveyard_order[i])); if s.graveyard_order[i]==s.card then matches=matches+1 end end
        assert(s.phase=='inspect_entry' and s.generation>0 and s.binding_matches==1 and s.current_turn and snapshot.turn
            and (s.card_status==0 or s.card_status==2) and s.card_type<=3,'current original extended Inspect contract differs')
        assert((s.card_status==0 and n==0) or (s.card_status==2 and matches==1),'exact original Graveyard membership differs')
    end
    local intro=f.flag(reading and nil or snapshot.car_intro~=nil)
    assert(intro==(snapshot.mode=='car_intro'),'current Intro mode/data differs')
    if intro then
        local s=snapshot.car_intro or {}; snapshot.car_intro=s
        for _,name in ipairs({'phase','gm_class','epoch','car','seat','car_class','ui_stage'}) do s[name]=f.text(s[name]) end
        key(s.car); key(s.seat)
        s.generation,s.seat_matches,s.intro_matches=f.count(s.generation),f.count(s.seat_matches),f.count(s.intro_matches)
        for _,name in ipairs({'authenticated','attached','ending','started'}) do s[name]=f.flag(s[name]) end
        for _,name in ipairs({'opened_at','removed_at','started_at'}) do s[name]=f.number(s[name]) end
        s.mesh_location,s.mesh_rotation=f.vector(s.mesh_location),f.rotation(s.mesh_rotation)
        assert(s.generation>0 and s.started_at>=0,'current original Intro generation/start observation required')
        require('extended_recipe').intro(s)
        if s.ui_stage~='initial' then assert(s.opened_at>=s.started_at and s.removed_at==s.opened_at+3,'original Intro UI times differ') end
    end
    return snapshot
end
return M
