local M={}
local bridge=require("cabin_host_settings")
local names={cabin_fast_turns="CabinFastTurns",cabin_lobby_pets="CabinLobbyPets",cabin_short_events="CabinShortEvents"}
function M.publish(owner,log)
    local request=bridge.publish(owner,log)
    local modules={}
    for id in pairs(request and request.mods or {}) do modules[#modules+1]=assert(names[id],"unsupported authority settings ID="..id) end
    table.sort(modules)
    return request,table.concat(modules,",")
end
function M.ready(request,identity,started,log)
    local ok,cause=bridge.acknowledged(request,identity)
    if ok then return true end
    local elapsed=os.time()-started
    assert(elapsed<120,"authority mod settings acknowledgement timed out; elapsed_seconds="..elapsed.."; required_less_than=120; cause="..tostring(cause))
    return false,cause
end
return M
