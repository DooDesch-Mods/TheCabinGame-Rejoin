local M={}
local ledger=require('input_ledger')
function M.visit(s,reading,f)
    if s.mode~='action_resume' and s.mode~='radio_resume' then
        assert(s.original_input==nil,'original input mode/data differs')
        return s
    end
    local row=reading and {flags={}} or s.original_input
    assert(type(row)=='table' and type(row.flags)=='table','original input snapshot required')
    for _,name in ipairs({'steam_id','epoch','world_key','pawn_key'}) do
        row[name]=f.text(row[name]);assert(row[name]~='' and not row[name]:find('|',1,true),'original input key invalid='..name)
    end
    assert(row.steam_id:match('^%d+$'),'native authenticated Steam ID required')
    row.source=f.text(row.source)
    assert(row.source=='authority_callspace_pre','current guarded callspace sender source required')
    row.sequence=tonumber(f.text(reading and nil or tostring(row.sequence)))
    assert(math.type(row.sequence)=='integer' and row.sequence>0,'exact original sender sequence required')
    for _,name in ipairs(ledger.fields) do row.flags[name]=f.flag(row.flags[name]) end
    row.phase=f.text(row.phase)
    assert(row.phase=='timed_action' or row.phase=='world_event' or row.phase=='radio','current original action/Radio phase required')
    row.phase_key=f.text(row.phase_key);assert(row.phase_key~='' and row.phase_key:match('^[%w_]+$'),'current original phase actor key required')
    row.phase_class=f.text(row.phase_class);assert(row.phase_class~='' and row.phase_class:match('_C$'),'exact original phase actor class required')
    row.phase_revision=tonumber(f.text(reading and nil or tostring(row.phase_revision)))
    assert(math.type(row.phase_revision)=='integer' and row.phase_revision>0,'exact current original phase revision required')
    row.input_fingerprint=ledger.fingerprint(row)
    s.original_input=row
    return s
end
return M
