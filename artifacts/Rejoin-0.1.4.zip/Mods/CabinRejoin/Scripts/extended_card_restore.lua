local M = {}
local recipe = require('extended_recipe')
local graveyard_layout=require('graveyard_layout')
local function valid(v) return v and v:IsValid() end
local function address(v) return valid(v) and v:GetAddress() or 0 end
local function near(a,b) return math.abs(a-b)<0.01 end
local function vector(v) return {X=v.X,Y=v.Y,Z=v.Z} end
local function rotation(v) return {Pitch=v.Pitch,Yaw=v.Yaw,Roll=v.Roll} end
local function vec_equal(a,b) return near(a.X,b.X) and near(a.Y,b.Y) and near(a.Z,b.Z) end
local function rot_equal(a,b)
    for _,name in ipairs({'Pitch','Yaw','Roll'}) do if math.abs((a[name]-b[name]+180)%360-180)>=0.01 then return false end end
    return true
end
local function count(array,target)
    local n=0; array:ForEach(function(_,p) if address(p:get())==target then n=n+1 end end); return n
end

function M.contract(s,token,current_token)
    assert(type(s)=='table' and (s.card_status==0 or s.card_status==2) and type(s.holding)=='boolean'
        and type(s.card_owner)=='string' and s.binding_matches==1 and s.current_turn==true and s.phase=='inspect_entry','current Authority Card inspect snapshot required')
    assert(type(s.card)=='string' and s.card:match('^[%w_]+$') and type(s.board)=='string'
        and s.board:match('^[%w_]+$') and type(s.card_class)=='string','exact original actor keys/class required')
    assert(type(s.epoch)=='string' and s.epoch~='' and math.type(s.turn_index)=='integer' and s.turn_index>=0
        and math.type(s.generation)=='integer' and s.generation>0,'current Card round/generation/turn required')
    assert(type(token)=='table' and type(current_token)=='table' and token.id==current_token.id
        and token.fingerprint==current_token.fingerprint and math.type(token.id)=='integer' and token.id>0
        and type(token.fingerprint)=='string' and token.fingerprint~='','current authenticated presentation token differs')
    assert(type(s.room_card_disable)=='boolean' and math.type(s.card_type)=='integer' and s.card_type>=0 and s.card_type<=3,
        'current replicated card branch/type required')
    for _,name in ipairs({'pawn_halted','board_halted','special_halted','graveyard_open','in_animation'}) do
        assert(type(s.activity)=='table' and type(s.activity[name])=='boolean','current original activity missing='..name)
    end
    return true
end

function M.ready(c,after_common)
    M.contract(c.snapshot,c.token,c.current_token())
    local pc,pawn,board,card,s=c.pc,c.pawn,c.board,c.card,c.snapshot
    for _,v in ipairs({pc,pawn,board,card}) do
        if not valid(v) or v:IsActorBeingDestroyed() then return nil,'waiting for current Card actors' end
    end
    if pc:GetLocalRole()~=2 or not pc:IsLocalController() or not pawn:IsLocallyControlled()
        or address(pc.Pawn)~=address(pawn) or address(pc.AcknowledgedPawn)~=address(pawn)
        or address(pawn.Controller)~=address(pc) then return nil,'waiting for original retained owner acknowledgement' end
    local world=address(pawn:GetWorld())
    if world==0 or address(board:GetWorld())~=world or address(card:GetWorld())~=world then return nil,'waiting for current Card world' end
    if c.key(board)~=s.board or c.key(card)~=s.card or card:GetClass():GetFullName()~=s.card_class then return nil,'waiting for exact Card actor keys/class' end
    if count(board.PlayerOrder,address(pawn))~=1 or address(board.CurrentPlayerTurn)~=address(pawn)
        or board.PlayerTurn~=s.turn_index or not pawn.IsCurrentTurn then return nil,'waiting for current Board roster/turn' end
    local member=s.card_status==0 and (address(board.Card)==address(card) and 1 or 0) or count(board.Graveyard,address(card))
    local owner=valid(card.CurrentOwnedPlayer) and c.key(card.CurrentOwnedPlayer) or 'none'
    if member~=1 or card.Status~=s.card_status or card.CardType~=s.card_type or card.IsHolding~=s.holding
        or owner~=s.card_owner or card.RoomCardDisable~=s.room_card_disable then
        return nil,'waiting for current replicated Card owner/status/hand/branch' end
    if not vec_equal(card:K2_GetActorLocation(),s.location) or not rot_equal(card:K2_GetActorRotation(),s.rotation) then
        return nil,'waiting for current authoritative Card actor pose' end
    if s.card_status==2 then
        if not valid(board.ViewGraveyard) then return nil,'waiting for original Graveyard view component' end
        local keys={}; board.Graveyard:ForEach(function(_,p) keys[#keys+1]=c.key(p:get()) end)
        if #keys~=#s.graveyard_order then return nil,'waiting for original Graveyard count' end
        for i,key in ipairs(keys) do if key~=s.graveyard_order[i] then return nil,'waiting for original Graveyard order index='..i end end
    end
    if after_common and address(pawn.GameBoard)~=address(board) then return nil,'waiting for original SetActors Board binding' end
    if after_common and (not valid(pawn.Camera) or not valid(pawn.CabinHud_WBP) or not valid(card.CardScene)
        or not valid(card.CardMesh) or address(card.CardScene)==address(card.RootComponent)
        or address(card.CardMesh)==address(card.RootComponent)) then return nil,'waiting for local Card presentation components' end
    return true
end

local function gameplay(c)
    local pawn,board,card=c.pawn,c.board,c.card
    local r={position=vector(pawn:K2_GetActorLocation()),rotation=rotation(pawn:K2_GetActorRotation()),
        chair=address(pawn.Chair),turn=pawn.IsCurrentTurn,turn_index=board.PlayerTurn,total_turns=board.TotalTurns,
        current=address(board.CurrentPlayerTurn),started=board.GameStarted,ending=board.GameEndTime,
        card=address(card),status=card.Status,holding=card.IsHolding,owner=address(card.CurrentOwnedPlayer),
        room_disabled=card.RoomCardDisable,card_location=vector(card:K2_GetActorLocation()),
        card_rotation=rotation(card:K2_GetActorRotation()),hand={},physical={}}
    pawn.CurrentCards:ForEach(function(i,p) r.hand[i]=address(p:get()) end)
    pawn.CurrentCardsObjects:ForEach(function(i,p) r.physical[i]=address(p:get()) end)
    return r
end
local function unchanged(a,b,path)
    for name,value in pairs(a) do
        local observed=b[name]
        if type(value)=='table' then assert(type(observed)=='table','Card invariant missing='..path..name); unchanged(value,observed,path..name..'.')
        else assert(value==observed,'Card restore changed gameplay='..path..name..' observed='..tostring(observed)..' required='..tostring(value)) end
    end
    for name in pairs(b) do assert(a[name]~=nil,'Card invariant added='..path..name) end
end
-- Replication and animation can update continuous poses between watch callbacks.
-- Exact comparisons still protect all gameplay fields and each synchronous setter.
local function logical_gameplay(state)
    local result={}
    for name,value in pairs(state) do
        if name=='position' or name=='rotation' or name=='card_location' or name=='card_rotation' then
            local axes=(name=='rotation' or name=='card_rotation') and {'Pitch','Yaw','Roll'} or {'X','Y','Z'}
            for _,axis in ipairs(axes) do
                local n=value[axis]
                assert(type(n)=='number' and n==n and math.abs(n)<math.huge,'Card continuous pose invalid='..name..'.'..axis)
            end
        else result[name]=value end
    end
    return result
end
local function hints(c)
    local rows=c.snapshot.card_status==0 and {{'accept','eject_accept','Cabin_Interact'}}
        or {{'accept','eject_accept','Cabin_Interact'},{'cancel','inspect_cancel','Cabin_Secondary'}}
    c.pawn:AddInputInstruction_E(c.text(''),'',false,true,c.name('None'))
    for _,row in ipairs(rows) do c.pawn:AddInputInstruction_E(c.text(row[1]),row[2],false,false,c.name(row[3])) end
    return rows
end
local function hint_ready(c)
    local keys,widgets={},{}
    local hud=c.pawn.CabinHud_WBP
    hud.UniqueStringsArray:ForEach(function(_,p) keys[p:get():ToString()]=true end)
    hud.InputInstructionsArray:ForEach(function(_,p)
        local v=p:get(); assert(valid(v),'Card HUD instruction widget unavailable'); widgets[v['Unique String']:ToString()]=true
    end)
    if c.snapshot.card_status==2 and (not keys.inspect_cancel or not widgets.inspect_cancel) then return nil,'waiting for original cancel hint' end
    local accept=true
    if (keys.eject_accept==true)~=accept or (widgets.eject_accept==true)~=accept then return nil,'waiting for original accept hint branch' end
    return true
end

function M.restore(c)
    for _,name in ipairs({'text','name','log','current_token','key'}) do assert(type(c[name])=='function','Card restore adapter missing='..name) end
    local ready,cause=M.ready(c,true); if not ready then c.log('info',cause); return nil,cause end
    local before=gameplay(c)
    local r={stage='attempted',before=before,input_receipt='incomplete',complete=false}
    c.log('info','Card inspect local presentation attempted card='..c.snapshot.card)
    local ok,failure=pcall(function()
        local pawn,card,s=c.pawn,c.card,c.snapshot
        local cam=pawn.Camera
        local graveyard
        if s.card_status==2 then
            assert(type(c.make_transform)=='function' and type(c.transform_matches)=='function',
                'original MakeTransform and typed readback adapters required')
            local index
            for i,key in ipairs(s.graveyard_order) do if key==s.card then assert(not index,'duplicate Graveyard key'); index=i-1 end end
            assert(index,'current Graveyard index unavailable')
            graveyard={index=index,count=#s.graveyard_order,
                view_location=vector(c.board.ViewGraveyard:K2_GetComponentLocation()),
                view_rotation=rotation(c.board.ViewGraveyard:K2_GetComponentRotation()),
                card_root_right=vector(card.RootComponent:GetRightVector())}
        end
        local target=recipe.inspect(s,{location=vector(cam:K2_GetComponentLocation()),
            rotation=rotation(cam:K2_GetComponentRotation()),base_aim=rotation(pawn:GetBaseAimRotation())},graveyard)
        if s.card_status==2 then graveyard_layout.restore(c) end
        card.PlayerNonRep=pawn
        card.GameBoard=c.board
        card.OriginHandLOC=target.origin_hand_location; card.OriginHandROT=target.origin_hand_rotation
        if s.card_status==2 then
            local g=target.graveyard_origin
            card.GraveyardOrigin=c.make_transform(g.location,g.rotation,g.scale)
            assert(c.transform_matches(card.GraveyardOrigin,g),'original Graveyard cancel transform readback differs')
            c.board.GraveyardOpen=true
        end
        c.board.DisableGraveyardCancel=false
        c.board.Graveyard:ForEach(function(_,p)
            local other=p:get(); assert(valid(other),'current Graveyard actor unavailable'); other.DisableInteraction=true
        end)
        card.InInspect=true; card.InTransition=false; card.CardInspectDistance=16
        card.CardMesh:K2_SetRelativeLocation({X=0,Y=0,Z=0},false,{},false)
        card.CardScene:K2_SetWorldLocationAndRotation(target.card_scene_location,target.card_scene_rotation,false,{},false)
        card.InspectROT_Scare=target.card_scene_rotation
        pawn:Inspect_PP_E(true)
        pawn.IsInTurn=true; pawn.TTurnTransition=false
        card:EnableInput(c.pc)
        local functions=StaticFindObject('/Game/CabinGameContent/Cabin_Functions.Default__Cabin_Functions_C')
        assert(valid(functions),'original Input Mode library unavailable')
        functions['Input Mode'](functions,c.pc,false,false,true,pawn)
        r.hints=hints(c); r.target=target; r.graveyard=graveyard; r.stage='presentation_registered'
        unchanged(before,gameplay(c),'')
        local current_ready,current_cause=M.ready(c,true); assert(current_ready,current_cause)
    end)
    if not ok then
        r.error=tostring(failure);r.stage='failed'
        c.log('error','Card inspect restore card='..c.snapshot.card..' cause='..r.error..'; local presentation remains incomplete')
        return nil,r
    end
    c.log('info','Card inspect registered; original PP completion and local readback pending')
    return r
end

local function terminal_pose(c,r)
    if r.terminal_pose_stage=='confirmed' then return true end
    assert(not r.terminal_pose_stage,'Card terminal pose already attempted; no setter replay')
    local pawn,card=c.pawn,c.card
    local cam=pawn.Camera
    local sample={observation=c,location=vector(cam:K2_GetComponentLocation()),
        rotation=rotation(cam:K2_GetComponentRotation()),base_aim=rotation(pawn:GetBaseAimRotation()),
        position=vector(pawn:K2_GetActorLocation())}
    local previous=r.pose_sample
    r.pose_sample=sample
    if not previous or previous.observation==c or not vec_equal(previous.location,sample.location)
        or not vec_equal(previous.position,sample.position) or not rot_equal(previous.rotation,sample.rotation)
        or not rot_equal(previous.base_aim,sample.base_aim) then
        return nil,'waiting for settled Card camera on distinct watch callbacks'
    end
    local target=recipe.inspect(c.snapshot,sample,r.graveyard)
    local before=gameplay(c)
    r.terminal_pose_stage='attempted'
    -- Only the local visual component follows the settled owner camera.
    card.CardScene:K2_SetWorldLocationAndRotation(target.card_scene_location,target.card_scene_rotation,false,{},false)
    card.InspectROT_Scare=target.card_scene_rotation
    unchanged(before,gameplay(c),'')
    assert(vec_equal(card.CardScene:K2_GetComponentLocation(),target.card_scene_location)
        and rot_equal(card.CardScene:K2_GetComponentRotation(),target.card_scene_rotation),
        'Card terminal visual pose readback differs')
    r.target=target;r.terminal_pose_stage='confirmed';r.pose_sample=nil
    return true
end

function M.finish(c,r)
    local ready,cause=M.ready(c,true); if not ready then return nil,cause end
    if type(r)~='table' or r.stage~='presentation_registered' then return nil,'Card restore registration receipt missing' end
    unchanged(logical_gameplay(r.before),logical_gameplay(gameplay(c)),'')
    local pawn,card=c.pawn,c.card
    if not valid(pawn.Inspect_PP_TL) or pawn.Inspect_PP_TL:IsPlaying() then return nil,'waiting for original Inspect_PP timeline completion' end
    local length=pawn.Inspect_PP_TL:GetTimelineLength()
    if length<=0 or pawn.Inspect_PP_TL:GetPlaybackPosition()<length-0.001 then return nil,'waiting for original Inspect_PP final timeline position' end
    if c.snapshot.card_status==2 and (not c.board.GraveyardOpen or not c.transform_matches(card.GraveyardOrigin,r.target.graveyard_origin)) then
        return nil,'waiting for original Graveyard cancel origin/open readback' end
    if c.board.DisableGraveyardCancel then return nil,'waiting for stable local Graveyard cancel state' end
    local terminal,terminal_cause=terminal_pose(c,r)
    if not terminal then return nil,terminal_cause end
    if not pawn.IsInspecting or not pawn.IsInTurn or pawn.TTurnTransition or not card.InInspect or card.InTransition
        or address(card.PlayerNonRep)~=address(pawn) or address(card.GameBoard)~=address(c.board)
        or not vec_equal(card.OriginHandLOC,r.target.origin_hand_location) or not rot_equal(card.OriginHandROT,r.target.origin_hand_rotation)
        or not vec_equal(card.CardScene:K2_GetComponentLocation(),r.target.card_scene_location)
        or not rot_equal(card.CardScene:K2_GetComponentRotation(),r.target.card_scene_rotation)
        or not vec_equal(card.CardMesh.RelativeLocation,{X=0,Y=0,Z=0})
        or not valid(card.InputComponent) or c.pc.bShowMouseCursor~=false or not pawn.InspectLight:IsVisible() then
        return nil,'waiting for original Card pose/origin/input/PP readback'
    end
    local hint,hint_cause=hint_ready(c); if not hint then return nil,hint_cause end
    r.local_confirmed,r.complete=true,true
    r.input_receipt='original_input_not_exercised'
    return r
end
return M
