# Changelog

## 0.1.4 - 2026-10-23

- Wait for the initial player roster during reconnect instead of permanently invalidating the retained player state.
- Fix disappearing inspected cards and incomplete reconnects caused by normal position updates while restoration is pending.
- Wait for the owner camera to settle before positioning the inspected card, and validate the original game-only cursor mode.
- Verified the card fix with two local graphical clients, a client restart, an actual host acknowledgement and the original card-accept action. The exact reported remote Steam blackscreen remains unconfirmed; the local network test does not cover two-account Steam authentication.

## 0.1.3 - 2026-10-23

- Load installed FastTurns, LobbyPets and ShortEvents in the background host and apply the host settings before joining.
- Restore the Neighbor card's three choices after its dialogue on the background host.
- Fix a crash when leaving a round caused by an expired player controller.
- A reported remote-host Reconnect blackscreen remains unresolved. A complete group round and recovery from a real AMD driver crash remain unmeasured.

## 0.1.2 - 2026-10-13

- Use Rejoin and Mod Settings together without overlapping menu cards.
- Keep Rejoin on the left and Mods on the right.
- Return each card to its front when moving the pointer between them.
- Keep the same manual installation and separate UE4SS requirement.

## 0.1.1 - 2026-10-13

- Use the same manual installation layout as the other Cabin mods.
- Include the finished mod containers directly in the download.
- Require the separate UE4SS download.
- Remove the test installer, BAT, asset recipes and bundled loader from the release archive.
- Keep the previously tested gameplay and mod container bytes unchanged.

## 0.1.0 - 2026-10-13

First release, using the tested V21 mod files.

- Add a manual `Rejoin` card to the left of the main menu, with a `Reconnect` entry on the reverse side.
- Keep the hosted session in a background process when the host's game client closes unexpectedly.
- Reopen the host's main menu after a client crash and let the player choose whether to reconnect.
- Restore the retained player, cards, turn and room state on reconnect.
- Keep the reconnect card visible until the menu is left and restore normal hover behavior for the other cards.
- Correct room restoration for removed furniture and individual heater components, including the cellar.
- End the host's old session when `Quit Game` or a new hosted session is chosen.
- Bundle UE4SS and install into the existing Steam game through one `Installieren.bat`.

Validated locally on Steam build 25553694. A full four-account group test and an actual AMD driver-crash test remain outstanding.
