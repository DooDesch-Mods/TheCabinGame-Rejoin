local M={}
local walls=require("room_wall_restore")
local PREFIX="/Game/CabinGameContent/CabinBuildingMeshes/Rooms/"
local FURNITURE="BlueprintGeneratedClass /Game/CabinGameContent/CabinBuildingMeshes/Furniture/"
local CLASSES={}
for _,name in ipairs({"Bathroom_BP","BedRoom_BP","Cellar_BP","FurnaceRoom_BP","HallL_01_BP","HallStraight_01_BP","HallStraight_02_BP","Hall_T2_BP","Hall_T_BP","Kitchen_BP","LivingRoom_BP","StudyRoom_BP"})do
    CLASSES["BlueprintGeneratedClass "..PREFIX..name.."."..name.."_C"]=true
end
local function valid(v)return v and v:IsValid()end
local function address(v)return valid(v)and v:GetAddress()or 0 end
local function copy(v,keys)local t={};for _,k in ipairs(keys)do t[k]=v[k]end;return t end
local XYZ,PYR={"X","Y","Z"},{"Pitch","Yaw","Roll"}
local function same(a,b,keys,tolerance)
    for _,k in ipairs(keys)do
        local delta=a[k]-b[k]
        if keys==PYR then delta=(delta+180)%360-180 end
        if math.abs(delta)>tolerance then return false end
    end
    return true
end
local function current(v,pawn)
    return valid(v)and not v:IsActorBeingDestroyed()and address(v:GetWorld())==address(pawn:GetWorld())
end
local function members(object,predicate)
    local result,seen={},{}
    local struct=object:GetClass()
    for _=1,16 do
        if not valid(struct)or struct:GetFullName()=="Class /Script/Engine.Actor"then break end
        struct:ForEachProperty(function(property)
            if property:IsA(PropertyTypes.ObjectProperty)then
                local class=property:GetPropertyClass()
                if valid(class)and predicate(class)then
                    local name=property:GetFName():ToString()
                    assert(name:match("^[%w_]+$"),"room member name cannot be encoded")
                    if not seen[name]then
                        seen[name]=true;result[#result+1]={field=name,class=class:GetFullName()}
                    end
                end
            end
        end)
        struct=struct:GetSuperStruct()
    end
    table.sort(result,function(a,b)return a.field<b.field end)
    return result
end
local function furniture(room)
    return members(room,function(class)return class:GetFullName():sub(1,#FURNITURE)==FURNITURE end)
end
local function components(actor)
    local scene=StaticFindObject("/Script/Engine.SceneComponent")
    assert(valid(scene),"original SceneComponent class missing")
    return members(actor,function(class)return class:IsChildOf(scene)end)
end
local function component_pose(v)
    return {location=copy(v.RelativeLocation,XYZ),rotation=copy(v.RelativeRotation,PYR),scale=copy(v.RelativeScale3D,XYZ),visible=v.bVisible,hidden=v.bHiddenInGame}
end
local function rooms(pawn)
    local result={}
    for _,room in ipairs(FindAllOf("ParentRoom_BP_C")or{})do
        if current(room,pawn)and CLASSES[room:GetClass():GetFullName()]then
            assert(room.bReplicates==true,"placed room is not an original replicated room")
            result[#result+1]=room
        end
    end
    assert(#result<=64,"placed room count exceeds64")
    table.sort(result,function(a,b)
        local x,y=a:GetClass():GetFullName(),b:GetClass():GetFullName()
        if x~=y then return x<y end
        local p,q=a:K2_GetActorLocation(),b:K2_GetActorLocation()
        for _,k in ipairs(XYZ)do if p[k]~=q[k]then return p[k]<q[k]end end
        error("placed rooms have ambiguous class and location")
    end)
    return result
end
function M.capture(pawn)
    local result={}
    for _,room in ipairs(rooms(pawn))do
        assert(room:HasAuthority(),"placed room capture requires authority")
        local row={class=room:GetClass():GetFullName(),location=copy(room:K2_GetActorLocation(),XYZ),furniture={},components={}}
        row.wall_visual=walls.capture(pawn,room)
        for _,definition in ipairs(components(room))do
            local value=room[definition.field]
            if valid(value)and valid(value:GetOwner())then
                assert(address(value:GetOwner())==address(room),"room component owner differs="..definition.field)
                local state=component_pose(value);state.field,state.class=definition.field,definition.class
                row.components[#row.components+1]=state
            end
        end
        for _,definition in ipairs(furniture(room))do
            assert(#row.furniture<128,"room furniture member count exceeds128")
            local actor=room[definition.field]
            local item={field=definition.field,class=definition.class,present=current(actor,pawn)}
            row.furniture[#row.furniture+1]=item
            if item.present then
                assert(actor:GetClass():GetFullName()==item.class,"room furniture class differs="..item.field.." actual="..actor:GetClass():GetFullName().." required="..item.class)
                item.replicated=actor.bReplicates
                assert(type(item.replicated)=="boolean","room furniture replication flag unavailable="..item.field)
                local parent=address(actor:GetAttachParentActor())
                assert(parent==0 or parent==address(room),"room furniture belongs to another room="..item.field)
                item.attached=parent==address(room)
                item.location,item.rotation,item.scale=copy(actor:K2_GetActorLocation(),XYZ),copy(actor:K2_GetActorRotation(),PYR),copy(actor:GetActorScale3D(),XYZ)
                item.hidden=actor.bHidden;item.components={}
                for _,component in ipairs(components(actor))do
                    local value=actor[component.field]
                    assert(valid(value)and address(value:GetOwner())==address(actor),"furniture component owner differs="..component.field)
                    local state=component_pose(value);state.field,state.class=component.field,component.class
                    item.components[#item.components+1]=state
                end
            end
        end
        result[#result+1]=row
    end
    return result
end
function M.visit(world,reading,api)
    local count=api.count(reading and nil or #(world.placed_rooms or{}));assert(count<=64,"snapshot placed room count exceeds64")
    world.placed_rooms=world.placed_rooms or{}
    for i=1,count do
        local row=world.placed_rooms[i]or{};world.placed_rooms[i]=row
        row.class,row.location=api.text(row.class),api.vector(row.location)
        assert(CLASSES[row.class],"snapshot placed room class differs")
        walls.visit(row,reading,api)
        local component_count=api.count(reading and nil or #(row.components or{}))
        assert(component_count<=256,"snapshot room component count exceeds256")
        row.components=row.components or{}
        for n=1,component_count do
            local comp=row.components[n]or{};row.components[n]=comp
            comp.field,comp.class=api.text(comp.field),api.text(comp.class)
            assert(comp.field:match("^[%w_]+$"),"snapshot room component field differs")
            comp.location,comp.rotation,comp.scale=api.vector(comp.location),api.rotation(comp.rotation),api.vector(comp.scale)
            comp.visible,comp.hidden=api.flag(comp.visible),api.flag(comp.hidden)
        end
        local total=api.count(reading and nil or #(row.furniture or{}));assert(total<=128,"snapshot room furniture count exceeds128")
        row.furniture=row.furniture or{}
        for n=1,total do
            local item=row.furniture[n]or{};row.furniture[n]=item
            item.field,item.class,item.present=api.text(item.field),api.text(item.class),api.flag(item.present)
            assert(item.field:match("^[%w_]+$")and item.class:sub(1,#FURNITURE)==FURNITURE,"snapshot furniture member/class differs")
            if item.present then
                item.replicated=api.flag(item.replicated)
                item.attached=api.flag(item.attached)
                item.location,item.rotation,item.scale=api.vector(item.location),api.rotation(item.rotation),api.vector(item.scale)
                item.hidden=api.flag(item.hidden)
                local num=api.count(reading and nil or #(item.components or{}));assert(num<=128,"snapshot furniture component count exceeds128")
                item.components=item.components or{}
                for k=1,num do
                    local comp=item.components[k]or{};item.components[k]=comp
                    comp.field,comp.class=api.text(comp.field),api.text(comp.class)
                    assert(comp.field:match("^[%w_]+$"),"snapshot furniture component field differs")
                    comp.location,comp.rotation,comp.scale=api.vector(comp.location),api.rotation(comp.rotation),api.vector(comp.scale)
                    comp.visible,comp.hidden=api.flag(comp.visible),api.flag(comp.hidden)
                end
            end
        end
    end
end
function M.prepare(pawn,world)
    local result={pawn=pawn,world=address(pawn:GetWorld()),rooms={}}
    local available=rooms(pawn)
    for _,row in ipairs(world.placed_rooms or{})do
        local room
        for _,candidate in ipairs(available)do
            if candidate:GetClass():GetFullName()==row.class and same(candidate:K2_GetActorLocation(),row.location,XYZ,1)then
                assert(not room,"snapshot placed room binding ambiguous");room=candidate
            end
        end
        if not room then return nil,"waiting for original placed room="..row.class end
        local wall,cause=walls.prepare(pawn,row,room);if not wall then return nil,cause end
        local item={room=room,address=address(room),wall=wall,furniture={},components={}}
        local fields={};for _,definition in ipairs(components(room))do fields[definition.field]=definition.class end
        for _,state in ipairs(row.components or{})do
            assert(fields[state.field]==state.class,"snapshot component is not a member of the current room")
            local value=room[state.field]
            if not valid(value)then return nil,"waiting for original room component="..state.field end
            assert(address(value:GetOwner())==address(room),"client room component owner differs")
            item.components[#item.components+1]={object=value,address=address(value),state=state}
        end
        local definitions={};for _,definition in ipairs(furniture(room))do definitions[definition.field]=definition.class end
        for _,state in ipairs(row.furniture)do
            assert(definitions[state.field]==state.class,"snapshot furniture is not a member of the current room="..state.field)
            local actor=room[state.field]
            if state.present and state.replicated and not current(actor,pawn)then
                local class=assert(state.class:match("%.([%w_]+)$"),"snapshot furniture class suffix differs")
                for _,candidate in ipairs(FindAllOf(class)or{})do
                    if current(candidate,pawn)and candidate.bReplicates==true and not candidate:HasAuthority()
                        and candidate:GetClass():GetFullName()==state.class
                        and same(candidate:K2_GetActorLocation(),state.location,XYZ,1)
                        and address(candidate:GetAttachParentActor())==(state.attached and address(room)or 0)then
                        assert(not current(actor,pawn),"snapshot replicated furniture binding ambiguous="..state.field)
                        actor=candidate
                    end
                end
            end
            if state.present and not current(actor,pawn)then return nil,"waiting for original furniture="..state.field end
            if current(actor,pawn)then
                assert(actor:GetClass():GetFullName()==state.class,"client furniture class differs="..state.field)
                if state.present then
                    assert(actor.bReplicates==state.replicated,"client furniture replication differs="..state.field)
                elseif actor.bReplicates then
                    return nil,"waiting for original replicated furniture removal="..state.field
                end
                local entry={actor=actor,address=address(actor),state=state,components={}}
                if state.present then
                    local fields={};for _,definition in ipairs(components(actor))do fields[definition.field]=definition.class end
                    for _,comp in ipairs(state.components)do
                        assert(fields[comp.field]==comp.class,"snapshot component is not a member of the current furniture")
                        local value=actor[comp.field]
                        if not valid(value)then return nil,"waiting for original furniture component="..comp.field end
                        assert(address(value:GetOwner())==address(actor),"client furniture component owner differs")
                        entry.components[#entry.components+1]={object=value,address=address(value),state=comp}
                    end
                end
                item.furniture[#item.furniture+1]=entry
            end
        end
        result.rooms[#result.rooms+1]=item
    end
    return result
end
function M.apply(prepared,log)
    assert(address(prepared.pawn:GetWorld())==prepared.world,"placed room restore world changed")
    for _,room in ipairs(prepared.rooms)do
        assert(current(room.room,prepared.pawn)and address(room.room)==room.address,"placed room binding ended")
        for _,comp in ipairs(room.components)do
            local value,data=comp.object,comp.state
            assert(address(value)==comp.address and address(value:GetOwner())==room.address,"room component binding ended")
            value:K2_SetRelativeLocation(data.location,false,{},true)
            value:K2_SetRelativeRotation(data.rotation,false,{},true)
            value:SetRelativeScale3D(data.scale);value:SetVisibility(data.visible,false);value:SetHiddenInGame(data.hidden,false)
            assert(same(value.RelativeLocation,data.location,XYZ,0.01)and same(value.RelativeRotation,data.rotation,PYR,0.01)and same(value.RelativeScale3D,data.scale,XYZ,0.001),"room component pose readback differs")
            assert(value.bVisible==data.visible and value.bHiddenInGame==data.hidden,"room component visibility readback differs")
        end
        for _,item in ipairs(room.furniture)do
            local actor,state=item.actor,item.state
            assert(current(actor,prepared.pawn)and address(actor)==item.address,"furniture binding ended")
            if not state.present then
                actor:K2_DestroyActor()
                assert(not valid(actor)or actor:IsActorBeingDestroyed(),"removed furniture destruction was not acknowledged")
            else
                actor:K2_SetActorLocationAndRotation(state.location,state.rotation,false,{},true)
                actor:SetActorScale3D(state.scale);actor:SetActorHiddenInGame(state.hidden)
                for _,comp in ipairs(item.components)do
                    local value,data=comp.object,comp.state
                    assert(address(value)==comp.address and address(value:GetOwner())==item.address,"furniture component binding ended")
                    value:K2_SetRelativeLocation(data.location,false,{},true)
                    value:K2_SetRelativeRotation(data.rotation,false,{},true)
                    value:SetRelativeScale3D(data.scale);value:SetVisibility(data.visible,false);value:SetHiddenInGame(data.hidden,false)
                    assert(same(value.RelativeLocation,data.location,XYZ,0.01)and same(value.RelativeRotation,data.rotation,PYR,0.01)and same(value.RelativeScale3D,data.scale,XYZ,0.001),"furniture component pose readback differs")
                    assert(value.bVisible==data.visible and value.bHiddenInGame==data.hidden,"furniture component visibility readback differs")
                end
                assert(same(actor:K2_GetActorLocation(),state.location,XYZ,0.01)and same(actor:K2_GetActorRotation(),state.rotation,PYR,0.01)and same(actor:GetActorScale3D(),state.scale,XYZ,0.001)and actor.bHidden==state.hidden,"furniture actor pose/visibility readback differs")
            end
        end
        walls.apply(room.wall,log)
    end
    log("info","placed room visual readback confirmed rooms="..#prepared.rooms)
end
return M
