local M = {}
local client = require("client")
local map_phase = require("map_phase")
local remaining_input = require("remaining_input")
local interaction_phase = require("interaction_phase")
local intro_visual = require("intro_visual_restore")
local room_visual = require("room_visual_restore")
local wall_visual = require("room_wall_restore")
local placed_rooms = require("placed_room_restore")
local ids = {}
local SHADES = {"SM_Lamp_chandelier_shade_C", "SM_Lamp_chandelier_shade_A", "SM_Lamp_chandelier_shade_D", "SM_Lamp_chandelier_shade_B", "SM_Lamp_chandelier_shade_E"}
local function valid(object) return object and object:IsValid() end
local function vector(value) return {X=value.X, Y=value.Y, Z=value.Z} end
local function address(object) return valid(object) and object:GetAddress() or 0 end
local function same_world(a,b) return address(a:GetWorld()) ~= 0 and address(a:GetWorld()) == address(b:GetWorld()) end

local function capture_map(receipt)
    local pawn, pc, reservation = receipt.pawn, receipt.pc, receipt.reservation
    local map
    for _, candidate in ipairs(FindAllOf("CardMapLayout_BP_C") or {}) do
        if valid(candidate) and not candidate:IsActorBeingDestroyed() and candidate:HasAuthority()
            and same_world(candidate,pawn) and candidate.HasCard and address(candidate.CurrentPlayer)==pawn:GetAddress() then
            assert(not map,"ambiguous current Authority Room Map for retained owner")
            map=candidate
        end
    end
    if not map then return nil end
    assert(type(reservation)=="table" and address(reservation.pawn)==pawn:GetAddress()
        and address(reservation.pc)==pc:GetAddress(),"current authenticated reservation binding differs")
    assert(math.type(reservation.generation)=="integer" and reservation.generation>0,"current reservation generation unavailable for Map snapshot")
    local board
    for _, candidate in ipairs(FindAllOf("GameBoard_BP_C") or {}) do
        if valid(candidate) and not candidate:IsActorBeingDestroyed() and candidate:HasAuthority()
            and same_world(candidate,pawn) and address(candidate.CurrentPlayerTurn)==pawn:GetAddress() then
            local matches=0
            candidate.PlayerOrder:ForEach(function(_,value) if address(value:get())==pawn:GetAddress() then matches=matches+1 end end)
            if matches==1 then assert(not board,"ambiguous current Authority Board for retained owner"); board=candidate end
        end
    end
    assert(board,"current Authority Board roster/turn binding unavailable for Room Map")
    local phase,cause=map_phase.authority({pawn=pawn,board=board,map=map,same_world=same_world,
        world_id=function(actor) return address(actor:GetWorld()) end,
        confirm_owner=function() return receipt.server_confirmed and address(pc.Pawn)==pawn:GetAddress() and address(pawn.Controller)==pc:GetAddress() end,
        current_round=function() return tostring(reservation.generation) end})
    assert(phase,"current Authority Map detection failed: " .. tostring(cause))
    assert(phase.phase=="room_map","current Authority Map phase changed during capture")
    local s=phase.observed
    return {board=client.key(board),map=client.key(map),card=client.key(map.CurrentCard),card_class=map.CurrentCard:GetClass():GetFullName(),
        generation=reservation.generation,turn_index=s.turn_index,location=s.current_card.location,rotation=s.current_card.rotation,
        rotation_basis=s.rotation_basis,rotation_active=phase.rotation_active,card_type=s.current_card.type,card_status=s.current_card.status,
        card_owner=s.current_card.owner==s.pawn and "owner" or "-",card_holding=s.current_card.holding,ports=s.current_card.ports,
        detector=valid(map["As Map Detector BP"]) and client.key(map["As Map Detector BP"]) or "-",
        activity={pawn_halted=pawn.GameHalted,board_halted=board.HaltGame,special_halted=board.SpecialEventHalt,
            graveyard_open=board.GraveyardOpen,in_animation=pawn.InAnimation}}
end

function M.capture(receipt)
    local pc, pawn = receipt.pc, receipt.pawn
    assert(receipt.server_confirmed and valid(pc) and valid(pawn) and pc:GetLocalRole()==3, "confirmed authority transfer required")
    assert(pc.Pawn:GetAddress()==pawn:GetAddress() and pawn.Controller:GetAddress()==pc:GetAddress(), "retained ownership differs before snapshot")
    local rotation = pawn:K2_GetActorRotation()
    local result = {pawn="owner", mode="common", chair=valid(pawn.Chair) and client.key(pawn.Chair) or "-", turn=pawn.IsCurrentTurn,
        cards={}, rotation={Pitch=rotation.Pitch, Yaw=rotation.Yaw, Roll=rotation.Roll}}
    local phase, cause = receipt.phase
    if type(phase) ~= "table" then cause = "phase ledger receipt unavailable"
    elseif phase.blocker then cause = phase.blocker
    elseif phase.phase == "turn_started" and phase.started then result.mode = "active_turn"
    elseif phase.phase == "seated" or phase.phase == "turn_assigned" then result.mode = "seated"
    elseif phase.phase == "standing" then result.mode = "standing"
    else cause = "phase ledger has no stable presentation phase=" .. tostring(phase.phase)
    end
    if type(receipt.card_phase)=="table" and receipt.card_phase.phase=="action_pending" then
        result.mode,cause="common","original card action continues; current subclass presentation not restored"
    end
    if type(receipt.holding_capture)=="function" then
        local holding,holding_cause=receipt.holding_capture()
        if holding then result.mode,result.holding_inspect,cause="holding_inspect",holding,nil
        elseif type(receipt.card_phase)=="table" and receipt.card_phase.phase=="inspect_entry" then
            result.mode,cause="common",holding_cause
        end
    end
    if type(receipt.extended_capture)=="function" then
        local extra,blocker=receipt.extended_capture()
        if extra and extra.phase=="inspect_entry" then result.mode,result.card_inspect,cause="card_inspect",extra,nil
        elseif extra and extra.phase=="action_pending" then result.mode,cause="common",extra.cause
        elseif type(receipt.card_phase)=="table" and receipt.card_phase.phase=="inspect_entry" and receipt.card_phase.status~=1 then
            result.mode,cause="common",blocker
        end
    end
    if type(receipt.intro_capture)=="function" then
        local intro,blocker=receipt.intro_capture()
        if intro then result.mode,result.car_intro,cause="car_intro",intro,nil
        elseif receipt.initial_gameplay_phase then result.mode,cause="common",blocker end
    end
    if (result.mode=="common" or result.mode=="seated" or result.mode=="standing" or result.mode=="active_turn") and type(receipt.interaction_capture)=="function" then
        local current,blocker=receipt.interaction_capture()
        if current then
            result.mode=current.kind=="radio" and "radio_seated" or "world_choice"
            result.interaction_phase=interaction_phase.contract(current)
            cause=nil
        elseif result.mode=="common" then cause=blocker end
    end
    local current_map = capture_map(receipt)
    if current_map then result.mode,result.room_map,cause="room_map",current_map,nil;result.interaction_phase=nil end
    if result.mode=="common" and type(receipt.input_capture)=="function" then
        local intent,blocker=receipt.input_capture()
        if intent then
            result=remaining_input.capture(result,{original_input=intent})
            cause=nil
        else cause=blocker end
    end
    if result.mode == "seated" then
        if type(phase.card_lock) == "boolean" then result.card_lock = phase.card_lock
        else result.mode, cause = "common", phase.card_lock_blocker or "original card lock decision unavailable" end
    end
    pawn.CurrentCards:ForEach(function(index, parameter) result.cards[index]=parameter:get():GetFullName() end)
    local lighting = FindFirstOf("UpdateLighting_BP_C")
    if not valid(lighting) then return result, cause end
    local world = {level_name=lighting.LevelName:ToString(), streams={}, chairs={}}
    result.world = world
    world.intro_visual = intro_visual.capture(pawn, client.key)
    world.room_visual = room_visual.capture(pawn, client.key)
    world.wall_visual = wall_visual.capture(pawn)
    world.placed_rooms = placed_rooms.capture(pawn)
    local names = {}
    pawn:GetWorld().StreamingLevels:ForEach(function(_, parameter)
        local level = parameter:get()
        assert(valid(level), "authority stream unavailable")
        local name = assert(level:GetWorldAssetPackageFName():ToString():match("([^/]+)$"), "authority stream name unavailable")
        assert(not names[name], "ambiguous original stream name="..name)
        names[name] = true
        world.streams[#world.streams+1] = {name=name, loaded=level:IsLevelLoaded(), visible=level:IsLevelVisible()}
    end)
    local lamp = FindFirstOf("DiningRoomLight_BP_C")
    if valid(lamp) then
        local values = {intensity=lamp.PointLight.Intensity, visible=lamp.PointLight:IsVisible(), on=lamp.LightOn, emissives={}}
        world.lamp = values
        for index, name in ipairs(SHADES) do
            local material = lamp[name]:GetMaterial(0)
            assert(valid(material), "authority lamp material missing="..name)
            values.emissives[index]=material:K2_GetScalarParameterValue(FName("LightsEmissive"))
        end
    end
    for _, actor in ipairs(FindAllOf("Cabin_Player_C") or {}) do
        if valid(actor) and valid(actor.RootComponent) and not actor:IsActorBeingDestroyed() and valid(actor.Chair) then
            local chair = actor.Chair
            local row = {chair=client.key(chair), mesh=vector(chair.Chair.RelativeLocation), attach=vector(chair.AttachPlayer.RelativeLocation),
                collision=chair.Chair:GetCollisionEnabled(), holder_visible=chair.PlayerCards:IsVisible(), cards={}}
            actor.CurrentCardsObjects:ForEach(function(index, parameter)
                local card = parameter:get()
                assert(valid(card) and valid(card.RootComponent), "authority physical card unavailable index="..index)
                row.cards[index]={class=card:GetClass():GetFullName(), visible=card.RootComponent:IsVisible()}
            end)
            world.chairs[#world.chairs+1]=row
        end
    end
    return result, cause
end

function M.send(receipt, log)
    local snapshot, cause = M.capture(receipt)
    if cause then log("warn", "client presentation phase incomplete cause=" .. cause .. "; common snapshot only") end
    if snapshot.mode == "active_turn" then
        log("warn", "client presentation restores observed turn phase; ongoing card-action subphase remains unproved")
    end
    local id = M.next_id(receipt.pc)
    M.send_snapshot(receipt.pc, snapshot, {id=id, fingerprint=client.fingerprint(snapshot)}, log)
    return id
end

function M.next_id(pc)
    local key = pc:GetAddress()
    local id = (ids[key] or 0)+1
    assert(math.type(id)=="integer" and id>0, "presentation snapshot ID exhausted")
    ids[key] = id
    return id
end

function M.send_snapshot(pc, snapshot, token, log)
    local id = token.id
    local packets = client.encode(snapshot, id)
    assert(client.fingerprint(snapshot)==token.fingerprint, "snapshot changed after fresh capture")
    log("info", "client presentation send attempted id="..id.." mode="..snapshot.mode.." packets="..#packets)
    for _, packet in ipairs(packets) do pc:ClientMessage("", FName(packet), 0) end
    log("info", "client presentation calls returned id="..id.."; actual client acknowledgement pending")
    return {calls_returned=true, id=id, fingerprint=token.fingerprint}
end

return M
