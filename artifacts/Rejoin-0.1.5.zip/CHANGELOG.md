# Changelog

## 0.1.5 - 2026-10-27

### Fixed

- Avoid treating Alt+F4 as choosing Quit Game.
- Restore changed room walls and furniture and keep seated players in their seats after reconnecting.
- Retry restoration when the first room or card snapshot is not ready.
- Preserve the Halloween update when loading Rejoin.

### Known issues

- The reported remote Steam reconnect black screen and actual Steam host recovery after Alt+F4 remain unconfirmed.

## 0.1.4 - 2026-10-23

### Fixed

- Improve reconnect reliability while the round is still loading.
- Fix inspected cards disappearing after reconnecting.
- Fix card placement after reconnecting.

### Known issues

- The reported black screen when reconnecting to a remote Steam host is not confirmed fixed.

## 0.1.3 - 2026-10-23

- Load installed FastTurns, LobbyPets and ShortEvents in the background host and apply the host settings before joining.
- Restore the Neighbor card's three choices after its dialogue on the background host.
- Fix a crash when leaving a round caused by an expired player controller.
- A reported remote-host Reconnect blackscreen remains unresolved. A complete group round and recovery from a real AMD driver crash remain unmeasured.

## 0.1.2 - 2026-10-13

- Use Rejoin and Mod Settings together without overlapping menu cards.
- Keep Rejoin on the left and Mods on the right.
- Return each card to its front when moving the pointer between them.
- Keep the same manual installation and separate UE4SS requirement.

## 0.1.1 - 2026-10-13

- Use the same manual installation layout as the other Cabin mods.
- Include the finished mod containers directly in the download.
- Require the separate UE4SS download.
- Remove the test installer, BAT, asset recipes and bundled loader from the release archive.
- Keep the previously tested gameplay and mod container bytes unchanged.

## 0.1.0 - 2026-10-13

First release, using the tested V21 mod files.

- Add a manual `Rejoin` card to the left of the main menu, with a `Reconnect` entry on the reverse side.
- Keep the hosted session in a background process when the host's game client closes unexpectedly.
- Reopen the host's main menu after a client crash and let the player choose whether to reconnect.
- Restore the retained player, cards, turn and room state on reconnect.
- Keep the reconnect card visible until the menu is left and restore normal hover behavior for the other cards.
- Correct room restoration for removed furniture and individual heater components, including the cellar.
- End the host's old session when `Quit Game` or a new hosted session is chosen.
- Bundle UE4SS and install into the existing Steam game through one `Installieren.bat`.

Validated locally on Steam build 25553694. A full four-account group test and an actual AMD driver-crash test remain outstanding.
