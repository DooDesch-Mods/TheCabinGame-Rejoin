Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
function New-CabinBootstrapAssets([string]$GameDirectory, [string]$OutputDirectory, [string]$ToolCacheDirectory) {
    $game = [IO.Path]::GetFullPath($GameDirectory).TrimEnd('\', '/')
    $output = Assert-AssetScratch (Join-Path $OutputDirectory 'bootstrap') $game
    Require-Asset (-not [IO.Directory]::Exists($output)) "Bootstrap output must be fresh=$output"
    [IO.Directory]::CreateDirectory($output) | Out-Null
    $receipt = [ordered]@{schema='CabinRejoinLocalBootstrapReceipt_v1';complete=$false;game_writes=0;containers=@()}
    try {
        $retoc = Join-Path $ToolCacheDirectory 'retoc.exe'
        Require-Asset ((Get-AssetHash $retoc) -ceq 'a145f3557ec60b163ed1b78b2f380232d2753fa30350c8013c98e171db3ae7e7') 'Bootstrap retoc hash differs'
        Require-Asset ((Get-AssetHash (Join-Path $ToolCacheDirectory 'oo2core_9_win64.dll')) -ceq '6f5d41a7892ea6b2db420f2458dad2f84a63901c9a93ce9497337b16c195f457') 'Bootstrap Oodle hash differs'
        $recipe = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'AssetRecipe/bootstrap.json')) | ConvertFrom-Json
        Require-Asset ($recipe.contract -ceq 'CabinRejoinLocalBootstrapCopyPatch_v1' -and $recipe.files.Count -eq 3 -and $recipe.source_chunk_id -ceq '5288241ab65e772200000001' -and $recipe.source_container -ceq 'the_cabin_game/Content/Paks/the_cabin_game-Windows.utoc') 'Bootstrap fixed original chunk contract differs'
        $source = Join-Path $output 'original-Cabin_GameMode.uasset'
        Invoke-AssetTool $retoc @('get', (Join-Path $game $recipe.source_container), $recipe.source_chunk_id, $source) $output 'read-original-GameMode'
        $result = @{}
        foreach ($row in $recipe.files) {
            Require-Asset ($row.suffix -cin @('pak','utoc','ucas')) 'Bootstrap suffix outside fixed three'
            $name = 'CabinRejoinBootstrap_P.' + $row.suffix; $target = Join-Path $output ('final/' + $name)
            Apply-AssetPatch $source $row $target
            $result[$name] = $target
            $receipt.containers += @{name=$name;sha256=(Get-AssetHash $target);bytes=([IO.FileInfo]$target).Length}
        }
        Require-Asset ($result.Count -eq 3) 'Duplicate Bootstrap suffix'
        Invoke-AssetTool $retoc @('verify', $result['CabinRejoinBootstrap_P.utoc']) $output 'verify-Bootstrap'
        $receipt.complete = $true
        Write-Host 'confirmed: Drei Bootstrapcontainer lokal aus dem eigenen Spiel erzeugt'
        return $result
    } catch { $receipt.failure = $_.Exception.Message; throw "Bootstrap derivation failed: $($_.Exception.Message); receipt=$output/receipt.json" }
    finally { [IO.File]::WriteAllText((Join-Path $output 'receipt.json'), ($receipt | ConvertTo-Json -Depth 8), [Text.UTF8Encoding]::new($false)) }
}
