Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Require-Asset($Condition, [string]$Cause) { if (-not $Condition) { throw $Cause } }
function Get-AssetHash([string]$Path) {
    $stream = [IO.File]::OpenRead($Path); $hash = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($hash.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
    finally { $hash.Dispose(); $stream.Dispose() }
}
function Assert-AssetScratch([string]$Path, [string]$Game) {
    $full = [IO.Path]::GetFullPath($Path).TrimEnd('\', '/')
    Require-Asset (-not ($full -ieq $Game -or $full.StartsWith($Game + '\', [StringComparison]::OrdinalIgnoreCase))) "Asset scratch is inside game=$full"
    $current = $full
    while ($current) {
        if ([IO.Directory]::Exists($current) -or [IO.File]::Exists($current)) {
            Require-Asset (([IO.File]::GetAttributes($current) -band [IO.FileAttributes]::ReparsePoint) -eq 0) "Asset scratch has reparse point=$current"
        }
        $current = [IO.Path]::GetDirectoryName($current)
    }
    return $full
}
function Apply-AssetPatch([string]$Source, $Row, [string]$Target) {
    Require-Asset ((Get-AssetHash $Source) -ceq $Row.source_sha256) "Asset patch source hash differs=$Source"
    $bytes = [IO.File]::ReadAllBytes($Source); $result = [IO.MemoryStream]::new()
    try {
        foreach ($op in $Row.ops) {
            if ($op[0] -ceq 'copy') {
                Require-Asset ($op.Count -eq 3 -and $op[1] -is [ValueType] -and $op[2] -is [ValueType]) 'Asset COPY operands invalid'
                $offset = [long]$op[1]; $length = [long]$op[2]
                Require-Asset ($offset -eq $op[1] -and $length -eq $op[2] -and $offset -ge 0 -and $length -gt 0 -and $offset + $length -le $bytes.Length) 'Asset COPY outside source'
                $result.Write($bytes, [int]$offset, [int]$length)
            } elseif ($op[0] -ceq 'literal') {
                Require-Asset ($op.Count -eq 2 -and $op[1] -is [string]) 'Asset LITERAL operand invalid'
                $literal = [Convert]::FromBase64String($op[1]); $result.Write($literal, 0, $literal.Length)
            } else { throw "Unknown asset patch operation=$($op[0])" }
            Require-Asset ($result.Length -le 1048576) 'Asset patch output exceeds fixed small asset limit'
        }
        Require-Asset (-not [IO.File]::Exists($Target)) "Asset output already exists=$Target"
        [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($Target)) | Out-Null
        [IO.File]::WriteAllBytes($Target, $result.ToArray())
        Require-Asset ((Get-AssetHash $Target) -ceq $Row.target_sha256) "Asset patch target hash differs=$Target"
    } finally { $result.Dispose() }
}
function Get-AssetDependency([string]$Url, [string]$Target, [string]$Sha) {
    if ([IO.File]::Exists($Target)) {
        Require-Asset ((Get-AssetHash $Target) -ceq $Sha) "Dependency cache hash differs=$Target"
        return
    }
    $part = $Target + '.' + [Guid]::NewGuid().ToString('N') + '.download'
    $response = $null; $inputStream = $null; $outputStream = $null
    try {
        Write-Host "info: Asset dependency download=$Url"
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $request = [Net.HttpWebRequest]::Create($Url)
        $request.Timeout = 45000; $request.ReadWriteTimeout = 45000
        $response = $request.GetResponse(); $inputStream = $response.GetResponseStream()
        $outputStream = [IO.File]::Open($part, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
        $buffer = [byte[]]::new(65536); $total = 0
        while (($read = $inputStream.Read($buffer, 0, $buffer.Length)) -gt 0) {
            $total += $read; Require-Asset ($total -le 10485760) "Dependency download exceeds fixed tool size limit=$Url"
            $outputStream.Write($buffer, 0, $read)
        }
        $outputStream.Dispose(); $outputStream = $null
        Require-Asset ((Get-AssetHash $part) -ceq $Sha) "Dependency download hash differs=$Url"
        [IO.File]::Move($part, $Target)
    } catch { throw "Asset dependency operation=$Url cause=$($_.Exception.Message); partial download retained=$part" }
    finally {
        if ($outputStream) { $outputStream.Dispose() }
        if ($inputStream) { $inputStream.Dispose() }
        if ($response) { $response.Dispose() }
    }
}
function Invoke-AssetTool([string]$Exe, [string[]]$Arguments, [string]$Output, [string]$Label) {
    foreach ($arg in $Arguments) { Require-Asset ($arg -notmatch '["\r\n]' -and -not $arg.EndsWith('\')) "Invalid fixed tool argument=$arg" }
    $start = [Diagnostics.ProcessStartInfo]::new()
    $start.FileName = $Exe; $start.Arguments = (($Arguments | ForEach-Object { '"' + $_ + '"' }) -join ' ')
    $start.UseShellExecute = $false; $start.CreateNoWindow = $true
    $start.RedirectStandardOutput = $true; $start.RedirectStandardError = $true
    $process = [Diagnostics.Process]::new(); $process.StartInfo = $start
    try {
        Require-Asset ($process.Start()) "Asset tool did not start=$Label"
        $stdout = $process.StandardOutput.ReadToEndAsync(); $stderr = $process.StandardError.ReadToEndAsync()
        $timedOut = -not $process.WaitForExit(60000)
        if ($timedOut) { $process.Kill(); $process.WaitForExit() }
        [IO.File]::WriteAllText((Join-Path $Output ($Label + '.stdout.log')), $stdout.Result)
        [IO.File]::WriteAllText((Join-Path $Output ($Label + '.stderr.log')), $stderr.Result)
        Require-Asset (-not $timedOut) "Asset tool timed out=$Label; own tool stopped; stdout/stderr retained"
        Require-Asset ($process.ExitCode -eq 0) "Asset tool operation=$Label exit=$($process.ExitCode) cause=$($stderr.Result)"
    } finally { $process.Dispose() }
}
function New-CabinMenuAssets([string]$GameDirectory, [string]$OutputDirectory, [string]$ToolCacheDirectory) {
    Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1') -ErrorAction Stop
    $game = [IO.Path]::GetFullPath($GameDirectory).TrimEnd('\', '/')
    $output = Assert-AssetScratch $OutputDirectory $game
    $cache = Assert-AssetScratch $ToolCacheDirectory $game
    Require-Asset (-not [IO.Directory]::Exists($output) -and -not [IO.File]::Exists($output)) "Asset output must be fresh=$output"
    [IO.Directory]::CreateDirectory($output) | Out-Null
    $receipt = [ordered]@{schema='CabinRejoinLocalAssetReceipt_v1'; complete=$false; game=$game; game_writes=0; game_copies=0; tool_processes_only=$true; containers=@()}
    try {
        $pins = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'AssetRecipe/game-pins.json')) | ConvertFrom-Json
        foreach ($row in $pins.files) {
            $path = Join-Path $game $row.path
            Require-Asset ([IO.File]::Exists($path) -and (Get-AssetHash $path) -ceq $row.sha256) "Local asset game input differs=$($row.path)"
        }
        [IO.Directory]::CreateDirectory($cache) | Out-Null
        $contract = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'AssetRecipe/tools.json')) | ConvertFrom-Json
        $zip = Join-Path $cache 'retoc-0.1.5.zip'
        Get-AssetDependency $contract.retoc_zip.url $zip $contract.retoc_zip.sha256
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $archive = [IO.Compression.ZipFile]::OpenRead($zip)
        try {
            foreach ($name in @('retoc.exe', 'LICENSE', 'README.md')) {
                $entry = @($archive.Entries | Where-Object { $_.FullName -ceq $name })
                Require-Asset ($entry.Count -eq 1) "Retoc archive entry missing/ambiguous=$name"
                $dest = Join-Path $cache $name
                if (-not [IO.File]::Exists($dest)) { [IO.Compression.ZipFileExtensions]::ExtractToFile($entry[0], $dest, $false) }
            }
        } finally { $archive.Dispose() }
        $retoc = Join-Path $cache 'retoc.exe'
        Require-Asset ((Get-AssetHash $retoc) -ceq $contract.retoc_exe_sha256) 'Retoc executable hash differs'
        Get-AssetDependency $contract.oodle.url (Join-Path $cache 'oo2core_9_win64.dll') $contract.oodle.sha256
        $receipt.tool_contract = $contract
        $names = @('MenuCard_PBP', 'MenuCard_Play', 'MenuCardPlay_WBP', 'M_RT_MenuCardPlay', 'RT_MenuCardPlay')
        $arguments = @('to-legacy', (Join-Path $game 'the_cabin_game/Content/Paks'), (Join-Path $output 'local'), '--no-shaders', '--no-script-objects', '--version', 'UE5_5')
        foreach ($name in $names) { $arguments += @('-f', ('MenuContent/3DMenuCards/' + $name + '.uasset')) }
        Invoke-AssetTool $retoc $arguments $output 'extract-five'
        $recipe = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'AssetRecipe/legacy.json')) | ConvertFrom-Json
        Require-Asset ($recipe.contract -ceq 'CabinRejoinLocalAssetsCopyPatch_v1' -and $recipe.files.Count -eq 10) 'Legacy recipe contract differs'
        $extracted = @([IO.Directory]::GetFiles((Join-Path $output 'local'), '*', [IO.SearchOption]::AllDirectories))
        Require-Asset ($extracted.Count -eq 10) "Five-asset extraction count measured=$($extracted.Count) required=10"
        foreach ($row in $recipe.files) {
            Require-Asset ($row.source -match '^the_cabin_game/Content/MenuContent/3DMenuCards/(MenuCard_PBP|MenuCard_Play|MenuCardPlay_WBP|M_RT_MenuCardPlay|RT_MenuCardPlay)\.(uasset|uexp)$' -and $row.target -match '^the_cabin_game/Content/CabinRejoin/Menu/(MenuCard_Rejoin_Base|MenuCard_Rejoin|MenuCardRejoin_WBP|M_RT_MenuCardRejoin|RT_MenuCardRejoin)\.(uasset|uexp)$') 'Legacy recipe path outside fixed five assets'
            Apply-AssetPatch (Join-Path (Join-Path $output 'local') $row.source) $row (Join-Path (Join-Path $output 'legacy') $row.target)
        }
        [IO.Directory]::CreateDirectory((Join-Path $output 'serial')) | Out-Null
        Invoke-AssetTool $retoc @('to-zen', (Join-Path $output 'legacy'), (Join-Path $output 'serial/CabinRejoinMenuV4_P.utoc'), '--version', 'UE5_5', '--no-parallel') $output 'serial-pack'
        $layout = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'AssetRecipe/layout.json')) | ConvertFrom-Json
        Require-Asset ($layout.contract -ceq 'CabinRejoinSerialContainerPatch_v1' -and $layout.files.Count -eq 3) 'Container recipe contract differs'
        $result = @{}
        foreach ($row in $layout.files) {
            Require-Asset ($row.suffix -cin @('pak', 'ucas', 'utoc')) 'Container suffix outside fixed three'
            $name = 'CabinRejoinMenuV4_P.' + $row.suffix; $target = Join-Path $output ('final/' + $name)
            Apply-AssetPatch (Join-Path $output ('serial/' + $name)) $row $target
            $result[$name] = $target
            $receipt.containers += @{name=$name; sha256=(Get-AssetHash $target); bytes=([IO.FileInfo]$target).Length}
        }
        Require-Asset ($result.Count -eq 3) 'Duplicate container recipe suffix'
        Invoke-AssetTool $retoc @('verify', $result['CabinRejoinMenuV4_P.utoc']) $output 'verify-final'
        $receipt.complete = $true
        Write-Host 'confirmed: Drei Menücontainer lokal aus dem eigenen Spiel erzeugt'
        return $result
    } catch { $receipt.failure = $_.Exception.Message; throw "Local menu asset derivation failed: $($_.Exception.Message); receipt=$output/receipt.json" }
    finally { [IO.File]::WriteAllText((Join-Path $output 'receipt.json'), ($receipt | ConvertTo-Json -Depth 12), [Text.UTF8Encoding]::new($false)) }
}
