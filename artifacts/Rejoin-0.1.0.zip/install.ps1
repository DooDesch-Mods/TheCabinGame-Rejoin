﻿param([string]$GameDirectory = $env:CABIN_REJOIN_INSTALL_GAME_DIRECTORY, [switch]$Check)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Require-InstallValue($Condition, [string]$Cause) {
    if (-not $Condition) { throw $Cause }
}

function Get-InstallHash([string]$Path) {
    $stream = [IO.File]::OpenRead($Path)
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($algorithm.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
    finally { $algorithm.Dispose(); $stream.Dispose() }
}

function Assert-InstallPlainPath([string]$GameRoot, [string]$Target) {
    $current = $Target
    while ($current -ine $GameRoot) {
        if ([IO.File]::Exists($current) -or [IO.Directory]::Exists($current)) {
            $attributes = [IO.File]::GetAttributes($current)
            Require-InstallValue (($attributes -band [IO.FileAttributes]::ReparsePoint) -eq 0) "Installationskonflikt: Schreibziel enthält eine Verknüpfung=$current"
        }
        $current = Split-Path -Parent $current
        Require-InstallValue ($current) "Installationsziel liegt außerhalb des Spielordners=$Target"
    }
}

function Find-SteamGame {
    $libraries = [Collections.Generic.List[string]]::new()
    foreach ($registryPath in @('HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam')) {
        if (-not (Test-Path -LiteralPath $registryPath)) { continue }
        $properties = Get-ItemProperty -LiteralPath $registryPath -ErrorAction Stop
        foreach ($name in @('SteamPath', 'InstallPath')) {
            $property = $properties.PSObject.Properties[$name]
            if ($property -and $property.Value) { $libraries.Add([string]$property.Value) }
        }
    }
    foreach ($steamRoot in @($libraries.ToArray())) {
        $vdf = Join-Path $steamRoot 'steamapps/libraryfolders.vdf'
        if (-not [IO.File]::Exists($vdf)) { continue }
        $text = [IO.File]::ReadAllText($vdf)
        foreach ($match in [regex]::Matches($text, '"path"\s+"([^"\r\n]+)"')) {
            $libraries.Add($match.Groups[1].Value.Replace('\\', '\'))
        }
    }
    $games = @($libraries.ToArray() | ForEach-Object {
        $candidate = [IO.Path]::GetFullPath((Join-Path $_ 'steamapps/common/the cabin game'))
        if ([IO.File]::Exists((Join-Path $candidate 'the_cabin_game/Binaries/Win64/the_cabin_game-Win64-Shipping.exe'))) { $candidate }
    } | Sort-Object -Unique)
    Require-InstallValue ($games.Count -eq 1) "Steaminstallation nicht eindeutig: gefunden=$($games.Count), erforderlich=1"
    return $games[0]
}

try {
    Import-Module -Name (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Utility/Microsoft.PowerShell.Utility.psd1') -ErrorAction Stop
    $manifestPath = Join-Path $PSScriptRoot 'manifest.json'
    $manifest = [IO.File]::ReadAllText($manifestPath) | ConvertFrom-Json
    Require-InstallValue ($manifest.schema -ceq 'CabinRejoinSteamInstall_v1') 'Installationsmanifest hat ein anderes Format'
    foreach ($row in $manifest.files) {
        Require-InstallValue ($row.path -notmatch '(^|/)\.\.(/|$)|^[\/]|:') "Ungültiger Paketpfad=$($row.path)"
        $source = Join-Path $PSScriptRoot $row.path
        Require-InstallValue ([IO.File]::Exists($source) -and (Get-InstallHash $source) -ceq $row.sha256) "Paketdatei fehlt oder Hash weicht ab=$($row.path)"
    }
    if (-not $GameDirectory) { $GameDirectory = Find-SteamGame }
    Require-InstallValue ([IO.Path]::IsPathRooted($GameDirectory)) 'Steam-Spielpfad muss absolut sein'
    $game = [IO.Path]::GetFullPath($GameDirectory).TrimEnd('\', '/')
    $shippingRelative = 'the_cabin_game/Binaries/Win64/the_cabin_game-Win64-Shipping.exe'
    $exe = Join-Path $game $shippingRelative
    Require-InstallValue ([IO.File]::Exists($exe) -and (Get-InstallHash $exe) -ceq $manifest.game_sha256) "Nicht unterstützter Spielbuild=$exe"
    foreach ($guard in $manifest.original_utoc) {
        $index = Join-Path $game $guard.path
        Require-InstallValue ([IO.File]::Exists($index) -and (Get-InstallHash $index) -ceq $guard.sha256) "Spielpaketindex weicht ab=$($guard.path)"
    }
    $binary = Split-Path -Parent $exe
    $runtime = Join-Path $binary 'ue4ss'
    foreach ($legacyDirectory in @('the_cabin_game/Content/Paks', 'the_cabin_game/Content/Paks/Mods/CabinRejoinMenu')) {
        foreach ($legacyName in @('CabinRejoinMenu_P.pak', 'CabinRejoinMenu_P.utoc', 'CabinRejoinMenu_P.ucas', 'CabinRejoinMenuV3_P.pak', 'CabinRejoinMenuV3_P.utoc', 'CabinRejoinMenuV3_P.ucas')) {
            $legacyPath = Join-Path $game ($legacyDirectory + '/' + $legacyName)
            Require-InstallValue (-not [IO.File]::Exists($legacyPath)) "Installationskonflikt: alter Menücontainer vorhanden=$legacyPath; keine Datei geändert"
        }
    }
    $plan = [Collections.Generic.List[object]]::new()
    foreach ($row in $manifest.install_files) {
        Require-InstallValue ($row.target -notmatch '(^|/)\.\.(/|$)|^[\/]|:') "Ungültiges Installationsziel=$($row.target)"
        $target = [IO.Path]::GetFullPath((Join-Path $game $row.target))
        Require-InstallValue ($target.StartsWith($game + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) "Installationsziel liegt außerhalb des Spielordners=$target"
        $previous = if ([IO.File]::Exists($target)) { Get-InstallHash $target } else { $null }
        if ($previous -ceq $row.sha256) { continue }
        Assert-InstallPlainPath $game $target
        $emptyLoader = $row.target -ceq 'the_cabin_game/Binaries/Win64/dwmapi.dll' -and $previous -ceq 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
        $ownedMod = $row.target -match '^the_cabin_game/Binaries/Win64/ue4ss/Mods/(CabinNativeProbe|CabinRejoin)/'
        $knownPrevious = @($manifest.upgrade_from | Where-Object { $_.target -ceq $row.target -and $_.sha256 -ceq $previous })
        $ownedUpgrade = $ownedMod -and $null -ne $previous -and $knownPrevious.Count -eq 1
        Require-InstallValue ($null -eq $previous -or $emptyLoader -or $ownedUpgrade) "Installationskonflikt: vorhandene Datei ist kein unverändertes r6-Modpayload=$target; keine Datei geändert"
        $plan.Add([pscustomobject]@{target=$target; relative=$row.target; source=(Join-Path $PSScriptRoot $row.source); hash=$row.sha256; previous_hash=$previous; bytes=$null})
    }
    $modsPath = Join-Path $runtime 'Mods/mods.txt'
    $oldMods = if ([IO.File]::Exists($modsPath)) { [IO.File]::ReadAllText($modsPath, [Text.Encoding]::UTF8) } else { '' }
    foreach ($name in @('CabinNativeProbe', 'CabinRejoin')) {
        $expression = '(?m)^([ \t]*' + [regex]::Escape($name) + '[ \t]*:[ \t]*)([01])([ \t]*(?:;[^\r\n]*)?\r?)$'
        $matchesForMod = [regex]::Matches($oldMods, $expression)
        Require-InstallValue ($matchesForMod.Count -le 1) "Installationskonflikt: Mod mehrfach in mods.txt=$name"
        $allEntries = [regex]::Matches($oldMods, "(?m)^[ `t]*" + [regex]::Escape($name) + "[ `t]*:")
        Require-InstallValue ($allEntries.Count -eq $matchesForMod.Count) "Installationskonflikt: ungültiger Modstatus in mods.txt=$name"
        Require-InstallValue ($matchesForMod.Count -eq 0 -or $matchesForMod[0].Groups[2].Value -ceq '1') "Installationskonflikt: Mod in mods.txt ausdrücklich deaktiviert=$name; Modliste bleibt unverändert"
    }
    Write-Host "info: Steaminstallation=$game; geplante Moddateien=$($plan.Count); keine Spielkopie"
    if ($Check) { Write-Host 'confirmed: Paket, Spielbuild und Installationsziele geprüft; keine Datei geändert'; exit 0 }
    if ($plan.Count -eq 0) { Write-Host 'confirmed: UE4SS und CabinRejoin sind bereits installiert'; exit 0 }
    $runningCount = 0
    foreach ($process in [Diagnostics.Process]::GetProcessesByName('the_cabin_game-Win64-Shipping')) {
        try {
            $processPath = $process.MainModule.FileName
            Require-InstallValue ($processPath) "Spielprozess nicht prüfbar: PID=$($process.Id)"
            if ([IO.Path]::GetFullPath($processPath) -ieq $exe) { $runningCount++ }
        } finally { $process.Dispose() }
    }
    Require-InstallValue ($runningCount -eq 0) "Installation blockiert: Spiel läuft aus dem Zielordner, Prozesse=$runningCount"
    . (Join-Path $PSScriptRoot 'derive-assets.ps1')
    $assetScratch = Join-Path ([IO.Path]::GetTempPath()) ('CabinRejoin-local-assets/' + [Guid]::NewGuid().ToString('N'))
    $assetCache = Join-Path ([IO.Path]::GetTempPath()) 'CabinRejoin-asset-tools-0.1.5'
    $localAssets = New-CabinMenuAssets $game $assetScratch $assetCache
    . (Join-Path $PSScriptRoot 'derive-bootstrap.ps1')
    $bootstrapAssets = New-CabinBootstrapAssets $game $assetScratch $assetCache
    foreach ($key in $bootstrapAssets.Keys) { $localAssets[$key] = $bootstrapAssets[$key] }
    foreach ($item in $plan) {
        $name = [IO.Path]::GetFileName($item.source)
        if ($localAssets.ContainsKey($name)) {
            $item.source = $localAssets[$name]
            Require-InstallValue ((Get-InstallHash $item.source) -ceq $item.hash) "Locally generated package hash differs=$name"
        }
    }
    $operation = [Guid]::NewGuid().ToString('N')
    $backup = Join-Path $binary ('CabinRejoin-install-backups/' + $operation)
    [IO.Directory]::CreateDirectory($backup) | Out-Null
    $receipt = [ordered]@{schema='CabinRejoinSteamInstallReceipt_v1'; game=$game; manifest_sha256=(Get-InstallHash $manifestPath); phase='attempted'; files=@(); game_copies=0; process_starts=0; process_stops=0}
    $receiptPath = Join-Path $backup 'receipt.json'
    foreach ($item in $plan) {
        $actualPrevious = if ([IO.File]::Exists($item.target)) { Get-InstallHash $item.target } else { $null }
        Require-InstallValue ($actualPrevious -ceq $item.previous_hash) "Installationsziel seit Prüfung verändert=$($item.target)"
        if ($null -ne $item.previous_hash) {
            $saved = Join-Path $backup $item.relative
            [IO.Directory]::CreateDirectory((Split-Path -Parent $saved)) | Out-Null
            [IO.File]::Copy($item.target, $saved, $false)
            Require-InstallValue ((Get-InstallHash $saved) -ceq $item.previous_hash) "Sicherungsreadback weicht ab=$saved"
        }
        $receipt.files += [ordered]@{target=$item.target; previous_hash=$item.previous_hash; sha256=$item.hash; phase='planned'}
    }
    [IO.File]::WriteAllText($receiptPath, ($receipt | ConvertTo-Json -Depth 6), [Text.UTF8Encoding]::new($false))
    for ($index = 0; $index -lt $plan.Count; $index++) {
        $item = $plan[$index]
        $actualPrevious = if ([IO.File]::Exists($item.target)) { Get-InstallHash $item.target } else { $null }
        Require-InstallValue ($actualPrevious -ceq $item.previous_hash) "Installationsziel vor Schreibzugriff verändert=$($item.target)"
        Assert-InstallPlainPath $game $item.target
        [IO.Directory]::CreateDirectory((Split-Path -Parent $item.target)) | Out-Null
        $temporary = $item.target + '.' + $operation + '.tmp'
        if ($null -ne $item.source) { [IO.File]::Copy($item.source, $temporary, $false) }
        else { [IO.File]::WriteAllBytes($temporary, $item.bytes) }
        Require-InstallValue ((Get-InstallHash $temporary) -ceq $item.hash) "Kopierreadback weicht ab=$temporary"
        if ([IO.File]::Exists($item.target)) { [IO.File]::Replace($temporary, $item.target, (Join-Path $backup ('replaced-' + $index + '.previous'))) }
        else { [IO.File]::Move($temporary, $item.target) }
        Require-InstallValue ((Get-InstallHash $item.target) -ceq $item.hash) "Installationsreadback weicht ab=$($item.target)"
        $receipt.files[$index].phase = 'confirmed'
        [IO.File]::WriteAllText($receiptPath, ($receipt | ConvertTo-Json -Depth 6), [Text.UTF8Encoding]::new($false))
    }
    $receipt.phase = 'confirmed'
    [IO.File]::WriteAllText($receiptPath, ($receipt | ConvertTo-Json -Depth 6), [Text.UTF8Encoding]::new($false))
    Write-Host "confirmed: UE4SS und CabinRejoin installiert; Dateireadbacks=$($plan.Count); Sicherung=$backup"
    exit 0
} catch {
    [Console]::Error.WriteLine('error: Installation fehlgeschlagen: ' + $_.Exception.Message + '; vorhandene Sicherungen und Teilinstallation bleiben erhalten')
    exit 1
}
