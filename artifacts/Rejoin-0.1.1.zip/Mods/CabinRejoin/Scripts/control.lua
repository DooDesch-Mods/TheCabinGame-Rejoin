local M = {}
local runtime = require("control_runtime")
local codec = require("control_codec")
local client = require("client")
local refs = require("bound_refs")
local function hand_key(card,index) return refs.member_key("hand",index,card) end
local presentation = require("presentation")
local server = require("server")
local receiver, sender
local host_options, rpc_hook
local generations = {}
local HEADER = "__CABIN_CTRL_META1__"
local HAND_HEADER = "__CABIN_HAND_META1__"

local function clock(pc)
    local library = StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")
    assert(library and library:IsValid(), "original control clock unavailable")
    return library:GetGameTimeInSeconds(pc)
end

function M.start_client(log)
    assert(not receiver, "client control already started")
    local current_pc
    receiver = runtime.start_client({codec=codec, log=log, hand_key=hand_key, refresh_interval=2, log_interval=60,
        now=function() return clock(assert(current_pc, "current client clock controller missing")) end,
        current_client=function(pc)
            current_pc=pc
            return {pc_address=pc:GetAddress(), generation=generations[pc:GetAddress()]}
        end,
        send_control=function(pc,wire) pc:ServerExecRPC(wire); return true end,
        confirm_local=function(receipt) return client.confirm_receipt(receipt) end,
        fingerprint_source=function(source) return client.fingerprint(client.decode(source)) end,
    })
    RegisterHook("/Script/Engine.PlayerController:ClientMessage", function(context,message,kind)
        local wire=kind:get():ToString()
        local hand=wire:sub(1,#HAND_HEADER+1)==HAND_HEADER.."|"
        if not hand and wire:sub(1,#HEADER+1)~=HEADER.."|" then return end
        if hand then wire=HEADER..wire:sub(#HAND_HEADER+1) end
        local ok,cause=pcall(function()
            local pc=context:get()
            assert(pc:IsValid() and pc:IsLocalController() and pc:GetLocalRole()==2 and not pc:IsActorBeingDestroyed(), "metadata target is not current owning client")
            local metadata,why=runtime.decode_header(codec,wire)
            assert(metadata,why)
            local key=pc:GetAddress()
            local old=generations[key]
            assert(not old or metadata.generation>=old, "server metadata generation moved backwards")
            generations[key]=metadata.generation
            local accepted,error=receiver.receive_header(pc,message:get():ToString(),wire,hand)
            assert(accepted,error)
        end)
        if not ok then log("error", "control metadata receive cause="..tostring(cause)) end
    end)
    return {
        on_tick=function()
            if current_pc then local value,cause=receiver.report_hand(current_pc);assert(value,cause) end
        end,
        bind_snapshot=function(pc,id,source)
            local result,cause=receiver.bind_snapshot(pc,id,source); assert(result,cause); return result
        end,
        token_for_job=function(pc,id)
            local token,cause=receiver.token_for_job(pc,id); assert(token,cause); return token
        end,
        on_ack=function(receipt)
            local result,cause=receiver.on_ack(receipt); assert(result,cause)
        end,
        on_wait=function(pc,cause)
            local result,why=receiver.on_wait(pc,cause); assert(result,why)
        end,
    }
end

local function listen_server(log)
    if rpc_hook then return end
    local pre,post=RegisterHook("/Script/Engine.PlayerController:ServerExecRPC",function(context,message)
        local ok,cause=pcall(function()
            local wire=message:get():ToString()
            if not codec.marked(wire) then return end
            local packet,why=codec.decode(wire);assert(packet,why)
            local result
            if packet.kind=="options4" then
                assert(host_options,"current Lobby host receiver unavailable")
                result=host_options.dispatch(context:get(),wire)
            else
                assert(sender,"current Round control receiver unavailable")
                result=sender.dispatch(context:get(),wire)
            end
            assert(type(result)=="table","control dispatch returned no receipt")
            if result.status=="failed" or result.status=="rejected" then log("error","control RPC status="..result.status.." cause="..tostring(result.cause)) end
        end)
        if not ok then log("error","control RPC dispatch cause="..tostring(cause)) end
    end)
    assert(type(pre)=="number" and type(post)=="number","original ServerExecRPC hook registration unacknowledged")
    rpc_hook={pre,post}
end

function M.register_host_options(api,log)
    assert(not host_options and type(api)=="table" and type(api.dispatch)=="function","one Lobby host receiver required")
    host_options=api
    listen_server(log)
    log("info","Lobby O receiver registered; actual OwnerGrant handshake pending")
end

function M.start_server(log)
    assert(not sender, "server control already started")
    local current_pc
    sender=runtime.start_server({codec=codec, dispatcher=require("control_dispatcher"), log=log,
        refresh_interval=2, log_interval=60, hand_key=hand_key,
        hand_intent_at=server.hand_intent_at,
        now=function() return clock(assert(current_pc, "current server clock controller missing")) end,
        authenticate=function(pc) current_pc=pc; return CabinAuthenticatedSteamID(pc:GetAddress()) end,
        current_peer=server.control_peer,
        capture=function(peer)
            local snapshot,cause=presentation.capture(server.presentation_receipt(peer.pc))
            if cause then log("warn", "fresh presentation phase incomplete cause="..cause) end
            return {snapshot=snapshot, fingerprint=client.fingerprint(snapshot)}
        end,
        next_id=presentation.next_id,
        send_header=function(pc,wire) pc:ClientMessage("",FName(wire),0); return true end,
        send_snapshot=function(pc,snapshot,token) return presentation.send_snapshot(pc,snapshot,token,log) end,
    })
    listen_server(log)
    return {
        on_effective_hand=function(pc)
            local value,cause=sender.observe_hand(pc);assert(value,cause)
        end,
        on_rejoined=function(receipt)
            receipt.reservation.control_issued=true
            local result,cause=sender.issue(receipt.pc); assert(result,cause)
        end,
        on_pending=function(pc)
            local result,cause=sender.poll(pc); assert(result,cause)
        end,
        on_disconnected=function(address,cause) sender.invalidate(address,cause) end,
    }
end

return M
